# Cấu hình Telegram Bot để nhận thông báo Ticket mới

## Bước 1: Tạo Telegram Bot

1. Mở Telegram và tìm `@BotFather`
2. Gửi lệnh `/newbot`
3. Đặt tên cho bot (ví dụ: "Support Ticket Bot")
4. Đặt username cho bot (phải kết thúc bằng `bot`, ví dụ: `my_support_ticket_bot`)
5. Lưu lại `BOT_TOKEN` mà BotFather cung cấp

## Bước 2: Lấy Chat ID

### Cách 1: Sử dụng bot @userinfobot
1. Tìm `@userinfobot` trên Telegram
2. Gửi tin nhắn `/start`
3. Bot sẽ trả về thông tin của bạn, bao gồm `Chat ID`

### Cách 2: Sử dụng API Telegram
1. Gửi tin nhắn cho bot bạn vừa tạo
2. Truy cập: `https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates`
3. Tìm `"chat":{"id":XXXXXXX}` trong response
4. Số `XXXXXXX` là Chat ID của bạn

## Bước 3: Cấu hình trong .env

Thêm các biến môi trường sau vào file `.env.local`:

```env
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789
TELEGRAM_CHAT_ID=123456789

# App URL (để tạo link trong thông báo)
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Bước 4: Kiểm tra

1. Restart ứng dụng Next.js
2. Tạo một ticket mới
3. Kiểm tra Telegram để xem có nhận được thông báo không

## Định dạng thông báo

Khi có ticket mới, bạn sẽ nhận được thông báo với format:

```
🎫 TICKET MỚI

📋 Tiêu đề: [Tiêu đề ticket]
👤 Người tạo: [Username]
🏷️ Chủ đề: [Chủ đề]
🆔 Ticket ID: #[ID]

📝 Nội dung:
[Nội dung ticket]

🔗 Link xử lý: [Link đến admin panel]

⏰ Thời gian: [Thời gian tạo]
```

## Lưu ý

- Nếu không cấu hình Telegram, hệ thống vẫn hoạt động bình thường
- Chỉ có thông báo trong console log rằng Telegram chưa được cấu hình
- Bot chỉ gửi thông báo cho 1 chat/group được chỉ định
- Để gửi cho nhiều người, bạn có thể tạo group và thêm bot vào group đó

