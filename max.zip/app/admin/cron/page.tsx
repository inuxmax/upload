'use client'

import React, { useState, useEffect } from 'react'
import { Play, Square, Clock, Activity, CheckCircle, XCircle, RotateCcw } from 'lucide-react'

interface CronStatus {
  isRunning: boolean;
  lastRun?: string;
  nextRun?: string;
  totalRuns: number;
  successCount: number;
  errorCount: number;
}

export default function CronManagementPage() {
  const [status, setStatus] = useState<CronStatus>({
    isRunning: false,
    totalRuns: 0,
    successCount: 0,
    errorCount: 0
  });
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  // Tự động cập nhật trạng thái mỗi 10 giây
  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const response = await fetch('/api/cron');
        if (response.ok) {
          const data = await response.json();
          if (data.status) {
            setStatus(data.status);
          }
        }
      } catch (error) {
        console.error('Error fetching cron status:', error);
      }
    };

    // Cập nhật ngay lập tức
    fetchStatus();

    // Cập nhật mỗi 10 giây
    const interval = setInterval(fetchStatus, 10000);
    return () => clearInterval(interval);
  }, []);

  const startCron = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/cron', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'start' })
      });

      const data = await response.json();
      
      if (response.ok) {
        addLog(`✅ Cron jobs started: ${data.message}`);
        // Trạng thái sẽ được cập nhật tự động qua useEffect
      } else {
        addLog(`❌ Failed to start cron: ${data.error}`);
      }
    } catch (error) {
      addLog(`❌ Error starting cron: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const stopCron = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/cron', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'stop' })
      });

      const data = await response.json();
      
      if (response.ok) {
        addLog(`🛑 Cron jobs stopped: ${data.message}`);
        // Trạng thái sẽ được cập nhật tự động qua useEffect
      } else {
        addLog(`❌ Failed to stop cron: ${data.error}`);
      }
    } catch (error) {
      addLog(`❌ Error stopping cron: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const resetStats = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/cron', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'reset' })
      });

      const data = await response.json();
      
      if (response.ok) {
        addLog(`📊 Stats reset: ${data.message}`);
        // Trạng thái sẽ được cập nhật tự động qua useEffect
      } else {
        addLog(`❌ Failed to reset stats: ${data.error}`);
      }
    } catch (error) {
      addLog(`❌ Error resetting stats: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleString('vi-VN');
    setLogs(prev => [`[${timestamp}] ${message}`, ...prev.slice(0, 49)]);
  };

  const testACB = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/acb-payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
      });

      const data = await response.json();
      
      if (response.ok) {
        addLog(`✅ ACB test successful: ${data.processed} transactions processed`);
      } else {
        addLog(`❌ ACB test failed: ${data.error}`);
      }
    } catch (error) {
      addLog(`❌ ACB test error: ${error}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Cron Jobs Management</h1>
          <p className="text-gray-600">Quản lý tự động kiểm tra giao dịch ACB</p>
        </div>

        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className={`p-3 rounded-lg ${status.isRunning ? 'bg-green-100' : 'bg-red-100'}`}>
                <Activity className={`w-6 h-6 ${status.isRunning ? 'text-green-600' : 'text-red-600'}`} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Trạng thái</p>
                <p className={`text-lg font-bold ${status.isRunning ? 'text-green-600' : 'text-red-600'}`}>
                  {status.isRunning ? 'Đang chạy' : 'Đã dừng'}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Clock className="w-6 h-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Tổng lần chạy</p>
                <p className="text-lg font-bold text-gray-900">{status.totalRuns}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Thành công</p>
                <p className="text-lg font-bold text-green-600">{status.successCount}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="p-3 bg-red-100 rounded-lg">
                <XCircle className="w-6 h-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Lỗi</p>
                <p className="text-lg font-bold text-red-600">{status.errorCount}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Control Buttons */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Điều khiển</h2>
          
          <div className="flex flex-wrap gap-4">
            <button
              onClick={startCron}
              disabled={loading || status.isRunning}
              className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Play className="w-5 h-5" />
              <span>Bắt đầu Cron</span>
            </button>

            <button
              onClick={stopCron}
              disabled={loading || !status.isRunning}
              className="flex items-center space-x-2 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Square className="w-5 h-5" />
              <span>Dừng Cron</span>
            </button>

            <button
              onClick={resetStats}
              disabled={loading}
              className="flex items-center space-x-2 px-6 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <RotateCcw className="w-5 h-5" />
              <span>Reset Stats</span>
            </button>

            <button
              onClick={testACB}
              disabled={loading}
              className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Activity className="w-5 h-5" />
              <span>Test ACB API</span>
            </button>
          </div>

          <div className="mt-4 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Thông tin Cron:</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Lịch trình: Mỗi 30 giây</li>
              <li>• Múi giờ: Asia/Ho_Chi_Minh</li>
              <li>• API endpoint: /api/acb-payment</li>
              <li>• Tự động xử lý giao dịch IN</li>
              <li>• Auto-start: Bật (tự động chạy khi server khởi động)</li>
            </ul>
          </div>
        </div>

        {/* Logs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Logs</h2>
          
          <div className="bg-gray-900 text-green-400 p-4 rounded-lg h-96 overflow-y-auto font-mono text-sm">
            {logs.length === 0 ? (
              <p className="text-gray-500">Chưa có logs...</p>
            ) : (
              logs.map((log, index) => (
                <div key={index} className="mb-1">
                  {log}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
} 