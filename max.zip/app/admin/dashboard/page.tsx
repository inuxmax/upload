'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { 
  Users, Database, Settings, Globe, BarChart3, Shield, LogOut, 
  UserCheck, UserX, Activity, TrendingUp, TrendingDown, FileText, Search,
  Plus, Edit, Trash, Trash2, Eye, ChevronDown, Home, Menu, X,
  CreditCard, Building, User, Zap, Crown, CheckCircle, Clock, RefreshCw,
  XCircle, MessageSquare
} from 'lucide-react'

interface Admin {
  id: string
  username: string
  email: string
  role: string
  permissions: string[]
}

interface DashboardStats {
  totalUsers: number
  totalAccounts: number
  activeUsers: number
  activeAccounts: number
}

interface User {
  _id: string
  username: string
  email: string
  password: string
  fullName: string
  role: string
  status: 'active' | 'inactive'
  balance: number
  isActive: boolean
  isAdmin: boolean
  createdAt: string
  lastLogin?: string
}

interface PaymentInfo {
  _id?: string;
  bankName: string;
  accountNumber: string;
  accountHolder: string;
  transferContent: string;
  passwordACB: string;
  tokenACB: string;
  isActive: boolean;
}

interface AdminSettings {
  globalMaxThreads: number;
  systemStatus: 'active' | 'maintenance' | 'offline';
  maintenanceMessage: string;
  allowUserThreadSettings: boolean;
  defaultUserThreads: number;
}

interface WelcomePopupSettings {
  enabled: boolean;
  title: string;
  message: string;
  showDontShowAgain: boolean;
  showOnLogin: boolean;
  showOnDashboard: boolean;
}

interface SubscriptionPlan {
  _id: string;
  plan: string;
  name: string;
  price: number;
  duration: number;
  maxThreads: number;
  features: string[];
  isActive: boolean;
  currency?: string;
  description?: string;
}

interface ProxySettings {
  _id?: string;
  id?: string;
  name: string;
  apiKey: string;
  isActive: boolean;
  currentProxy?: string;
  refreshAt?: Date;
  nextChange?: number;
  acceptIp?: string;
  isResidential?: boolean;
  maxUsers?: number;
  currentUsers?: number;
  createdAt: Date;
  updatedAt: Date;
}

export default function AdminDashboard() {
  const router = useRouter()
  const [admin, setAdmin] = useState<Admin | null>(null)
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalAccounts: 0,
    activeUsers: 0,
    activeAccounts: 0
  })
  const [activeTab, setActiveTab] = useState('overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [users, setUsers] = useState<User[]>([])
  const [usersLoading, setUsersLoading] = useState(false)
  const [userSearchTerm, setUserSearchTerm] = useState('')
  const [userStatusFilter, setUserStatusFilter] = useState('')
  const [showPasswords, setShowPasswords] = useState<{[key: string]: boolean}>({})
  const [userPagination, setUserPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalUsers: 0,
    hasNext: false,
    hasPrev: false
  })
  const [showAllUsers, setShowAllUsers] = useState(false)
  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo>({
    bankName: 'ACB Bank',
    accountNumber: '123456789',
    accountHolder: 'CÔNG TY ABC',
    transferContent: 'MAXABC123DEF456',
    passwordACB: '',
    tokenACB: '',
    isActive: true
  });
  const [isEditingPayment, setIsEditingPayment] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [settings, setSettings] = useState<AdminSettings>({
    globalMaxThreads: 50,
    systemStatus: 'active',
    maintenanceMessage: '',
    allowUserThreadSettings: true,
    defaultUserThreads: 10
  });
  const [subscriptionPlans, setSubscriptionPlans] = useState<SubscriptionPlan[]>([]);
  const [isEditingPlan, setIsEditingPlan] = useState(false);
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null);

  // Accounts state
  const [accounts, setAccounts] = useState<any[]>([]);
  const [accountsLoading, setAccountsLoading] = useState(false);
  const [accountSearchTerm, setAccountSearchTerm] = useState('');
  const [accountStatusFilter, setAccountStatusFilter] = useState('');
  const [accountPagination, setAccountPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    pages: 0
  });
  const [adminViewKey, setAdminViewKey] = useState('');

  // User management states
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showEditUserModal, setShowEditUserModal] = useState(false);
  const [showUpgradeUserModal, setShowUpgradeUserModal] = useState(false);
  const [showBanUserModal, setShowBanUserModal] = useState(false);
  const [showAddBalanceModal, setShowAddBalanceModal] = useState(false);
  const [addBalanceAmount, setAddBalanceAmount] = useState('');
  
  // Toast notification state
  const [toasts, setToasts] = useState<Array<{
    id: string;
    type: 'success' | 'error' | 'info' | 'warning';
    title: string;
    message: string;
  }>>([]);
  const [isUpdatingUser, setIsUpdatingUser] = useState(false);
  const [userFormData, setUserFormData] = useState({
    username: '',
    email: '',
    fullName: '',
    role: 'user',
    status: 'active' as 'active' | 'inactive'
  });
  const [upgradeFormData, setUpgradeFormData] = useState({
    plan: 'free',
    duration: 30
  });

  // Proxy settings state
  const [proxySettings, setProxySettings] = useState<ProxySettings[]>([]);
  const [isEditingProxy, setIsEditingProxy] = useState(false);
  const [proxyStatus, setProxyStatus] = useState<any>(null);
  const [proxyFormData, setProxyFormData] = useState({
    id: '',
    name: '',
    apiKey: '',
    isActive: true,
    isResidential: false,
    maxUsers: 10
  });

  // Welcome popup settings state
  const [welcomePopupSettings, setWelcomePopupSettings] = useState<WelcomePopupSettings>({
    enabled: true,
    title: "Thông báo",
    message: "Chào mừng bạn quay trở lại !",
    showDontShowAgain: true,
    showOnLogin: true,
    showOnDashboard: false
  });
  const [isLoadingWelcomeSettings, setIsLoadingWelcomeSettings] = useState(false);

  useEffect(() => {
    checkAuth()
    loadStats()
    loadPaymentInfo()
    loadAdminSettings()
    loadSubscriptionPlans()
    loadProxySettings()
    loadWelcomePopupSettings()
  }, [])

  useEffect(() => {
    if (activeTab === 'users') {
      loadUsers(1, showAllUsers ? 1000 : 20)
    }
    if (activeTab === 'accounts') {
      // Mặc định KHÔNG gửi admin key để hiển thị dạng mã hóa
      loadAccounts(false)
      // Nếu muốn tự xem lại theo key phiên, bỏ comment khối dưới
      // try {
      //   const k = sessionStorage.getItem('admin_key') || ''
      //   if (k) { setAdminViewKey(k) ; loadAccounts(true) }
      // } catch {}
    }
    if (activeTab === 'subscriptions') {
      loadSubscriptionPlans()
    }
    if (activeTab === 'proxy') {
      loadProxySettings()
      loadProxyStatus()
    }
  }, [activeTab])

  const checkAuth = async () => {
    try {
      console.log('Checking admin auth...')
      const response = await fetch('/api/admin/check')
      console.log('Auth check response:', response.status)
      if (response.ok) {
        const data = await response.json()
        console.log('Auth check successful:', data)
        setAdmin(data.admin)
      } else {
        console.log('Auth check failed, redirecting to login')
        router.push('/admin/auth')
      }
    } catch (error) {
      console.error('Auth check failed:', error)
      router.push('/admin/auth')
    } finally {
      setLoading(false)
    }
  }

  const loadStats = async () => {
    try {
      const response = await fetch('/api/admin/stats')
      if (response.ok) {
        const data = await response.json()
        const s: Partial<DashboardStats> = (data && (data.stats || data)) || {}
        setStats({
          totalUsers: Number(s.totalUsers) || 0,
          totalAccounts: Number(s.totalAccounts) || 0,
          activeUsers: Number(s.activeUsers) || 0,
          activeAccounts: Number(s.activeAccounts) || 0,
        })
      } else {
        setStats({
          totalUsers: 0,
          totalAccounts: 0,
          activeUsers: 0,
          activeAccounts: 0,
        })
      }
    } catch (error) {
      console.error('Failed to load stats:', error)
      setStats({
        totalUsers: 0,
        totalAccounts: 0,
        activeUsers: 0,
        activeAccounts: 0,
      })
    }
  }

  const loadUsers = async (page: number = 1, limit: number = showAllUsers ? 1000 : 20) => {
    setUsersLoading(true)
    try {
      console.log('Loading users...', { page, limit })
      const params = new URLSearchParams({
        page: page.toString(),
        limit: limit.toString()
      })
      
      const response = await fetch(`/api/admin/users?${params}`)
      console.log('Users response status:', response.status)
      
      if (response.ok) {
        const data = await response.json()
        console.log('Users data:', data)
        setUsers(data.users || [])
        setUserPagination(data.pagination || {
          currentPage: 1,
          totalPages: 1,
          totalUsers: 0,
          hasNext: false,
          hasPrev: false
        })
      } else {
        const errorData = await response.json().catch(() => ({}))
        console.error('Failed to load users:', response.status, errorData)
      }
    } catch (error) {
      console.error('Failed to load users:', error)
    } finally {
      setUsersLoading(false)
    }
  }

  const loadAccounts = async (useAdminKey: boolean = false) => {
    setAccountsLoading(true)
    try {
      const params = new URLSearchParams({
        page: accountPagination.page.toString(),
        limit: accountPagination.limit.toString(),
        ...(accountSearchTerm && { search: accountSearchTerm }),
        ...(accountStatusFilter && { status: accountStatusFilter })
      })
      
      const headers: any = {}
      if (useAdminKey && adminViewKey) {
        headers['x-admin-key'] = adminViewKey
      }
      const response = await fetch(`/api/admin/accounts?${params}`, { headers })
      if (response.ok) {
        const data = await response.json()
        setAccounts(data.accounts)
        setAccountPagination(data.pagination)
      }
    } catch (error) {
      console.error('Failed to load accounts:', error)
    } finally {
      setAccountsLoading(false)
    }
  }

  // Helpers for Accounts table: extract full credentials from document
  const extractCleanUID = (account: any): string => {
    if (!account?.uid) return ''
    if (typeof account.uid === 'string' && account.uid.includes('|')) {
      const uid = account.uid.split('|')[0]
      if (uid && /^\d{10,}$/.test(uid)) return uid
    }
    if (typeof account.uid === 'string' && /^\d{10,}$/.test(account.uid)) return account.uid
    return account.uid || ''
  }

  const getAccountCredentials = (account: any) => {
    const cleanUID = extractCleanUID(account)
    if (account.pass || account.twofa || account.mail || account.passmail || account.mailkp) {
      return {
        uid: cleanUID,
        pass: account.pass || '',
        twofa: account.twofa || '',
        mail: account.mail || '',
        passmail: account.passmail || '',
        mailkp: account.mailkp || ''
      }
    }
    if (typeof account.uid === 'string' && account.uid.includes('|')) {
      const parts = account.uid.trim().split('|')
      return {
        uid: cleanUID,
        pass: parts[1] || '',
        twofa: parts[2] || '',
        mail: parts[3] || '',
        passmail: parts[4] || '',
        mailkp: parts[5] || ''
      }
    }
    return { uid: cleanUID, pass: '', twofa: '', mail: '', passmail: '', mailkp: '' }
  }

  const copyToClipboard = async (value: string, label: string) => {
    try {
      if (!value) return
      await navigator.clipboard.writeText(value)
      showToast('success', 'Đã copy', `${label} đã được copy vào clipboard`)
    } catch {
      showToast('error', 'Lỗi', `Không thể copy ${label}`)
    }
  }

  const loadPaymentInfo = async () => {
    try {
      const response = await fetch('/api/admin/payment-info')
      if (response.ok) {
        const data = await response.json()
        setPaymentInfo(data)
      }
    } catch (error) {
      console.error('Failed to load payment info:', error)
    }
  }

  const generateTransferContent = () => {
    const random = Math.random().toString(36).substring(2, 15)
    return `MAX${random}`
  }

  const savePaymentInfo = async () => {
    setIsSaving(true)
    try {
      const response = await fetch('/api/admin/payment-info', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(paymentInfo)
      })

      if (response.ok) {
        setIsEditingPayment(false)
        // Reload payment info
        loadPaymentInfo()
      }
    } catch (error) {
      console.error('Failed to save payment info:', error)
    } finally {
      setIsSaving(false)
    }
  }

  const loadAdminSettings = async () => {
    try {
      const response = await fetch('/api/admin/settings')
      if (response.ok) {
        const data = await response.json()
        setSettings(data)
      }
    } catch (error) {
      console.error('Failed to load admin settings:', error)
    }
  }

  const saveAdminSettings = async () => {
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settings)
      })

      if (response.ok) {
        // Settings saved successfully
        console.log('Settings saved successfully')
      }
    } catch (error) {
      console.error('Failed to save admin settings:', error)
    }
  }

  const loadSubscriptionPlans = async () => {
    try {
      const response = await fetch('/api/admin/subscription-plans')
      if (response.ok) {
        const data = await response.json()
        setSubscriptionPlans(data)
      }
    } catch (error) {
      console.error('Failed to load subscription plans:', error)
    }
  }

  const saveSubscriptionPlan = async () => {
    if (!editingPlan) return

    try {
      // Client-side duplicate code validation
      const normalizedPlan = (editingPlan.plan || '').trim();
      const isCreating = editingPlan._id === 'new';
      const isDuplicate = subscriptionPlans.some((p) => {
        if (isCreating) return (p.plan || '').trim() === normalizedPlan;
        return p._id !== editingPlan._id && (p.plan || '').trim() === normalizedPlan;
      });
      if (!normalizedPlan) {
        alert('Mã gói (plan) không được để trống');
        return;
      }
      if (isDuplicate) {
        alert('Mã gói đã tồn tại. Vui lòng chọn mã khác.');
        return;
      }
      
      // Validate required fields
      if (!editingPlan.name?.trim()) {
        alert('Tên gói không được để trống');
        return;
      }
      if (!editingPlan.description?.trim()) {
        alert('Mô tả gói không được để trống');
        return;
      }
      if (editingPlan.price === undefined || editingPlan.price < 0) {
        alert('Giá gói phải là số không âm');
        return;
      }
      if (!editingPlan.duration || editingPlan.duration < 1) {
        alert('Thời hạn gói phải ít nhất 1 tháng');
        return;
      }
      if (editingPlan.maxThreads === undefined || editingPlan.maxThreads < -1) {
        alert('Luồng tối đa phải là -1 (không giới hạn) hoặc số không âm');
        return;
      }

      const url = editingPlan._id === 'new' 
        ? '/api/admin/subscription-plans'
        : `/api/admin/subscription-plans/${editingPlan._id}`
      
      const method = editingPlan._id === 'new' ? 'POST' : 'PUT'
      
      const adminToken = typeof window !== 'undefined' ? localStorage.getItem('admin_token') : null;
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {})
        },
        credentials: 'include',
        body: JSON.stringify({
          name: editingPlan.name,
          plan: editingPlan.plan,
          duration: editingPlan.duration,
          price: editingPlan.price,
          currency: editingPlan.currency || 'VND',
          maxThreads: editingPlan.maxThreads,
          features: Array.isArray(editingPlan.features) ? editingPlan.features : [],
          isActive: typeof editingPlan.isActive === 'boolean' ? editingPlan.isActive : true,
          description: editingPlan.description
        })
      })

      if (response.ok) {
        setIsEditingPlan(false)
        setEditingPlan(null)
        loadSubscriptionPlans()
      } else {
        const errorData = await response.json().catch(() => ({} as any));
        const msg = errorData?.error || 'Không thể lưu gói đăng ký';
        alert(msg);
      }
    } catch (error) {
      console.error('Failed to save subscription plan:', error)
    }
  }

  const handleDeleteSubscriptionPlan = async (planId: string) => {
    try {
      const token = localStorage.getItem('admin_token');
      
      // Prepare headers
      const headers: any = {
        'Content-Type': 'application/json'
      };
      
      // Add authorization header if token exists
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      const response = await fetch(`/api/admin/subscription-plans/${planId}`, {
        method: 'DELETE',
        headers,
        credentials: 'include' // Include cookies for authentication fallback
      });

      if (response.ok) {
        // Refresh the subscription plans list
        loadSubscriptionPlans();
        
        // Show success message
        alert('Đã xóa gói đăng ký thành công!');
        console.log('Subscription plan deleted successfully');
      } else {
        const errorData = await response.json();
        console.error('Failed to delete subscription plan:', errorData.error);
        
        if (response.status === 401) {
          alert('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại!');
          // Optionally redirect to login
          // window.location.href = '/admin/auth';
        } else {
          alert(`Không thể xóa gói đăng ký: ${errorData.error || 'Lỗi không xác định'}`);
        }
      }
    } catch (error) {
      console.error('Error deleting subscription plan:', error);
      alert('Có lỗi xảy ra khi xóa gói đăng ký!');
    }
  }

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      router.push('/admin/auth')
    } catch (error) {
      console.error('Logout failed:', error)
      router.push('/admin/auth')
    }
  }

  const hasPermission = (permission: string) => {
    return admin?.permissions?.includes(permission) || admin?.permissions?.includes('all') || false
  }

  // User management functions
  const handleEditUser = (user: User) => {
    setSelectedUser(user);
    setUserFormData({
      username: user.username,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      status: user.status
    });
    setShowEditUserModal(true);
  };

  const handleUpgradeUser = (user: User) => {
    setSelectedUser(user);
    setUpgradeFormData({
      plan: 'free',
      duration: 30
    });
    setShowUpgradeUserModal(true);
  };

  const handleBanUser = (user: User) => {
    setSelectedUser(user);
    setShowBanUserModal(true);
  };

  const handleAddBalance = (user: User) => {
    setSelectedUser(user);
    setAddBalanceAmount('');
    setShowAddBalanceModal(true);
  };

  const handleResetPassword = async (userId: string) => {
    try {
      const newPassword = Math.random().toString(36).substring(2, 15);
      const response = await fetch(`/api/admin/users/${userId}/reset-password`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ newPassword })
      });

      if (response.ok) {
        showToast('success', 'Thành công', `Đã reset mật khẩu cho user. Mật khẩu mới: ${newPassword}`);
        loadUsers(); // Reload users list
      } else {
        const error = await response.json();
        showToast('error', 'Lỗi', 'Không thể reset mật khẩu: ' + error.error);
      }
    } catch (error) {
      console.error('Failed to reset password:', error);
      showToast('error', 'Lỗi', 'Không thể reset mật khẩu');
    }
  };

  // Toast helper functions
  const showToast = (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => {
    const id = Date.now().toString();
    const newToast = { id, type, title, message };
    setToasts(prev => [...prev, newToast]);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(toast => toast.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  const updateUser = async () => {
    if (!selectedUser) return;
    
    setIsUpdatingUser(true);
    try {
      const response = await fetch(`/api/admin/users/${selectedUser._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(userFormData)
      });

      if (response.ok) {
        setShowEditUserModal(false);
        setSelectedUser(null);
        loadUsers(); // Reload users list
      } else {
        const error = await response.json();
        alert('Lỗi cập nhật user: ' + error.error);
      }
    } catch (error) {
      console.error('Failed to update user:', error);
      alert('Lỗi cập nhật user');
    } finally {
      setIsUpdatingUser(false);
    }
  };

  const upgradeUserSubscription = async () => {
    if (!selectedUser) return;
    
    setIsUpdatingUser(true);
    try {
      const response = await fetch(`/api/admin/users/${selectedUser._id}/upgrade`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(upgradeFormData)
      });

      if (response.ok) {
        setShowUpgradeUserModal(false);
        setSelectedUser(null);
        loadUsers(); // Reload users list
      } else {
        const error = await response.json();
        alert('Lỗi nâng cấp user: ' + error.error);
      }
    } catch (error) {
      console.error('Failed to upgrade user:', error);
      alert('Lỗi nâng cấp user');
    } finally {
      setIsUpdatingUser(false);
    }
  };

  const banUser = async () => {
    if (!selectedUser) return;
    
    setIsUpdatingUser(true);
    try {
      const response = await fetch(`/api/admin/users/${selectedUser._id}/ban`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: 'inactive' })
      });

      if (response.ok) {
        setShowBanUserModal(false);
        setSelectedUser(null);
        loadUsers(); // Reload users list
      } else {
        const error = await response.json();
        alert('Lỗi ban user: ' + error.error);
      }
    } catch (error) {
      console.error('Failed to ban user:', error);
      alert('Lỗi ban user');
    } finally {
      setIsUpdatingUser(false);
    }
  };

  const addBalanceToUser = async () => {
    if (!selectedUser || !addBalanceAmount) return;

    const amount = Number(addBalanceAmount);
    if (isNaN(amount) || amount <= 0) {
      showToast('error', 'Lỗi', 'Số tiền không hợp lệ');
      return;
    }

    setIsUpdatingUser(true);
    try {
      const response = await fetch(`/api/admin/users/${selectedUser._id}/add-balance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ amount })
      });

      if (response.ok) {
        const result = await response.json();
        showToast('success', 'Thành công', result.message);
        setShowAddBalanceModal(false);
        setSelectedUser(null);
        setAddBalanceAmount('');
        loadUsers(); // Reload users list
        loadStats(); // Reload stats
      } else {
        const error = await response.json();
        showToast('error', 'Lỗi cộng tiền', error.error);
      }
    } catch (error) {
      console.error('Failed to add balance:', error);
      showToast('error', 'Lỗi', 'Không thể cộng tiền. Vui lòng thử lại.');
    } finally {
      setIsUpdatingUser(false);
    }
  };

  // Proxy settings functions
  const loadProxySettings = async () => {
    try {
      const response = await fetch('/api/admin/proxy-settings');
      
      if (response.ok) {
        const data = await response.json();
        setProxySettings(data.proxySettings || []);
      } else {
        console.error('Failed to load proxy settings');
      }
    } catch (error) {
      console.error('Error loading proxy settings:', error);
    }
  };

  const saveProxySettings = async () => {
    try {
      const method = proxyFormData.id ? 'PUT' : 'POST';
      const url = '/api/admin/proxy-settings';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(proxyFormData)
      });

      if (response.ok) {
        const data = await response.json();
        console.log('Proxy settings saved:', data.message);
        setIsEditingProxy(false);
        setProxyFormData({
          id: '',
          name: '',
          apiKey: '',
          isActive: true,
          isResidential: false,
          maxUsers: 10
        });
        loadProxySettings();
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.error}`);
      }
    } catch (error) {
      console.error('Error saving proxy settings:', error);
      alert('Error saving proxy settings');
    }
  };

  const deleteProxySettings = async (id: string) => {
    if (!confirm('Bạn có chắc muốn xóa proxy setting này?')) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/proxy-settings?id=${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        console.log('Proxy setting deleted successfully');
        loadProxySettings();
      } else {
        const errorData = await response.json();
        alert(`Error: ${errorData.error}`);
      }
    } catch (error) {
      console.error('Error deleting proxy settings:', error);
      alert('Error deleting proxy settings');
    }
  };

  const handleEditProxy = (proxy: ProxySettings) => {
    setProxyFormData({
              id: proxy._id || proxy.id || '',
      name: proxy.name,
      apiKey: proxy.apiKey,
      isActive: proxy.isActive,
      isResidential: proxy.isResidential || false,
      maxUsers: proxy.maxUsers || 10
    });
    setIsEditingProxy(true);
  };

  const handleAddProxy = () => {
    setProxyFormData({
      id: '',
      name: '',
      apiKey: '',
      isActive: true,
      isResidential: false,
      maxUsers: 10
    });
    setIsEditingProxy(true);
  };

  const loadProxyStatus = async () => {
    try {
      const response = await fetch('/api/proxy/status');
      if (response.ok) {
        const data = await response.json();
        setProxyStatus(data);
      }
    } catch (error) {
      console.error('Failed to load proxy status:', error);
    }
  };

  const loadWelcomePopupSettings = async () => {
    try {
      const response = await fetch('/api/admin/welcome-popup/settings', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setWelcomePopupSettings(data.settings);
      }
    } catch (error) {
      console.error('Error loading welcome popup settings:', error);
    }
  };

  const saveWelcomePopupSettings = async () => {
    setIsLoadingWelcomeSettings(true);
    try {
      const response = await fetch('/api/admin/welcome-popup/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(welcomePopupSettings)
      });
      
      if (response.ok) {
        showToast('success', 'Thành công', 'Cài đặt popup đã được lưu!');
      } else {
        showToast('error', 'Lỗi', 'Không thể lưu cài đặt popup!');
      }
    } catch (error) {
      console.error('Error saving welcome popup settings:', error);
      showToast('error', 'Lỗi', 'Không thể lưu cài đặt popup!');
    } finally {
      setIsLoadingWelcomeSettings(false);
    }
  };

  const resetAllPopupDismissals = async () => {
    if (!confirm('Bạn có chắc muốn xóa tất cả lịch sử ẩn popup của người dùng?')) {
      return;
    }

    try {
      const response = await fetch('/api/admin/welcome-popup/reset-dismissals', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        showToast('success', 'Thành công', 'Đã xóa tất cả lịch sử ẩn popup!');
      } else {
        showToast('error', 'Lỗi', 'Không thể xóa lịch sử ẩn popup!');
      }
    } catch (error) {
      console.error('Error resetting popup dismissals:', error);
      showToast('error', 'Lỗi', 'Không thể xóa lịch sử ẩn popup!');
    }
  };

  // Filter users based on search term and status
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(userSearchTerm.toLowerCase()) ||
                         user.fullName.toLowerCase().includes(userSearchTerm.toLowerCase())
    
    const matchesStatus = !userStatusFilter || user.status === userStatusFilter
    
    return matchesSearch && matchesStatus
  })

  // Add status filter dropdown
  const handleStatusFilterChange = (status: string) => {
    setUserStatusFilter(status)
    // Reset to first page when filtering
    loadUsers(1, showAllUsers ? 1000 : 20)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Đang tải...</p>
        </div>
      </div>
    )
  }

  if (!admin) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Menu Button */}
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className="lg:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
              >
                {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
              
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold text-gray-900">Admin Panel</span>
              </div>
            </div>

            {/* Admin Info */}
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm font-medium text-gray-900">{admin?.username}</div>
                <div className="text-xs text-gray-500">{admin?.role}</div>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-4 py-2 text-sm text-red-600 hover:text-red-700 font-medium"
              >
                <LogOut className="w-4 h-4" />
                <span>Đăng xuất</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}>
          <div className="h-full flex flex-col">
            <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
              <nav className="mt-5 flex-1 px-2 space-y-1">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    activeTab === 'overview'
                      ? 'bg-purple-100 text-purple-700'
                      : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                >
                  <BarChart3 className="w-5 h-5" />
                  <span>Tổng quan</span>
                </button>

                {hasPermission('manage_users') && (
                  <button
                    onClick={() => setActiveTab('users')}
                    className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === 'users'
                        ? 'bg-purple-100 text-purple-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <Users className="w-5 h-5" />
                    <span>Quản lý Users</span>
                  </button>
                )}

                {hasPermission('manage_accounts') && (
                  <button
                    onClick={() => setActiveTab('accounts')}
                    className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeTab === 'accounts'
                        ? 'bg-purple-100 text-purple-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                  >
                    <Database className="w-5 h-5" />
                    <span>Quản lý Accounts</span>
                  </button>
                )}

                                 {hasPermission('manage_general') && (
                   <button
                     onClick={() => setActiveTab('general')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'general'
                         ? 'bg-purple-100 text-purple-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <CreditCard className="w-5 h-5" />
                     <span>Ngân Hàng</span>
                   </button>
                 )}

                 {hasPermission('manage_threads') && (
                   <button
                     onClick={() => setActiveTab('threads')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'threads'
                         ? 'bg-purple-100 text-purple-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <Zap className="w-5 h-5" />
                     <span>Quản lý luồng</span>
                   </button>
                 )}

                 {hasPermission('manage_subscriptions') && (
                   <button
                     onClick={() => setActiveTab('subscriptions')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'subscriptions'
                         ? 'bg-purple-100 text-purple-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <Crown className="w-5 h-5" />
                     <span>Gói đăng ký</span>
                   </button>
                 )}

                 {hasPermission('manage_tickets') && (
                   <button
                     onClick={() => router.push('/admin/tickets')}
                     className="w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                   >
                     <MessageSquare className="w-5 h-5" />
                     <span>Quản lý Tickets</span>
                   </button>
                 )}

                 {hasPermission('manage_subscriptions') && (
                   <button
                     onClick={() => setActiveTab('downgrade')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'downgrade'
                         ? 'bg-purple-100 text-purple-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <TrendingDown className="w-5 h-5" />
                     <span>Hạ cấp tự động</span>
                   </button>
                 )}

                 {hasPermission('manage_general') && (
                   <button
                     onClick={() => setActiveTab('proxy')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'proxy'
                         ? 'bg-green-100 text-green-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <Globe className="w-5 h-5" />
                     <span>Quản lý Proxy</span>
                   </button>
                 )}

                 {hasPermission('manage_general') && (
                   <button
                     onClick={() => setActiveTab('welcome-popup')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'welcome-popup'
                         ? 'bg-blue-100 text-blue-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <Settings className="w-5 h-5" />
                     <span>Popup Thông báo</span>
                   </button>
                 )}

                 {hasPermission('manage_nav') && (
                   <button
                     onClick={() => setActiveTab('navigation')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'navigation'
                         ? 'bg-purple-100 text-purple-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <Menu className="w-5 h-5" />
                     <span>Quản lý Menu</span>
                   </button>
                 )}

                 {hasPermission('manage_seo') && (
                   <button
                     onClick={() => setActiveTab('seo')}
                     className={`w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                       activeTab === 'seo'
                         ? 'bg-purple-100 text-purple-700'
                         : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                     }`}
                   >
                     <Globe className="w-5 h-5" />
                     <span>Quản lý SEO</span>
                   </button>
                 )}

                 {hasPermission('manage_transactions') && (
                   <button
                     onClick={() => router.push('/admin/transactions')}
                     className="w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium rounded-md transition-colors text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                   >
                     <CreditCard className="w-5 h-5" />
                     <span>Lịch sử giao dịch</span>
                   </button>
                 )}
              </nav>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Tổng quan hệ thống</h1>
                  <p className="text-gray-600">Thống kê và báo cáo tổng quan</p>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center">
                      <div className="p-3 bg-blue-100 rounded-lg">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Tổng Users</p>
                        <p className="text-2xl font-bold text-gray-900">{stats?.totalUsers ?? 0}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center">
                      <div className="p-3 bg-green-100 rounded-lg">
                        <Database className="w-6 h-6 text-green-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Tổng Accounts</p>
                        <p className="text-2xl font-bold text-gray-900">{stats?.totalAccounts ?? 0}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center">
                      <div className="p-3 bg-purple-100 rounded-lg">
                        <UserCheck className="w-6 h-6 text-purple-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Users Active</p>
                        <p className="text-2xl font-bold text-gray-900">{stats?.activeUsers ?? 0}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center">
                      <div className="p-3 bg-orange-100 rounded-lg">
                        <Activity className="w-6 h-6 text-orange-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">Accounts Active</p>
                        <p className="text-2xl font-bold text-gray-900">{stats?.activeAccounts ?? 0}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Hoạt động gần đây</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">Hệ thống hoạt động bình thường</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">Cập nhật cài đặt hệ thống</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">Thêm user mới</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Users Tab */}
            {activeTab === 'users' && hasPermission('manage_users') && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Quản lý Users</h1>
                    <p className="text-gray-600">
                      Quản lý tài khoản người dùng 
                      <span className="font-semibold text-purple-600 ml-1">
                        ({userPagination.totalUsers} users)
                      </span>
                    </p>
                  </div>
                  <button className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                    <Plus className="w-4 h-4" />
                    <span>Thêm User</span>
                  </button>
                </div>

                {/* Users Summary Stats */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Users className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-600">Tổng Users</p>
                        <p className="text-lg font-semibold text-gray-900">{userPagination.totalUsers}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <UserCheck className="w-5 h-5 text-green-600" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-600">Active</p>
                        <p className="text-lg font-semibold text-gray-900">{users.filter(u => u.status === 'active').length}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-red-100 rounded-lg">
                        <UserX className="w-5 h-5 text-red-600" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-600">Inactive</p>
                        <p className="text-lg font-semibold text-gray-900">{users.filter(u => u.status === 'inactive').length}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                    <div className="flex items-center">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <CreditCard className="w-5 h-5 text-purple-600" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-600">Tổng số dư</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {users.reduce((sum, user) => sum + (user.balance || 0), 0).toLocaleString('vi-VN')} ₫
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                  {/* Search and Filter Bar */}
                  <div className="p-4 border-b border-gray-200">
                    <div className="flex items-center space-x-4">
                      <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <input
                          type="text"
                          placeholder="Tìm kiếm users..."
                          value={userSearchTerm}
                          onChange={(e) => setUserSearchTerm(e.target.value)}
                          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none text-sm"
                        />
                      </div>
                      <select
                        value={userStatusFilter}
                        onChange={(e) => handleStatusFilterChange(e.target.value)}
                        className="px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none text-sm text-gray-700"
                      >
                        <option value="">Tất cả trạng thái</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                      </select>
                      <button
                        onClick={() => {
                          const allUserIds = filteredUsers.map(user => user._id);
                          const allHidden = allUserIds.every(id => !showPasswords[id]);
                          setShowPasswords(prev => {
                            const newState = { ...prev };
                            allUserIds.forEach(id => {
                              newState[id] = allHidden;
                            });
                            return newState;
                          });
                        }}
                        className="flex items-center space-x-2 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors text-sm"
                        title="Hiện/Ẩn tất cả mật khẩu"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        <span>Hiện/Ẩn tất cả MK</span>
                      </button>
                      <button
                        onClick={() => {
                          showToast('info', 'Thông báo', 'Mật khẩu đã được mã hóa. Sử dụng nút "Reset mật khẩu" để tạo mật khẩu mới.');
                        }}
                        className="flex items-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                        title="Copy tất cả mật khẩu"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                        </svg>
                        <span>Copy tất cả MK</span>
                      </button>
                      <button
                        onClick={() => {
                          const totalBalance = filteredUsers.reduce((sum, user) => sum + (user.balance || 0), 0);
                          showToast('info', 'Tổng số dư', `Tổng số dư của tất cả users: ${totalBalance.toLocaleString('vi-VN')} ₫`);
                        }}
                        className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                        title="Xem tổng số dư"
                      >
                        <CreditCard className="w-4 h-4" />
                        <span>Xem tổng số dư</span>
                      </button>
                      <button
                        onClick={() => {
                          setShowAllUsers(!showAllUsers);
                          loadUsers(1, !showAllUsers ? 1000 : 20);
                        }}
                        className={`flex items-center space-x-2 px-3 py-2 text-sm rounded-lg transition-colors ${
                          showAllUsers 
                            ? 'bg-purple-600 text-white hover:bg-purple-700' 
                            : 'bg-gray-600 text-white hover:bg-gray-700'
                        }`}
                        title={showAllUsers ? 'Hiển thị phân trang' : 'Hiển thị tất cả'}
                      >
                        {showAllUsers ? <Eye className="w-4 h-4" /> : <Database className="w-4 h-4" />}
                        <span>{showAllUsers ? 'Phân trang' : 'Tất cả'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="p-6">
                    {usersLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
                        <p className="mt-2 text-gray-600">Đang tải users...</p>
                      </div>
                    ) : filteredUsers.length === 0 ? (
                      <div className="text-center text-gray-500 py-8">
                        <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Không tìm thấy users nào</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                User
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Email
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Số dư
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Mật khẩu
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Role
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Ngày tạo
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Actions
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {filteredUsers.map((user) => (
                              <tr key={user._id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center">
                                    <div className="flex-shrink-0 h-10 w-10">
                                      <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                                        <User className="h-6 w-6 text-purple-600" />
                                      </div>
                                    </div>
                                    <div className="ml-4">
                                      <div className="text-sm font-medium text-gray-900">
                                        {user.fullName || user.username}
                                      </div>
                                      <div className="text-sm text-gray-500">
                                        @{user.username}
                                      </div>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="text-sm text-gray-900">{user.email}</div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="text-sm font-medium">
                                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                                      (user.balance || 0) > 0 
                                        ? 'bg-green-100 text-green-800' 
                                        : 'bg-gray-100 text-gray-600'
                                    }`}>
                                      {(user.balance || 0).toLocaleString('vi-VN')} ₫
                                    </span>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="flex items-center space-x-2">
                                    <div className="text-sm text-gray-900 font-mono bg-gray-100 px-2 py-1 rounded">
                                      {user.password ? '••••••••' : 'N/A'}
                                    </div>
                                    <button
                                      onClick={() => {
                                        if (confirm(`Bạn có muốn reset mật khẩu cho user ${user.username}?`)) {
                                          handleResetPassword(user._id);
                                        }
                                      }}
                                      className="text-orange-600 hover:text-orange-800 p-1 hover:bg-orange-50 rounded"
                                      title="Reset mật khẩu"
                                      disabled={!user.password}
                                    >
                                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                      </svg>
                                    </button>
                                    <button
                                      onClick={() => {
                                        if (user.password) {
                                          navigator.clipboard.writeText(user.password);
                                          showToast('success', 'Thành công', 'Đã copy mật khẩu vào clipboard');
                                        }
                                      }}
                                      className="text-blue-600 hover:text-blue-800 p-1 hover:bg-blue-50 rounded"
                                      title="Copy mật khẩu"
                                      disabled={!user.password}
                                    >
                                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                                      </svg>
                                    </button>
                                  </div>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                    {user.role}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                    user.status === 'active' 
                                      ? 'bg-green-100 text-green-800' 
                                      : 'bg-red-100 text-red-800'
                                  }`}>
                                    {user.status === 'active' ? 'Active' : 'Inactive'}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {new Date(user.createdAt).toLocaleDateString('vi-VN')}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                  <div className="flex items-center space-x-2">
                                    <button 
                                      className="text-purple-600 hover:text-purple-900"
                                      title="Xem chi tiết"
                                    >
                                      <Eye className="w-4 h-4" />
                                    </button>
                                    <button 
                                      className="text-blue-600 hover:text-blue-900"
                                      onClick={() => handleEditUser(user)}
                                      title="Chỉnh sửa user"
                                    >
                                      <Edit className="w-4 h-4" />
                                    </button>
                                    <button 
                                      className="text-purple-600 hover:text-purple-900"
                                      onClick={() => handleUpgradeUser(user)}
                                      title="Nâng cấp gói"
                                    >
                                      <Crown className="w-4 h-4" />
                                    </button>
                                    <button 
                                      className="inline-flex items-center space-x-1 px-2 py-1 bg-green-100 text-green-700 hover:bg-green-200 border border-green-200 rounded text-xs font-medium"
                                      onClick={() => handleAddBalance(user)}
                                      title="Cộng tiền"
                                    >
                                      <Plus className="w-3 h-3" />
                                      <span>Cộng tiền</span>
                                    </button>
                                    <button 
                                      className={`hover:text-red-900 ${user.status === 'active' ? 'text-red-600' : 'text-green-600'}`}
                                      onClick={() => handleBanUser(user)}
                                      title={user.status === 'active' ? 'Ban user' : 'Unban user'}
                                    >
                                      {user.status === 'active' ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
                                    </button>
                                    <button 
                                      onClick={() => {
                                        const userInfo = `Username: ${user.username}\nEmail: ${user.email}\nPassword: [Đã mã hóa]`;
                                        navigator.clipboard.writeText(userInfo);
                                        showToast('success', 'Thành công', 'Đã copy thông tin user vào clipboard');
                                      }}
                                      className="text-orange-600 hover:text-orange-800 p-1 hover:bg-orange-50 rounded"
                                      title="Copy thông tin user"
                                      disabled={!user.password}
                                    >
                                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                      </svg>
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    
                    {/* Pagination Controls */}
                    {!showAllUsers && userPagination.totalPages > 1 && (
                      <div className="flex items-center justify-between px-6 py-4 border-t border-gray-200">
                        <div className="text-sm text-gray-700">
                          Hiển thị {((userPagination.currentPage - 1) * 20) + 1} - {Math.min(userPagination.currentPage * 20, userPagination.totalUsers)} 
                          trong tổng số {userPagination.totalUsers} users
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => loadUsers(userPagination.currentPage - 1, 20)}
                            disabled={!userPagination.hasPrev}
                            className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            Trước
                          </button>
                          <span className="px-3 py-2 text-sm text-gray-700">
                            Trang {userPagination.currentPage} / {userPagination.totalPages}
                          </span>
                          <button
                            onClick={() => loadUsers(userPagination.currentPage + 1, 20)}
                            disabled={!userPagination.hasNext}
                            className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            Sau
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Accounts Tab */}
            {activeTab === 'accounts' && hasPermission('manage_accounts') && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Quản lý Accounts</h1>
                    <p className="text-gray-600">Quản lý tài khoản Facebook của users</p>
                  </div>
                  <button className="flex items-center space-x-2 px-3 py-1.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm">
                    <Plus className="w-3.5 h-3.5" />
                    <span>Thêm Account</span>
                  </button>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex items-center space-x-4">
                      <div className="flex-1">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                          <input
                            type="text"
                            placeholder="Tìm kiếm accounts..."
                            value={accountSearchTerm}
                            onChange={(e) => setAccountSearchTerm(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && loadAccounts()}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
                          />
                        </div>
                      </div>
                      <select 
                        value={accountStatusFilter}
                        onChange={(e) => setAccountStatusFilter(e.target.value)}
                        className="px-4 py-2 border border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none text-gray-800"
                      >
                        <option value="">Tất cả trạng thái</option>
                        <option value="active">Active</option>
                        <option value="checking">Checking</option>
                        <option value="error">Error</option>
                        <option value="inactive">Inactive</option>
                      </select>
                      <div className="flex items-center space-x-2">
                        <input
                          type="password"
                          placeholder="Admin key để xem dữ liệu mã hóa"
                          onChange={(e) => {
                            setAdminViewKey(e.target.value)
                            try { sessionStorage.setItem('admin_key', e.target.value) } catch {}
                          }}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none text-gray-800"
                        />
                        <button
                          onClick={() => {
                            try { sessionStorage.setItem('admin_key', adminViewKey) } catch {}
                            loadAccounts(true)
                          }}
                          className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                          title="Xem dữ liệu bằng admin key"
                        >
                          Xem
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 max-h-96 overflow-y-auto">
                    {accountsLoading ? (
                      <div className="text-center py-8">
                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
                        <p className="mt-2 text-gray-600">Đang tải accounts...</p>
                      </div>
                    ) : accounts.length === 0 ? (
                      <div className="text-center text-gray-500 py-8">
                        <Database className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Chưa có accounts nào</p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                UID
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Tên
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                PASS
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                2FA
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                MAIL
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                PASSMAIL
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                MAILKP
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                User
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Trạng thái
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Ngày tạo
                              </th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Thao tác
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {accounts.map((account) => (
                              <tr key={account._id} className="hover:bg-gray-50">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {account.uid}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {account.name || 'N/A'}
                                </td>
                                {(() => {
                                  const creds = getAccountCredentials(account)
                                  return (
                                    <>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <div className="flex items-center space-x-2">
                                          <span className="truncate max-w-[160px]" title={creds.pass || ''}>{creds.pass || '—'}</span>
                                          {creds.pass && (
                                            <button onClick={() => copyToClipboard(creds.pass, 'PASS')} className="text-blue-600 hover:text-blue-800">Copy</button>
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <div className="flex items-center space-x-2">
                                          <span className="truncate max-w-[160px]" title={creds.twofa || ''}>{creds.twofa || '—'}</span>
                                          {creds.twofa && (
                                            <button onClick={() => copyToClipboard(creds.twofa, '2FA')} className="text-blue-600 hover:text-blue-800">Copy</button>
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <div className="flex items-center space-x-2">
                                          <span className="truncate max-w-[180px]" title={creds.mail || ''}>{creds.mail || '—'}</span>
                                          {creds.mail && (
                                            <button onClick={() => copyToClipboard(creds.mail, 'MAIL')} className="text-blue-600 hover:text-blue-800">Copy</button>
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <div className="flex items-center space-x-2">
                                          <span className="truncate max-w-[160px]" title={creds.passmail || ''}>{creds.passmail || '—'}</span>
                                          {creds.passmail && (
                                            <button onClick={() => copyToClipboard(creds.passmail, 'PASSMAIL')} className="text-blue-600 hover:text-blue-800">Copy</button>
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        <div className="flex items-center space-x-2">
                                          <span className="truncate max-w-[160px]" title={creds.mailkp || ''}>{creds.mailkp || '—'}</span>
                                          {creds.mailkp && (
                                            <button onClick={() => copyToClipboard(creds.mailkp, 'MAILKP')} className="text-blue-600 hover:text-blue-800">Copy</button>
                                          )}
                                        </div>
                                      </td>
                                    </>
                                  )
                                })()}
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                  {account.userId?.username || 'N/A'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                    account.status === 'active' ? 'bg-green-100 text-green-800' :
                                    account.status === 'checking' ? 'bg-yellow-100 text-yellow-800' :
                                    account.status === 'error' ? 'bg-red-100 text-red-800' :
                                    'bg-gray-100 text-gray-800'
                                  }`}>
                                    {account.status}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {new Date(account.createdAt).toLocaleDateString('vi-VN')}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                  <div className="flex items-center space-x-2">
                                    <button className="text-purple-600 hover:text-purple-900">
                                      <Eye className="w-4 h-4" />
                                    </button>
                                    <button className="text-blue-600 hover:text-blue-900">
                                      <Edit className="w-4 h-4" />
                                    </button>
                                    <button className="text-red-600 hover:text-red-900">
                                      <Trash className="w-4 h-4" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

                         {/* Thread Management Tab */}
             {activeTab === 'threads' && hasPermission('manage_threads') && (
               <div className="space-y-6">
                 <div>
                   <h1 className="text-2xl font-bold text-gray-900">Quản lý đa luồng</h1>
                   <p className="text-gray-600">Cấu hình số luồng tối đa cho toàn hệ thống</p>
                 </div>

                 <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                   <div className="flex items-center space-x-3 mb-6">
                     <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg">
                       <Zap className="w-6 h-6 text-white" />
                     </div>
                     <div>
                       <h3 className="text-lg font-semibold text-gray-900">Cài đặt toàn cục</h3>
                       <p className="text-sm text-gray-600">Cấu hình số luồng tối đa cho toàn hệ thống</p>
                     </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     {/* Global Thread Settings */}
                     <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl p-6 border border-cyan-100">
                       <h3 className="text-lg font-semibold text-gray-900 mb-4">Cài đặt toàn cục</h3>
                       
                       <div className="space-y-4">
                         <div>
                           <label className="block text-sm font-medium text-gray-700 mb-2">
                             Số luồng tối đa toàn hệ thống
                           </label>
                           <div className="flex items-center space-x-3">
                             <input
                               type="range"
                               min="10"
                               max="100"
                               value={settings.globalMaxThreads}
                               onChange={(e) => setSettings(prev => ({ ...prev, globalMaxThreads: parseInt(e.target.value) }))}
                               className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                             />
                             <span className="text-sm font-semibold text-gray-800 min-w-[3rem] text-center">
                               {settings.globalMaxThreads}
                             </span>
                           </div>
                           <p className="text-xs text-gray-500 mt-1">Tối đa 100 luồng cho toàn hệ thống</p>
                         </div>

                         <div>
                           <label className="block text-sm font-medium text-gray-700 mb-2">
                             Số luồng mặc định cho user mới
                           </label>
                           <div className="flex items-center space-x-3">
                             <input
                               type="range"
                               min="1"
                               max="50"
                               value={settings.defaultUserThreads}
                               onChange={(e) => setSettings(prev => ({ ...prev, defaultUserThreads: parseInt(e.target.value) }))}
                               className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                             />
                             <span className="text-sm font-semibold text-gray-800 min-w-[2rem] text-center">
                               {settings.defaultUserThreads}
                             </span>
                           </div>
                           <p className="text-xs text-gray-500 mt-1">Số luồng mặc định khi user đăng ký</p>
                         </div>

                         <label className="flex items-center space-x-3 p-4 bg-white rounded-lg border border-gray-200 cursor-pointer hover:bg-gray-50 transition-colors">
                           <input
                             type="checkbox"
                             checked={settings.allowUserThreadSettings}
                             onChange={(e) => setSettings(prev => ({ ...prev, allowUserThreadSettings: e.target.checked }))}
                             className="w-5 h-5 text-cyan-600 rounded focus:ring-cyan-500"
                           />
                           <span className="text-gray-700 font-medium">Cho phép user tùy chỉnh số luồng</span>
                         </label>
                       </div>
                     </div>

                     {/* System Status */}
                     <div className="bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl p-6 border border-emerald-100">
                       <h3 className="text-lg font-semibold text-gray-900 mb-4">Trạng thái hệ thống</h3>
                       
                       <div className="space-y-4">
                         <div>
                           <label className="block text-sm font-medium text-gray-700 mb-2">
                             Trạng thái hệ thống
                           </label>
                           <select
                             value={settings.systemStatus}
                             onChange={(e) => setSettings(prev => ({ ...prev, systemStatus: e.target.value as 'active' | 'maintenance' | 'offline' }))}
                             className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-gray-900 font-medium"
                           >
                             <option value="active">Hoạt động</option>
                             <option value="maintenance">Bảo trì</option>
                             <option value="offline">Tắt</option>
                           </select>
                         </div>

                         <div>
                           <label className="block text-sm font-medium text-gray-700 mb-2">
                             Thông báo bảo trì
                           </label>
                           <textarea
                             value={settings.maintenanceMessage}
                             onChange={(e) => setSettings(prev => ({ ...prev, maintenanceMessage: e.target.value }))}
                             placeholder="Nhập thông báo bảo trì..."
                             className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-gray-900 resize-none font-medium"
                             rows={3}
                           />
                         </div>
                       </div>
                     </div>
                   </div>

                   {/* Save Button */}
                   <div className="flex justify-end mt-6">
                     <button
                       onClick={saveAdminSettings}
                       disabled={isSaving}
                       className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 shadow-md hover:shadow-lg disabled:opacity-50 font-medium"
                     >
                       {isSaving ? (
                         <>
                           <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                           <span>Đang lưu...</span>
                         </>
                       ) : (
                         <>
                           <Settings className="w-4 h-4" />
                           <span>Lưu cài đặt</span>
                         </>
                       )}
                     </button>
                   </div>
                 </div>
               </div>
             )}

             {/* Subscription Plans Tab */}
             {activeTab === 'subscriptions' && hasPermission('manage_subscriptions') && (
               <div className="space-y-6">
                 <div>
                   <h1 className="text-2xl font-bold text-blue-600">Quản lý gói đăng ký</h1>
                   <p className="text-blue-500 font-medium">Quản lý các gói đăng ký và tính năng</p>
                 </div>

                 <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                   <div className="flex items-center justify-between mb-6">
                     <div className="flex items-center space-x-3">
                       <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg">
                         <Crown className="w-6 h-6 text-white" />
                       </div>
                       <div>
                         <h3 className="text-lg font-semibold text-gray-800">Gói đăng ký</h3>
                         <p className="text-sm text-gray-600 font-medium">Quản lý các gói đăng ký và tính năng</p>
                       </div>
                     </div>
                     <button
                       onClick={() => {
                         setEditingPlan({
                           _id: 'new',
                           plan: '',
                           name: '',
                           price: 0,
                           duration: 1,
                           maxThreads: 10,
                           features: [],
                           isActive: true
                         });
                         setIsEditingPlan(true);
                       }}
                       className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                     >
                       <Plus className="w-4 h-4" />
                       <span>Thêm gói mới</span>
                     </button>
                   </div>

                   {subscriptionPlans.length === 0 ? (
                     <div className="text-center py-8">
                       <Crown className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                       <p className="text-gray-500">Chưa có gói đăng ký nào</p>
                     </div>
                   ) : (
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                       {subscriptionPlans?.map((plan) => (
                         <div key={plan._id} className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                           <div className="flex items-center justify-between mb-4">
                             <h4 className="text-lg font-semibold text-gray-900">{plan.name}</h4>
                             <div className="flex items-center space-x-2">
                             <button
                               onClick={() => {
                                 setEditingPlan(plan);
                                 setIsEditingPlan(true);
                               }}
                               className="px-3 py-1 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm"
                             >
                               Chỉnh sửa
                             </button>
                               <button
                                 onClick={() => {
                                   if (confirm(`Bạn có chắc muốn xóa gói "${plan.name}"?\n\nHành động này không thể hoàn tác!`)) {
                                     handleDeleteSubscriptionPlan(plan._id);
                                   }
                                 }}
                                 className="px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors text-sm flex items-center space-x-1"
                                 title="Xóa gói"
                               >
                                 <Trash2 className="w-3 h-3" />
                                 <span>Xóa</span>
                               </button>
                             </div>
                           </div>
                           
                           <div className="space-y-2">
                             <div className="flex justify-between">
                               <span className="text-sm font-medium text-gray-700">Giá:</span>
                               <span className="font-semibold text-gray-900">{plan.price.toLocaleString()} VNĐ</span>
                             </div>
                             <div className="flex justify-between">
                               <span className="text-sm font-medium text-gray-700">Thời hạn:</span>
                               <span className="font-semibold text-gray-900">{plan.duration} tháng</span>
                             </div>
                             <div className="flex justify-between">
                               <span className="text-sm font-medium text-gray-700">Luồng tối đa:</span>
                               <span className="font-semibold text-gray-900">{plan.maxThreads === -1 ? 'Không giới hạn' : plan.maxThreads}</span>
                             </div>
                             <div className="flex justify-between">
                               <span className="text-sm font-medium text-gray-700">Trạng thái:</span>
                               <span className={`font-semibold ${plan.isActive ? 'text-green-600' : 'text-red-600'}`}>
                                 {plan.isActive ? 'Hoạt động' : 'Tạm dừng'}
                               </span>
                             </div>
                           </div>
                         </div>
                       ))}
                     </div>
                   )}
                 </div>
               </div>
             )}

             {/* Proxy Settings Tab */}
             {activeTab === 'proxy' && (
               <div className="space-y-6">
                 <div className="flex justify-between items-center">
                   <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                     Quản lý Proxy Settings
                   </h2>
                   <div className="flex gap-2">
                     <button
                       onClick={() => {
                         loadProxySettings();
                         loadProxyStatus();
                       }}
                       className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
                     >
                       <RefreshCw className="w-4 h-4" />
                       Làm mới
                     </button>
                     <button
                       onClick={async () => {
                         if (confirm('Bạn có chắc muốn reset số user sử dụng proxy về 0?')) {
                           try {
                             const response = await fetch('/api/admin/reset-proxy-users', {
                               method: 'POST'
                             });
                             if (response.ok) {
                               alert('Đã reset số user sử dụng proxy thành công!');
                               loadProxySettings();
                             } else {
                               alert('Lỗi khi reset proxy users!');
                             }
                           } catch (error) {
                             console.error('Error resetting proxy users:', error);
                             alert('Lỗi khi reset proxy users!');
                           }
                         }
                       }}
                       className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
                     >
                       <Trash className="w-4 h-4" />
                       Reset Users
                     </button>
                     <button
                       onClick={handleAddProxy}
                       className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
                     >
                       <Plus className="w-4 h-4" />
                       Thêm Proxy
                     </button>
                   </div>
                 </div>

                 {/* Proxy Status Overview */}
                 {proxyStatus && (
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                     <div className="bg-white rounded-lg shadow p-4 border border-gray-200">
                       <div className="flex items-center">
                         <div className="p-2 bg-blue-500 rounded-lg">
                           <Globe className="w-4 h-4 text-white" />
                         </div>
                         <div className="ml-3">
                           <p className="text-sm font-medium text-gray-500">Tổng Proxy</p>
                           <p className="text-lg font-semibold text-gray-900">{proxyStatus.stats.totalProxies}</p>
                         </div>
                       </div>
                     </div>
                     
                     <div className="bg-white rounded-lg shadow p-4 border border-gray-200">
                       <div className="flex items-center">
                         <div className="p-2 bg-green-500 rounded-lg">
                           <Globe className="w-4 h-4 text-white" />
                         </div>
                         <div className="ml-3">
                           <p className="text-sm font-medium text-gray-500">Đang hoạt động</p>
                           <p className="text-lg font-semibold text-gray-900">{proxyStatus.stats.activeProxies}</p>
                         </div>
                       </div>
                     </div>
                     
                     <div className="bg-white rounded-lg shadow p-4 border border-gray-200">
                       <div className="flex items-center">
                         <div className="p-2 bg-purple-500 rounded-lg">
                           <Globe className="w-4 h-4 text-white" />
                         </div>
                         <div className="ml-3">
                           <p className="text-sm font-medium text-gray-500">Có IP</p>
                           <p className="text-lg font-semibold text-gray-900">{proxyStatus.stats.proxiesWithIP}</p>
                         </div>
                       </div>
                     </div>
                     
                     <div className="bg-white rounded-lg shadow p-4 border border-gray-200">
                       <div className="flex items-center">
                         <div className="p-2 bg-orange-500 rounded-lg">
                           <Globe className="w-4 h-4 text-white" />
                         </div>
                         <div className="ml-3">
                           <p className="text-sm font-medium text-gray-500">Cần cập nhật</p>
                           <p className="text-lg font-semibold text-gray-900">{proxyStatus.stats.proxiesNeedingUpdate}</p>
                         </div>
                       </div>
                     </div>
                   </div>
                 )}

                 {/* Cron Job Info */}
                 <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
                   <div className="flex items-center space-x-3 mb-3">
                     <div className="p-2 bg-blue-500 rounded-lg">
                       <Clock className="w-5 h-5 text-white" />
                     </div>
                     <div>
                       <h3 className="text-lg font-semibold text-gray-900">Cron Job - Tự động cập nhật IP</h3>
                       <p className="text-sm text-gray-600">Cập nhật IP proxy mỗi 2 phút cho tất cả user</p>
                     </div>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                     <div className="bg-white rounded-lg p-3 border border-gray-200">
                       <p className="text-xs text-gray-500">Tần suất</p>
                       <p className="text-sm font-medium text-gray-900">Mỗi 2 phút</p>
                     </div>
                     <div className="bg-white rounded-lg p-3 border border-gray-200">
                       <p className="text-xs text-gray-500">Trạng thái</p>
                       <p className="text-sm font-medium text-green-600">Đang chạy</p>
                     </div>
                     <div className="bg-white rounded-lg p-3 border border-gray-200">
                       <p className="text-xs text-gray-500">Tổng user</p>
                       <p className="text-sm font-medium text-gray-900">{proxyStatus?.stats.totalUsers || 0}</p>
                     </div>
                   </div>
                 </div>

                 {/* Proxy Settings Table */}
                 <div className="bg-white dark:bg-gray-800 rounded-lg shadow overflow-hidden">
                   <div className="overflow-x-auto">
                     <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                       <thead className="bg-gray-50 dark:bg-gray-700">
                         <tr>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             Tên
                           </th>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             API Key
                           </th>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             Trạng thái
                           </th>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             Proxy hiện tại
                           </th>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             Loại
                           </th>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             Giới hạn User
                           </th>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             User hiện tại
                           </th>
                           <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                             Thao tác
                           </th>
                         </tr>
                       </thead>
                       <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                         {proxySettings.map((proxy) => (
                           <tr key={proxy._id || proxy.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                             <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                               {proxy.name}
                             </td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                               {proxy.apiKey.substring(0, 8)}...
                             </td>
                             <td className="px-6 py-4 whitespace-nowrap">
                               <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                 proxy.isActive 
                                   ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                                   : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                               }`}>
                                 {proxy.isActive ? 'Hoạt động' : 'Không hoạt động'}
                               </span>
                             </td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                               {proxy.currentProxy ? (
                                 <span className="text-green-600 dark:text-green-400">
                                   {proxy.currentProxy.substring(0, 20)}...
                                 </span>
                               ) : (
                                 <span className="text-gray-400">Chưa có</span>
                               )}
                             </td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                               {proxy.isResidential ? 'Residential' : 'Datacenter'}
                             </td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                               {proxy.maxUsers || 10}
                             </td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                               <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                                 (proxy.currentUsers || 0) >= (proxy.maxUsers || 10)
                                   ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                                   : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                               }`}>
                                 {proxy.currentUsers || 0} / {proxy.maxUsers || 10}
                               </span>
                             </td>
                             <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                               <div className="flex space-x-2">
                                 <button
                                   onClick={() => handleEditProxy(proxy)}
                                   className="text-indigo-600 hover:text-indigo-900 dark:text-indigo-400 dark:hover:text-indigo-300"
                                 >
                                   Sửa
                                 </button>
                                 <button
                                   onClick={() => deleteProxySettings(proxy._id || proxy.id || '')}
                                   className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                                 >
                                   Xóa
                                 </button>
                               </div>
                             </td>
                           </tr>
                         ))}
                       </tbody>
                     </table>
                   </div>
                 </div>

                 {proxySettings.length === 0 && (
                   <div className="text-center py-8">
                     <p className="text-gray-500 dark:text-gray-400">
                       Chưa có proxy settings nào. Hãy thêm proxy đầu tiên.
                     </p>
                   </div>
                 )}
               </div>
             )}

             {/* General Settings Tab */}
             {activeTab === 'general' && hasPermission('manage_general') && (
              <div className="space-y-6">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Cài đặt chung</h1>
                  <p className="text-gray-600">Quản lý cài đặt hệ thống</p>
                </div>

                {/* Payment Information Management */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gradient-to-r from-red-500 to-pink-600 rounded-lg">
                        <CreditCard className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">Thông tin chuyển khoản</h3>
                        <p className="text-sm text-gray-600">Cấu hình thông tin ngân hàng và tài khoản chuyển khoản</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={async () => {
                          if (!confirm('Bạn có chắc muốn kiểm tra và cập nhật phiên bản mới?')) return
                          try {
                            const res = await fetch('/api/admin/update', { method: 'POST' })
                            if (res.ok) {
                              showToast('info', 'Đang cập nhật', 'Updater đã được khởi động trên server')
                            } else {
                              const err = await res.json().catch(() => ({} as any))
                              showToast('error', 'Lỗi cập nhật', err.error || 'Không thể khởi động updater')
                            }
                          } catch (e) {
                            showToast('error', 'Lỗi', 'Không thể kết nối tới server')
                          }
                        }}
                        className="px-4 py-2 rounded-lg font-medium bg-blue-600 text-white hover:bg-blue-700"
                        title="Kiểm tra manifest và cập nhật tự động"
                      >
                        Cập nhật hệ thống
                      </button>
                      <button
                        onClick={() => setIsEditingPayment(!isEditingPayment)}
                        className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                          isEditingPayment 
                            ? 'bg-gray-500 text-white hover:bg-gray-600' 
                            : 'bg-red-600 text-white hover:bg-red-700'
                        }`}
                      >
                        {isEditingPayment ? 'Hủy' : 'Chỉnh sửa'}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Payment Info Form */}
                    <div className="space-y-4">
                      {/* Bank Name */}
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                          <Building className="w-4 h-4" />
                          Tên ngân hàng
                        </label>
                        <input
                          type="text"
                          value={paymentInfo?.bankName || ''}
                          onChange={(e) => setPaymentInfo({...paymentInfo, bankName: e.target.value})}
                          disabled={!isEditingPayment}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                            'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                          } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed bg-gray-100' : ''}`}
                          placeholder="Nhập tên ngân hàng"
                        />
                      </div>

                      {/* Account Number */}
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                          <CreditCard className="w-4 h-4" />
                          Số tài khoản
                        </label>
                        <input
                          type="text"
                          value={paymentInfo?.accountNumber || ''}
                          onChange={(e) => setPaymentInfo({...paymentInfo, accountNumber: e.target.value})}
                          disabled={!isEditingPayment}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                            'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                          } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed bg-gray-100' : ''}`}
                          placeholder="Nhập số tài khoản"
                        />
                      </div>

                      {/* Account Holder */}
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                          <User className="w-4 h-4" />
                          Chủ tài khoản
                        </label>
                        <input
                          type="text"
                          value={paymentInfo?.accountHolder || ''}
                          onChange={(e) => setPaymentInfo({...paymentInfo, accountHolder: e.target.value})}
                          disabled={!isEditingPayment}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                            'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                          } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed bg-gray-100' : ''}`}
                          placeholder="Nhập tên chủ tài khoản"
                        />
                      </div>

                      {/* Transfer Content */}
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          Nội dung chuyển khoản
                        </label>
                        <div className="flex space-x-2">
                          <input
                            type="text"
                            value={paymentInfo?.transferContent || ''}
                            onChange={(e) => setPaymentInfo({...paymentInfo, transferContent: e.target.value})}
                            disabled={!isEditingPayment}
                            className={`flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                              'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                            } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed bg-gray-100' : ''}`}
                            placeholder="MAXABC123DEF456"
                          />
                          {isEditingPayment && (
                            <button
                              type="button"
                              onClick={() => setPaymentInfo({...paymentInfo, transferContent: generateTransferContent()})}
                              className="px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                              title="Tạo nội dung tự động"
                            >
                              Tạo tự động
                            </button>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          Format: MAX + RANDOM - Ví dụ: MAXABC123DEF456
                        </p>
                      </div>

                      {/* ACB Password */}
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          Password ACB
                        </label>
                        <input
                          type="password"
                          value={paymentInfo?.passwordACB || ''}
                          onChange={(e) => setPaymentInfo({...paymentInfo, passwordACB: e.target.value})}
                          disabled={!isEditingPayment}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                            'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                          } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed bg-gray-100' : ''}`}
                          placeholder="Nhập mật khẩu tài khoản ACB"
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          Mật khẩu tài khoản ngân hàng ACB
                        </p>
                      </div>

                      {/* ACB Token */}
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                          <Shield className="w-4 h-4" />
                          Token ACB
                        </label>
                        <input
                          type="password"
                          value={paymentInfo?.tokenACB || ''}
                          onChange={(e) => setPaymentInfo({...paymentInfo, tokenACB: e.target.value})}
                          disabled={!isEditingPayment}
                          className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                            'bg-white border-gray-300 text-gray-900 placeholder-gray-500'
                          } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed bg-gray-100' : ''}`}
                          placeholder="Nhập token ACB từ Web2M"
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          Mã Token tương ứng tài khoản trên API Web2M
                        </p>
                      </div>

                      {/* Save Button */}
                      {isEditingPayment && (
                        <div className="flex justify-end pt-4">
                          <button
                            onClick={savePaymentInfo}
                            disabled={isSaving}
                            className="flex items-center gap-2 px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                          >
                            {isSaving ? (
                              <>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                <span>Đang lưu...</span>
                              </>
                            ) : (
                              <>
                                <CreditCard className="w-4 h-4" />
                                <span>Lưu thông tin</span>
                              </>
                            )}
                          </button>
                        </div>
                      )}
                    </div>

                    {/* Preview */}
                    <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
                      <h4 className="text-md font-semibold mb-4">Xem trước thông tin chuyển khoản</h4>
                      {!paymentInfo ? (
                        <div className="text-center py-4">
                          <div className="w-6 h-6 border-2 border-gray-300 border-t-blue-600 rounded-full animate-spin mx-auto mb-2"></div>
                          <p className="text-gray-500 text-sm">Đang tải thông tin...</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                        <div className="flex justify-between items-center py-2 border-b border-gray-200">
                          <span className="font-semibold text-sm text-gray-700">Ngân hàng:</span>
                          <span className="text-sm font-medium text-gray-900">{paymentInfo?.bankName}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-gray-200">
                          <span className="font-semibold text-sm text-gray-700">Số tài khoản:</span>
                          <span className="text-sm font-medium text-gray-900">{paymentInfo?.accountNumber}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-gray-200">
                          <span className="font-semibold text-sm text-gray-700">Chủ tài khoản:</span>
                          <span className="text-sm font-medium text-gray-900">{paymentInfo?.accountHolder}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-gray-200">
                          <span className="font-semibold text-sm text-gray-700">Nội dung:</span>
                          <span className="text-xs font-medium text-gray-800 break-all">{paymentInfo?.transferContent}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-gray-200">
                          <span className="font-semibold text-sm text-gray-700">Password ACB:</span>
                          <span className="text-sm font-medium text-gray-900">{paymentInfo?.passwordACB ? '***' : 'Chưa cấu hình'}</span>
                        </div>
                        <div className="flex justify-between items-center py-2">
                          <span className="font-semibold text-sm text-gray-700">Token ACB:</span>
                          <span className="text-sm font-medium text-gray-900">{paymentInfo?.tokenACB ? '***' : 'Chưa cấu hình'}</span>
                        </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Telegram Notification Settings */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-lg">
                        <MessageSquare className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">Thông báo Telegram</h3>
                        <p className="text-sm text-gray-600">Cấu hình bot Telegram để nhận thông báo khi có ticket mới</p>
                      </div>
                    </div>
                    <button
                      onClick={async () => {
                        try {
                          const response = await fetch('/api/telegram/test', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' }
                          })
                          const result = await response.json()
                          
                          if (result.success) {
                            showToast('success', 'Thành công', 'Tin nhắn test đã được gửi đến Telegram!')
                          } else {
                            showToast('error', 'Lỗi', result.error || 'Không thể gửi tin nhắn test')
                          }
                        } catch (error) {
                          showToast('error', 'Lỗi', 'Không thể kết nối đến server')
                        }
                      }}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
                    >
                      Test Telegram
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Setup Instructions */}
                    <div className="space-y-4">
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 className="font-semibold text-blue-900 mb-3">Hướng dẫn cấu hình:</h4>
                        <ol className="text-sm text-blue-800 space-y-2 list-decimal list-inside">
                          <li>Tạo bot mới với <span className="font-mono bg-blue-100 px-1 rounded">@BotFather</span> trên Telegram</li>
                          <li>Lấy Bot Token từ BotFather</li>
                          <li>Lấy Chat ID bằng cách gửi tin nhắn cho <span className="font-mono bg-blue-100 px-1 rounded">@userinfobot</span></li>
                          <li>Thêm <span className="font-mono bg-blue-100 px-1 rounded">TELEGRAM_BOT_TOKEN</span> và <span className="font-mono bg-blue-100 px-1 rounded">TELEGRAM_CHAT_ID</span> vào file <span className="font-mono bg-blue-100 px-1 rounded">.env.local</span></li>
                          <li>Restart ứng dụng và test thông báo</li>
                        </ol>
                      </div>

                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                        <h4 className="font-semibold text-yellow-900 mb-2">Lưu ý:</h4>
                        <p className="text-sm text-yellow-800">
                          Xem file <span className="font-mono bg-yellow-100 px-1 rounded">TELEGRAM_SETUP.md</span> để có hướng dẫn chi tiết.
                          Nếu không cấu hình Telegram, hệ thống vẫn hoạt động bình thường.
                        </p>
                      </div>
                    </div>

                    {/* Configuration Status */}
                    <div className="space-y-4">
                      <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                        <h4 className="text-md font-semibold mb-4">Trạng thái cấu hình:</h4>
                        <div className="space-y-3">
                          <div className="flex justify-between items-center py-2 border-b border-gray-200">
                            <span className="font-semibold text-sm text-gray-700">Bot Token:</span>
                            <span className="text-sm font-medium text-orange-600">
                              ⚙️ Cần restart để kiểm tra
                            </span>
                          </div>
                          <div className="flex justify-between items-center py-2 border-b border-gray-200">
                            <span className="font-semibold text-sm text-gray-700">Chat ID:</span>
                            <span className="text-sm font-medium text-orange-600">
                              ⚙️ Cần restart để kiểm tra
                            </span>
                          </div>
                          <div className="flex justify-between items-center py-2">
                            <span className="font-semibold text-sm text-gray-700">Trạng thái:</span>
                            <span className="text-sm font-medium text-blue-600">
                              🔧 Click "Test Telegram" để kiểm tra
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <h4 className="font-semibold text-green-900 mb-2">Thông báo tự động:</h4>
                        <p className="text-sm text-green-800">
                          Khi có ticket mới, hệ thống sẽ tự động gửi thông báo đến Telegram với thông tin:
                        </p>
                        <ul className="text-sm text-green-800 mt-2 list-disc list-inside">
                          <li>Tiêu đề và nội dung ticket</li>
                          <li>Tên người tạo ticket</li>
                          <li>Chủ đề và ID ticket</li>
                          <li>Link trực tiếp đến admin panel</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Tab */}
            {activeTab === 'navigation' && hasPermission('manage_nav') && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Quản lý Menu</h1>
                    <p className="text-gray-600">Quản lý navigation menu</p>
                  </div>
                  <button className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                    <Plus className="w-4 h-4" />
                    <span>Thêm Menu</span>
                  </button>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="text-center text-gray-500 py-8">
                    <Menu className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Chức năng quản lý menu sẽ được hiển thị ở đây</p>
                  </div>
                </div>
              </div>
            )}

            {/* Subscription Downgrade Tab */}
            {activeTab === 'downgrade' && hasPermission('manage_subscriptions') && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Hạ cấp tự động</h1>
                    <p className="text-gray-600">Quản lý việc hạ cấp subscription đã hết hạn</p>
                  </div>
                  <button 
                    onClick={async () => {
                      try {
                        const response = await fetch('/api/subscription/downgrade', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' }
                        });
                        const data = await response.json();
                        if (response.ok) {
                          alert(`Đã kiểm tra và hạ cấp ${data.downgraded} subscription đã hết hạn`);
                        } else {
                          alert('Có lỗi xảy ra khi kiểm tra subscription');
                        }
                      } catch (error) {
                        alert('Có lỗi xảy ra khi kiểm tra subscription');
                      }
                    }}
                    className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    <TrendingDown className="w-4 h-4" />
                    <span>Kiểm tra ngay</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Thống kê */}
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Tổng subscription</p>
                        <p className="text-2xl font-bold text-gray-900">-</p>
                      </div>
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Crown className="w-6 h-6 text-blue-600" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Đã hết hạn</p>
                        <p className="text-2xl font-bold text-red-600">-</p>
                      </div>
                      <div className="p-2 bg-red-100 rounded-lg">
                        <TrendingDown className="w-6 h-6 text-red-600" />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Đã hạ cấp</p>
                        <p className="text-2xl font-bold text-green-600">-</p>
                      </div>
                      <div className="p-2 bg-green-100 rounded-lg">
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Thông tin hệ thống</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span className="text-sm text-gray-700">Cron job tự động hạ cấp</span>
                      </div>
                      <span className="text-sm font-medium text-green-600">Đang hoạt động</span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <span className="text-sm text-gray-700">Tần suất kiểm tra</span>
                      </div>
                      <span className="text-sm font-medium text-blue-600">Mỗi 5 phút</span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <span className="text-sm text-gray-700">Hạ cấp về gói</span>
                      </div>
                      <span className="text-sm font-medium text-purple-600">Free</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Lịch sử hạ cấp</h3>
                  <div className="text-center text-gray-500 py-8">
                    <TrendingDown className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Chưa có lịch sử hạ cấp nào</p>
                  </div>
                </div>
              </div>
            )}

            {/* SEO Tab */}
            {activeTab === 'seo' && hasPermission('manage_seo') && (
              <div className="space-y-6">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Quản lý SEO</h1>
                  <p className="text-gray-600">Quản lý SEO và thông tin website</p>
                </div>

                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="text-center text-gray-500 py-8">
                    <Globe className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>Chức năng quản lý SEO sẽ được hiển thị ở đây</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-gray-600 bg-opacity-75 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Subscription Plan Edit Modal */}
      {isEditingPlan && editingPlan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setIsEditingPlan(false)}></div>
          <div className="relative bg-white rounded-xl shadow-xl max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">
                  {editingPlan._id === 'new' ? 'Thêm gói mới' : 'Chỉnh sửa gói'}
                </h3>
                <button
                  onClick={() => setIsEditingPlan(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={(e) => {
                e.preventDefault();
                saveSubscriptionPlan();
              }} className="space-y-4">
                {/* Plan ID */}
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Mã gói *
                  </label>
                  <input
                    type="text"
                    value={editingPlan?.plan || ''}
                    onChange={(e) => setEditingPlan({...editingPlan!, plan: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium placeholder-gray-500"
                    placeholder="free, basic, premium..."
                    required
                  />
                </div>

                {/* Plan Name */}
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Tên gói *
                  </label>
                  <input
                    type="text"
                    value={editingPlan?.name || ''}
                    onChange={(e) => setEditingPlan({...editingPlan!, name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium placeholder-gray-500"
                    placeholder="Gói Miễn phí"
                    required
                  />
                </div>

                {/* Price */}
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Giá (VNĐ) *
                  </label>
                  <input
                    type="number"
                    value={editingPlan?.price || 0}
                    onChange={(e) => setEditingPlan({...editingPlan!, price: parseInt(e.target.value) || 0})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium placeholder-gray-500"
                    placeholder="0"
                    min="0"
                    required
                  />
                </div>

                {/* Duration */}
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Thời hạn (tháng) *
                  </label>
                  <input
                    type="number"
                    value={editingPlan?.duration || 1}
                    onChange={(e) => setEditingPlan({...editingPlan!, duration: parseInt(e.target.value) || 1})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium placeholder-gray-500"
                    placeholder="1"
                    min="1"
                    required
                  />
                </div>

                {/* Max Threads */}
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Luồng tối đa (-1 = không giới hạn) *
                  </label>
                  <input
                    type="number"
                    value={editingPlan?.maxThreads || 0}
                    onChange={(e) => setEditingPlan({...editingPlan!, maxThreads: parseInt(e.target.value) || 0})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium placeholder-gray-500"
                    placeholder="10"
                    min="-1"
                    required
                  />
                </div>

                {/* Features */}
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Tính năng (mỗi dòng một tính năng)
                  </label>
                  <textarea
                    value={editingPlan?.features?.join('\n') || ''}
                    onChange={(e) => setEditingPlan({...editingPlan!, features: e.target.value.split('\n').filter(f => f.trim())})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium placeholder-gray-500"
                    placeholder="Truy cập cơ bản&#10;2 luồng tối đa"
                    rows={3}
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Mô tả *
                  </label>
                  <textarea
                    value={editingPlan?.description || ''}
                    onChange={(e) => setEditingPlan({...editingPlan!, description: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium placeholder-gray-500"
                    placeholder="Nhập mô tả gói đăng ký"
                    rows={3}
                    required
                  />
                </div>

                {/* Active Status */}
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="isActive"
                    checked={editingPlan?.isActive || false}
                    onChange={(e) => setEditingPlan({...editingPlan!, isActive: e.target.checked})}
                    className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                  />
                  <label htmlFor="isActive" className="ml-2 block text-sm text-gray-900">
                    Gói đang hoạt động
                  </label>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsEditingPlan(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Hủy
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                  >
                    {editingPlan._id === 'new' ? 'Thêm gói' : 'Lưu thay đổi'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {showEditUserModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Chỉnh sửa User</h3>
              <button
                onClick={() => setShowEditUserModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={(e) => { e.preventDefault(); updateUser(); }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Username
                  </label>
                  <input
                    type="text"
                    value={userFormData.username}
                    onChange={(e) => setUserFormData({...userFormData, username: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={userFormData.email}
                    onChange={(e) => setUserFormData({...userFormData, email: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Họ tên
                  </label>
                  <input
                    type="text"
                    value={userFormData.fullName}
                    onChange={(e) => setUserFormData({...userFormData, fullName: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Role
                  </label>
                  <select
                    value={userFormData.role}
                    onChange={(e) => setUserFormData({...userFormData, role: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                  >
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                    <option value="super_admin">Super Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Trạng thái
                  </label>
                  <select
                    value={userFormData.status}
                    onChange={(e) => setUserFormData({...userFormData, status: e.target.value as 'active' | 'inactive'})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowEditUserModal(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Hủy
                  </button>
                  <button
                    type="submit"
                    disabled={isUpdatingUser}
                    className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50"
                  >
                    {isUpdatingUser ? 'Đang cập nhật...' : 'Cập nhật'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upgrade User Modal */}
      {showUpgradeUserModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Nâng cấp Gói cho User</h3>
              <button
                onClick={() => setShowUpgradeUserModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="mb-4">
              <p className="text-sm text-gray-600">
                Nâng cấp gói cho: <span className="font-semibold">{selectedUser.username}</span>
              </p>
            </div>
            
            <form onSubmit={(e) => { e.preventDefault(); upgradeUserSubscription(); }}>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Gói
                  </label>
                  <select
                    value={upgradeFormData.plan}
                    onChange={(e) => setUpgradeFormData({...upgradeFormData, plan: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                  >
                    <option value="free">Free</option>
                    <option value="basic">Basic</option>
                    <option value="premium">Premium</option>
                    <option value="enterprise">Enterprise</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-800 mb-2">
                    Thời hạn (ngày)
                  </label>
                  <input
                    type="number"
                    value={upgradeFormData.duration}
                    onChange={(e) => setUpgradeFormData({...upgradeFormData, duration: parseInt(e.target.value) || 30})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                    min="1"
                    required
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowUpgradeUserModal(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Hủy
                  </button>
                  <button
                    type="submit"
                    disabled={isUpdatingUser}
                    className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
                  >
                    {isUpdatingUser ? 'Đang nâng cấp...' : 'Nâng cấp'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Ban User Modal */}
      {showBanUserModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                {selectedUser.status === 'active' ? 'Ban User' : 'Unban User'}
              </h3>
              <button
                onClick={() => setShowBanUserModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="mb-4">
              <p className="text-sm text-gray-600">
                {selectedUser.status === 'active' 
                  ? `Bạn có chắc muốn ban user "${selectedUser.username}"?`
                  : `Bạn có chắc muốn unban user "${selectedUser.username}"?`
                }
              </p>
            </div>
            
            <div className="flex space-x-3 pt-4">
              <button
                onClick={() => setShowBanUserModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Hủy
              </button>
              <button
                onClick={banUser}
                disabled={isUpdatingUser}
                className={`flex-1 px-4 py-2 text-white rounded-lg transition-colors disabled:opacity-50 ${
                  selectedUser.status === 'active' 
                    ? 'bg-red-600 hover:bg-red-700' 
                    : 'bg-green-600 hover:bg-green-700'
                }`}
              >
                {isUpdatingUser 
                  ? 'Đang xử lý...' 
                  : selectedUser.status === 'active' ? 'Ban User' : 'Unban User'
                }
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Balance Modal */}
      {showAddBalanceModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Cộng tiền cho User</h3>
              <button
                onClick={() => setShowAddBalanceModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="mb-4">
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-medium text-blue-600">
                      {selectedUser.username.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{selectedUser.username}</p>
                    <p className="text-sm text-gray-500">{selectedUser.email}</p>
                    <p className="text-sm font-semibold text-green-600">
                      Số dư hiện tại: {(selectedUser.balance || 0).toLocaleString('vi-VN')} ₫
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-800 mb-2">
                  Số tiền cộng thêm (VND)
                </label>
                <input
                  type="number"
                  value={addBalanceAmount}
                  onChange={(e) => setAddBalanceAmount(e.target.value)}
                  placeholder="Nhập số tiền..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                  min="1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Số tiền phải lớn hơn 0
                </p>
              </div>

              {addBalanceAmount && !isNaN(Number(addBalanceAmount)) && Number(addBalanceAmount) > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mt-3">
                  <p className="text-sm text-green-800">
                    <strong>Số dư sau khi cộng:</strong> {((selectedUser.balance || 0) + Number(addBalanceAmount)).toLocaleString('vi-VN')} ₫
                  </p>
                </div>
              )}
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={() => setShowAddBalanceModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Hủy
              </button>
              <button
                onClick={addBalanceToUser}
                disabled={isUpdatingUser || !addBalanceAmount || isNaN(Number(addBalanceAmount)) || Number(addBalanceAmount) <= 0}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isUpdatingUser ? 'Đang xử lý...' : 'Cộng tiền'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Proxy Settings Modal */}
      {isEditingProxy && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {proxyFormData.id ? 'Sửa Proxy Setting' : 'Thêm Proxy Setting'}
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Tên Proxy
                </label>
                <input
                  type="text"
                  value={proxyFormData.name}
                  onChange={(e) => setProxyFormData({...proxyFormData, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-gray-100"
                  placeholder="Nhập tên proxy (ví dụ: Proxy 1)"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  API Key
                </label>
                <input
                  type="password"
                  value={proxyFormData.apiKey}
                  onChange={(e) => setProxyFormData({...proxyFormData, apiKey: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-gray-100"
                  placeholder="Nhập API key từ NetProxy.io"
                />
              </div>

              <div className="flex items-center space-x-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={proxyFormData.isActive}
                    onChange={(e) => setProxyFormData({...proxyFormData, isActive: e.target.checked})}
                    className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                    Hoạt động
                  </span>
                </label>

                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={proxyFormData.isResidential}
                    onChange={(e) => setProxyFormData({...proxyFormData, isResidential: e.target.checked})}
                    className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                    Residential
                  </span>
                </label>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Giới hạn số User
                </label>
                <input
                  type="number"
                  value={proxyFormData.maxUsers}
                  onChange={(e) => setProxyFormData({...proxyFormData, maxUsers: parseInt(e.target.value) || 10})}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-gray-100"
                  placeholder="Số lượng user tối đa (mặc định: 10)"
                  min="1"
                  max="100"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setIsEditingProxy(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600"
              >
                Hủy
              </button>
              <button
                onClick={saveProxySettings}
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
              >
                {proxyFormData.id ? 'Cập nhật' : 'Thêm'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Welcome Popup Settings Tab */}
      {activeTab === 'welcome-popup' && hasPermission('manage_general') && (
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Quản lý Popup Thông báo</h1>
            <p className="text-gray-600">Cài đặt popup chào mừng người dùng</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="space-y-6">
              {/* Enable/Disable */}
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Bật/Tắt Popup</h3>
                  <p className="text-sm text-gray-600">Hiển thị popup thông báo cho người dùng</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={welcomePopupSettings.enabled}
                    onChange={(e) => setWelcomePopupSettings({...welcomePopupSettings, enabled: e.target.checked})}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                </label>
              </div>

              {/* Title */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-2">
                  Tiêu đề
                </label>
                <input
                  type="text"
                  value={welcomePopupSettings.title}
                  onChange={(e) => setWelcomePopupSettings({...welcomePopupSettings, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-400 bg-white"
                  placeholder="Nhập tiêu đề popup"
                />
              </div>

              {/* Message */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-2">
                  Nội dung thông báo
                </label>
                <textarea
                  value={welcomePopupSettings.message}
                  onChange={(e) => setWelcomePopupSettings({...welcomePopupSettings, message: e.target.value})}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-400 bg-white resize-none"
                  placeholder="Nhập nội dung thông báo"
                />
              </div>

              {/* Show Don't Show Again */}
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-gray-800">Hiển thị checkbox "Không hiển thị lại"</h3>
                  <p className="text-xs text-gray-600">Cho phép người dùng ẩn popup vĩnh viễn</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={welcomePopupSettings.showDontShowAgain}
                    onChange={(e) => setWelcomePopupSettings({...welcomePopupSettings, showDontShowAgain: e.target.checked})}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                </label>
              </div>

              {/* Show Locations */}
              <div>
                <h3 className="text-sm font-semibold text-gray-800 mb-3">Hiển thị tại</h3>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={welcomePopupSettings.showOnLogin}
                      onChange={(e) => setWelcomePopupSettings({...welcomePopupSettings, showOnLogin: e.target.checked})}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="ml-3 text-sm text-gray-800">Trang đăng nhập</span>
                  </label>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={welcomePopupSettings.showOnDashboard}
                      onChange={(e) => setWelcomePopupSettings({...welcomePopupSettings, showOnDashboard: e.target.checked})}
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span className="ml-3 text-sm text-gray-800">Dashboard</span>
                  </label>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center space-x-4 pt-6 border-t border-gray-200">
                <button
                  onClick={saveWelcomePopupSettings}
                  disabled={isLoadingWelcomeSettings}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  <Settings className="w-4 h-4" />
                  <span>{isLoadingWelcomeSettings ? 'Đang lưu...' : 'Lưu cài đặt'}</span>
                </button>

                <button
                  onClick={resetAllPopupDismissals}
                  className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Xóa lịch sử ẩn</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      <div className="fixed top-6 right-6 z-50 space-y-4 max-w-sm">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`w-full backdrop-blur-sm bg-white/95 shadow-2xl rounded-2xl pointer-events-auto border overflow-hidden transform transition-all duration-700 ease-out animate-in hover:scale-105 hover:shadow-3xl ${
              toast.type === 'success' ? 'border-green-200 shadow-green-500/20 hover:shadow-green-500/30' :
              toast.type === 'error' ? 'border-red-200 shadow-red-500/20 hover:shadow-red-500/30' :
              toast.type === 'warning' ? 'border-yellow-200 shadow-yellow-500/20 hover:shadow-yellow-500/30' :
              'border-blue-200 shadow-blue-500/20 hover:shadow-blue-500/30'
            }`}
          >
            <div className="p-5">
              <div className="flex items-center">
                <div className={`flex-shrink-0 p-3 rounded-full animate-pulse ${
                  toast.type === 'success' ? 'bg-gradient-to-r from-green-400 to-green-500 shadow-lg shadow-green-500/50' :
                  toast.type === 'error' ? 'bg-gradient-to-r from-red-400 to-red-500 shadow-lg shadow-red-500/50' :
                  toast.type === 'warning' ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 shadow-lg shadow-yellow-500/50' :
                  'bg-gradient-to-r from-blue-400 to-blue-500 shadow-lg shadow-blue-500/50'
                }`}>
                  {toast.type === 'success' && (
                    <CheckCircle className="h-6 w-6 text-white" />
                  )}
                  {toast.type === 'error' && (
                    <XCircle className="h-6 w-6 text-white" />
                  )}
                  {toast.type === 'warning' && (
                    <Clock className="h-6 w-6 text-white" />
                  )}
                  {toast.type === 'info' && (
                    <Eye className="h-6 w-6 text-white" />
                  )}
                </div>
                <div className="ml-4 flex-1">
                  <p className="text-base font-bold text-gray-900 mb-1">
                    {toast.title}
                  </p>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {toast.message}
                  </p>
                </div>
                <div className="ml-3 flex-shrink-0">
                  <button
                    className="inline-flex text-gray-400 hover:text-gray-700 transition-all duration-200 p-2 rounded-full hover:bg-gray-100/80 hover:scale-110 active:scale-95"
                    onClick={() => removeToast(toast.id)}
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
            
            {/* Animated progress bar */}
            <div className="h-1 bg-gray-100 relative overflow-hidden">
              <div 
                className={`absolute top-0 left-0 h-full w-full ${
                  toast.type === 'success' ? 'bg-gradient-to-r from-green-400 to-green-600' :
                  toast.type === 'error' ? 'bg-gradient-to-r from-red-400 to-red-600' :
                  toast.type === 'warning' ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' :
                  'bg-gradient-to-r from-blue-400 to-blue-600'
                }`}
                style={{
                  animation: 'toast-progress 4s linear forwards'
                }}
              ></div>
            </div>
          </div>
        ))}
      </div>
      
      <style jsx>{`
        @keyframes toast-progress {
          from { 
            transform: translateX(0%);
          }
          to { 
            transform: translateX(-100%);
          }
        }
        
        .animate-in {
          animation: slide-in-from-right 0.7s ease-out;
        }
        
        @keyframes slide-in-from-right {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0%);
            opacity: 1;
          }
        }
      `}</style>
    </div>
  )
} 