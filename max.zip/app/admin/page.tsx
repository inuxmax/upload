'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { 
  Settings, Users, Database, Globe, BarChart3, Activity, Target, Lock, Unlock, Download, Upload, Filter, Star, Crown, Home, Menu, X, EyeOff, AlertCircle, UserCheck, UserX, TrendingUp, Edit, LogOut, Bell, Grid3X3, List, MoreVertical, Trash2, Sun, Moon, Mail, Key, Cookie, Hash, Copy, Shield, Zap, CreditCard, Building, User, FileText
} from 'lucide-react'
import { useTheme } from '../../contexts/ThemeContext'
import { useNotification } from '../../components/NotificationSystem'

interface AdminSettings {
  globalMaxThreads: number;
  systemStatus: 'active' | 'maintenance' | 'offline';
  maintenanceMessage: string;
  allowUserThreadSettings: boolean;
  defaultUserThreads: number;
}

interface PaymentInfo {
  _id?: string;
  bankName: string;
  accountNumber: string;
  accountHolder: string;
  transferContent: string;
  isActive: boolean;
}

export default function AdminPanel() {
  const router = useRouter()
  const { theme, toggleTheme } = useTheme()
  const { addNotification } = useNotification()
  const [admin, setAdmin] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [settings, setSettings] = useState<AdminSettings>({
    globalMaxThreads: 50,
    systemStatus: 'active',
    maintenanceMessage: '',
    allowUserThreadSettings: true,
    defaultUserThreads: 10
  })
  const [isSaving, setIsSaving] = useState(false)
  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo>({
    bankName: 'ACB Bank',
    accountNumber: '123456789',
    accountHolder: 'CÔNG TY ABC',
    transferContent: 'NAP688f3e936f5f9a834e839cba',
    isActive: true
  });
  const [isEditingPayment, setIsEditingPayment] = useState(false);

  // Authentication check and load settings
  useEffect(() => {
    const token = localStorage.getItem('adminToken')
    const adminData = localStorage.getItem('admin')
    
    if (!token || !adminData) {
      router.push('/admin/auth')
      return
    }
    
    try {
      setAdmin(JSON.parse(adminData))
      loadAdminSettings()
      loadPaymentInfo()
    } catch (error) {
      localStorage.removeItem('adminToken')
      localStorage.removeItem('admin')
      router.push('/admin/auth')
    }
  }, [router])

  const loadAdminSettings = async () => {
    try {
      const response = await fetch('/api/admin/settings', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setSettings(data)
      }
    } catch (error) {
      console.error('Error loading admin settings:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadPaymentInfo = async () => {
    try {
      const response = await fetch('/api/admin/payment-info', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setPaymentInfo(data)
      }
    } catch (error) {
      console.error('Error loading payment info:', error)
    }
  }

  const saveAdminSettings = async () => {
    setIsSaving(true)
    
    try {
      const response = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        },
        body: JSON.stringify(settings)
      })
      
      if (response.ok) {
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã lưu cài đặt admin thành công!'
        })
      } else {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể lưu cài đặt. Vui lòng thử lại!'
        })
      }
    } catch (error) {
      console.error('Error saving admin settings:', error)
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể lưu cài đặt. Vui lòng thử lại!'
      })
    } finally {
      setIsSaving(false)
    }
  }

  const savePaymentInfo = async () => {
    setIsSaving(true)
    
    try {
      const response = await fetch('/api/admin/payment-info', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        },
        body: JSON.stringify(paymentInfo)
      })
      
      if (response.ok) {
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã cập nhật thông tin chuyển khoản thành công!'
        })
        setIsEditingPayment(false)
        await loadPaymentInfo()
      } else {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể cập nhật thông tin chuyển khoản. Vui lòng thử lại!'
        })
      }
    } catch (error) {
      console.error('Error saving payment info:', error)
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể cập nhật thông tin chuyển khoản. Vui lòng thử lại!'
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('adminToken')
    localStorage.removeItem('admin')
    router.push('/admin/auth')
  }

  // Add CSS for slider
  React.useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .slider::-webkit-slider-thumb {
        appearance: none;
        height: 16px;
        width: 16px;
        border-radius: 50%;
        background: #3b82f6;
        cursor: pointer;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      }
      .slider::-moz-range-thumb {
        height: 16px;
        width: 16px;
        border-radius: 50%;
        background: #3b82f6;
        cursor: pointer;
        border: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      }
    `;
    document.head.appendChild(style);
    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-gray-600 dark:text-gray-300 text-xl font-medium">Đang tải...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-r from-red-600 to-pink-700 rounded-lg shadow-lg">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">Admin Panel</h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">Quản lý hệ thống</p>
              </div>
            </div>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5" />
                ) : (
                  <Moon className="w-5 h-5" />
                )}
              </button>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-red-500 to-pink-600 rounded-full flex items-center justify-center">
                  <Crown className="w-4 h-4 text-white" />
                </div>
                <div className="hidden sm:block">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{admin?.username || 'Admin'}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Administrator</p>
                </div>
              </div>
              <button 
                onClick={handleLogout}
                className="flex items-center space-x-2 px-4 py-2 text-sm text-red-600 hover:text-red-700 font-medium hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Đăng xuất</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Menu */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <button
            onClick={() => router.push('/admin/subscription-plans')}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300 group"
          >
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg group-hover:scale-110 transition-transform">
                <Crown className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Gói đăng ký</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Quản lý các gói</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => router.push('/admin/users')}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300 group"
          >
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Quản lý User</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Danh sách người dùng</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => router.push('/admin/accounts')}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300 group"
          >
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg group-hover:scale-110 transition-transform">
                <Database className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Tài khoản FB</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Quản lý tài khoản</p>
              </div>
            </div>
          </button>

          <button
            onClick={() => router.push('/admin/settings')}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300 group"
          >
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-lg group-hover:scale-110 transition-transform">
                <Settings className="w-6 h-6 text-white" />
              </div>
              <div className="text-left">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Cài đặt</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">Cấu hình hệ thống</p>
              </div>
            </div>
          </button>
        </div>

        {/* Thread Management */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 mb-8">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Quản lý đa luồng</h2>
              <p className="text-gray-600 dark:text-gray-400">Cấu hình số luồng tối đa cho toàn hệ thống</p>
            </div>
          </div>

                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             {/* Global Thread Settings */}
             <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl p-6 border border-cyan-100">
               <h3 className="text-lg font-semibold text-gray-900 mb-4">Cài đặt toàn cục</h3>
               
               <div className="space-y-4">
                 <div>
                   <label className="block text-sm font-medium text-gray-700 mb-2">
                     Số luồng tối đa toàn hệ thống
                   </label>
                   <div className="flex items-center space-x-3">
                     <input
                       type="range"
                       min="10"
                       max="100"
                       value={settings.globalMaxThreads}
                       onChange={(e) => setSettings(prev => ({ ...prev, globalMaxThreads: parseInt(e.target.value) }))}
                       className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                     />
                     <span className="text-sm font-medium text-gray-700 min-w-[3rem] text-center">
                       {settings.globalMaxThreads}
                     </span>
                   </div>
                   <p className="text-xs text-gray-500 mt-1">Tối đa 100 luồng cho toàn hệ thống</p>
                 </div>

                 <div>
                   <label className="block text-sm font-medium text-gray-700 mb-2">
                     Số luồng mặc định cho user mới
                   </label>
                   <div className="flex items-center space-x-3">
                     <input
                       type="range"
                       min="1"
                       max="50"
                       value={settings.defaultUserThreads}
                       onChange={(e) => setSettings(prev => ({ ...prev, defaultUserThreads: parseInt(e.target.value) }))}
                       className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                     />
                     <span className="text-sm font-medium text-gray-700 min-w-[2rem] text-center">
                       {settings.defaultUserThreads}
                     </span>
                   </div>
                   <p className="text-xs text-gray-500 mt-1">Số luồng mặc định khi user đăng ký</p>
                 </div>

                 <label className="flex items-center space-x-3 p-4 bg-white rounded-lg border border-gray-200 cursor-pointer hover:bg-gray-50 transition-colors">
                   <input
                     type="checkbox"
                     checked={settings.allowUserThreadSettings}
                     onChange={(e) => setSettings(prev => ({ ...prev, allowUserThreadSettings: e.target.checked }))}
                     className="w-5 h-5 text-cyan-600 rounded focus:ring-cyan-500"
                   />
                   <span className="text-gray-700 font-medium">Cho phép user tùy chỉnh số luồng</span>
                 </label>
               </div>
             </div>

             {/* System Status */}
             <div className="bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl p-6 border border-emerald-100">
               <h3 className="text-lg font-semibold text-gray-900 mb-4">Trạng thái hệ thống</h3>
               
               <div className="space-y-4">
                 <div>
                   <label className="block text-sm font-medium text-gray-700 mb-2">
                     Trạng thái hệ thống
                   </label>
                   <select
                     value={settings.systemStatus}
                     onChange={(e) => setSettings(prev => ({ ...prev, systemStatus: e.target.value as 'active' | 'maintenance' | 'offline' }))}
                     className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-gray-900"
                   >
                     <option value="active">Hoạt động</option>
                     <option value="maintenance">Bảo trì</option>
                     <option value="offline">Tắt</option>
                   </select>
                 </div>

                 <div>
                   <label className="block text-sm font-medium text-gray-700 mb-2">
                     Thông báo bảo trì
                   </label>
                   <textarea
                     value={settings.maintenanceMessage}
                     onChange={(e) => setSettings(prev => ({ ...prev, maintenanceMessage: e.target.value }))}
                     placeholder="Nhập thông báo bảo trì..."
                     className="w-full px-4 py-3 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-gray-900 resize-none"
                     rows={3}
                   />
                 </div>
               </div>
             </div>
           </div>

           {/* Payment Information */}
           <div className="mt-6">
             <div className="bg-gradient-to-r from-red-50 to-pink-50 rounded-xl p-6 border border-red-100">
               <div className="flex items-center justify-between mb-4">
                 <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                   <CreditCard className="w-5 h-5" />
                   Thông tin chuyển khoản
                 </h3>
                 <button
                   onClick={() => setIsEditingPayment(!isEditingPayment)}
                   className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                     isEditingPayment 
                       ? 'bg-gray-500 text-white hover:bg-gray-600' 
                       : 'bg-red-600 text-white hover:bg-red-700'
                   }`}
                 >
                   {isEditingPayment ? 'Hủy' : 'Chỉnh sửa'}
                 </button>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 {/* Payment Info Form */}
                 <div className="space-y-4">
                   {/* Bank Name */}
                   <div>
                     <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                       <Building className="w-4 h-4" />
                       Tên ngân hàng
                     </label>
                     <input
                       type="text"
                       value={paymentInfo.bankName}
                       onChange={(e) => setPaymentInfo({...paymentInfo, bankName: e.target.value})}
                       disabled={!isEditingPayment}
                       className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                         theme === 'dark' 
                           ? 'bg-gray-700 border-gray-600 text-white' 
                           : 'bg-white border-gray-300 text-gray-900'
                       } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed' : ''}`}
                     />
                   </div>

                   {/* Account Number */}
                   <div>
                     <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                       <CreditCard className="w-4 h-4" />
                       Số tài khoản
                     </label>
                     <input
                       type="text"
                       value={paymentInfo.accountNumber}
                       onChange={(e) => setPaymentInfo({...paymentInfo, accountNumber: e.target.value})}
                       disabled={!isEditingPayment}
                       className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                         theme === 'dark' 
                           ? 'bg-gray-700 border-gray-600 text-white' 
                           : 'bg-white border-gray-300 text-gray-900'
                       } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed' : ''}`}
                     />
                   </div>

                   {/* Account Holder */}
                   <div>
                     <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                       <User className="w-4 h-4" />
                       Chủ tài khoản
                     </label>
                     <input
                       type="text"
                       value={paymentInfo.accountHolder}
                       onChange={(e) => setPaymentInfo({...paymentInfo, accountHolder: e.target.value})}
                       disabled={!isEditingPayment}
                       className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                         theme === 'dark' 
                           ? 'bg-gray-700 border-gray-600 text-white' 
                           : 'bg-white border-gray-300 text-gray-900'
                       } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed' : ''}`}
                     />
                   </div>

                   {/* Transfer Content */}
                   <div>
                     <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                       <FileText className="w-4 h-4" />
                       Nội dung chuyển khoản
                     </label>
                     <input
                       type="text"
                       value={paymentInfo.transferContent}
                       onChange={(e) => setPaymentInfo({...paymentInfo, transferContent: e.target.value})}
                       disabled={!isEditingPayment}
                       className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent ${
                         theme === 'dark' 
                           ? 'bg-gray-700 border-gray-600 text-white' 
                           : 'bg-white border-gray-300 text-gray-900'
                       } ${!isEditingPayment ? 'opacity-50 cursor-not-allowed' : ''}`}
                     />
                   </div>

                   {/* Save Button */}
                   {isEditingPayment && (
                     <div className="flex justify-end pt-4">
                       <button
                         onClick={savePaymentInfo}
                         disabled={isSaving}
                         className="flex items-center gap-2 px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                       >
                         {isSaving ? (
                           <>
                             <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                             <span>Đang lưu...</span>
                           </>
                         ) : (
                           <>
                             <CreditCard className="w-4 h-4" />
                             <span>Lưu thông tin</span>
                           </>
                         )}
                       </button>
                     </div>
                   )}
                 </div>

                 {/* Preview */}
                 <div className="bg-white rounded-xl p-6 border border-gray-200">
                   <h4 className="text-md font-semibold mb-4">Xem trước thông tin chuyển khoản</h4>
                   <div className="space-y-3">
                     <div className="flex justify-between items-center py-2 border-b border-gray-200">
                       <span className="font-medium text-sm">Ngân hàng:</span>
                       <span className="text-sm">{paymentInfo.bankName}</span>
                     </div>
                     <div className="flex justify-between items-center py-2 border-b border-gray-200">
                       <span className="font-medium text-sm">Số tài khoản:</span>
                       <span className="text-sm">{paymentInfo.accountNumber}</span>
                     </div>
                     <div className="flex justify-between items-center py-2 border-b border-gray-200">
                       <span className="font-medium text-sm">Chủ tài khoản:</span>
                       <span className="text-sm">{paymentInfo.accountHolder}</span>
                     </div>
                     <div className="flex justify-between items-center py-2">
                       <span className="font-medium text-sm">Nội dung:</span>
                       <span className="text-xs text-gray-600 break-all">{paymentInfo.transferContent}</span>
                     </div>
                   </div>
                 </div>
               </div>
             </div>
           </div>

          {/* Save Button */}
          <div className="flex justify-end mt-6">
            <button
              onClick={saveAdminSettings}
              disabled={isSaving}
              className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-lg hover:from-cyan-600 hover:to-blue-700 transition-all duration-300 shadow-md hover:shadow-lg disabled:opacity-50 font-medium"
            >
              {isSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Đang lưu...</span>
                </>
              ) : (
                <>
                  <Settings className="w-4 h-4" />
                  <span>Lưu cài đặt</span>
                </>
              )}
            </button>
          </div>
        </div>

        

        {/* System Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg">
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Tổng số user</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">1,234</p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-emerald-500 to-green-600 rounded-lg">
                <Database className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Tài khoản Facebook</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">5,678</p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Luồng đang chạy</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{settings.globalMaxThreads}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 