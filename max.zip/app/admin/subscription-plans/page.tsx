'use client';

import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Save, X, Crown, Star, Zap, Users } from 'lucide-react';
import { useTheme } from '../../../contexts/ThemeContext';
import { useNotification } from '../../../components/NotificationSystem';

interface SubscriptionPlan {
  _id: string;
  name: string;
  plan: string; // Cho phép nhập giá trị tự do
  duration: number;
  price: number;
  currency: string;
  maxThreads: number;
  features: string[];
  description: string;
  isActive: boolean;
}

export default function AdminSubscriptionPlans() {
  const { theme } = useTheme();
  const { addNotification } = useNotification();
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    plan: 'basic',
    duration: 1,
    price: 0,
    currency: 'VND',
    maxThreads: 2,
    description: '',
    features: [''],
    isActive: true
  });

  useEffect(() => {
    loadPlans();
  }, []);

  const loadPlans = async () => {
    try {
      const response = await fetch('/api/admin/subscription-plans');
      
      if (response.ok) {
        const data = await response.json();
        setPlans(data);
      } else {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể tải danh sách gói!'
        });
      }
    } catch (error) {
      console.error('Error loading plans:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể tải danh sách gói!'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Client-side validate duplicate plan code when creating or changing code
      const normalizedNewPlan = formData.plan.trim();
      const isDuplicatePlan = plans.some((p) => {
        // when creating new
        if (!editingPlan) return p.plan.trim() === normalizedNewPlan;
        // when editing, allow same record to keep same code
        const isSameRecord = p._id === editingPlan._id;
        return !isSameRecord && p.plan.trim() === normalizedNewPlan;
      });
      if (isDuplicatePlan) {
        addNotification({
          type: 'error',
          title: 'Mã gói đã tồn tại',
          message: 'Vui lòng chọn một mã gói (plan) khác, mã hiện tại đã tồn tại.'
        });
        return;
      }

      const url = editingPlan 
        ? `/api/admin/subscription-plans/${editingPlan._id}`
        : '/api/admin/subscription-plans';
      
      const method = editingPlan ? 'PUT' : 'POST';
      
      const adminToken = typeof window !== 'undefined' ? localStorage.getItem('admin_token') : null;
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(adminToken ? { Authorization: `Bearer ${adminToken}` } : {})
        },
        credentials: 'include',
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: editingPlan ? 'Đã cập nhật gói!' : 'Đã tạo gói mới!'
        });
        setShowModal(false);
        setEditingPlan(null);
        resetForm();
        loadPlans();
      } else {
        const errorData = await response.json().catch(() => ({} as any));
        const statusText = response.status === 409 
          ? 'Mã gói đã tồn tại. Vui lòng chọn mã khác.' 
          : (errorData?.error || 'Không thể lưu gói!');
        throw new Error(statusText);
      }
    } catch (error) {
      console.error('Error saving plan:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: error instanceof Error ? error.message : 'Không thể lưu gói!'
      });
    }
  };

  const handleDelete = async (planId: string) => {
    // Tìm plan để hiển thị tên trong confirmation
    const planToDelete = plans.find(p => p._id === planId);
    const planName = planToDelete ? planToDelete.name : 'gói này';
    
    if (!confirm(`Bạn có chắc muốn xóa "${planName}"?\n\nHành động này không thể hoàn tác!`)) return;

    try {
      const token = localStorage.getItem('admin_token');
      const response = await fetch(`/api/admin/subscription-plans/${planId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { 'Authorization': `Bearer ${token}` } : {})
        },
        credentials: 'include'
      });

      if (response.ok) {
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: `Đã xóa gói "${planName}"!`
        });
        loadPlans();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to delete plan');
      }
    } catch (error) {
      console.error('Error deleting plan:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: `Không thể xóa gói "${planName}"!`
      });
    }
  };

  const handleEdit = (plan: SubscriptionPlan) => {
    setEditingPlan(plan);
    setFormData({
      name: plan.name,
      plan: plan.plan,
      duration: plan.duration,
      price: plan.price,
      currency: plan.currency,
      maxThreads: plan.maxThreads,
      description: plan.description,
      features: plan.features,
      isActive: plan.isActive
    });
    setShowModal(true);
  };

  const handleAdd = () => {
    setEditingPlan(null);
    resetForm();
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      plan: 'basic',
      duration: 1,
      price: 0,
      currency: 'VND',
      maxThreads: 2,
      description: '',
      features: [''],
      isActive: true
    });
  };

  const addFeature = () => {
    setFormData(prev => ({
      ...prev,
      features: [...prev.features, '']
    }));
  };

  const removeFeature = (index: number) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.filter((_, i) => i !== index)
    }));
  };

  const updateFeature = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.map((feature, i) => i === index ? value : feature)
    }));
  };

  const getPlanIcon = (plan: string) => {
    // Handle common plan types
    if (plan.toLowerCase().includes('free') || plan.toLowerCase().includes('miễn phí')) {
      return <Users className="w-5 h-5" />;
    }
    if (plan.toLowerCase().includes('basic') || plan.toLowerCase().includes('cơ bản')) {
      return <Zap className="w-5 h-5" />;
    }
    if (plan.toLowerCase().includes('premium') || plan.toLowerCase().includes('cao cấp')) {
      return <Star className="w-5 h-5" />;
    }
    if (plan.toLowerCase().includes('enterprise') || plan.toLowerCase().includes('doanh nghiệp')) {
      return <Crown className="w-5 h-5" />;
    }
    // Default icon for any other plan names
    return <Star className="w-5 h-5" />;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Đang tải...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-blue-600 dark:text-blue-400">
              Quản lý gói đăng ký
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Quản lý các gói đăng ký và tính năng
            </p>
          </div>
          <button
            onClick={handleAdd}
            className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-300 shadow-md hover:shadow-lg"
          >
            <Plus className="w-5 h-5" />
            <span>Thêm gói mới</span>
          </button>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div
              key={plan._id}
              className={`bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden ${
                !plan.isActive ? 'opacity-60' : ''
              }`}
            >
              {/* Header */}
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-6 text-white">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2 bg-white/20 rounded-lg">
                    {getPlanIcon(plan.plan)}
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleEdit(plan)}
                      className="p-2 hover:bg-white/20 rounded-lg transition-colors text-white/80 hover:text-white"
                      title="Chỉnh sửa gói"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(plan._id)}
                      className="p-2 bg-red-500/20 hover:bg-red-500 rounded-lg transition-colors text-red-300 hover:text-white border border-red-400/30"
                      title="Xóa gói"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                <p className="text-white/80 text-sm">{plan.description}</p>
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="text-center mb-4">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {plan.price === 0 ? 'Miễn phí' : formatPrice(plan.price)}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    / {plan.duration} tháng
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Mã gói:</span>
                    <span className="font-medium text-gray-900 dark:text-gray-100">{plan.plan}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Thời hạn:</span>
                    <span className="font-medium text-gray-900 dark:text-gray-100">{plan.duration} tháng</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Luồng tối đa:</span>
                    <span className="font-medium text-gray-900 dark:text-gray-100">
                      {plan.maxThreads === -1 ? 'Không giới hạn' : plan.maxThreads}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600 dark:text-gray-400">Trạng thái:</span>
                    <span className={`font-medium ${plan.isActive ? 'text-green-600' : 'text-red-600'}`}>
                      {plan.isActive ? 'Hoạt động' : 'Tạm dừng'}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 text-sm">Tính năng:</h4>
                  <ul className="space-y-1">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
                <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                  {editingPlan ? 'Chỉnh sửa gói' : 'Thêm gói mới'}
                </h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">
                      Tên gói
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-gray-100 font-medium placeholder-gray-500 dark:placeholder-gray-400"
                      placeholder="Nhập tên gói"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">
                      Mã gói
                    </label>
                    <input
                      type="text"
                      value={formData.plan}
                      onChange={(e) => setFormData(prev => ({ ...prev, plan: e.target.value }))}
                      className="w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-gray-100 font-medium placeholder-gray-500 dark:placeholder-gray-400"
                      placeholder="Nhập mã gói"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">
                      Giá (VND)
                    </label>
                    <input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData(prev => ({ ...prev, price: Number(e.target.value) }))}
                      className="w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-gray-100 font-medium placeholder-gray-500 dark:placeholder-gray-400"
                      placeholder="0"
                      min="0"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">
                      Thời hạn (tháng)
                    </label>
                    <input
                      type="number"
                      value={formData.duration}
                      onChange={(e) => setFormData(prev => ({ ...prev, duration: Number(e.target.value) }))}
                      className="w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-gray-100 font-medium placeholder-gray-500 dark:placeholder-gray-400"
                      placeholder="1"
                      min="1"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">
                      Luồng tối đa (-1 = không giới hạn)
                    </label>
                    <input
                      type="number"
                      value={formData.maxThreads}
                      onChange={(e) => setFormData(prev => ({ ...prev, maxThreads: Number(e.target.value) }))}
                      className="w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-gray-100 font-medium placeholder-gray-500 dark:placeholder-gray-400"
                      placeholder="2"
                      min="-1"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">
                    Tính năng (mỗi dòng một tính năng)
                  </label>
                  <div className="space-y-2">
                    {formData.features.map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <input
                          type="text"
                          value={feature}
                          onChange={(e) => updateFeature(index, e.target.value)}
                          className="flex-1 px-4 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-gray-100 font-medium placeholder-gray-500 dark:placeholder-gray-400"
                          placeholder="Nhập tính năng"
                        />
                        {formData.features.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeFeature(index)}
                            className="p-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                    <button
                      type="button"
                      onClick={addFeature}
                      className="flex items-center space-x-2 px-4 py-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Thêm tính năng</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-800 dark:text-gray-200 mb-2">
                    Mô tả
                  </label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    className="w-full px-4 py-3 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900 dark:text-gray-100 font-medium placeholder-gray-500 dark:placeholder-gray-400"
                    placeholder="Nhập mô tả gói"
                    rows={3}
                    required
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="isActive"
                    checked={formData.isActive}
                    onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                    className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                  />
                  <label htmlFor="isActive" className="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                    Gói đang hoạt động
                  </label>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between pt-6 border-t border-gray-200 dark:border-gray-700">
                  {/* Left side - Delete button (only when editing) */}
                  <div style={{ minWidth: '120px' }}>
                    <button
                      type="button"
                      onClick={() => {
                        if (editingPlan) {
                          setShowModal(false);
                          handleDelete(editingPlan._id);
                        } else {
                          alert('Không có gói để xóa!');
                        }
                      }}
                      className="flex items-center space-x-2 px-6 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors font-medium"
                                              style={{ display: 'flex', visibility: 'visible' }}
                    >
                      <Trash2 className="w-4 h-4" />
                      <span>Xóa gói</span>
                    </button>
                  </div>
                  
                  {/* Right side - Cancel and Save buttons */}
                  <div className="flex items-center space-x-3">
                    <button
                      type="button"
                      onClick={() => setShowModal(false)}
                      className="px-6 py-3 text-gray-700 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors font-medium"
                    >
                      Hủy
                    </button>
                    <button
                      type="submit"
                      className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-300 shadow-md hover:shadow-lg font-medium"
                    >
                      <Save className="w-4 h-4" />
                      <span>{editingPlan ? 'Cập nhật' : 'Tạo gói'}</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}