'use client'

import React, { useEffect, useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Send, MessageSquarePlus, Loader2, Eye, Clock, CheckCircle, MessageSquare, Plus, Search, Filter, X, Users, Lock, Unlock } from 'lucide-react'

type Ticket = { 
  _id: string; 
  title: string; 
  status: 'open'|'closed'; 
  subject?: string;
  orderId?: string;
  createdAt: string; 
  updatedAt: string;
  lastMessageAt?: string;
  user?: {
    username: string;
    email: string;
  };
  messageCount?: number;
}

type TicketMessage = { 
  _id?: string; 
  senderType: 'user'|'admin'; 
  content: string; 
  imageUrl?: string; // URL của ảnh nếu có
  createdAt?: string;
  tempId?: number; // Temporary ID for optimistic updates
}

export default function AdminTicketsPage() {
  const router = useRouter()
  const [tickets, setTickets] = useState<Ticket[]>([])
  const [loading, setLoading] = useState(true)
  const [admin, setAdmin] = useState<any>(null)
  const [activeId, setActiveId] = useState<string | null>(null)
  const [messages, setMessages] = useState<TicketMessage[]>([])
  const [msg, setMsg] = useState('')
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [showImageModal, setShowImageModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [subjectFilter, setSubjectFilter] = useState('all')
  const listRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const checkAdminAuth = async () => {
    try {
      const response = await fetch('/api/admin/check')
      if (response.ok) {
        const data = await response.json()
        setAdmin(data.admin)
        return true
      } else {
        // Redirect to admin login if not authenticated
        window.location.href = '/admin/auth'
        return false
      }
    } catch (error) {
      console.error('Admin auth check failed:', error)
      window.location.href = '/admin/auth'
      return false
    }
  }

  const loadTickets = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/tickets', { 
        headers: { Authorization: `Bearer ${localStorage.getItem('admin_token')}` } 
      })
      const j = await res.json()
      if (j.success) setTickets(j.tickets)
    } catch (error) {
      console.error('Error loading tickets:', error)
    }
    setLoading(false)
  }

  const [sseConnection, setSseConnection] = useState<EventSource | null>(null)

  useEffect(() => {
    checkAdminAuth().then((isAuth) => {
      if (isAuth) {
        loadTickets()
      }
    })
  }, [])

    const openTicket = async (id: string) => {
    setActiveId(id)
    try {
      // Close previous connection if exists
      if (sseConnection) {
        sseConnection.close()
      }

      const res = await fetch(`/api/admin/tickets/${id}`, { 
        headers: { Authorization: `Bearer ${localStorage.getItem('admin_token')}` } 
      })
      const j = await res.json()
      if (j.success) setMessages(j.messages)
      
      // Use polling for real-time updates (more reliable than SSE in Next.js)
      startPolling(id)
      
    } catch (error) {
      console.error('Error opening ticket:', error)
    }
  }

  // Polling function for real-time updates
  const startPolling = (ticketId: string) => {
    let lastMessageCount = 0
    
    const pollInterval = setInterval(async () => {
      try {
        const res = await fetch(`/api/admin/tickets/${ticketId}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('admin_token')}` }
        })
        const j = await res.json()
        
        if (j.success && j.messages) {
          const currentMessageCount = j.messages.length
          
          // Only update if we have new messages
          if (currentMessageCount > lastMessageCount) {
            setMessages(j.messages)
            lastMessageCount = currentMessageCount
            
            // Scroll to bottom when new messages arrive
            setTimeout(() => listRef.current && (listRef.current.scrollTop = listRef.current.scrollHeight), 100)
          }
        }
      } catch (error) {
        // Silent error handling
      }
    }, 1000) // Poll every 1 second for better responsiveness

    // Store interval ID for cleanup
    setSseConnection({ close: () => clearInterval(pollInterval) } as any)
  }



  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        alert('Ảnh quá lớn. Vui lòng chọn ảnh nhỏ hơn 5MB.')
        return
      }
      
      if (!file.type.startsWith('image/')) {
        alert('Vui lòng chọn file ảnh hợp lệ.')
        return
      }
      
      setSelectedImage(file)
      const reader = new FileReader()
      reader.onload = (e) => setImagePreview(e.target?.result as string)
      reader.readAsDataURL(file)
    }
  }

  const removeImage = () => {
    setSelectedImage(null)
    setImagePreview(null)
    setShowImageModal(false)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const uploadImage = async (file: File): Promise<string> => {
    const formData = new FormData()
    formData.append('image', file)
    
    const response = await fetch('/api/upload-image', {
      method: 'POST',
      headers: { Authorization: `Bearer ${localStorage.getItem('admin_token')}` },
      body: formData
    })
    
    if (!response.ok) {
      throw new Error('Upload failed')
    }
    
    const data = await response.json()
    return data.imageUrl
  }

  const sendMessage = async () => {
    if (!activeId || (!msg && !selectedImage)) return
    
    setIsUploading(true)
    let imageUrl = ''
    
    // Upload image first if selected
    if (selectedImage) {
      try {
        imageUrl = await uploadImage(selectedImage)
      } catch (error) {
        console.error('Error uploading image:', error)
        alert('Không thể tải ảnh lên. Vui lòng thử lại.')
        setIsUploading(false)
        return
      }
    }
    
    const tempMessage = {
      senderType: 'admin' as const,
      content: msg || '',
      imageUrl: imageUrl || undefined,
      createdAt: new Date().toISOString(),
      tempId: Date.now()
    }
    
    // Add message to local state immediately (optimistic update)
    setMessages(prev => [...prev, tempMessage])
    setMsg('')
    setSelectedImage(null)
    setImagePreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
    
    // Scroll to bottom
    setTimeout(() => listRef.current && (listRef.current.scrollTop = listRef.current.scrollHeight), 50)
    
    try {
      const res = await fetch(`/api/admin/tickets/${activeId}`, { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('admin_token')}` }, 
        body: JSON.stringify({ 
          content: msg || undefined, 
          imageUrl: imageUrl || undefined 
        }) 
      })
      const j = await res.json()
      
      if (j.success) {
        // Replace temp message with real message from server
        setMessages(prev => prev.map(m => 
          m.tempId === tempMessage.tempId 
            ? { ...j.message, senderType: 'admin' as const }
            : m
        ))
      } else {
        // If failed, remove the temp message
        setMessages(prev => prev.filter(m => m.tempId !== tempMessage.tempId))
        if (imageUrl) {
          setSelectedImage(selectedImage)
          setImagePreview(imagePreview)
        }
        if (msg) setMsg(msg)
      }
    } catch (error) {
      console.error('Error sending message:', error)
      // If failed, remove the temp message
      setMessages(prev => prev.filter(m => m.tempId !== tempMessage.tempId))
      if (imageUrl) {
        setSelectedImage(selectedImage)
        setImagePreview(imagePreview)
      }
      if (msg) setMsg(msg)
    } finally {
      setIsUploading(false)
    }
  }

  const toggleTicketStatus = async (ticketId: string, newStatus: 'open' | 'closed') => {
    try {
      const res = await fetch(`/api/tickets/${ticketId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('admin_token')}` },
        body: JSON.stringify({ status: newStatus })
      })
      const j = await res.json()
      if (j.success) {
        setTickets(prev => prev.map(t => 
          t._id === ticketId ? { ...t, status: newStatus } : t
        ))
      }
    } catch (error) {
      console.error('Error updating ticket status:', error)
    }
  }

  useEffect(() => { 
    loadTickets() 
    
    // Cleanup connection on unmount
    return () => {
      if (sseConnection) {
        sseConnection.close()
      }
    }
  }, [])

  const getStatusColor = (status: string) => {
    return status === 'open' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
  }

  const getSubjectColor = (subject: string) => {
    const colors: { [key: string]: string } = {
      'Tài khoản': 'bg-purple-500/20 text-purple-300 border border-purple-500/30',
      'Yêu cầu hủy Child Panel': 'bg-orange-500/20 text-orange-300 border border-orange-500/30',
      'default': 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
    }
    return colors[subject] || colors.default
  }

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (ticket.user?.username || '').toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter
    const matchesSubject = subjectFilter === 'all' || ticket.subject === subjectFilter
    return matchesSearch && matchesStatus && matchesSubject
  })

  const stats = {
    total: tickets.length,
    open: tickets.filter(t => t.status === 'open').length,
    closed: tickets.filter(t => t.status === 'closed').length,
    users: new Set(tickets.map(t => t.user?.username)).size
  }

  // Show loading while checking admin auth
  if (loading && !admin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400 mx-auto"></div>
          <p className="mt-4 text-white/70">Đang kiểm tra quyền truy cập...</p>
        </div>
      </div>
    )
  }

  // Redirect if not admin
  if (!admin) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Main Content */}
      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Admin Header */}
          {admin && (
            <div className="bg-white rounded-xl p-4 mb-6 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                    <span className="text-white font-bold text-lg">A</span>
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-gray-900">Admin Panel - Quản lý Tickets</h2>
                    <p className="text-gray-600">Xin chào, {admin.username} ({admin.role})</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => router.push('/admin/dashboard')}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center space-x-2"
                  >
                    <span>← Dashboard</span>
                  </button>
                  <button
                    onClick={() => {
                      localStorage.removeItem('admin_token')
                      window.location.href = '/admin/auth'
                    }}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors flex items-center space-x-2"
                  >
                    <span>Đăng xuất</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="space-y-2">
              <h1 className="text-4xl font-bold text-gray-900">
                QUẢN LÝ TICKETS
              </h1>
              <p className="text-gray-600 text-lg">Quản lý tất cả yêu cầu hỗ trợ của người dùng</p>
            </div>
            <div className="text-sm text-gray-500 bg-gray-100 px-4 py-2 rounded-full">
              Admin &gt; Quản lý tickets
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white p-6 border border-gray-200 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300">
              <div className="flex items-center">
                <div className="p-4 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl shadow-lg">
                  <MessageSquare className="w-7 h-7 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
                  <p className="text-sm text-gray-600">Tổng tickets</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 border border-gray-200 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300">
              <div className="flex items-center">
                <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg">
                  <Eye className="w-7 h-7 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-3xl font-bold text-gray-900">{stats.open}</p>
                  <p className="text-sm text-gray-600">Đang mở</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 border border-gray-200 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300">
              <div className="flex items-center">
                <div className="p-4 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl shadow-lg">
                  <CheckCircle className="w-7 h-7 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-3xl font-bold text-gray-900">{stats.closed}</p>
                  <p className="text-sm text-gray-600">Đã đóng</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 border border-gray-200 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300">
              <div className="flex items-center">
                <div className="p-4 bg-gradient-to-br from-amber-500 to-amber-600 rounded-2xl shadow-lg">
                  <Users className="w-7 h-7 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-3xl font-bold text-gray-900">{stats.users}</p>
                  <p className="text-sm text-gray-600">Người dùng</p>
                </div>
              </div>
            </div>
          </div>

          {/* Tickets Container */}
          <div className="bg-white border border-gray-200 rounded-3xl shadow-sm">
            {/* Header */}
            <div className="flex items-center justify-between p-8 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                  <MessageSquare className="w-6 h-6 text-white" />
                </div>
                DANH SÁCH TẤT CẢ TICKETS
              </h2>
            </div>

            {/* Search and Filters */}
            <div className="p-8 border-b border-gray-200">
              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex-1 min-w-64">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Tìm theo tiêu đề hoặc username..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 bg-white border border-gray-300 rounded-xl text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    />
                  </div>
                </div>
                
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-4 py-3 bg-white border border-gray-300 rounded-xl text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                >
                  <option value="all" className="bg-white text-gray-900">Tất cả trạng thái</option>
                  <option value="open" className="bg-white text-gray-900">Đang mở</option>
                  <option value="closed" className="bg-white text-gray-900">Đã đóng</option>
                </select>
                
                <select
                  value={subjectFilter}
                  onChange={(e) => setSubjectFilter(e.target.value)}
                  className="px-4 py-3 bg-white border border-gray-300 rounded-xl text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                >
                  <option value="all" className="bg-white text-gray-900">Tất cả chủ đề</option>
                  <option value="Tài khoản" className="bg-white text-gray-900">Tài khoản</option>
                  <option value="Yêu cầu hủy Child Panel" className="bg-white text-gray-900">Yêu cầu hủy Child Panel</option>
                  <option value="Khác" className="bg-white text-gray-900">Khác</option>
                </select>
                
                <button className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl flex items-center gap-2 transition-all duration-300 hover:scale-105 hover:shadow-lg">
                  <Filter className="w-4 h-4" />
                  Bộ lọc
                </button>
              </div>
            </div>

            {/* Tickets Table */}
            <div className="overflow-x-auto p-8">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">ID</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Người dùng</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Tiêu đề</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Chủ đề</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Trạng thái</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Ngày tạo</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredTickets.map((ticket) => (
                    <tr key={ticket._id} className="hover:bg-gray-50 transition-colors duration-200">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">#{ticket._id.slice(-4)}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-700">
                          <div className="font-medium">{ticket.user?.username || 'Unknown'}</div>
                          <div className="text-gray-500">{ticket.user?.email || 'No email'}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 max-w-xs truncate">{ticket.title}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${getSubjectColor(ticket.subject || '')}`}>
                          {ticket.subject || 'Khác'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${getStatusColor(ticket.status)}`}>
                          {ticket.status === 'open' ? 'Đang mở' : 'Đã đóng'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(ticket.createdAt).toLocaleDateString('vi-VN')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex gap-2">
                          <button
                            onClick={() => openTicket(ticket._id)}
                            className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg flex items-center gap-2 transition-all duration-300 hover:scale-105 hover:shadow-lg"
                          >
                            <Eye className="w-4 h-4" />
                            Chat
                          </button>
                          <button
                            onClick={() => toggleTicketStatus(ticket._id, ticket.status === 'open' ? 'closed' : 'open')}
                            className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-all duration-300 hover:scale-105 ${
                              ticket.status === 'open' 
                                ? 'bg-gradient-to-r from-red-500 to-pink-600 text-white hover:shadow-lg'
                                : 'bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:shadow-lg'
                            }`}
                          >
                            {ticket.status === 'open' ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                            {ticket.status === 'open' ? 'Đóng' : 'Mở'}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Modal */}
      {activeId && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="relative overflow-hidden bg-white dark:bg-slate-900 rounded-3xl p-8 w-full max-w-4xl mx-4 h-[600px] flex flex-col border border-gray-200 dark:border-slate-800 shadow-2xl">
            <div className="relative flex flex-col h-full">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Trò chuyện hỗ trợ (Admin)</h3>
                <button
                  onClick={() => {
                    setActiveId(null)
                    // Close connection when closing modal
                    if (sseConnection) {
                      sseConnection.close()
                      setSseConnection(null)
                    }
                  }}
                  className="text-gray-400 dark:text-slate-400 hover:text-gray-600 dark:hover:text-white transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div ref={listRef} className="flex-1 overflow-y-auto space-y-4 mb-6 p-6 bg-gray-50 dark:bg-slate-800/50 rounded-2xl border border-gray-200 dark:border-slate-700">
                {messages.map((m, i) => (
                  <div key={i} className={`max-w-[80%] ${m.senderType === 'admin' ? 'ml-auto' : ''}`}>
                    <div className={`px-4 py-3 rounded-2xl ${m.senderType === 'admin' ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg' : 'bg-white dark:bg-slate-800 text-gray-900 dark:text-slate-200 border border-gray-200 dark:border-slate-700'}`}>
                      {m.content && m.content.trim().length > 0 && <div className="mb-2">{m.content}</div>}
                      {m.imageUrl && (
                        <div className="mt-2">
                          <img 
                            src={m.imageUrl} 
                            alt="Hình ảnh" 
                            className="max-w-full h-auto rounded-lg cursor-pointer hover:scale-105 transition-transform duration-200"
                            onClick={() => window.open(m.imageUrl, '_blank')}
                          />
                        </div>
                      )}
                    </div>
                    <div className={`text-xs text-gray-500 dark:text-slate-400 mt-2 ${m.senderType === 'admin' ? 'text-right' : ''}`}>
                      {m.createdAt ? new Date(m.createdAt).toLocaleString('vi-VN') : 'Vừa xong'}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="space-y-3">
                {/* Image Preview - Hiển thị phía trên input */}
                {imagePreview && (
                  <div className="bg-white dark:bg-slate-800 rounded-xl p-3 border border-gray-200 dark:border-slate-700 shadow-lg">
                    <div className="relative inline-block">
                      <div className="text-xs text-gray-500 dark:text-slate-400 mb-2 font-medium">
                        Xem trước ảnh (Admin):
                      </div>
                      <img 
                        src={imagePreview} 
                        alt="Preview" 
                        className="w-24 h-24 object-cover rounded-lg cursor-pointer hover:scale-105 transition-transform duration-200 border border-gray-100 dark:border-slate-600"
                        onClick={() => setShowImageModal(true)}
                      />
                      <button
                        onClick={removeImage}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600 transition-colors shadow-md"
                      >
                        <X className="w-3 h-3" />
                      </button>
                      <div className="text-xs text-gray-400 dark:text-slate-500 mt-1 text-center">
                        Click để xem full size
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Input và nút gửi */}
                <div className="flex gap-3">
                  {/* File Input */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="hidden"
                  />
                  
                  {/* Image Button */}
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-3 bg-gray-500 hover:bg-gray-600 text-white rounded-xl flex items-center gap-2 transition-all duration-300"
                    title="Gửi ảnh"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </button>
                  
                  <input
                    value={msg}
                    onChange={(e) => setMsg(e.target.value)}
                    placeholder="Nhập tin nhắn..."
                    className="flex-1 px-4 py-3 bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-xl text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  />
                  <button
                    onClick={sendMessage}
                    disabled={isUploading}
                    className={`px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl flex items-center gap-2 transition-all duration-300 hover:scale-105 hover:shadow-lg font-semibold ${
                      isUploading ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {isUploading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                    {isUploading ? 'Đang gửi...' : 'Gửi'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {showImageModal && imagePreview && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-[9999]">
          <div className="relative max-w-5xl max-h-[95vh] p-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Xem trước ảnh (Admin)
                </h3>
                <button
                  onClick={() => setShowImageModal(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="max-h-[70vh] overflow-auto">
                <img 
                  src={imagePreview} 
                  alt="Full Preview" 
                  className="max-w-full h-auto rounded-lg shadow-lg border border-gray-200 dark:border-slate-700"
                />
              </div>
              
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200 dark:border-slate-700">
                <div className="text-sm text-gray-500 dark:text-slate-400">
                  {selectedImage ? `${selectedImage.name} • ${(selectedImage.size / 1024 / 1024).toFixed(2)} MB` : 'Ảnh đã chọn'}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={removeImage}
                    className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors flex items-center gap-2"
                  >
                    <X className="w-4 h-4" />
                    Xóa ảnh
                  </button>
                  <button
                    onClick={() => setShowImageModal(false)}
                    className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                  >
                    Đóng
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}


