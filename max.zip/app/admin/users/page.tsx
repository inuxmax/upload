'use client'

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { 
  Users, DollarSign, UserCheck, UserX, Search, Filter, 
  Edit, Trash2, Ban, CheckCircle, XCircle, Eye, Plus,
  ChevronLeft, ChevronRight, Download, Upload, Settings,
  Calendar, Mail, Phone, Globe, Shield, Crown, Clock, X,
  Menu
} from 'lucide-react'

interface User {
  _id: string
  username: string
  email: string
  fullName: string
  phone?: string
  balance: number
  totalDeposit: number
  qualityScore: number
  subscription: {
    plan: string
    expiresAt: string
    isActive: boolean
  }
  isActive: boolean
  isAdmin: boolean
  utm_source: string
  createdAt: string
  lastLoginAt?: string
}

interface UserStats {
  totalUsers: number
  totalBalance: number
  activeUsers: number
  bannedUsers: number
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [stats, setStats] = useState<UserStats>({
    totalUsers: 0,
    totalBalance: 0,
    activeUsers: 0,
    bannedUsers: 0
  })
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(10)
  const [sortBy, setSortBy] = useState('createdAt')
  const [sortOrder, setSortOrder] = useState('desc')
  const [filterStatus, setFilterStatus] = useState('all')
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [editForm, setEditForm] = useState({
    username: '',
    email: '',
    fullName: '',
    phone: '',
    balance: 0,
    isActive: true,
    isAdmin: false
  })
  const [showAddBalanceModal, setShowAddBalanceModal] = useState(false)
  const [addBalanceUser, setAddBalanceUser] = useState<User | null>(null)
  const [addBalanceAmount, setAddBalanceAmount] = useState('')
  const [isUpdating, setIsUpdating] = useState(false)
  const router = useRouter()

  useEffect(() => {
    checkAdminAuth()
    loadUsers()
    loadStats()
  }, [currentPage, itemsPerPage, sortBy, sortOrder, filterStatus, searchTerm])

  const checkAdminAuth = async () => {
    try {
      const response = await fetch('/api/admin/check', {
        credentials: 'include'
      })

      if (!response.ok) {
        router.push('/admin/auth')
      }
    } catch (error) {
      console.error('Admin auth check failed:', error)
      router.push('/admin/auth')
    }
  }

  const loadUsers = async () => {
    try {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        limit: itemsPerPage.toString(),
        sortBy,
        sortOrder,
        status: filterStatus,
        search: searchTerm
      })

      const response = await fetch(`/api/admin/users?${params}`, {
        credentials: 'include'
      })

      if (response.ok) {
        const data = await response.json()
        setUsers(data.users || [])
      }
    } catch (error) {
      console.error('Error loading users:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadStats = async () => {
    try {
      const response = await fetch('/api/admin/stats', {
        credentials: 'include'
      })

      if (response.ok) {
        const data = await response.json()
        setStats(data.stats || data)
      }
    } catch (error) {
      console.error('Error loading stats:', error)
    }
  }

  const handleUserAction = async (userId: string, action: 'ban' | 'unban' | 'delete') => {
    try {
      let endpoint = ''
      let method = 'POST'

      switch (action) {
        case 'ban':
          endpoint = `/api/admin/users/${userId}/ban`
          break
        case 'unban':
          endpoint = `/api/admin/users/${userId}/ban`
          method = 'DELETE'
          break
        case 'delete':
          endpoint = `/api/admin/users/${userId}`
          method = 'DELETE'
          break
      }

      const response = await fetch(endpoint, {
        method,
        credentials: 'include'
      })

      if (response.ok) {
        loadUsers()
        loadStats()
      }
    } catch (error) {
      console.error(`Error ${action} user:`, error)
    }
  }

  const handleEditUser = (user: User) => {
    setEditingUser(user)
    setEditForm({
      username: user.username,
      email: user.email,
      fullName: user.fullName || '',
      phone: user.phone || '',
      balance: user.balance,
      isActive: user.isActive,
      isAdmin: user.isAdmin
    })
    setShowEditModal(true)
  }

  const handleSaveUser = async () => {
    if (!editingUser) return

    setIsUpdating(true)
    try {
      const response = await fetch(`/api/admin/users/${editingUser._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(editForm)
      })

      if (response.ok) {
        setShowEditModal(false)
        setEditingUser(null)
        loadUsers()
        loadStats()
      } else {
        const error = await response.json()
        alert('Lỗi cập nhật user: ' + error.error)
      }
    } catch (error) {
      console.error('Error updating user:', error)
      alert('Lỗi cập nhật user')
    } finally {
      setIsUpdating(false)
    }
  }

  const handleAddBalance = async () => {
    if (!addBalanceUser || !addBalanceAmount) return

    const amount = Number(addBalanceAmount)
    if (isNaN(amount) || amount <= 0) {
      alert('Số tiền không hợp lệ')
      return
    }

    setIsUpdating(true)
    try {
      const response = await fetch(`/api/admin/users/${addBalanceUser._id}/add-balance`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({ amount })
      })

      if (response.ok) {
        const result = await response.json()
        alert(result.message)
        setShowAddBalanceModal(false)
        setAddBalanceUser(null)
        setAddBalanceAmount('')
        loadUsers()
        loadStats()
      } else {
        const error = await response.json()
        alert('Lỗi cộng tiền: ' + error.error)
      }
    } catch (error) {
      console.error('Error adding balance:', error)
      alert('Lỗi cộng tiền')
    } finally {
      setIsUpdating(false)
    }
  }

  const openAddBalanceModal = (user: User) => {
    setAddBalanceUser(user)
    setAddBalanceAmount('')
    setShowAddBalanceModal(true)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('vi-VN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formatBalance = (balance: number) => {
    return new Intl.NumberFormat('vi-VN').format(balance || 0)
  }

  const getStatusBadge = (user: User) => {
    if (!user.isActive) {
      return <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">Không</span>
    }
    return <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">Active</span>
  }

  const getActivityBadge = (user: User) => {
    // Giả sử offline cho tất cả users
    return <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">Offline</span>
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Đang tải...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Menu className="w-5 h-5 text-gray-600" />
              <Users className="w-6 h-6 text-blue-600" />
              <span className="text-lg font-medium text-gray-900">Users</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">taodeovao</span>
              <span className="text-xs text-gray-500">super_admin</span>
              <button className="text-red-600 hover:text-red-800 text-sm">
                Đăng xuất
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{stats.totalUsers}</p>
                <p className="text-sm text-gray-600">Tổng thành viên</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center">
              <div className="p-2 bg-cyan-100 rounded-lg">
                <DollarSign className="w-6 h-6 text-cyan-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{formatBalance(stats.totalBalance)}</p>
                <p className="text-sm text-gray-600">Số dư còn lại</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <UserCheck className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{stats.activeUsers}</p>
                <p className="text-sm text-gray-600">Active</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center">
              <div className="p-2 bg-red-100 rounded-lg">
                <UserX className="w-6 h-6 text-red-600" />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{stats.bannedUsers}</p>
                <p className="text-sm text-gray-600">Banned</p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button className="inline-flex items-center px-3 py-2 bg-green-600 text-white text-sm rounded hover:bg-green-700">
            <Download className="w-4 h-4 mr-1" />
            TẢI TOÀN BỘ CSV EMAIL & SĐT
          </button>
          <button className="inline-flex items-center px-3 py-2 bg-red-600 text-white text-sm rounded hover:bg-red-700">
            THÔNG KÊ UTM_SOURCE
          </button>
          <button className="inline-flex items-center px-3 py-2 bg-cyan-600 text-white text-sm rounded hover:bg-cyan-700">
            RESET TỔNG NẠP
          </button>
          <button className="inline-flex items-center px-3 py-2 bg-orange-600 text-white text-sm rounded hover:bg-orange-700">
            NÂNG XUẤT VÀ LÀM
          </button>
          <button className="inline-flex items-center px-3 py-2 bg-purple-600 text-white text-sm rounded hover:bg-purple-700">
            THAY ĐỔI API KEY TOÀN BỘ THÀNH VIÊN
          </button>
          <button 
            onClick={() => router.push('/admin')}
            className="inline-flex items-center px-3 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
          >
            + Thêm thành viên
          </button>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-4 border-b">
            <h2 className="text-lg font-semibold text-gray-900">DANH SÁCH THÀNH VIÊN</h2>
          </div>

          {/* Filters */}
          <div className="p-4 border-b bg-gray-50">
            <div className="flex flex-wrap items-center gap-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">ID Khách hàng</label>
                <input
                  type="text"
                  placeholder=""
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">Username</label>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">Full name</label>
                <input
                  type="text"
                  placeholder=""
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">Email</label>
                <input
                  type="text"
                  placeholder=""
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">Phone</label>
                <input
                  type="text"
                  placeholder=""
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">Mã số IP</label>
                <input
                  type="text"
                  placeholder=""
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                />
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">utm_source</label>
                <input
                  type="text"
                  placeholder=""
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                />
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <label className="text-sm text-gray-600">SHOW:</label>
                  <select
                    value={itemsPerPage}
                    onChange={(e) => setItemsPerPage(Number(e.target.value))}
                    className="px-3 py-1 border border-gray-300 rounded text-sm"
                  >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                  </select>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <label className="text-sm text-gray-600">SHORT BY DATE:</label>
                  <select
                    value={sortOrder}
                    onChange={(e) => setSortOrder(e.target.value)}
                    className="px-3 py-1 border border-gray-300 rounded text-sm"
                  >
                    <option value="desc">Tất cả</option>
                    <option value="asc">Cũ nhất</option>
                  </select>
                </div>
                <button className="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
                  Search
                </button>
                <button className="px-4 py-2 bg-red-600 text-white text-sm rounded hover:bg-red-700">
                  Clear Filter
                </button>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    <input type="checkbox" className="rounded" />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Username</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Số dư khả dụng</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tổng nạp</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Chất khẩu</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Admin</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Trạng thái</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hoạt động</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">utm_source</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Thời gian</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Thao tác</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {users.map((user) => (
                  <tr key={user._id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <input type="checkbox" className="rounded" />
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-blue-600 hover:text-blue-800 cursor-pointer">
                        {user.username}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center">
                        <Mail className="w-4 h-4 text-gray-400 mr-1" />
                        <span className="text-sm text-gray-900">{user.email}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm font-medium text-blue-600">
                        {formatBalance(user.balance)}₫
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-red-600">
                        {formatBalance(user.totalDeposit || 0)}₫
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-gray-900">{user.qualityScore || 0}%</span>
                    </td>
                    <td className="px-4 py-3">
                      {user.isAdmin ? (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                          Admin
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                          Không
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {getStatusBadge(user)}
                    </td>
                    <td className="px-4 py-3">
                      {getActivityBadge(user)}
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-gray-900">{user.utm_source || 'web'}</span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-sm text-gray-900">{formatDate(user.createdAt)}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex space-x-1">
                        <button 
                          onClick={() => handleEditUser(user)}
                          className="inline-flex items-center px-2 py-1 bg-blue-100 text-blue-700 hover:bg-blue-200 border border-blue-200 rounded text-xs"
                          title="Chỉnh sửa"
                        >
                          <Edit className="w-3 h-3 mr-1" />
                          Edit
                        </button>
                        <button 
                          onClick={() => openAddBalanceModal(user)}
                          className="inline-flex items-center px-2 py-1 bg-green-100 text-green-700 hover:bg-green-200 border border-green-200 rounded text-xs"
                          title="Cộng tiền"
                        >
                          <Plus className="w-3 h-3 mr-1" />
                          Cộng tiền
                        </button>
                        <button 
                          onClick={() => {
                            if (confirm('Bạn có chắc muốn xóa user này?')) {
                              handleUserAction(user._id, 'delete')
                            }
                          }}
                          className="inline-flex items-center px-2 py-1 bg-red-100 text-red-700 hover:bg-red-200 border border-red-200 rounded text-xs"
                          title="Xóa user"
                        >
                          <Trash2 className="w-3 h-3 mr-1" />
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="px-4 py-3 border-t bg-gray-50">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Showing {((currentPage - 1) * itemsPerPage) + 1} of {stats.totalUsers} Results
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                  className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-100 disabled:opacity-50"
                >
                  1
                </button>
                <button className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-100">
                  2
                </button>
                <button className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-100">
                  3
                </button>
                <span className="text-sm text-gray-500">...</span>
                <button className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-100">
                  5
                </button>
                <button
                  onClick={() => setCurrentPage(currentPage + 1)}
                  className="px-3 py-1 border border-gray-300 rounded text-sm hover:bg-gray-100"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="mt-4 flex space-x-2">
          <button className="inline-flex items-center px-3 py-2 bg-red-600 text-white text-sm rounded hover:bg-red-700">
            XÓA THÀNH VIÊN
          </button>
          <button className="inline-flex items-center px-3 py-2 bg-green-600 text-white text-sm rounded hover:bg-green-700">
            <CheckCircle className="w-4 h-4 mr-1" />
            CHỌN TRẠNG THÁI
          </button>
        </div>
      </div>

      {/* Edit User Modal */}
      {showEditModal && editingUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="px-6 py-4 border-b">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Chỉnh sửa User</h3>
                <button
                  onClick={() => setShowEditModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Username
                </label>
                <input
                  type="text"
                  value={editForm.username}
                  onChange={(e) => setEditForm({...editForm, username: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({...editForm, email: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={editForm.fullName}
                  onChange={(e) => setEditForm({...editForm, fullName: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone
                </label>
                <input
                  type="text"
                  value={editForm.phone}
                  onChange={(e) => setEditForm({...editForm, phone: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Số dư (VND)
                </label>
                <input
                  type="number"
                  value={editForm.balance}
                  onChange={(e) => setEditForm({...editForm, balance: Number(e.target.value)})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              <div className="flex items-center space-x-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={editForm.isActive}
                    onChange={(e) => setEditForm({...editForm, isActive: e.target.checked})}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Active</span>
                </label>

                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={editForm.isAdmin}
                    onChange={(e) => setEditForm({...editForm, isAdmin: e.target.checked})}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Admin</span>
                </label>
              </div>
            </div>

            <div className="px-6 py-4 border-t bg-gray-50">
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Hủy
                </button>
                <button
                  onClick={handleSaveUser}
                  disabled={isUpdating}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {isUpdating ? 'Đang cập nhật...' : 'Cập nhật'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Balance Modal */}
      {showAddBalanceModal && addBalanceUser && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="px-6 py-4 border-b">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Cộng tiền cho User</h3>
                <button
                  onClick={() => setShowAddBalanceModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-medium text-blue-600">
                      {addBalanceUser.username.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{addBalanceUser.username}</p>
                    <p className="text-sm text-gray-500">{addBalanceUser.email}</p>
                    <p className="text-sm text-blue-600">
                      Số dư hiện tại: {formatBalance(addBalanceUser.balance)}₫
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Số tiền cộng thêm (VND)
                </label>
                <input
                  type="number"
                  value={addBalanceAmount}
                  onChange={(e) => setAddBalanceAmount(e.target.value)}
                  placeholder="Nhập số tiền..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                  min="1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Số tiền phải lớn hơn 0
                </p>
              </div>

              {addBalanceAmount && !isNaN(Number(addBalanceAmount)) && Number(addBalanceAmount) > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                  <p className="text-sm text-green-800">
                    <strong>Số dư sau khi cộng:</strong> {formatBalance(addBalanceUser.balance + Number(addBalanceAmount))}₫
                  </p>
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t bg-gray-50">
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowAddBalanceModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Hủy
                </button>
                <button
                  onClick={handleAddBalance}
                  disabled={isUpdating || !addBalanceAmount || isNaN(Number(addBalanceAmount)) || Number(addBalanceAmount) <= 0}
                  className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isUpdating ? 'Đang xử lý...' : 'Cộng tiền'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}