'use client'

import { useState, useEffect } from 'react'
import { Save, Eye, EyeOff, Settings, X } from 'lucide-react'

interface WelcomePopupSettings {
  enabled: boolean
  title: string
  message: string
  showDontShowAgain: boolean
  showOnLogin: boolean
  showOnDashboard: boolean
}

export default function WelcomePopupAdmin() {
  const [settings, setSettings] = useState<WelcomePopupSettings>({
    enabled: true,
    title: "Thông báo",
    message: "Chào mừng bạn quay trở lại !",
    showDontShowAgain: true,
    showOnLogin: true,
    showOnDashboard: false
  })

  const [isLoading, setIsLoading] = useState(false)
  const [showPreview, setShowPreview] = useState(false)

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    try {
      const response = await fetch('/api/admin/welcome-popup/settings', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setSettings(data.settings)
      }
    } catch (error) {
      console.error('Error loading settings:', error)
    }
  }

  const saveSettings = async () => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/admin/welcome-popup/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(settings)
      })
      
      if (response.ok) {
        alert('Cài đặt đã được lưu thành công!')
      } else {
        alert('Lỗi khi lưu cài đặt!')
      }
    } catch (error) {
      console.error('Error saving settings:', error)
      alert('Lỗi khi lưu cài đặt!')
    } finally {
      setIsLoading(false)
    }
  }

  const resetAllDismissals = async () => {
    if (!confirm('Bạn có chắc muốn xóa tất cả lịch sử ẩn popup của người dùng?')) {
      return
    }

    try {
      const response = await fetch('/api/admin/welcome-popup/reset-dismissals', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        alert('Đã xóa tất cả lịch sử ẩn popup!')
      } else {
        alert('Lỗi khi xóa lịch sử!')
      }
    } catch (error) {
      console.error('Error resetting dismissals:', error)
      alert('Lỗi khi xóa lịch sử!')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <div className="flex items-center bg-gradient-to-r from-blue-600 to-indigo-600 p-2.5 rounded-xl shadow-lg">
              <Settings className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                Quản lý Popup Thông báo
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Cài đặt popup chào mừng người dùng
              </p>
            </div>
          </div>
        </div>

        {/* Settings Form */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
          <div className="space-y-6">
            {/* Enable/Disable */}
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">Bật/Tắt Popup</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Hiển thị popup thông báo cho người dùng</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.enabled}
                  onChange={(e) => setSettings({...settings, enabled: e.target.checked})}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Tiêu đề
              </label>
              <input
                type="text"
                value={settings.title}
                onChange={(e) => setSettings({...settings, title: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                placeholder="Nhập tiêu đề popup"
              />
            </div>

            {/* Message */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Nội dung thông báo
              </label>
              <textarea
                value={settings.message}
                onChange={(e) => setSettings({...settings, message: e.target.value})}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                placeholder="Nhập nội dung thông báo"
              />
            </div>

            {/* Show Don't Show Again */}
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Hiển thị checkbox "Không hiển thị lại"</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">Cho phép người dùng ẩn popup vĩnh viễn</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showDontShowAgain}
                  onChange={(e) => setSettings({...settings, showDontShowAgain: e.target.checked})}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
              </label>
            </div>

            {/* Show Locations */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">Hiển thị tại</h3>
              <div className="space-y-2">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={settings.showOnLogin}
                    onChange={(e) => setSettings({...settings, showOnLogin: e.target.checked})}
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Trang đăng nhập</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={settings.showOnDashboard}
                    onChange={(e) => setSettings({...settings, showOnDashboard: e.target.checked})}
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">Dashboard</span>
                </label>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center space-x-4 pt-6 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={saveSettings}
                disabled={isLoading}
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{isLoading ? 'Đang lưu...' : 'Lưu cài đặt'}</span>
              </button>

              <button
                onClick={() => setShowPreview(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <Eye className="w-4 h-4" />
                <span>Xem trước</span>
              </button>

              <button
                onClick={resetAllDismissals}
                className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <EyeOff className="w-4 h-4" />
                <span>Xóa lịch sử ẩn</span>
              </button>
            </div>
          </div>
        </div>

        {/* Preview Modal */}
        {showPreview && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 relative">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-gray-200">
                <h2 className="text-lg font-bold text-gray-900">{settings.title}</h2>
                <button
                  onClick={() => setShowPreview(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Content */}
              <div className="p-4">
                <p className="text-gray-700 text-base">{settings.message}</p>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between p-4 border-t border-gray-200">
                {settings.showDontShowAgain && (
                  <label className="flex items-center space-x-2 text-sm text-gray-600 cursor-pointer">
                    <input
                      type="checkbox"
                      className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                    />
                    <span>Không hiển thị lại</span>
                  </label>
                )}
                
                <button
                  onClick={() => setShowPreview(false)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  Đóng
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
