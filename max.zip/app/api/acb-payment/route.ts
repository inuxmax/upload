import { NextRequest, NextResponse } from 'next/server';
import Transaction from '@/models/Transaction';

interface ACBTransaction {
  transactionID: number;
  amount: number;
  description: string;
  transactionDate: string;
  type: string;
}

interface ACBResponse {
  status: boolean;
  message: string;
  transactions: ACBTransaction[];
}

async function processACBPayment(transaction: ACBTransaction, User: any, Subscription: any, SubscriptionPlan: any) {
  try {
    console.log('Processing ACB payment:', transaction);

    const description = transaction.description || '';
    console.log('Payment description:', description);

    // Tìm user có pendingTransferContents khớp với description
    // Thử nhiều cách match khác nhau
    let user = await User.findOne({
      pendingTransferContents: { $exists: true, $ne: null, $not: { $size: 0 } },
      $or: [
        { pendingTransferContents: description },
        { pendingTransferContents: { $regex: description, $options: 'i' } },
        { pendingTransferContents: { $regex: description.substring(0, 10), $options: 'i' } }
      ]
    });

    // Nếu không tìm thấy, thử tìm user có pendingTransferContents chứa trong description
    if (!user) {
      console.log('Trying alternative matching...');
      const usersWithPending = await User.find({
        pendingTransferContents: { $exists: true, $ne: null, $not: { $size: 0 } }
      });
      
      console.log('Users with pendingTransferContents:', usersWithPending.map((u: any) => ({
        username: u.username,
        pendingTransferContents: u.pendingTransferContents
      })));
      
      // Tìm user có pendingTransferContents chứa trong description
      for (const u of usersWithPending) {
        if (u.pendingTransferContents && u.pendingTransferContents.length > 0) {
          for (const pendingContent of u.pendingTransferContents) {
            // Cải thiện logic matching cho pendingTransferContents
            const isMatching = 
              description.includes(pendingContent) ||
              description.toUpperCase().includes(pendingContent.toUpperCase()) ||
              description.includes(pendingContent.toUpperCase()) ||
              description.toUpperCase().includes(pendingContent) ||
              // Kiểm tra xem có chứa một phần của pendingContent không (ít nhất 8 ký tự)
              (pendingContent.length >= 8 && 
               (description.includes(pendingContent.substring(0, 8)) ||
                description.toUpperCase().includes(pendingContent.substring(0, 8).toUpperCase())));
            
            if (isMatching) {
              user = u;
              console.log('Found user with improved match:', u.username, 'for content:', pendingContent);
              break;
            }
          }
          if (user) break;
        }
      }
    }

    if (!user) {
      console.log('No user found with matching transfer content');
      console.log('Available pendingTransferContents:', await User.find({ pendingTransferContents: { $exists: true, $ne: null, $not: { $size: 0 } } }).select('username pendingTransferContents'));
      return { success: false, error: 'No user found with matching transfer content' };
    }

    console.log('Found user with matching transfer content:', user._id, user.username);

    // Xác định gói dựa trên số tiền
    const amount = transaction.amount;
    console.log('Payment amount:', amount);
    
    let plan = 'free';
    let duration = 1;

    // Logic xác định gói dựa trên số tiền
    // Kiểm tra xem có phải môi trường test không (số tiền nhỏ)
    const isTestMode = amount < 10000; // Nếu số tiền < 10k thì coi như test
    
    if (amount >= 500000) {
      plan = 'enterprise';
      duration = 6;
    } else if (amount >= 300000) {
      plan = 'premium';
      duration = 3;
    } else if (amount >= 100000) {
      plan = 'basic';
      duration = 1;
    } else if (isTestMode && amount >= 1000) {
      // Chỉ cho phép test với số tiền nhỏ trong môi trường development
      plan = 'basic';
      duration = 1;
      console.log('Test mode: small amount upgraded to basic plan');
    }

    console.log(`Determined plan: ${plan}, duration: ${duration} months`);
    
    if (plan === 'free') {
      console.log('Amount too small for any paid plan. Minimum required: 100,000 VND for Basic plan');
      return { success: false, error: 'Amount too small for paid plan' };
    }

    // Tìm thông tin gói
    const planInfo = await SubscriptionPlan.findOne({ plan });
    if (!planInfo) {
      console.error(`Plan ${plan} not found`);
      return { success: false, error: `Plan ${plan} not found` };
    }

    // Kiểm tra xem user đã có subscription chưa
    let subscription = await Subscription.findOne({ userId: user._id });
    
    if (subscription) {
      // Cập nhật subscription hiện tại
      subscription.plan = plan;
      subscription.status = 'active';
      subscription.startDate = new Date();
      // Sử dụng UTC để tránh vấn đề timezone
      const now = new Date();
      const endDate = new Date(now.getTime() + duration * 30 * 24 * 60 * 60 * 1000);
      subscription.endDate = endDate;
      subscription.amount = amount;
      subscription.autoRenew = false;
      subscription.transactionId = transaction.transactionID.toString();
      await subscription.save();
      console.log('Updated existing subscription');
    } else {
      // Tạo subscription mới
      const now = new Date();
      const endDate = new Date(now.getTime() + duration * 30 * 24 * 60 * 60 * 1000);
      subscription = new Subscription({
        userId: user._id,
        plan: plan,
        status: 'active',
        startDate: now,
        endDate: endDate,
        amount: amount,
        autoRenew: false,
        transactionId: transaction.transactionID.toString()
      });
      await subscription.save();
      console.log('Created new subscription');
    }

    // Lưu transaction vào database
    const newTransaction = new Transaction({
      userId: user._id,
      transactionId: transaction.transactionID.toString(),
      amount: amount,
      currency: 'VND',
      description: transaction.description,
      type: 'IN',
      status: 'completed',
      plan: plan,
      transferContent: user.pendingTransferContents?.find((content: string) => description.includes(content)) || '',
      bankName: 'ACB Bank',
      accountNumber: 'N/A',
      processedAt: new Date()
    });
    await newTransaction.save();
    console.log('Transaction saved to database:', newTransaction._id);

    // Xóa tất cả pendingTransferContents sau khi xử lý thành công
    user.pendingTransferContents = [];
    await user.save();
    console.log('Cleared all pendingTransferContents for user:', user.username);

    console.log('ACB Payment processing completed successfully');
    return { 
      success: true, 
      message: `User ${user.username} upgraded to ${plan} plan for ${duration} months`,
      userId: user._id,
      plan,
      duration,
      amount
    };

  } catch (error) {
    console.error('ACB Payment processing error:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// Hàm tự động hạ cấp subscription đã hết hạn
async function checkAndDowngradeExpiredSubscriptions() {
  try {
    console.log('Checking for expired subscriptions...');
    
    const connectMongoDB = (await import('@/lib/mongodb')).default;
    const SubscriptionModel = (await import('@/models/Subscription')).default as any;
    const User = (await import('@/models/User')).default;
    
    await connectMongoDB();

    const now = new Date();
    console.log('Current time:', now.toISOString());

    // Tìm tất cả subscription đã hết hạn nhưng vẫn có status 'active'
    const expiredSubscriptions = await (SubscriptionModel as any).find({
      status: 'active',
      endDate: { $lt: now }
    }).populate('userId', 'username email');

    console.log(`Found ${expiredSubscriptions.length} expired subscriptions`);

    let downgradedCount = 0;
    for (const subscription of expiredSubscriptions) {
      try {
        console.log(`Downgrading subscription for user: ${subscription.userId?.username || subscription.userId}`);
        
        // Hạ cấp về gói free
        subscription.plan = 'free';
        subscription.status = 'expired';
        subscription.autoRenew = false;
        
        // Cập nhật endDate thành thời gian hiện tại
        subscription.endDate = now;
        
        await subscription.save();
        
        console.log(`Successfully downgraded subscription for user: ${subscription.userId?.username || subscription.userId}`);
        downgradedCount++;
        
      } catch (error) {
        console.error(`Error downgrading subscription for user ${subscription.userId}:`, error);
      }
    }

    console.log(`Downgraded ${downgradedCount} expired subscriptions`);
    return { 
      success: true, 
      checked: expiredSubscriptions.length,
      downgraded: downgradedCount 
    };

  } catch (error) {
    console.error('Error checking expired subscriptions:', error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    };
  }
}

// Thêm vào cuối hàm POST để tự động kiểm tra hạ cấp
export async function POST(request: NextRequest) {
  try {
    console.log('ACB Payment API received:', new Date().toISOString());
    
    // Parse request body để lấy expectedTransferContent
    const requestBody = await request.json();
    const { expectedTransferContent } = requestBody;
    
    console.log('Expected transfer content:', expectedTransferContent);
    
    // Sử dụng @/ paths thay vì relative paths
    const connectMongoDB = (await import('@/lib/mongodb')).default;
    const PaymentInfo = (await import('@/models/PaymentInfo')).default;
    const User = (await import('@/models/User')).default;
    const Subscription = (await import('@/models/Subscription')).default;
    const SubscriptionPlan = (await import('@/models/SubscriptionPlan')).default;
    
    await connectMongoDB();

    // Tự động kiểm tra và hạ cấp subscription đã hết hạn
    const downgradeResult = await checkAndDowngradeExpiredSubscriptions();
    console.log('Downgrade check result:', downgradeResult);

    // Lấy thông tin ACB từ PaymentInfo
    const paymentInfo = await (PaymentInfo as any).findOne({ isActive: true });
    
    if (!paymentInfo) {
      return NextResponse.json(
        { error: 'Payment info not found' },
        { status: 400 }
      );
    }

    const { passwordACB, tokenACB, accountNumber } = paymentInfo;

    if (!passwordACB || !accountNumber || !tokenACB) {
      return NextResponse.json(
        { error: 'Missing ACB credentials in payment info. Please configure in admin settings.' },
        { status: 400 }
      );
    }

    console.log('ACB API Parameters:', {
      passwordACB: passwordACB ? '***' : 'missing',
      accountNumber,
      tokenACB: tokenACB ? '***' : 'missing'
    });

    // Gọi API ACB Version 3 với GET method
    const acbApiUrl = `https://api.web2m.com/historyapiacbv3/${passwordACB}/${accountNumber}/${tokenACB}`;
    console.log('Calling ACB API:', acbApiUrl);

    const acbResponse = await fetch(acbApiUrl, {
      method: 'GET', // Sử dụng GET thay vì POST
      headers: {
        'Content-Type': 'application/json'
      }
    });


    if (!acbResponse.ok) {
      
      // Thử đọc response text để debug
      const errorText = await acbResponse.text();
      console.log('ACB API Error Response:', errorText);
      
      return NextResponse.json(
        { error: 'Failed to fetch ACB transactions', status: acbResponse.status, details: errorText },
        { status: 500 }
      );
    }

    const acbData: ACBResponse = await acbResponse.json();
    console.log('ACB API Response:', {
      status: acbData.status,
      message: acbData.message,
      transactionCount: acbData.transactions?.length || 0
    });

    if (!acbData.status || !acbData.transactions) {
      return NextResponse.json(
        { error: 'Invalid ACB API response', details: acbData.message },
        { status: 400 }
      );
    }

    // Xử lý các giao dịch
    let processedCount = 0;
    let matchingTransactionFound = false;
    
    for (const transaction of acbData.transactions) {
      console.log('Processing ACB transaction:', {
        id: transaction.transactionID,
        amount: transaction.amount,
        type: transaction.type,
        description: transaction.description
      });

      // Chỉ xử lý giao dịch IN (tiền vào) và có description khớp với expectedTransferContent
      if (transaction.type === 'IN' && expectedTransferContent) {
        const description = transaction.description || '';
        
        // Cải thiện logic matching - thử nhiều cách khác nhau
        const isMatchingContent = 
          description.includes(expectedTransferContent) ||
          description.toUpperCase().includes(expectedTransferContent.toUpperCase()) ||
          description.includes(expectedTransferContent.toUpperCase()) ||
          description.toUpperCase().includes(expectedTransferContent) ||
          // Kiểm tra xem có chứa một phần của expectedTransferContent không (ít nhất 8 ký tự)
          (expectedTransferContent.length >= 8 && 
           (description.includes(expectedTransferContent.substring(0, 8)) ||
            description.toUpperCase().includes(expectedTransferContent.substring(0, 8).toUpperCase())));
        
        console.log('Checking transaction content:', {
          description,
          expectedTransferContent,
          isMatchingContent,
          descriptionLength: description.length,
          expectedLength: expectedTransferContent.length
        });
        
        if (isMatchingContent) {
          matchingTransactionFound = true;
          const result = await processACBPayment(transaction, User, Subscription, SubscriptionPlan);
          if (result.success) {
            processedCount++;
            console.log('Payment processed successfully:', result);
          } else {
            console.error('Payment processing failed:', result.error);
          }
        } else {
          console.log('Transaction content does not match expected content');
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: `Processed ${processedCount} transactions`,
      processed: processedCount,
      matchingTransactionFound,
      expectedTransferContent,
      downgraded: downgradeResult.downgraded || 0,
      checked: downgradeResult.checked || 0
    });

  } catch (error) {
    console.error('ACB Payment processing error:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
} 