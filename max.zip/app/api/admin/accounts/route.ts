import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import connectDB from '@/lib/mongodb'
import FacebookAccount from '@/models/FacebookAccount'
import Settings from '@/models/Settings'
import { decryptUserKey, decryptFields, isValidAdminKey, isEncrypted, decryptStringWithKey } from '@/lib/encryption'
import User from '@/models/User'

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Middleware để verify admin token
const verifyAdminToken = async (request: NextRequest) => {
  const token = request.cookies.get('admin_token')?.value || 
                request.headers.get('authorization')?.replace('Bearer ', '')
  
  if (!token) {
    return null
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    return decoded
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_accounts')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const search = searchParams.get('search') || ''
    const status = searchParams.get('status') || ''
    const userId = searchParams.get('userId') || ''
    
    const skip = (page - 1) * limit
    
    let query: any = {}
    
    if (search) {
      query.$or = [
        { uid: { $regex: search, $options: 'i' } },
        { name: { $regex: search, $options: 'i' } }
      ]
    }
    
    if (status) {
      query.status = status
    }
    
    if (userId) {
      query.userId = userId
    }
    
    let accounts = await (FacebookAccount as any).find(query)
      .populate({ path: 'userId', model: (User as any).modelName || 'User', select: 'username email' })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
    
    const total = await (FacebookAccount as any).countDocuments(query)

    // Optional admin decryption using master key
    const adminKey = request.headers.get('x-admin-key') || ''
    if (adminKey && isValidAdminKey(adminKey)) {
      try {
        const userIds = accounts.map((a: any) => a.userId?._id || a.userId).filter(Boolean)
        const settingsDocs: any[] = await (Settings as any).find({ userId: { $in: userIds } })
        const userIdToKey = new Map<string, string>()
        for (const s of settingsDocs) {
          const encKey = s?.encryption?.userKeyEncrypted || s?.userEncryptionKey || null
          let key: string | null = null
          if (adminKey) {
            try { key = decryptStringWithKey(encKey, adminKey) } catch {}
          }
          if (!key) {
            key = decryptUserKey(encKey)
          }
          if (key) userIdToKey.set(String(s.userId), key)
        }
        // also collect all keys to try for accounts without userId
        const allSettings: any[] = await (Settings as any).find({})
        const allKeys: string[] = []
        for (const s of allSettings) {
          const key = decryptUserKey(s?.encryption?.userKeyEncrypted || s?.userEncryptionKey || null)
          if (key) allKeys.push(key)
        }
        const sensitive = ['pass','twofa','mail','passmail','mailkp','cookie','token','accessToken','cookies','sessionKey','secret','eaagToken','eaabToken']
        accounts = accounts.map((doc: any) => {
          const key = userIdToKey.get(String(doc.userId?._id || doc.userId)) || null
          const obj = doc.toObject ? doc.toObject() : doc
          if (key) {
            return decryptFields(obj, sensitive, key)
          }
          // Try all known keys field-by-field when userId is missing
          for (const f of sensitive) {
            if (isEncrypted(obj[f])) {
              for (const k of allKeys) {
                try {
                  const plain = decryptStringWithKey(obj[f], k)
                  if (plain) { obj[f] = plain; break }
                } catch {}
              }
              // As a final fallback, try adminKey directly
              if (isEncrypted(obj[f])) {
                try { obj[f] = decryptStringWithKey(obj[f], adminKey) } catch {}
              }
            }
          }
          return obj
        })
      } catch (e) {
        // swallow decryption errors; return raw
      }
    }
    
    // Get statistics
    const stats = await (FacebookAccount as any).aggregate([
      { $match: query },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ])
    
    const statusStats = stats.reduce((acc: any, stat) => {
      acc[stat._id] = stat.count
      return acc
    }, {})
    
    return NextResponse.json({
      accounts,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      },
      stats: statusStats
    })
    
  } catch (error) {
    console.error('Get accounts error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_accounts')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    const { accountId, action, data } = await request.json()
    
    if (!accountId || !action) {
      return NextResponse.json({ error: 'Thiếu thông tin cần thiết' }, { status: 400 })
    }
    
    let updateData: any = {}
    
    switch (action) {
      case 'update':
        updateData = data
        break
      case 'delete':
        await (FacebookAccount as any).findByIdAndDelete(accountId)
        return NextResponse.json({ message: 'Đã xóa tài khoản thành công' })
      case 'bulk_delete':
        const { accountIds } = data
        await (FacebookAccount as any).deleteMany({ _id: { $in: accountIds } })
        return NextResponse.json({ message: `Đã xóa ${accountIds.length} tài khoản thành công` })
      default:
        return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
    }
    
    const updatedAccount = await (FacebookAccount as any).findByIdAndUpdate(
      accountId,
      updateData,
      { new: true }
    ).populate('userId', 'username email')
    
    if (!updatedAccount) {
      return NextResponse.json({ error: 'Tài khoản không tồn tại' }, { status: 404 })
    }
    
    return NextResponse.json({
      message: 'Cập nhật tài khoản thành công',
      account: updatedAccount
    })
    
  } catch (error) {
    console.error('Update account error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
} 