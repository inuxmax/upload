import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'

// Force dynamic rendering
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    // Dynamic imports
    const connectDB = (await import('@/lib/mongodb')).default;
    const Admin = (await import('@/models/Admin')).default;
    
    const token = request.cookies.get('admin_token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '')
    
    if (!token) {
      return NextResponse.json({ error: 'Không có token' }, { status: 401 })
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    
    await connectDB()
    
    const admin = await (Admin as any).findById(decoded.adminId).select('-password')
    
    if (!admin || !admin.isActive) {
      return NextResponse.json({ error: 'Admin không tồn tại hoặc đã bị khóa' }, { status: 401 })
    }
    
    return NextResponse.json({
      admin: {
        id: admin._id,
        username: admin.username,
        email: admin.email,
        role: admin.role,
        permissions: admin.permissions
      }
    })
    
  } catch (error) {
    console.error('Admin auth check error:', error)
    return NextResponse.json({ error: 'Token không hợp lệ' }, { status: 401 })
  }
} 