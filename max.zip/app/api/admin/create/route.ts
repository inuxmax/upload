import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'

export async function POST(request: NextRequest) {
  try {
    // Dynamic imports
    const connectDB = (await import('@/lib/mongodb')).default;
    const Admin = (await import('@/models/Admin')).default;
    
    await connectDB()
    
    // Kiểm tra xem admin đã tồn tại chưa
    const existingAdmin = await (Admin as any).findOne({ username: 'admin' })
    
    if (existingAdmin) {
      return NextResponse.json({ 
        message: 'Admin đã tồn tại!',
        username: 'admin',
        password: 'admin123'
      })
    }

    // Tạo password hash
    const hashedPassword = await bcrypt.hash('admin123', 12)
    
    // Tạo admin mới
    const admin = new Admin({
      username: 'admin',
      email: 'admin@xmdt.com',
      password: hashedPassword,
      role: 'admin',
      permissions: ['manage_users', 'manage_accounts', 'manage_general', 'manage_threads', 'manage_subscriptions', 'manage_nav', 'manage_seo', 'manage_transactions'],
      isActive: true
    })
    
    await (admin as any).save()
    
    return NextResponse.json({
      message: 'Admin đã được tạo thành công!',
      username: 'admin',
      password: 'admin123'
    })
    
  } catch (error) {
    console.error('Create admin error:', error)
    return NextResponse.json(
      { error: 'Lỗi tạo admin' },
      { status: 500 }
    )
  }
} 