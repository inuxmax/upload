import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import connectDB from '@/lib/mongodb'
import GeneralSettings from '@/models/GeneralSettings'

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Middleware để verify admin token
const verifyAdminToken = async (request: NextRequest) => {
  const token = request.cookies.get('admin_token')?.value || 
                request.headers.get('authorization')?.replace('Bearer ', '')
  
  if (!token) {
    return null
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    return decoded
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_general')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    let settings = await (GeneralSettings as any).findOne()
    
    if (!settings) {
      // Create default settings if none exist
      settings = await (GeneralSettings as any).create({})
    }
    
    return NextResponse.json({ settings })
    
  } catch (error) {
    console.error('Get general settings error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_general')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    const updateData = await request.json()
    
    let settings = await (GeneralSettings as any).findOne()
    
    if (!settings) {
      settings = await (GeneralSettings as any).create(updateData)
    } else {
      settings = await (GeneralSettings as any).findOneAndUpdate(
        {},
        { ...updateData, lastUpdated: new Date() },
        { new: true }
      )
    }
    
    return NextResponse.json({
      message: 'Cập nhật cài đặt thành công',
      settings
    })
    
  } catch (error) {
    console.error('Update general settings error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
} 