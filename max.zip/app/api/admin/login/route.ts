import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

export async function POST(request: NextRequest) {
  try {
    // Dynamic imports
    const connectDB = (await import('@/lib/mongodb')).default;
    const Admin = (await import('@/models/Admin')).default;
    
    await connectDB()
    
    const { username, password } = await request.json()
    
    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username và password là bắt buộc' },
        { status: 400 }
      )
    }
    
    const admin = await (Admin as any).findOne({ username, isActive: true })
    
    if (!admin) {
      return NextResponse.json(
        { error: 'Tài khoản không tồn tại hoặc đã bị khóa' },
        { status: 401 }
      )
    }
    
    const isPasswordValid = await bcrypt.compare(password, admin.password)
    
    if (!isPasswordValid) {
      return NextResponse.json(
        { error: 'Mật khẩu không đúng' },
        { status: 401 }
      )
    }
    
    // Update last login
    await (Admin as any).findByIdAndUpdate(admin._id, { lastLogin: new Date() })
    
    const token = jwt.sign(
      { 
        adminId: admin._id, 
        username: admin.username,
        role: admin.role,
        permissions: admin.permissions
      },
      process.env.JWT_SECRET!,
      { expiresIn: '24h' }
    )
    
    const response = NextResponse.json({
      message: 'Đăng nhập thành công',
      admin: {
        id: admin._id,
        username: admin.username,
        email: admin.email,
        role: admin.role,
        permissions: admin.permissions
      }
    })
    
    response.cookies.set('admin_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 // 24 hours
    })
    
    return response
    
  } catch (error) {
    console.error('Admin login error:', error)
    return NextResponse.json(
      { error: 'Lỗi server' },
      { status: 500 }
    )
  }
} 