import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import connectDB from '@/lib/mongodb'
import Navigation from '@/models/Navigation'

// Middleware để verify admin token
const verifyAdminToken = async (request: NextRequest) => {
  const token = request.cookies.get('admin_token')?.value || 
                request.headers.get('authorization')?.replace('Bearer ', '')
  
  if (!token) {
    return null
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    return decoded
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_nav')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    const navigation = await (Navigation as any).find()
      .sort({ order: 1, createdAt: 1 })
    
    return NextResponse.json({ navigation })
    
  } catch (error) {
    console.error('Get navigation error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_nav')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    const navigationData = await request.json()
    
    const newNavigation = await (Navigation as any).create(navigationData)
    
    return NextResponse.json({
      message: 'Thêm menu thành công',
      navigation: newNavigation
    })
    
  } catch (error) {
    console.error('Create navigation error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_nav')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    const { navigationId, action, data } = await request.json()
    
    if (!navigationId || !action) {
      return NextResponse.json({ error: 'Thiếu thông tin cần thiết' }, { status: 400 })
    }
    
    let updateData: any = {}
    
    switch (action) {
      case 'update':
        updateData = data
        break
      case 'activate':
        updateData = { isActive: true }
        break
      case 'deactivate':
        updateData = { isActive: false }
        break
      case 'delete':
        await (Navigation as any).findByIdAndDelete(navigationId)
        return NextResponse.json({ message: 'Đã xóa menu thành công' })
      default:
        return NextResponse.json({ error: 'Hành động không hợp lệ' }, { status: 400 })
    }
    
    const updatedNavigation = await (Navigation as any).findByIdAndUpdate(
      navigationId,
      updateData,
      { new: true }
    )
    
    if (!updatedNavigation) {
      return NextResponse.json({ error: 'Menu không tồn tại' }, { status: 404 })
    }
    
    return NextResponse.json({
      message: 'Cập nhật menu thành công',
      navigation: updatedNavigation
    })
    
  } catch (error) {
    console.error('Update navigation error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
} 