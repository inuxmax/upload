import { NextRequest, NextResponse } from 'next/server';
import PaymentInfo from '@/models/PaymentInfo';
import connectMongoDB from '@/lib/mongodb';
import jwt from 'jsonwebtoken';

// Helper function to verify admin token
async function verifyAdminToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

function buildCorsHeaders(request: NextRequest) {
  const origin = request.headers.get('origin') || '*';
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Methods': 'GET,PUT,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  } as Record<string, string>;
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 204, headers: buildCorsHeaders(request) });
}

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const paymentInfo = await (PaymentInfo as any).findOne({ isActive: true });
    
    if (!paymentInfo) {
      // Tạo thông tin mặc định nếu chưa có
      const defaultPaymentInfo = new PaymentInfo({
        bankName: 'ACB Bank',
        accountNumber: '123456789',
        accountHolder: 'CÔNG TY ABC',
        transferContent: 'MAXABC123DEF456',
        passwordACB: '',
        tokenACB: '',
        isActive: true
      });
      await (defaultPaymentInfo as any).save();
      return NextResponse.json(defaultPaymentInfo, { headers: buildCorsHeaders(request) });
    }
    
    return NextResponse.json(paymentInfo, { headers: buildCorsHeaders(request) });
  } catch (error) {
    console.error('Error fetching payment info:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500, headers: buildCorsHeaders(request) }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Try to get token from authorization header first
    let token = request.headers.get('authorization')?.replace('Bearer ', '');
    if (!token || token === 'null' || token === 'undefined') {
      token = '';
    }
    
    // If no authorization header, try to get from cookies
    if (!token) {
      const cookies = request.headers.get('cookie');
      if (cookies) {
        const adminTokenMatch = cookies.match(/admin_token=([^;]+)/);
        if (adminTokenMatch) {
          token = adminTokenMatch[1];
        }
      }
    }
    
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401, headers: buildCorsHeaders(request) }
      );
    }

    const admin = await verifyAdminToken(token);
    if (!admin) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401, headers: buildCorsHeaders(request) }
      );
    }

    const body = await request.json();
    const { bankName, accountNumber, accountHolder, transferContent, passwordACB, tokenACB } = body;
    
    let paymentInfo = await (PaymentInfo as any).findOne({ isActive: true });
    
    if (!paymentInfo) {
      // Tạo mới nếu chưa có
      paymentInfo = new PaymentInfo({
        bankName: bankName || 'ACB Bank',
        accountNumber: accountNumber || '123456789',
        accountHolder: accountHolder || 'CÔNG TY ABC',
        transferContent: transferContent || 'MAXABC123DEF456',
        passwordACB: passwordACB || '',
        tokenACB: tokenACB || '',
        isActive: true
      });
    } else {
      // Cập nhật thông tin hiện tại
      paymentInfo.bankName = bankName || paymentInfo.bankName;
      paymentInfo.accountNumber = accountNumber || paymentInfo.accountNumber;
      paymentInfo.accountHolder = accountHolder || paymentInfo.accountHolder;
      paymentInfo.transferContent = transferContent || paymentInfo.transferContent;
      paymentInfo.passwordACB = passwordACB !== undefined ? passwordACB : paymentInfo.passwordACB;
      paymentInfo.tokenACB = tokenACB !== undefined ? tokenACB : paymentInfo.tokenACB;
    }
    
    await (paymentInfo as any).save();
    
    return NextResponse.json({
      message: 'Payment info updated successfully',
      data: {
        bankName: paymentInfo.bankName,
        accountNumber: paymentInfo.accountNumber,
        accountHolder: paymentInfo.accountHolder,
        transferContent: paymentInfo.transferContent,
        passwordACB: paymentInfo.passwordACB ? '***' : '',
        tokenACB: paymentInfo.tokenACB ? '***' : ''
      }
    }, { headers: buildCorsHeaders(request) });
  } catch (error) {
    console.error('Error updating payment info:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500, headers: buildCorsHeaders(request) }
    );
  }
} 