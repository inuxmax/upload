import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import ProxySettings from '@/models/ProxySettings';
import jwt from 'jsonwebtoken';

async function verifyAdminToken(request: NextRequest) {
  try {
    const token = request.cookies.get('admin_token')?.value;
    if (!token) {
      return null;
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// GET - Lấy danh sách tất cả proxy settings
export async function GET(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request);
    if (!admin || (admin.role !== 'admin' && admin.role !== 'super_admin')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    await connectMongoDB();
    const proxySettings = await (ProxySettings as any).find({}).sort({ createdAt: -1 });
    
    return NextResponse.json({ proxySettings });
  } catch (error) {
    console.error('Error fetching proxy settings:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST - Tạo proxy setting mới
export async function POST(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request);
    if (!admin || (admin.role !== 'admin' && admin.role !== 'super_admin')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { name, apiKey, isActive = true, isResidential = false, maxUsers = 10 } = await request.json();
    
    if (!name || !apiKey) {
      return NextResponse.json({ error: 'Name and API key are required' }, { status: 400 });
    }

    await connectMongoDB();
    
    // Kiểm tra tên đã tồn tại chưa
    const existingProxy = await (ProxySettings as any).findOne({ name });
    if (existingProxy) {
      return NextResponse.json({ error: 'Proxy name already exists' }, { status: 400 });
    }

    const newProxySetting = new ProxySettings({
      name,
      apiKey,
      isActive,
      isResidential,
      maxUsers
    });

    await (newProxySetting as any).save();
    
    return NextResponse.json({ 
      message: 'Proxy setting created successfully',
      proxySetting: newProxySetting 
    });
  } catch (error) {
    console.error('Error creating proxy setting:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// PUT - Cập nhật proxy setting
export async function PUT(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request);
    if (!admin || (admin.role !== 'admin' && admin.role !== 'super_admin')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id, name, apiKey, isActive, isResidential, maxUsers } = await request.json();
    
    if (!id) {
      return NextResponse.json({ error: 'Proxy ID is required' }, { status: 400 });
    }

    await connectMongoDB();
    
    const proxySetting = await (ProxySettings as any).findById(id);
    if (!proxySetting) {
      return NextResponse.json({ error: 'Proxy setting not found' }, { status: 404 });
    }

    // Kiểm tra tên mới có trùng với proxy khác không
    if (name && name !== proxySetting.name) {
      const existingProxy = await (ProxySettings as any).findOne({ name, _id: { $ne: id } });
      if (existingProxy) {
        return NextResponse.json({ error: 'Proxy name already exists' }, { status: 400 });
      }
    }

    const updateData: any = {};
    if (name !== undefined) updateData.name = name;
    if (apiKey !== undefined) updateData.apiKey = apiKey;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (isResidential !== undefined) updateData.isResidential = isResidential;
    if (maxUsers !== undefined) updateData.maxUsers = maxUsers;

    const updatedProxySetting = await (ProxySettings as any).findByIdAndUpdate(
      id, 
      updateData,
      { new: true }
    );
    
    return NextResponse.json({ 
      message: 'Proxy setting updated successfully',
      proxySetting: updatedProxySetting 
    });
  } catch (error) {
    console.error('Error updating proxy setting:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE - Xóa proxy setting
export async function DELETE(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request);
    if (!admin || (admin.role !== 'admin' && admin.role !== 'super_admin')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ error: 'Proxy ID is required' }, { status: 400 });
    }

    await connectMongoDB();
    
    const proxySetting = await (ProxySettings as any).findByIdAndDelete(id);
    if (!proxySetting) {
      return NextResponse.json({ error: 'Proxy setting not found' }, { status: 404 });
    }
    
    return NextResponse.json({ 
      message: 'Proxy setting deleted successfully' 
    });
  } catch (error) {
    console.error('Error deleting proxy setting:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
} 