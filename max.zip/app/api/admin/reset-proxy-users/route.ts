import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import ProxySettings from '@/models/ProxySettings';
import Settings from '@/models/Settings';

// POST - Reset số user sử dụng proxy
export async function POST(request: NextRequest) {
  try {
    console.log('🔄 POST /api/admin/reset-proxy-users called');
    
    await connectMongoDB();
    
    // Reset tất cả currentUsers về 0
    const result = await ProxySettings.updateMany({}, { currentUsers: 0 });
    
    console.log('✅ Reset proxy users result:', result);
    
    return NextResponse.json({ 
      success: true,
      message: 'Đã reset số user sử dụng proxy thành công',
      modifiedCount: result.modifiedCount
    });
  } catch (error) {
    console.error('Error resetting proxy users:', error);
    return NextResponse.json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
} 