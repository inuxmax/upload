import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import connectDB from '@/lib/mongodb'
import SEO from '@/models/SEO'

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Middleware để verify admin token
const verifyAdminToken = async (request: NextRequest) => {
  const token = request.cookies.get('admin_token')?.value || 
                request.headers.get('authorization')?.replace('Bearer ', '')
  
  if (!token) {
    return null
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    return decoded
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_seo')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    let seoSettings = await (SEO as any).findOne()
    
    if (!seoSettings) {
      // Create default SEO settings if none exist
      seoSettings = await (SEO as any).create({})
    }
    
    return NextResponse.json({ seoSettings })
    
  } catch (error) {
    console.error('Get SEO settings error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin || !admin.permissions.includes('manage_seo')) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    const updateData = await request.json()
    
    let seoSettings = await (SEO as any).findOne()
    
    if (!seoSettings) {
      seoSettings = await (SEO as any).create(updateData)
    } else {
      seoSettings = await (SEO as any).findOneAndUpdate(
        {},
        { ...updateData, lastUpdated: new Date() },
        { new: true }
      )
    }
    
    return NextResponse.json({
      message: 'Cập nhật SEO thành công',
      seoSettings
    })
    
  } catch (error) {
    console.error('Update SEO settings error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
} 