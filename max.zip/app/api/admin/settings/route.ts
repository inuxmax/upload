import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import AdminSettings from '@/models/AdminSettings';
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to get admin from token
async function getAdminFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// GET admin settings
export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('admin_token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const admin = await getAdminFromToken(token);
    if (!admin) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    let settings = await (AdminSettings as any).findOne();
    
    // Create default settings if none exist
    if (!settings) {
      settings = await (AdminSettings as any).create({
        globalMaxThreads: 50,
        systemStatus: 'active',
        maintenanceMessage: '',
        allowUserThreadSettings: true,
        defaultUserThreads: 10
      });
    }

    return NextResponse.json(settings);
  } catch (error) {
    console.error('Error fetching admin settings:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// PUT/UPDATE admin settings
export async function PUT(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('admin_token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const admin = await getAdminFromToken(token);
    
    if (!admin) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const body = await request.json();
    
    // Update or create settings
    const settings = await (AdminSettings as any).findOneAndUpdate(
      {},
      {
        $set: {
          globalMaxThreads: body.globalMaxThreads || 50,
          systemStatus: body.systemStatus || 'active',
          maintenanceMessage: body.maintenanceMessage || '',
          allowUserThreadSettings: body.allowUserThreadSettings !== undefined ? body.allowUserThreadSettings : true,
          defaultUserThreads: body.defaultUserThreads || 10
        }
      },
      { upsert: true, new: true }
    );

    return NextResponse.json(settings);
  } catch (error) {
    console.error('Error updating admin settings:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
} 