import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import connectDB from '@/lib/mongodb'
import User from '@/models/User'
import FacebookAccount from '@/models/FacebookAccount'

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Middleware để verify admin token
const verifyAdminToken = async (request: NextRequest) => {
  const token = request.cookies.get('admin_token')?.value
  
  if (!token) {
    return null
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    return decoded
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const admin = await verifyAdminToken(request)
    if (!admin) {
      return NextResponse.json({ error: 'Không có quyền truy cập' }, { status: 403 })
    }
    
    await connectDB()
    
    // Get statistics
    const [
      totalUsers,
      activeUsers,
      bannedUsers,
      totalAccounts,
      activeAccounts,
      totalBalanceResult
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ isActive: true }),
      User.countDocuments({ isActive: false }),
      FacebookAccount.countDocuments(),
      FacebookAccount.countDocuments({ status: 'active' }),
      User.aggregate([
        { $group: { _id: null, totalBalance: { $sum: '$balance' } } }
      ])
    ])
    
    const totalBalance = totalBalanceResult[0]?.totalBalance || 0;
    
    const stats = {
      totalUsers,
      activeUsers,
      bannedUsers,
      totalBalance,
      totalAccounts,
      activeAccounts
    }
    
    return NextResponse.json(stats)
    
  } catch (error) {
    console.error('Get stats error:', error)
    return NextResponse.json({ error: 'Lỗi server' }, { status: 500 })
  }
} 