import { NextRequest, NextResponse } from 'next/server';
import SubscriptionPlan from '@/models/SubscriptionPlan';
import connectMongoDB from '@/lib/mongodb';
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to verify admin token
async function verifyAdminToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB();
    
    // Try to get token from authorization header first
    let token = request.headers.get('authorization')?.replace('Bearer ', '');
    
    // If no authorization header, try to get from cookies
    if (!token) {
      const cookies = request.headers.get('cookie');
      if (cookies) {
        const adminTokenMatch = cookies.match(/admin_token=([^;]+)/);
        if (adminTokenMatch) {
          token = adminTokenMatch[1];
        }
      }
    }
    
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const admin = await verifyAdminToken(token);
    if (!admin) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    const body = await request.json();
    
    const plan = await (SubscriptionPlan as any).findByIdAndUpdate(
      params.id,
      body,
      { new: true, runValidators: true }
    );
    
    if (!plan) {
      return NextResponse.json(
        { error: 'Plan not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(plan);
  } catch (error) {
    console.error('Error updating subscription plan:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB();
    
    // Try to get token from authorization header first
    let token = request.headers.get('authorization')?.replace('Bearer ', '');
    
    // If no authorization header, try to get from cookies
    if (!token) {
      const cookies = request.headers.get('cookie');
      if (cookies) {
        const adminTokenMatch = cookies.match(/admin_token=([^;]+)/);
        if (adminTokenMatch) {
          token = adminTokenMatch[1];
        }
      }
    }
    
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const admin = await verifyAdminToken(token);
    if (!admin) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    const plan = await (SubscriptionPlan as any).findByIdAndDelete(params.id);
    
    if (!plan) {
      return NextResponse.json(
        { error: 'Plan not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json({ message: 'Plan deleted successfully' });
  } catch (error) {
    console.error('Error deleting subscription plan:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 