import { NextRequest, NextResponse } from 'next/server';
import SubscriptionPlan from '@/models/SubscriptionPlan';
import connectMongoDB from '@/lib/mongodb';
import jwt from 'jsonwebtoken';

// Helper function to verify admin token
async function verifyAdminToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const plans = await (SubscriptionPlan as any).find().sort({ price: 1 });
    
    return NextResponse.json(plans);
  } catch (error) {
    console.error('Error fetching subscription plans:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Try to get token from authorization header first
    let token = request.headers.get('authorization')?.replace('Bearer ', '');
    
    // If no authorization header, try to get from cookies
    if (!token) {
      const cookies = request.headers.get('cookie');
      if (cookies) {
        const adminTokenMatch = cookies.match(/admin_token=([^;]+)/);
        if (adminTokenMatch) {
          token = adminTokenMatch[1];
        }
      }
    }
    
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const admin = await verifyAdminToken(token);
    if (!admin) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    // Sanitize body and validate required fields
    const payload = await request.json();
    const {
      name,
      plan,
      duration,
      price,
      currency,
      maxThreads,
      features,
      isActive,
      description
    } = payload || {};

    if (!name || !plan || !duration || price === undefined || maxThreads === undefined || !description) {
      return NextResponse.json(
        { error: 'Missing required fields: name, plan, duration, price, maxThreads, description' },
        { status: 400 }
      );
    }

    // Kiểm tra xem plan đã tồn tại chưa
    const existingPlan = await (SubscriptionPlan as any).findOne({ plan });
    if (existingPlan) {
      return NextResponse.json(
        { error: 'Plan already exists' },
        { status: 400 }
      );
    }

    // Only allow whitelisted fields, DO NOT accept _id from client
    const planDoc = new (SubscriptionPlan as any)({
      name,
      plan,
      duration,
      price,
      currency: currency || 'VND',
      maxThreads,
      features: Array.isArray(features) ? features.filter((f: string) => typeof f === 'string' && f.trim().length > 0) : [],
      isActive: typeof isActive === 'boolean' ? isActive : true,
      description
    });
    await planDoc.save();
    
    return NextResponse.json(planDoc, { status: 201 });
  } catch (error) {
    console.error('Error creating subscription plan:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 