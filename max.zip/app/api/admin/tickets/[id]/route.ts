import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import { verifyToken, extractTokenFromRequest } from '@/lib/jwt'
import Ticket from '@/models/Ticket'
import TicketMessage from '@/models/TicketMessage'

// Force dynamic rendering
export const dynamic = 'force-dynamic'


export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // For now, allow any authenticated user to view tickets
    // In production, you should implement proper admin role checking
    const decoded: any = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const ticket = await (Ticket as any).findById(params.id)
    if (!ticket) {
      return NextResponse.json({ error: 'Ticket not found' }, { status: 404 })
    }

    const messages = await (TicketMessage as any).find({ ticketId: params.id })
      .sort({ createdAt: 1 })
      .lean()

    return NextResponse.json({
      success: true,
      ticket,
      messages
    })

  } catch (error) {
    console.error('Error fetching ticket:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // For now, allow any authenticated user to send admin messages
    // In production, you should implement proper admin role checking
    const decoded: any = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const body = await request.json()
    const content = body.content ? String(body.content).trim() : ''
    const imageUrl = body.imageUrl

    if (!content && !imageUrl) {
      return NextResponse.json(
        { error: 'Nội dung tin nhắn hoặc ảnh không được để trống' },
        { status: 400 }
      )
    }

    // Create admin message
    const messageData: any = {
      ticketId: params.id,
      senderType: 'admin',
      senderId: decoded.userId || decoded.id || decoded._id,
      isRead: false // Mark as unread by default
    }
    
    if (content && content.length > 0) {
      messageData.content = content
    }
    
    if (imageUrl && imageUrl.length > 0) {
      messageData.imageUrl = imageUrl
    }
    
    const message = await (TicketMessage as any).create(messageData)

    // Update ticket lastMessageAt
    await (Ticket as any).findByIdAndUpdate(params.id, {
      lastMessageAt: new Date()
    })



    return NextResponse.json({
      success: true,
      message
    })

  } catch (error) {
    console.error('Error sending admin message:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Verify admin token
    const decoded: any = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    const ticketId = params.id

    // Delete all messages first
    await (TicketMessage as any).deleteMany({ ticketId })

    // Delete the ticket
    const deletedTicket = await (Ticket as any).findByIdAndDelete(ticketId)

    if (!deletedTicket) {
      return NextResponse.json({ error: 'Ticket not found' }, { status: 404 })
    }

    console.log(`Admin ${decoded.username || decoded.userId} đã xóa ticket ${ticketId}`)

    return NextResponse.json({
      success: true,
      message: 'Ticket đã được xóa thành công',
      deletedTicket
    })

  } catch (error) {
    console.error('Error deleting ticket:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
