import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import { verifyToken, extractTokenFromRequest } from '@/lib/jwt'
import Ticket from '@/models/Ticket'

// Force dynamic rendering
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // For now, allow any authenticated user to view tickets
    // In production, you should implement proper admin role checking
    const decoded: any = verifyToken(token)
    if (!decoded) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 })
    }

    // Get all tickets with user information
    const tickets = await (Ticket as any).aggregate([
      {
        $lookup: {
          from: 'users',
          localField: 'userId',
          foreignField: '_id',
          as: 'user'
        }
      },
      {
        $unwind: '$user'
      },
      {
        $project: {
          _id: 1,
          title: 1,
          subject: 1,
          status: 1,
          createdAt: 1,
          updatedAt: 1,
          lastMessageAt: 1,
          'user.username': 1,
          'user.email': 1
        }
      },
      {
        $sort: { lastMessageAt: -1 }
      }
    ])

    return NextResponse.json({
      success: true,
      tickets
    })

  } catch (error) {
    console.error('Error fetching admin tickets:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
