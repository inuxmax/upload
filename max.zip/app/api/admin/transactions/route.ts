import { NextRequest, NextResponse } from 'next/server';
import Transaction from '@/models/Transaction';
import connectMongoDB from '@/lib/mongodb';
import jwt from 'jsonwebtoken';
import Admin from '@/models/Admin';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to get admin from token
async function getAdminFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    const admin = await (Admin as any).findById(decoded.adminId);
    return admin;
  } catch (error) {
    return null;
  }
}

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.headers.get('authorization')?.replace('Bearer ', '');
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const admin = await getAdminFromToken(token);
    if (!admin) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    // Check admin permissions
    if (!admin.permissions.includes('all') && !admin.permissions.includes('manage_transactions')) {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      );
    }

    // Get query parameters
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status');
    const type = searchParams.get('type');
    const userId = searchParams.get('userId');
    const search = searchParams.get('search');

    // Build query
    const query: any = {};
    if (status) query.status = status;
    if (type) query.type = type;
    if (userId) query.userId = userId;
    if (search) {
      query.$or = [
        { transactionId: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { transferContent: { $regex: search, $options: 'i' } }
      ];
    }

    // Get transactions with pagination
    const transactions = await (Transaction as any).find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit)
      .populate('userId', 'username email');

    // Get total count
    const total = await (Transaction as any).countDocuments(query);

    // Get statistics
    const stats = await (Transaction as any).aggregate([
      { $match: query },
      {
        $group: {
          _id: null,
          totalAmount: { $sum: '$amount' },
          completedCount: {
            $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] }
          },
          pendingCount: {
            $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] }
          },
          failedCount: {
            $sum: { $cond: [{ $eq: ['$status', 'failed'] }, 1, 0] }
          }
        }
      }
    ]);

    return NextResponse.json({
      transactions,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      },
      stats: stats[0] || {
        totalAmount: 0,
        completedCount: 0,
        pendingCount: 0,
        failedCount: 0
      }
    });
  } catch (error) {
    console.error('Error fetching admin transactions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 