import { NextRequest, NextResponse } from 'next/server'
import jwt from 'jsonwebtoken'
import { spawn } from 'child_process'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get('admin_token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Không có token' }, { status: 401 })
    }

    let decoded: any
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    } catch {
      return NextResponse.json({ error: 'Token không hợp lệ' }, { status: 401 })
    }

    // Optional: you can check admin permissions by querying DB if needed
    // For lightweight trigger, we proceed if token is valid

    // Spawn updater as detached process so API can return immediately
    const child = spawn('node', ['update.mjs'], {
      cwd: process.cwd(),
      detached: true,
      stdio: 'ignore',
      shell: process.platform === 'win32'
    })
    try { child.unref() } catch {}

    return NextResponse.json({ started: true })
  } catch (error) {
    console.error('Update trigger error:', error)
    return NextResponse.json({ error: 'Không thể khởi động cập nhật' }, { status: 500 })
  }
}


