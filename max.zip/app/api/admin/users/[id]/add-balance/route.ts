import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import User from '@/models/User';
import Transaction from '@/models/Transaction';
import connectMongoDB from '@/lib/mongodb';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to verify admin token
async function verifyAdminToken(request: NextRequest) {
  try {
    const token = request.cookies.get('admin_token')?.value;
    if (!token) return null;

    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB();
    
    // Verify admin authentication
    const admin = await verifyAdminToken(request);
    if (!admin || !admin.adminId) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { amount } = await request.json();
    const userId = params.id;

    // Validate input
    if (!amount || typeof amount !== 'number' || amount <= 0) {
      return NextResponse.json(
        { error: 'Invalid amount' },
        { status: 400 }
      );
    }

    // Find user
    const user = await (User as any).findById(userId);
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Update user balance
    const oldBalance = user.balance || 0;
    const newBalance = oldBalance + amount;
    
    console.log(`Updating balance for user ${user.username}: ${oldBalance} -> ${newBalance}`);
    
    user.balance = newBalance;
    await (user as any).save();
    
    console.log('User balance updated successfully');

    // Create transaction record
    const transactionId = `ADMIN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    console.log('Creating transaction with ID:', transactionId);
    
    const transaction = new Transaction({
      userId: user._id,
      transactionId: transactionId,
      type: 'deposit',
      amount: amount,
      transferContent: `ADMIN_ADD_${Date.now()}`,
      status: 'completed',
      description: `Admin cộng tiền - ${admin.username}`,
      bankInfo: {
        bankName: 'Admin System',
        accountNumber: 'ADMIN',
        accountHolder: 'SYSTEM'
      },
      completedAt: new Date()
    });

    const savedTransaction = await (transaction as any).save();
    console.log('Transaction saved successfully:', savedTransaction._id);

    return NextResponse.json({
      success: true,
      message: `Đã cộng ${amount.toLocaleString('vi-VN')} VND cho user ${user.username}`,
      oldBalance,
      newBalance: user.balance,
      transactionId: savedTransaction._id
    });

  } catch (error) {
    console.error('Error adding balance:', error);
    
    // Provide more specific error message
    let errorMessage = 'Internal server error';
    if (error instanceof Error) {
      errorMessage = error.message;
    }
    
    return NextResponse.json(
      { 
        error: errorMessage,
        details: error instanceof Error ? error.stack : String(error)
      },
      { status: 500 }
    );
  }
}
