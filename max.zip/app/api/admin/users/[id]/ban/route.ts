import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import User from '@/models/User';
import jwt from 'jsonwebtoken';

// Verify admin token
async function verifyAdminToken(request: NextRequest) {
  try {
    const token = request.cookies.get('admin_token')?.value;
    
    if (!token) {
      return null;
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB();
    
    // Verify admin authentication
    const admin = await verifyAdminToken(request);
    if (!admin || (admin.role !== 'admin' && admin.role !== 'super_admin')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { id } = params;
    const body = await request.json();
    const { status } = body;

    // Validate status
    if (status !== 'active' && status !== 'inactive') {
      return NextResponse.json(
        { error: 'Status không hợp lệ' },
        { status: 400 }
      );
    }

    // Check if user exists
    const existingUser = await (User as any).findById(id);
    if (!existingUser) {
      return NextResponse.json(
        { error: 'User không tồn tại' },
        { status: 404 }
      );
    }

    // Update user status
    const updatedUser = await (User as any).findByIdAndUpdate(
      id,
      { status },
      { new: true, select: '-password' }
    );

    const action = status === 'active' ? 'unban' : 'ban';
    return NextResponse.json({
      success: true,
      message: `User đã được ${action} thành công`,
      user: updatedUser
    });

  } catch (error) {
    console.error('Error updating user status:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 