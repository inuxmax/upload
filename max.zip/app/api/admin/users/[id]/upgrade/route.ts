import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import User from '@/models/User';
import Subscription from '@/models/Subscription';
import jwt from 'jsonwebtoken';

// Verify admin token
async function verifyAdminToken(request: NextRequest) {
  try {
    const token = request.cookies.get('admin_token')?.value;
    
    if (!token) {
      return null;
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB();
    
    // Verify admin authentication
    const admin = await verifyAdminToken(request);
    if (!admin || (admin.role !== 'admin' && admin.role !== 'super_admin')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { id } = params;
    const body = await request.json();
    const { plan, duration } = body;

    // Validate required fields
    if (!plan || !duration) {
      return NextResponse.json(
        { error: 'Plan và duration là bắt buộc' },
        { status: 400 }
      );
    }

    // Check if user exists
    const existingUser = await (User as any).findById(id);
    if (!existingUser) {
      return NextResponse.json(
        { error: 'User không tồn tại' },
        { status: 404 }
      );
    }

    // Calculate end date
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + duration);

    // Update or create subscription
    const subscription = await (Subscription as any).findOneAndUpdate(
      { userId: id },
      {
        userId: id,
        plan,
        status: 'active',
        startDate: new Date(),
        endDate,
        updatedAt: new Date()
      },
      { upsert: true, new: true }
    );

    return NextResponse.json({
      success: true,
      message: `User đã được nâng cấp lên gói ${plan} thành công`,
      subscription
    });

  } catch (error) {
    console.error('Error upgrading user:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 