import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/mongodb'
import User from '@/models/User'
import SystemSettings from '@/models/SystemSettings'

export const dynamic = 'force-dynamic'

// POST - Reset tất cả lịch sử ẩn popup
export async function POST(request: NextRequest) {
  try {
    await dbConnect()
    
    // Kiểm tra quyền admin
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Xóa tất cả lịch sử ẩn popup từ database
    // Cập nhật tất cả user để xóa welcomePopupDismissed
    await (User as any).updateMany({}, { $unset: { welcomePopupDismissed: 1 } })
    
    // Cũng có thể reset trong SystemSettings nếu cần
    await (SystemSettings as any).findOneAndUpdate(
      { type: 'welcome_popup' },
      { 
        $set: { 
          'data.lastReset': new Date(),
          updatedAt: new Date()
        }
      },
      { upsert: true }
    )

    return NextResponse.json({ 
      success: true,
      message: 'All popup dismissals have been reset' 
    })
  } catch (error) {
    console.error('Error resetting popup dismissals:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
