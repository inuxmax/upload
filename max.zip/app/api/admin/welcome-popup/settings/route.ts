import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/mongodb'
import SystemSettings from '@/models/SystemSettings'

export const dynamic = 'force-dynamic'

// GET - Lấy cài đặt popup
export async function GET(request: NextRequest) {
  try {
    await dbConnect()
    
    // Kiểm tra quyền admin
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Lấy cài đặt từ database hoặc trả về default
    const defaultSettings = {
      enabled: true,
      title: "Thông báo",
      message: "Chào mừng bạn quay trở lại !",
      showDontShowAgain: true,
      showOnLogin: true,
      showOnDashboard: false
    }

    // Lấy cài đặt từ database
    let settings = await (SystemSettings as any).findOne({ type: 'welcome_popup' })
    
    if (!settings) {
      // Nếu chưa có, tạo mới với default
      settings = await (SystemSettings as any).create({
        type: 'welcome_popup',
        data: defaultSettings
      })
    }
    
    return NextResponse.json({ 
      settings: settings.data 
    })
  } catch (error) {
    console.error('Error loading welcome popup settings:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST - Lưu cài đặt popup
export async function POST(request: NextRequest) {
  try {
    await dbConnect()
    
    // Kiểm tra quyền admin
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { enabled, title, message, showDontShowAgain, showOnLogin, showOnDashboard } = body

    // Validate data
    if (typeof enabled !== 'boolean' || typeof title !== 'string' || typeof message !== 'string') {
      return NextResponse.json({ error: 'Invalid data' }, { status: 400 })
    }

    // Lưu vào database
    await (SystemSettings as any).findOneAndUpdate(
      { type: 'welcome_popup' },
      { 
        data: { enabled, title, message, showDontShowAgain, showOnLogin, showOnDashboard },
        updatedAt: new Date()
      },
      { upsert: true }
    )

    return NextResponse.json({ 
      success: true,
      message: 'Settings saved successfully' 
    })
  } catch (error) {
    console.error('Error saving welcome popup settings:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
