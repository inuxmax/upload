import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/mongodb'
import User from '@/models/User'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    await dbConnect()
    const { username } = await request.json()
    if (!username) return NextResponse.json({ error: 'Username is required' }, { status: 400 })

    const user: any = await (User as any).findOne({
      $or: [{ username }, { email: username }]
    }).select('_id username email isVerified')

    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

    return NextResponse.json({
      success: true,
      isVerified: user.isVerified,
      username: user.username,
      email: user.email
    })
  } catch (e) {
    console.error('Check verification error:', e)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
