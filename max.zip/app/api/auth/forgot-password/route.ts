import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/mongodb'
import User from '@/models/User'
import PasswordResetToken from '@/models/PasswordResetToken'
import crypto from 'crypto'
import bcrypt from 'bcryptjs'
import { sendPasswordResetEmail } from '@/lib/mailer'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    await dbConnect()
    const { email } = await request.json()
    if (!email) return NextResponse.json({ error: 'Email is required' }, { status: 400 })

    const user: any = await (User as any).findOne({ email }).select('_id email username')
    if (!user) {
      // Avoid user enumeration: respond success anyway
      return NextResponse.json({ success: true })
    }

    // Generate token
    const token = crypto.randomBytes(32).toString('hex')
    const tokenHash = await bcrypt.hash(token, 10)
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000) // 15 minutes

    // Store token
    await (PasswordResetToken as any).create({ userId: user._id, tokenHash, expiresAt })

    const origin = request.headers.get('origin') || request.nextUrl.origin
    const resetUrl = `${origin}/auth/reset?token=${encodeURIComponent(token)}&uid=${user._id}`
    await sendPasswordResetEmail(user.email, resetUrl)

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('Forgot password error:', e)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}


