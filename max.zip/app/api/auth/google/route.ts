import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import User from '@/models/User'
import { generateToken } from '@/lib/jwt'

// OAuth with Google Identity Services: client sends idToken (Google credential)
// Expect body: { idToken }
export async function POST(request: NextRequest) {
  try {
    await connectMongoDB()

    const body = await request.json().catch(() => ({} as any))
    const { idToken } = body || {}

    if (!idToken) {
      return NextResponse.json({ success: false, error: 'Missing idToken' }, { status: 400 })
    }

    // Verify id_token with Google tokeninfo endpoint (avoids external deps)
    const verifyResp = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`)
    if (!verifyResp.ok) {
      const txt = await verifyResp.text().catch(() => '')
      return NextResponse.json({ success: false, error: `Invalid Google token`, details: txt }, { status: 401 })
    }
    const payload: any = await verifyResp.json()

    // Validate audience (support multiple client IDs via comma-separated env)
    const allowedAudsRaw = [
      process.env.GOOGLE_ALLOWED_AUDS || '',
      process.env.GOOGLE_CLIENT_ID || '',
      process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID || ''
    ].filter(Boolean).join(',')
    const allowedAuds = Array.from(new Set(
      allowedAudsRaw.split(',').map(s => s.trim()).filter(Boolean)
    ))
    if (allowedAuds.length > 0 && !allowedAuds.includes(payload.aud)) {
      return NextResponse.json({ success: false, error: 'Token audience mismatch', expected: allowedAuds, actual: payload.aud }, { status: 401 })
    }

    const email = payload.email as string | undefined
    const emailVerified = payload.email_verified === 'true' || payload.email_verified === true
    const googleId = payload.sub as string
    const fullName = payload.name as string | undefined
    const avatar = payload.picture as string | undefined

    if (!email || !emailVerified) {
      return NextResponse.json({ success: false, error: 'Email not verified' }, { status: 401 })
    }

    let user: any = await (User as any).findOne({ $or: [{ email }, { googleId }] })
    if (!user) {
      user = await (User as any).create({
        username: email.split('@')[0],
        email,
        password: Math.random().toString(36).slice(2),
        fullName: fullName || '',
        googleId,
        avatar: avatar || null,
        role: 'user',
        isActive: true
      })
    } else {
      if (!user.googleId) user.googleId = googleId
      if (avatar && !user.avatar) user.avatar = avatar
      if (fullName && !user.fullName) user.fullName = fullName
      await user.save()
    }

    if (!user.isActive) {
      return NextResponse.json({ success: false, error: 'Account is deactivated' }, { status: 401 })
    }

    const token = generateToken({ userId: user._id, username: user.username, role: user.role })

    return NextResponse.json({
      success: true,
      message: 'Google login successful',
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        avatar: user.avatar,
        role: user.role
      }
    })
  } catch (error: any) {
    console.error('Google login error:', error)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}


