import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import { generateToken } from '@/lib/jwt';
import bcryptjs from 'bcryptjs';

export async function POST(request: NextRequest) {
  try {
    await dbConnect();

    const body = await request.json();
    const { username, password } = body;
    
    // Log request data for debugging
    console.log('Login attempt:', {
      username: username ? username.substring(0, 3) + '***' : 'null',
      passwordLength: password ? password.length : 0,
      hasUsername: !!username,
      hasPassword: !!password,
      timestamp: new Date().toISOString()
    });
    
    // Validate required fields
    if (!username || !password) {
      console.log('Login failed: Missing required fields', { username: !!username, password: !!password });
      return NextResponse.json(
        { 
          error: 'Username and password are required',
          message: 'Vui lòng nhập tên đăng nhập và mật khẩu',
          code: 'MISSING_FIELDS'
        },
        { status: 400 }
      );
    }

    // Find user by username or email
    const user = await (User as any).findOne({
      $or: [
        { username: username.trim() },
        { email: username.trim().toLowerCase() }
      ]
    }).select('username email password isVerified isActive role fullName createdAt');

    if (!user) {
      console.log('Login failed: User not found', { username: username.substring(0, 3) + '***' });
      return NextResponse.json(
        { 
          error: 'Invalid credentials',
          message: 'Tên đăng nhập hoặc mật khẩu không đúng',
          code: 'USER_NOT_FOUND'
        },
        { status: 401 }
      );
    }

    console.log('User found:', {
      userId: user._id,
      username: user.username,
      email: user.email,
      isActive: user.isActive,
      isVerified: user.isVerified,
      role: user.role
    });

    // Check if user is active
    if (!user.isActive) {
      console.log('Login failed: Account deactivated', { userId: user._id });
      return NextResponse.json(
        { 
          error: 'Account is deactivated',
          message: 'Tài khoản đã bị vô hiệu hóa. Vui lòng liên hệ admin.',
          code: 'ACCOUNT_DEACTIVATED'
        },
        { status: 401 }
      );
    }

    // Check if user is verified
    if (!user.isVerified) {
      console.log('Login failed: Account not verified', { userId: user._id });
      return NextResponse.json(
        { 
          error: 'Account not verified',
          message: 'Tài khoản chưa được xác thực. Vui lòng kiểm tra email để xác thực.',
          code: 'ACCOUNT_NOT_VERIFIED'
        },
        { status: 403 }
      );
    }

    // Verify password
    console.log('Verifying password for user:', user._id);
    const isPasswordValid = await bcryptjs.compare(password, user.password);
    
    if (!isPasswordValid) {
      console.log('Login failed: Invalid password', { userId: user._id });
      return NextResponse.json(
        { 
          error: 'Invalid credentials',
          message: 'Tên đăng nhập hoặc mật khẩu không đúng',
          code: 'INVALID_PASSWORD'
        },
        { status: 401 }
      );
    }

    console.log('Password verified successfully for user:', user._id);

    // Generate JWT token
    const tokenPayload = { 
      userId: user._id, 
      username: user.username, 
      role: user.role,
      email: user.email
    };
    
    const token = generateToken(tokenPayload);
    console.log('JWT token generated successfully for user:', user._id);

    // Return user data (without password) and token
    const userResponse = {
      id: user._id,
      username: user.username,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      isActive: user.isActive,
      createdAt: user.createdAt
    };

    console.log('Login successful for user:', user._id);

    return NextResponse.json({
      success: true,
      message: 'Đăng nhập thành công',
      user: userResponse,
      token
    });

  } catch (error: any) {
    console.error('Login error:', {
      error: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
    
    return NextResponse.json(
      { 
        error: 'Internal server error',
        message: 'Có lỗi xảy ra khi đăng nhập. Vui lòng thử lại sau.',
        code: 'INTERNAL_ERROR'
      },
      { status: 500 }
    );
  }
} 