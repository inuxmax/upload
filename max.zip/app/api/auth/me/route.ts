import { NextRequest, NextResponse } from 'next/server';
import User from '@/models/User';
import connectMongoDB from '@/lib/mongodb';
import { verifyToken, extractTokenFromRequest } from '@/lib/jwt';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = extractTokenFromRequest(request);
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const decoded = verifyToken(token);
    
    if (!decoded || !decoded.userId) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const user = await (User as any).findById(decoded.userId).select('-password').exec();
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
              user: {
          id: user._id,
          username: user.username,
          email: user.email,
          role: user.role,
          maxThreads: user.maxThreads,
          balance: user.balance,
          createdAt: user.createdAt
        }
    });
  } catch (error) {
    console.error('Error in /api/auth/me:', error);
    return NextResponse.json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
