import { NextRequest, NextResponse } from 'next/server';
import { verifyToken, generateToken, checkTokenValidity } from '@/lib/jwt';

export async function POST(request: NextRequest) {
  try {
    // Lấy token từ request
    const authHeader = request.headers.get('authorization');
    const token = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : null;
    
    if (!token) {
      return NextResponse.json({ 
        error: 'No token provided',
        message: 'Token không được cung cấp',
        code: 'NO_TOKEN'
      }, { status: 401 });
    }
    
    // Kiểm tra token validity
    const tokenCheck = checkTokenValidity(token);
    
    if (!tokenCheck.isValid) {
      if (tokenCheck.error === 'TOKEN_EXPIRED') {
        return NextResponse.json({ 
          error: 'Token expired',
          message: 'Token đã hết hạn, vui lòng đăng nhập lại',
          code: 'TOKEN_EXPIRED'
        }, { status: 401 });
      }
      
      return NextResponse.json({ 
        error: 'Invalid token',
        message: 'Token không hợp lệ',
        code: 'TOKEN_INVALID'
      }, { status: 401 });
    }
    
    // Token hợp lệ, tạo token mới
    const decoded = tokenCheck.decoded;
    if (!decoded) {
      return NextResponse.json({ 
        error: 'Invalid token payload',
        message: 'Token payload không hợp lệ',
        code: 'INVALID_PAYLOAD'
      }, { status: 400 });
    }
    
    // Tạo token mới với thông tin từ token cũ
    const { iat, exp, ...payload } = decoded;
    const newToken = generateToken(payload);
    
    // Trả về token mới
    return NextResponse.json({
      success: true,
      message: 'Token đã được refresh thành công',
      token: newToken,
      expiresIn: '7d'
    });
    
  } catch (error) {
    console.error('Token refresh error:', error);
    
    return NextResponse.json({
      error: 'Internal server error',
      message: 'Lỗi server nội bộ',
      code: 'INTERNAL_ERROR'
    }, { status: 500 });
  }
}
