import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import EmailVerificationToken from '@/models/EmailVerificationToken';
import bcrypt from 'bcryptjs';
import { sendEmailVerification } from '@/lib/mailer';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export async function POST(request: NextRequest) {
  try {
    await dbConnect();

    const { username, email, password, fullName } = await request.json();

    // Validate required fields
    if (!username || !email || !password) {
      return NextResponse.json(
        { error: 'Username, email, and password are required' },
        { status: 400 }
      );
    }

    // Check if user already exists
    const existingUser = await (User as any).findOne({
      $or: [{ email }, { username }]
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User with this email or username already exists' },
        { status: 400 }
      );
    }

    // Create new user
    const user = new User({
      username,
      email,
      password,
      fullName,
      role: 'user',
      isActive: true,
      isVerified: false
    });

    console.log('Creating user with:', { username, email, isActive: user.isActive, isVerified: user.isVerified });

    await (user as any).save();
    
    console.log('User created successfully:', { userId: user._id, isActive: user.isActive, isVerified: user.isVerified });

    // Create email verification token (30 minutes)
    const rawToken = (await import('crypto')).randomBytes(32).toString('hex')
    const tokenHash = await bcrypt.hash(rawToken, 10)
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000)
    await (EmailVerificationToken as any).create({ userId: user._id, tokenHash, expiresAt })

    const origin = request.headers.get('origin') || (request as any).nextUrl?.origin || ''
    const verifyUrl = `${origin}/auth/verify?token=${encodeURIComponent(rawToken)}&uid=${user._id}`
    await sendEmailVerification(user.email, verifyUrl)

    return NextResponse.json({
      message: 'User registered successfully. Please verify your email to activate account.',
      requiresVerification: true
    }, { status: 201 });

  } catch (error: any) {
    console.error('Registration error:', error);
    
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map((err: any) => err.message);
      return NextResponse.json(
        { error: 'Validation error', details: errors },
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 