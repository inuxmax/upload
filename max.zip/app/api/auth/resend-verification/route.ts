import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/mongodb'
import User from '@/models/User'
import EmailVerificationToken from '@/models/EmailVerificationToken'
import bcrypt from 'bcryptjs'
import { sendEmailVerification } from '@/lib/mailer'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    await dbConnect()
    const { username } = await request.json()
    if (!username) return NextResponse.json({ error: 'Username is required' }, { status: 400 })

    const user: any = await (User as any).findOne({
      $or: [{ username }, { email: username }]
    }).select('_id username email isVerified')

    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })
    if (user.isVerified) return NextResponse.json({ error: 'User already verified' }, { status: 400 })

    // Delete old tokens
    await (EmailVerificationToken as any).deleteMany({ userId: user._id })

    // Create new verification token (30 minutes)
    const rawToken = (await import('crypto')).randomBytes(32).toString('hex')
    const tokenHash = await bcrypt.hash(rawToken, 10)
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000)
    await (EmailVerificationToken as any).create({ userId: user._id, tokenHash, expiresAt })

    const origin = request.headers.get('origin') || (request as any).nextUrl?.origin || ''
    const verifyUrl = `${origin}/auth/verify?token=${encodeURIComponent(rawToken)}&uid=${user._id}`
    await sendEmailVerification(user.email, verifyUrl)

    return NextResponse.json({ success: true, message: 'Verification email sent' })
  } catch (e) {
    console.error('Resend verification error:', e)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
