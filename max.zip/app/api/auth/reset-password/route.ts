import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/mongodb'
import User from '@/models/User'
import PasswordResetToken from '@/models/PasswordResetToken'
import bcrypt from 'bcryptjs'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    await dbConnect()
    const { token, uid, newPassword } = await request.json()
    if (!token || !uid || !newPassword) return NextResponse.json({ error: 'Missing fields' }, { status: 400 })

    const record: any = await (PasswordResetToken as any).findOne({ userId: uid, usedAt: null, expiresAt: { $gt: new Date() } })
    if (!record) return NextResponse.json({ error: 'Invalid or expired token' }, { status: 400 })

    // Verify token with bcrypt
    const match = await bcrypt.compare(token, record.tokenHash)
    if (!match) return NextResponse.json({ error: 'Invalid token' }, { status: 400 })

    // Update password
    const user: any = await (User as any).findById(uid).select('+password')
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })
    const salt = await bcrypt.genSalt(10)
    user.password = await bcrypt.hash(newPassword, salt)
    await user.save()

    // Mark token used
    record.usedAt = new Date()
    await record.save()

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('Reset password error:', e)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}


