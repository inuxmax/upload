import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '@/lib/mongodb'
import User from '@/models/User'
import EmailVerificationToken from '@/models/EmailVerificationToken'
import bcrypt from 'bcryptjs'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    await dbConnect()
    const { token, uid } = await request.json()
    if (!token || !uid) return NextResponse.json({ error: 'Missing token or uid' }, { status: 400 })

    const record: any = await (EmailVerificationToken as any).findOne({ userId: uid, usedAt: null, expiresAt: { $gt: new Date() } })
    if (!record) return NextResponse.json({ error: 'Invalid or expired token' }, { status: 400 })
    const ok = await bcrypt.compare(token, record.tokenHash)
    if (!ok) return NextResponse.json({ error: 'Invalid token' }, { status: 400 })

    const user: any = await (User as any).findById(uid)
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })
    
    console.log('Before verification:', { userId: user._id, isVerified: user.isVerified, isActive: user.isActive });
    
    user.isVerified = true
    await user.save()
    
    console.log('After verification:', { userId: user._id, isVerified: user.isVerified, isActive: user.isActive });
    
    record.usedAt = new Date()
    await record.save()

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('Verify email error:', e)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}


