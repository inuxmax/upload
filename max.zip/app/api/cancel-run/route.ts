import { NextRequest, NextResponse } from 'next/server'
import { cancelRun, isRunCanceled } from '@/lib/cancel-jobs'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest) {
  try {
    const { runId } = await req.json()
    if (!runId) {
      return NextResponse.json({ success: false, message: 'runId required' }, { status: 400 })
    }
    cancelRun(String(runId))
    return NextResponse.json({ success: true })
  } catch (e) {
    return NextResponse.json({ success: false, message: 'Invalid request' }, { status: 400 })
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const runId = searchParams.get('runId')
  const check = searchParams.get('check')
  if (check && runId) {
    return NextResponse.json({ canceled: isRunCanceled(runId) })
  }
  return NextResponse.json({ ok: true })
}


