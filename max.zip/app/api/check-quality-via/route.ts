import { NextRequest, NextResponse } from 'next/server';
import { isRunCanceled } from '@/lib/cancel-jobs'
import connectMongoDB from '@/lib/mongodb';
import FacebookAccount from '@/models/FacebookAccount';

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
		const raw = await request.json();
		const { accountId, loginFirst = false, loginMethod = 'cookie', useProxy = true, runId } = raw as { accountId: string; loginFirst?: boolean; loginMethod?: 'cookie' | 'password'; useProxy?: boolean; runId?: string };

    if (isRunCanceled(runId)) {
      return NextResponse.json({ success: false, message: 'Canceled' }, { status: 499 })
    }

    if (!accountId) {
			return NextResponse.json({ error: 'Account ID is required' }, { status: 400 });
    }

		// Kiểm tra nếu accountId là local ID (không phải ObjectId hợp lệ)
		const isValidObjectId = /^[a-fA-F0-9]{24}$/.test(String(accountId))
		
		let account: any
		if (isValidObjectId) {
			// Tìm trong database nếu là ObjectId hợp lệ
			account = await (FacebookAccount as any).findById(accountId)
    if (!account) {
				return NextResponse.json({ error: 'Account not found in database' }, { status: 404 })
			}
		} else {
			// Nếu là local ID, trả về lỗi vì API này cần account trong database
      return NextResponse.json({ 
				error: 'Local accounts are not supported for this operation. Please use server-stored accounts.' 
			}, { status: 400 })
		}

		let cookiesString: string | undefined = account.cookie?.length ? account.cookie : account.cookies;

		// Optional login-first or auto-login when missing cookies
		if (loginFirst || !cookiesString) {
			try {
				const endpoint = loginMethod === 'password' ? 'login' : 'login-cookie';
				await fetch(`http://localhost:3000/api/facebook/${endpoint}`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json', 'x-internal-call': '1' },
					body: JSON.stringify({ accountId, useProxy })
				});
				const refreshed = await (FacebookAccount as any).findById(accountId);
				if (refreshed?.cookie) cookiesString = refreshed.cookie;
				else if (refreshed?.cookies) cookiesString = refreshed.cookies;
				account = refreshed || account;
			} catch {}
		}

		if (!cookiesString) {
			return NextResponse.json({ error: 'Account cookies not found. Please login by cookie first.' }, { status: 400 });
		}

		const cUserMatch = cookiesString.match(/c_user=([^;]+)/);
		const userId = cUserMatch ? cUserMatch[1] : undefined;
		if (!userId) {
			return NextResponse.json({ error: 'c_user not found in cookies' }, { status: 400 });
		}

		// Helper to compute jazoest like web
		const computeJazoest = (token: string) => {
			try {
				const sum = Array.from(token).reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
				return `2${sum}`;
			} catch {
				return '2';
			}
		};

		// Obtain fb_dtsg and lsd and try to discover doc_id from HTML
		let fb_dtsg: string | undefined = account.dtsg || undefined;
		let lsd: string | undefined = undefined;
		let docId: string = '7327539680662016';
		try {
			// Try multiple pages to extract tokens
			const candidates = [
				'https://www.facebook.com/',
				`https://www.facebook.com/accountquality/?asset_id=${userId}`,
				'https://www.facebook.com/adsmanager',
				'https://www.facebook.com/adsmanager/manage/campaigns',
				'https://m.facebook.com/',
				'https://m.facebook.com/accountquality'
			];
			for (const u of candidates) {
				const res = await fetch(u, {
					method: 'GET',
					headers: {
						'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
						'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
						'Cookie': cookiesString,
						'Accept-Language': 'en-US,en;q=0.9,vi;q=0.8',
						'Referer': 'https://www.facebook.com/'
					}
				});
				const html = await res.text();
				try {
					console.log('🧩 Token probe:', { url: u, status: res.status, len: html.length });
				} catch {}
				if (!fb_dtsg) {
					const patternsDtsg = [
						/name=\"fb_dtsg\"\s+value=\"([^\"]+)\"/,
						/DTSGInitialData\"\s*:\s*\{\"token\"\s*:\s*\"([^\"]+)\"/
					];
					for (const p of patternsDtsg) {
						const m = html.match(p);
						if (m) { fb_dtsg = m[1]; break; }
					}
				}
				if (!lsd) {
					const patternsLsd = [
						/name=\"lsd\"\s+value=\"([^\"]+)\"/,
						/\"LSD\"\s*,\s*\[\]\s*,\s*\{\s*\"token\"\s*:\s*\"([^\"]+)\"/,
						/\"lsd\"\s*:\s*\"([^\"]+)\"/
					];
					for (const p of patternsLsd) {
						const m = html.match(p);
						if (m) { lsd = m[1]; break; }
					}
				}
				// Try discover doc_id for the query from HTML/relay payloads
				try {
					const patternsDoc = [
						/AccountQualityHubAssetOwnerViewQuery[\s\S]*?\"id\"\s*:\s*\"(\d{6,})\"/,
						/fb_api_req_friendly_name\\\":\\\"AccountQualityHubAssetOwnerViewQuery\\\"[\s\S]*?doc_id\\\":\\\"(\d{6,})\\\"/,
						/\"doc_id\"\s*:\s*\"(\d{6,})\"[\s\S]*?AccountQualityHubAssetOwnerViewQuery/
					];
					for (const p of patternsDoc) {
						const m = html.match(p as any);
						if (m && m[1]) { docId = m[1]; break; }
					}
					if (docId) { console.log('🆔 Using doc_id:', docId, ' from ', u); }
				} catch {}
				if (fb_dtsg || lsd) {
					try { console.log('✅ Tokens found:', { fb_dtsg: !!fb_dtsg, lsd: !!lsd, url: u }); } catch {}
				}
				if (fb_dtsg && lsd && docId) break;
			}
		} catch {}

		// Proceed even if fb_dtsg missing (some flows may still accept LSD-only)

		const jazoest = computeJazoest(fb_dtsg || lsd || '');

		// Build form data matching the browser cURL
		const form = new URLSearchParams();
		form.set('av', userId);
		form.set('__user', userId);
		form.set('__a', '1');
		form.set('dpr', '1');
		if (fb_dtsg) form.set('fb_dtsg', fb_dtsg);
		if (fb_dtsg || lsd) form.set('jazoest', jazoest);
		if (lsd) form.set('lsd', lsd);
		form.set('fb_api_caller_class', 'RelayModern');
		form.set('fb_api_req_friendly_name', 'AccountQualityHubAssetOwnerViewQuery');
		form.set('variables', JSON.stringify({ assetOwnerId: userId, scale: 1 }));
		form.set('server_timestamps', 'true');
		form.set('doc_id', docId);
		form.set('__comet_req', '1');
		// extra spin params
		try {
			form.set('__spin_r', '0');
			form.set('__spin_b', 'trunk');
			form.set('__spin_t', Math.floor(Date.now() / 1000).toString());
		} catch {}

		const url = 'https://www.facebook.com/api/graphql/?_flowletID=1&_triggerFlowletID=2';

		// Log outgoing request (mask cookie)
		try {
			console.log('🛰️ Requesting GraphQL:', url);
			console.log('🛰️ Headers preview:', {
				accept: '*/*',
				'content-type': 'application/x-www-form-urlencoded',
				origin: 'https://www.facebook.com',
				referer: `https://www.facebook.com/accountquality/?asset_id=${userId}`,
				'user-agent': 'Mozilla/5.0 Chromium/139',
				'x-fb-friendly-name': 'AccountQualityHubAssetOwnerViewQuery',
				'x-fb-lsd': lsd ? '[present]' : '[missing]'
			});
			console.log('🧾 Form body preview:', {
				av: form.get('av'),
				__user: form.get('__user'),
				__a: form.get('__a'),
				dpr: form.get('dpr'),
				fb_dtsg: fb_dtsg ? '[present]' : '[missing]',
				jazoest: form.get('jazoest'),
				lsd: lsd ? '[present]' : '[missing]',
				fb_api_caller_class: form.get('fb_api_caller_class'),
				fb_api_req_friendly_name: form.get('fb_api_req_friendly_name'),
				doc_id: form.get('doc_id'),
				variables: form.get('variables'),
				__comet_req: form.get('__comet_req'),
				__spin_b: form.get('__spin_b'),
				__spin_r: form.get('__spin_r'),
				__spin_t: form.get('__spin_t')
			});
		} catch {}

		const res = await fetch(url, {
			method: 'POST',
			headers: {
				'accept': '*/*',
				'accept-language': 'en-US,en;q=0.9,vi;q=0.8',
				'content-type': 'application/x-www-form-urlencoded',
				'origin': 'https://www.facebook.com',
				'referer': `https://www.facebook.com/accountquality/?asset_id=${userId}`,
				'cookie': cookiesString,
				'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
				'x-fb-friendly-name': 'AccountQualityHubAssetOwnerViewQuery',
				...(lsd ? { 'x-fb-lsd': lsd } : {} as any),
				'x-asbd-id': '198387',
				'sec-fetch-site': 'same-origin',
				'sec-fetch-mode': 'cors',
				'sec-fetch-dest': 'empty'
			}
			, body: form
		});

		console.log('🛰️ Response status:', res.status, res.statusText);
		console.log('🛰️ Response headers x-fb-trace-id:', res.headers.get('x-fb-trace-id'));
		const text = await res.text();
		try { console.log('🛰️ Raw response preview:', text.slice(0, 800)); } catch {}
		// Remove potential anti-CSRF prefix
		const jsonText = text.replace(/^for \(;;\);/, '').trim();
		let data: any = null;
		try { data = JSON.parse(jsonText); } catch { data = { raw: text }; }

		// Fallback to business.facebook.com if www returns error or no data
		if (!data?.data || (data?.error ?? data?.errorSummary)) {
			try {
				const bizUrl = 'https://business.facebook.com/api/graphql/?_flowletID=1&_triggerFlowletID=2';
				console.log('↩️ Fallback requesting GraphQL (business):', bizUrl);
				const bizRes = await fetch(bizUrl, {
					method: 'POST',
					headers: {
						'accept': '*/*',
						'accept-language': 'en-US,en;q=0.9,vi;q=0.8',
						'content-type': 'application/x-www-form-urlencoded',
						'origin': 'https://business.facebook.com',
						'referer': `https://business.facebook.com/accountquality/?asset_id=${userId}`,
						'cookie': cookiesString,
						'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
						'x-fb-friendly-name': 'AccountQualityHubAssetOwnerViewQuery',
						...(lsd ? { 'x-fb-lsd': lsd } : {} as any),
						'x-asbd-id': '198387',
						'sec-fetch-site': 'same-origin',
						'sec-fetch-mode': 'cors',
						'sec-fetch-dest': 'empty'
					}
					, body: form
				});
				console.log('↩️ Fallback response status:', bizRes.status, bizRes.statusText);
				const bizText = await bizRes.text();
				try { console.log('↩️ Fallback raw response preview:', bizText.slice(0, 800)); } catch {}
				const bizJsonText = bizText.replace(/^for \(;;\);/, '').trim();
				let bizData: any = null;
				try { bizData = JSON.parse(bizJsonText); } catch { bizData = { raw: bizText }; }
				if (bizData?.data) {
					data = bizData;
				}
			} catch (e) {
				console.log('↩️ Fallback (business) failed:', e);
			}
		}

		// Debug logs to verify structure
		try {
			const asset = data?.data?.assetOwnerData;
			const restr = asset?.advertising_restriction_info;
			const viewer = data?.data?.viewerData?.actor;
			const defaultBMNodes = data?.data?.viewerData?.default_business?.nodes;
			console.log('🔎 GraphQL keys:', Object.keys(data?.data || {}));
			console.log('🔎 assetOwnerData.id:', asset?.id);
			console.log('🔎 assetOwnerData.name:', asset?.name);
			console.log('🔎 advertising_restriction_info.status:', restr?.status);
			console.log('🔎 viewer.actor.id:', viewer?.id);
			console.log('🔎 default_business.nodes:', Array.isArray(defaultBMNodes) ? defaultBMNodes.map((n: any) => n?.id) : defaultBMNodes);
		} catch {}

		// Prefer explicit path from GraphQL result, then fallback heuristic
		const statuses: string[] = [];
		const keysOfInterest = new Set(['status', 'restriction_status', 'restrictionType', 'restriction_type']);
		const collectStatuses = (node: any) => {
			if (!node || typeof node !== 'object') return;
			for (const [k, v] of Object.entries(node)) {
				if (keysOfInterest.has(k) && typeof v === 'string') {
					statuses.push(v);
				}
				if (v && typeof v === 'object') collectStatuses(v);
			}
		};
		collectStatuses(data);

		const preferredOrder = ['NOT_RESTRICTED', 'RESTRICTED', 'APPEAL_TIMEOUT', 'UNSPECIFIED', 'UNKNOWN'];
		let restrictionStatus: string | undefined = data?.data?.assetOwnerData?.advertising_restriction_info?.status
			|| statuses.find(s => preferredOrder.includes(s))
			|| statuses.find(s => /RESTRICT|APPEAL|NOT/.test(s))
			|| undefined;
		let adsStatus: 'live' | 'die' | 'unknown' = 'unknown';
		if (restrictionStatus === 'NOT_RESTRICTED') adsStatus = 'live';
		else if (restrictionStatus && restrictionStatus !== 'NOT_RESTRICTED') adsStatus = 'die';

		return NextResponse.json({ success: true, message: 'OK', adsStatus, restrictionStatus, data });
	} catch (error) {
		console.error('💥 Check-Quality-Via Error:', error);
		return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}