import { NextRequest, NextResponse } from 'next/server';
import { isRunCanceled } from '@/lib/cancel-jobs'
import FacebookAccount from '@/models/FacebookAccount';
import connectDB from '@/lib/mongodb';

// Helper function to parse Facebook response (handles security prefix)
async function parseFacebookResponse(response: Response): Promise<any> {
  let text = await response.text();
  
  // Remove Facebook's security prefix if present
  if (text.startsWith('for (;;);')) {
    text = text.substring(9);
  }
  
  return JSON.parse(text);
}

// Helper function to retry API calls
async function retryApiCall(
  url: string, 
  options: RequestInit, 
  maxRetries: number = 2,
  delay: number = 1000
): Promise<Response> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(url, options);
      
      // If successful or client error (4xx), don't retry
      if (response.ok || (response.status >= 400 && response.status < 500)) {
        return response;
      }
      
      // For server errors (5xx), retry
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2; // Exponential backoff
        continue;
      }
      
      return response;
    } catch (error) {
      lastError = error as Error;
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2;
        continue;
      }
    }
  }
  
  throw   lastError || new Error('Max retries exceeded');
}

// Helper functions for processing account data (based on C# logic)
function mapAccountStatus(status: number): string {
  switch (status) {
    case 1: return 'Live Ads';
    case 2: return 'Die Ads';
    case 3: return 'Live & Nợ';
    case 100:
    case 101: return 'Die Đã Close';
    default: return `Status ${status}`;
  }
}

function convertCurrencyValue(value: string | number, currency: string): string {
  if (!value || currency === 'VND') return value?.toString() || '0';
  
  try {
    const numValue = typeof value === 'string' ? parseFloat(value) : value;
    return (numValue / 100).toString();
  } catch {
    return value?.toString() || '0';
  }
}

function formatAdtrustDsl(adtrust: number | string, currency: string): string {
  if (!adtrust) return '0';
  if (adtrust === -1 || adtrust === '-1') return 'Nolimit';
  
  return convertCurrencyValue(adtrust, currency);
}

function detectAccountType(owner: string, currentUserId: string): { type: string, ownerDisplay: string } {
  if (!owner) return { type: 'Unknown', ownerDisplay: 'Unknown' };
  
  if (owner === currentUserId) {
    return { type: 'Tkqc Cá Nhân', ownerDisplay: 'Chính' };
  }
  
  const ownerLength = owner.length;
  if (ownerLength < 15) {
    return { type: 'Tkqc Cá Nhân', ownerDisplay: owner };
  } else if (ownerLength > 15) {
    return { type: 'Tkqc BM', ownerDisplay: owner };
  } else {
    // Length = 15, check if contains "1000"
    const type = owner.includes('1000') ? 'Tkqc Cá Nhân' : 'Tkqc BM';
    return { type, ownerDisplay: owner };
  }
}

function countHiddenAdmins(userpermissions: any[]): number {
  if (!userpermissions) return 0;
  
  let totalPermissions = 0;
  let visibleUsers = 0;
  
  userpermissions.forEach(permission => {
    if (permission.status) totalPermissions++;
    if (permission.user?.id) visibleUsers++;
  });
  
  return totalPermissions - visibleUsers;
}

function processPaymentMethods(allPaymentMethods: any): {
  credit_cards: string[];
  direct_debits: string[];
  paypal_emails: string[];
  other_methods: string[];
} {
  const result = {
    credit_cards: [] as string[],
    direct_debits: [] as string[],
    paypal_emails: [] as string[],
    other_methods: [] as string[]
  };
  
  if (!allPaymentMethods?.data) return result;
  
  allPaymentMethods.data.forEach((method: any) => {
    if (method.pm_credit_card?.display_string) {
      result.credit_cards.push(method.pm_credit_card.display_string);
    }
    if (method.payment_method_direct_debits?.display_string) {
      result.direct_debits.push(method.payment_method_direct_debits.display_string);
    }
    if (method.payment_method_paypal?.email_address) {
      result.paypal_emails.push(method.payment_method_paypal.email_address);
    }
    if (method.payment_method_tokens?.type) {
      result.other_methods.push(method.payment_method_tokens.type);
    }
  });
  
  return result;
}

interface TKQCInfo {
  id?: string;
  account_id: string;
  name: string;
  account_status: number;
  account_status_text?: string;
  balance?: string;
  currency?: string;
  adtrust_dsl?: number;
  adtrust_dsl_formatted?: string;
  limit?: string | number;
  disable_reason?: number;
  owner?: string;
  owner_display?: string;
  account_type?: string;
  created_time?: string;
  next_bill_date?: string;
  is_prepay_account?: boolean;
  threshold_amount?: number;
  threshold_amount_formatted?: string;
  amount_spent?: string;
  amount_spent_formatted?: string;
  spend_cap?: string;
  spend_cap_formatted?: string;
  total_prepay_balance?: string;
  total_prepay_balance_formatted?: string;
  funding_source_details?: any;
  payment_methods?: {
    credit_cards?: string[];
    direct_debits?: string[];
    paypal_emails?: string[];
    other_methods?: string[];
  };
  lifetime_spend?: string;
  lifetime_spend_formatted?: string;
  user_role?: string;
  spend?: string;
  source?: string;
  bm_id?: string;
  bm_name?: string;
  owner_business?: any;
  business_country_code?: string;
  timezone_name?: string;
  timezone_offset_hours_utc?: number;
  hidden_admins_count?: number;
  total_permissions?: number;
  visible_users?: number;
  thongtinthanhtoan?: string;
  loaithanhtoan?: string;
}

interface BMInfo {
  id: string;
  name: string;
  is_disabled_for_integrity_reasons: boolean;
  verification_status: string;
  created_time: string;
  adAccountLimit?: string;
  restriction_type?: string | null;
}

export async function POST(request: NextRequest) {
  try {
    const raw = await request.json();
    const { token, cookie, accountId, getAllAccounts = false, loginFirst = false, loginMethod = 'cookie', runQualityAfter = false, runId } = raw as any;

    if (loginFirst && accountId) {
      try {
        		// Kiểm tra nếu accountId là local ID (không phải ObjectId hợp lệ)
		const isValidObjectId = /^[a-fA-F0-9]{24}$/.test(String(accountId))
		
		let accountDoc: any
		if (isValidObjectId) {
			// Tìm trong database nếu là ObjectId hợp lệ
			accountDoc = await (FacebookAccount as any).findById(accountId)
			if (!accountDoc) {
				return NextResponse.json({ error: 'Account not found in database' }, { status: 404 })
			}
		} else {
			// Nếu là local ID, trả về lỗi vì API này cần account trong database
			return NextResponse.json({ 
				error: 'Local accounts are not supported for this operation. Please use server-stored accounts.' 
			}, { status: 400 })
		}
        const payload: any = { accountId, useProxy: true };
        if (isValidObjectId) {
          if (loginMethod === 'password') {
            await fetch('http://localhost:3000/api/facebook/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
          } else {
            await fetch('http://localhost:3000/api/facebook/login-cookie', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-internal-call': '1' }, body: JSON.stringify(payload) });
          }
        } else {
          // Skip internal login for local temp ids
        }
      } catch {}
    }

    if (!token) {
      return NextResponse.json({ error: 'Token is required' }, { status: 400 });
    }

    const results = {
      tkqc_list: [] as TKQCInfo[],
      bm_list: [] as BMInfo[],
      account_info: null as any,
      success: true,
      message: 'Check TKQC thành công',
      needsLogin: false,
      qualityCheck: null as any
    };

    try {
      // Allow early cancel checks between long steps
      const checkCanceled = () => { if (isRunCanceled(runId)) { throw new Error('Canceled') } }
      checkCanceled()
      // Validate token first - thử /me trước, nếu fail thì thử /me/adaccounts
      let tokenValidationResponse;
      
      // Thử validate với /me endpoint trước (đơn giản hơn)
      try {
        tokenValidationResponse = await retryApiCall(
          `https://graph.facebook.com/v18.0/me?access_token=${token}&fields=id,name`,
          {
            method: 'GET',
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept': 'application/json',
              'Cookie': cookie || ''
            },
            signal: AbortSignal.timeout(15000)
          }
        );
        
        if (!tokenValidationResponse.ok) {
          tokenValidationResponse = null;
        }
      } catch (error) {
        tokenValidationResponse = null;
      }
      
      checkCanceled()
      // Nếu /me fail, thử /me/adaccounts
      if (!tokenValidationResponse || !tokenValidationResponse.ok) {
        tokenValidationResponse = await retryApiCall(
          `https://graph.facebook.com/v18.0/me/adaccounts?access_token=${token}&fields=id,name&limit=10000`,
          {
            method: 'GET',
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept': 'application/json',
              'Cookie': cookie || ''
            },
            signal: AbortSignal.timeout(15000)
          }
        );
      }

      if (!tokenValidationResponse.ok) {
        const validationError = await tokenValidationResponse.text();
        
        // Parse validation error to provide better feedback
        try {
          const errorData = JSON.parse(validationError);
          if (errorData.error) {
            const { message, code, type } = errorData.error;
            
            if (type === 'OAuthException') {
              results.success = false;
              results.message = 'Session Facebook đã hết hạn. Cần đăng nhập lại để lấy session fresh và sử dụng Graph API.';
              results.needsLogin = true; // Flag để frontend biết cần login lại
              return NextResponse.json(results);
            }
          }
        } catch (parseError) {
          // Could not parse validation error
        }
        
        results.success = false;
        results.message = 'EAAG token không hợp lệ hoặc đã hết hạn. Cần đăng nhập lại Facebook để duy trì session.';
        results.needsLogin = true;
        return NextResponse.json(results);
      }

      const validationData = await tokenValidationResponse.json();
      
      // Kiểm tra response dựa trên endpoint được sử dụng và lưu user info
      let isValidToken = false;
      let currentUserInfo = null;
      
      if (validationData.id && validationData.name) {
        // Response từ /me endpoint
        isValidToken = true;
        currentUserInfo = {
          id: validationData.id,
          name: validationData.name,
          email: validationData.email || '',
          picture: validationData.picture?.data?.url || ''
        };
      } else if (validationData.data) {
        // Response từ /me/adaccounts endpoint - cần lấy user info riêng
        isValidToken = true;
        // Sẽ lấy user info sau
      } else {
        results.success = false;
        results.message = 'Token không có quyền truy cập cần thiết. Cần login lại để lấy token với quyền phù hợp.';
        results.needsLogin = true;
        return NextResponse.json(results);
      }
      
      // Nếu chưa có user info, lấy từ /me endpoint
      if (!currentUserInfo) {
        try {
          const userInfoResponse = await retryApiCall(
            `https://graph.facebook.com/v18.0/me?access_token=${token}&fields=id,name,email,picture`,
            {
              method: 'GET',
              headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json',
                'Cookie': cookie || ''
              },
              signal: AbortSignal.timeout(15000)
            }
          );
          
          if (userInfoResponse.ok) {
            const userInfo = await userInfoResponse.json();
            currentUserInfo = {
              id: userInfo.id,
              name: userInfo.name,
              email: userInfo.email || '',
              picture: userInfo.picture?.data?.url || ''
            };
          }
        } catch (error) {
        }
      }
      
      // Set account_info với user info thay vì account đầu tiên
      results.account_info = currentUserInfo;
      
      checkCanceled()
      // 1. Lấy danh sách TKQC cá nhân TRƯỚC
      const tkqcResponse = await retryApiCall(
        `https://graph.facebook.com/v18.0/me/adaccounts?limit=50000&fields=name,profile_picture,account_id,account_status,currency,amount_spent,balance&access_token=${token}&summary=1&locale=en_US`,
        {
          method: 'GET',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Cookie': cookie || ''
          },
          signal: AbortSignal.timeout(30000) // 30 second timeout
        }
      );
      if (tkqcResponse.ok) {
        const tkqcData = await tkqcResponse.json();
          
        if (tkqcData.data) {
          results.tkqc_list = tkqcData.data.map((account: any) => ({
            account_id: account.account_id,
            name: account.name,
            account_status: account.account_status,
            currency: account.currency,
            balance: account.balance,
            source: 'Personal' // Đánh dấu là tài khoản cá nhân
          }));
        }
      } else {
          const errorText = await tkqcResponse.text();
          
          // Parse error response for better error handling
          try {
            const errorData = JSON.parse(errorText);
            if (errorData.error) {
              const { message, code, type } = errorData.error;
              
              if (type === 'OAuthException') {
                // Nếu là lỗi quyền truy cập Ad Accounts, tiếp tục với Business Managers
                if (code === 1 || code === 190) {
                  // Không return error, tiếp tục với Business Managers
                } else {
                  // Các lỗi OAuthException khác thì cần login lại
                  results.success = false;
                  results.message = 'Lỗi xác thực Facebook. EAAG token đã hết hạn. Vui lòng đăng nhập lại để lấy EAAG token mới.';
                  results.needsLogin = true;
                  return NextResponse.json(results);
                }
              }
            }
          } catch (parseError) {
            // Could not parse error response
          }
        }

      checkCanceled()
      // 2. Lấy danh sách Business Manager
      try {
        const bmResponse = await retryApiCall(
          `https://graph.facebook.com/v18.0/me/businesses?fields=name,id,is_disabled_for_integrity_reasons,verification_status,business_users,allow_page_management_in_www,sharing_eligibility_status,created_time,permitted_roles&limit=5000&access_token=${token}`,
          {
            method: 'GET',
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept': 'application/json',
              'Cookie': cookie || ''
            },
            signal: AbortSignal.timeout(30000) // 30 second timeout
          }
        );
        if (bmResponse.ok) {
          const bmData = await bmResponse.json();
          if (bmData.data) {
            results.bm_list = bmData.data.map((bm: any) => ({
              id: bm.id,
              name: bm.name,
              is_disabled_for_integrity_reasons: bm.is_disabled_for_integrity_reasons,
              verification_status: bm.verification_status,
              created_time: bm.created_time
            }));
          }
        } else {
        }
      } catch (error) {
        console.error('❌ Error fetching Business Managers:', error);
      }

      // 3. Lấy TKQC từ Business Managers và thông tin chi tiết cho TẤT CẢ TKQC
      const allAdAccounts = [...results.tkqc_list];
      // 3.1. Lấy thêm TKQC từ Business Managers (đã có BM list)
      results.bm_list.forEach((bm, index) => {
      });
      
      for (const bm of results.bm_list) {
        checkCanceled()
        try {
          // Fetch all pages of accounts from this BM
          let allBmAccounts: any[] = [];
          let nextUrl: string | null = `https://graph.facebook.com/v17.0/${bm.id}/owned_ad_accounts?fields=account_id,name,adtrust_dsl,currency,account_status,balance,owner_business,created_time,disable_reason,is_prepay_account,next_bill_date,owner,permitted_roles&limit=5000&access_token=${token}`;
          let pageCount = 0;
          
          while (nextUrl && pageCount < 10) { // Max 10 pages to prevent infinite loop
            pageCount++;
            const bmAdAccountsResponse = await retryApiCall(
              nextUrl,
              {
                method: 'GET',
                headers: {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                  'Accept': 'application/json',
                  'Cookie': cookie || ''
                },
                signal: AbortSignal.timeout(30000)
              }
            );

            if (bmAdAccountsResponse.ok) {
              const bmAdAccountsData = await bmAdAccountsResponse.json();

              if (bmAdAccountsData.data) {
                // Add accounts from this page
                allBmAccounts.push(...bmAdAccountsData.data);
                // Set next URL for pagination
                nextUrl = bmAdAccountsData.paging?.next || null;
              } else {
                nextUrl = null;
              }
            } else {
              try {
                const errorText = await bmAdAccountsResponse.text();
              } catch (e) {
              }
              nextUrl = null; // Stop pagination on error
            }
          }
          
          // Process all accounts from all pages
          if (allBmAccounts.length > 0) {
            const bmAccounts = allBmAccounts.map((account: any) => ({
              account_id: account.account_id,
              name: account.name,
              account_status: account.account_status,
              currency: account.currency,
              balance: account.balance,
              owner_business: account.owner_business,
              created_time: account.created_time,
              adtrust_dsl: account.adtrust_dsl,
              disable_reason: account.disable_reason,
              is_prepay_account: account.is_prepay_account,
              next_bill_date: account.next_bill_date,
              owner: account.owner,
              user_role: account.permitted_roles?.[0] || '', // Lấy role đầu tiên
              spend: '0', // Sẽ được cập nhật trong batch processing
              source: `BM: ${bm.name}`,
              bm_id: bm.id,
              bm_name: bm.name,
              threshold_amount: 0 // Sẽ được cập nhật trong batch processing
            }));
            
            // Thêm vào danh sách tổng (tránh trùng lặp)
            let addedCount = 0;
            bmAccounts.forEach((bmAccount: TKQCInfo) => {
              const exists = allAdAccounts.find(acc => acc.account_id === bmAccount.account_id);
              if (!exists) {
                allAdAccounts.push(bmAccount);
                addedCount++;
              }
            });
            
          } else {
          }
        } catch (error) {
        }
      }

      // 2.2. Lấy thông tin chi tiết cho TẤT CẢ ad accounts (batch request)
      // Phân loại accounts theo nguồn
      const personalAccounts = allAdAccounts.filter(acc => acc.source === 'Personal');
      const bmAccounts = allAdAccounts.filter(acc => acc.source && acc.source.startsWith('BM:'));
      
      if (allAdAccounts.length > 0) {
        // Xử lý TẤT CẢ accounts với thông tin đầy đủ
        const batchSize = 50; // Tăng batch size tối đa
        const detailedAccounts: TKQCInfo[] = [];
        
        // Xử lý TẤT CẢ accounts, không giới hạn
        let accountsToProcess = allAdAccounts;
        // Ưu tiên: Personal accounts trước, sau đó BM accounts theo status
        accountsToProcess = allAdAccounts.sort((a, b) => {
          // Personal accounts trước
          if (a.source === 'Personal' && b.source !== 'Personal') return -1;
          if (a.source !== 'Personal' && b.source === 'Personal') return 1;
          
          // Accounts active trước
          if (a.account_status === 1 && b.account_status !== 1) return -1;
          if (a.account_status !== 1 && b.account_status === 1) return 1;
          
          return 0;
        });
        
        for (let i = 0; i < accountsToProcess.length; i += batchSize) {
          checkCanceled()
          const batch = accountsToProcess.slice(i, i + batchSize);
          try {
            const batchRequests = batch.map((account, index) => ({
              "id": `req_${i + index}`,
              "relative_url": `/act_${account.account_id}?fields=account_id,name,account_status,owner_business,created_time,next_bill_date,currency,adtrust_dsl,timezone_name,timezone_offset_hours_utc,business_country_code,disable_reason,adspaymentcycle{threshold_amount},balance,owner,spend_cap,amount_spent,funding_source_details,is_prepay_account,total_prepay_balance,all_payment_methods{pm_credit_card{display_string},payment_method_direct_debits{display_string},payment_method_paypal{email_address},payment_method_tokens{type}},insights.date_preset(lifetime){spend},userpermissions.limit(500){status,role,user,business,business_persona},users.limit(100){id,role,is_active,name,permissions,roles}`,
              "method": "GET"
            }));

            const detailResponse = await fetch(
              'https://adsmanager-graph.facebook.com/v16.0?suppress_http_code=1&locale=en_US',
              {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded',
                  'Cookie': cookie || ''
                },
                body: new URLSearchParams({
                  'access_token': token,
                  'include_headers': 'false',
                  'batch': JSON.stringify(batchRequests)
                })
              }
            );

            if (detailResponse.ok) {
              const detailData = await detailResponse.json();
              // Đảm bảo xử lý TẤT CẢ accounts trong batch
              for (let batchIndex = 0; batchIndex < batch.length; batchIndex++) {
                const originalAccount = batch[batchIndex];
                const response = detailData[batchIndex];
                if (response && response.body) {
                  try {
                    const accountDetail = JSON.parse(response.body);
                    // Get current user ID for owner comparison
                    const currentUserId = results.account_info?.id || '';
                    
                    // Process account data with C# logic
                    const currency = accountDetail.currency || 'USD';
                    const rawBalance = accountDetail.balance || '0';
                    const rawAdtrust = accountDetail.adtrust_dsl || 0;
                    const rawThreshold = accountDetail.adspaymentcycle?.data?.[0]?.threshold_amount || 0;
                    const rawAmountSpent = accountDetail.amount_spent || '0';
                    const rawSpendCap = accountDetail.spend_cap || '0';
                    const rawTotalPrepayBalance = accountDetail.total_prepay_balance || '0';
                    const rawLifetimeSpend = accountDetail.insights?.data?.[0]?.spend || '0';
                    const userpermissions = accountDetail.userpermissions?.data || [];
                    
                    // Apply currency conversion
                    const balance = convertCurrencyValue(rawBalance, currency);
                    const adtrustFormatted = formatAdtrustDsl(rawAdtrust, currency);
                    const thresholdFormatted = convertCurrencyValue(rawThreshold, currency);
                    const amountSpentFormatted = convertCurrencyValue(rawAmountSpent, currency);
                    const spendCapFormatted = convertCurrencyValue(rawSpendCap, currency);
                    const totalPrepayBalanceFormatted = convertCurrencyValue(rawTotalPrepayBalance, currency);
                    const lifetimeSpendFormatted = convertCurrencyValue(rawLifetimeSpend, currency);
                    
                    // Process payment methods
                    const paymentMethods = processPaymentMethods(accountDetail.all_payment_methods);
                    
                    // Detect account type and owner
                    const { type: accountType, ownerDisplay } = detectAccountType(accountDetail.owner, currentUserId);
                    
                    // Count hidden admins
                    const hiddenAdminsCount = countHiddenAdmins(userpermissions);
                    
                    // Map account status
                    const accountStatusText = mapAccountStatus(accountDetail.account_status);
                    
                    detailedAccounts.push({
                      account_id: accountDetail.account_id,
                      name: accountDetail.name,
                      account_status: accountDetail.account_status,
                      account_status_text: accountStatusText,
                      balance: balance,
                      currency: currency,
                      adtrust_dsl: rawAdtrust,
                      adtrust_dsl_formatted: adtrustFormatted,
                      disable_reason: accountDetail.disable_reason,
                      owner: accountDetail.owner,
                      owner_display: ownerDisplay,
                      account_type: accountType,
                      created_time: accountDetail.created_time,
                      next_bill_date: accountDetail.next_bill_date,
                      is_prepay_account: accountDetail.is_prepay_account,
                      threshold_amount: rawThreshold,
                      threshold_amount_formatted: thresholdFormatted,
                      amount_spent: rawAmountSpent,
                      amount_spent_formatted: amountSpentFormatted,
                      spend_cap: rawSpendCap,
                      spend_cap_formatted: spendCapFormatted,
                      total_prepay_balance: rawTotalPrepayBalance,
                      total_prepay_balance_formatted: totalPrepayBalanceFormatted,
                      funding_source_details: accountDetail.funding_source_details,
                      payment_methods: paymentMethods,
                      lifetime_spend: rawLifetimeSpend,
                      lifetime_spend_formatted: lifetimeSpendFormatted,
                      user_role: accountDetail.userpermissions?.data?.[0]?.role,
                      spend: accountDetail.insights?.data?.[0]?.spend || '0',
                      source: originalAccount.source || 'Personal',
                      bm_id: originalAccount.bm_id || undefined,
                      bm_name: originalAccount.bm_name || undefined,
                      owner_business: accountDetail.owner_business,
                      business_country_code: accountDetail.business_country_code || 'No.QG',
                      timezone_name: accountDetail.timezone_name,
                      timezone_offset_hours_utc: accountDetail.timezone_offset_hours_utc,
                      hidden_admins_count: hiddenAdminsCount,
                      total_permissions: userpermissions.length,
                      visible_users: userpermissions.filter((p: any) => p.user?.id).length
                    });
                  } catch (parseError) {
                    // Parse fail - thêm với thông tin cơ bản nhưng vẫn áp dụng logic
                    const currentUserId = results.account_info?.id || '';
                    const currency = originalAccount.currency || 'USD';
                    const { type: accountType, ownerDisplay } = detectAccountType(originalAccount.owner || '', currentUserId);
                    const accountStatusText = mapAccountStatus(originalAccount.account_status);
                    
                    detailedAccounts.push({
                      account_id: originalAccount.account_id,
                      name: originalAccount.name,
                      account_status: originalAccount.account_status,
                      account_status_text: accountStatusText,
                      balance: originalAccount.balance || '',
                      currency: currency,
                      adtrust_dsl: originalAccount.adtrust_dsl || 0,
                      adtrust_dsl_formatted: formatAdtrustDsl(originalAccount.adtrust_dsl || 0, currency),
                      disable_reason: originalAccount.disable_reason || 0,
                      owner: originalAccount.owner || '',
                      owner_display: ownerDisplay,
                      account_type: accountType,
                      created_time: originalAccount.created_time || '',
                      next_bill_date: originalAccount.next_bill_date || '',
                      is_prepay_account: originalAccount.is_prepay_account || false,
                      threshold_amount: originalAccount.threshold_amount || 0,
                      threshold_amount_formatted: convertCurrencyValue(originalAccount.threshold_amount || 0, currency),
                      amount_spent: '0',
                      amount_spent_formatted: '0',
                      user_role: originalAccount.user_role || '',
                      spend: originalAccount.spend || '0',
                      source: originalAccount.source || 'Personal',
                      bm_id: originalAccount.bm_id || undefined,
                      bm_name: originalAccount.bm_name || undefined,
                      owner_business: originalAccount.owner_business || null,
                      business_country_code: 'No.QG',
                      timezone_name: undefined,
                      timezone_offset_hours_utc: undefined,
                      hidden_admins_count: 0,
                      total_permissions: 0,
                      visible_users: 0
                    });
                  }
                } else {
                  if (response) {
                  }
                  
                  // Không có response hợp lệ - thêm với thông tin cơ bản nhưng vẫn áp dụng logic
                  const currentUserId = results.account_info?.id || '';
                  const currency = originalAccount.currency || 'USD';
                  const { type: accountType, ownerDisplay } = detectAccountType(originalAccount.owner || '', currentUserId);
                  const accountStatusText = mapAccountStatus(originalAccount.account_status);
                  
                  detailedAccounts.push({
                    account_id: originalAccount.account_id,
                    name: originalAccount.name,
                    account_status: originalAccount.account_status,
                    account_status_text: accountStatusText,
                    balance: originalAccount.balance || '',
                    currency: currency,
                    adtrust_dsl: originalAccount.adtrust_dsl || 0,
                    adtrust_dsl_formatted: formatAdtrustDsl(originalAccount.adtrust_dsl || 0, currency),
                    disable_reason: originalAccount.disable_reason || 0,
                    owner: originalAccount.owner || '',
                    owner_display: ownerDisplay,
                    account_type: accountType,
                    created_time: originalAccount.created_time || '',
                    next_bill_date: originalAccount.next_bill_date || '',
                    is_prepay_account: originalAccount.is_prepay_account || false,
                    threshold_amount: originalAccount.threshold_amount || 0,
                    threshold_amount_formatted: convertCurrencyValue(originalAccount.threshold_amount || 0, currency),
                    amount_spent: '0',
                    amount_spent_formatted: '0',
                    user_role: originalAccount.user_role || '',
                    spend: originalAccount.spend || '0',
                    source: originalAccount.source || 'Personal',
                    bm_id: originalAccount.bm_id || undefined,
                    bm_name: originalAccount.bm_name || undefined,
                    owner_business: originalAccount.owner_business || null,
                    business_country_code: 'No.QG',
                    timezone_name: undefined,
                    timezone_offset_hours_utc: undefined,
                    hidden_admins_count: 0,
                    total_permissions: 0,
                    visible_users: 0
                  });
                }
              }
            } else {
              // Nếu batch request fail, thêm tất cả accounts với thông tin cơ bản
              batch.forEach(originalAccount => {
                detailedAccounts.push({
                  account_id: originalAccount.account_id,
                  name: originalAccount.name,
                  account_status: originalAccount.account_status,
                  balance: originalAccount.balance || '',
                  currency: originalAccount.currency || '',
                  adtrust_dsl: originalAccount.adtrust_dsl || 0,
                  disable_reason: originalAccount.disable_reason || 0,
                  owner: originalAccount.owner || '',
                  created_time: originalAccount.created_time || '',
                  next_bill_date: originalAccount.next_bill_date || '',
                  is_prepay_account: originalAccount.is_prepay_account || false,
                  threshold_amount: originalAccount.threshold_amount || 0,
                  user_role: originalAccount.user_role || '',
                  spend: originalAccount.spend || '0',
                  source: originalAccount.source || 'Personal',
                  bm_id: originalAccount.bm_id || undefined,
                  bm_name: originalAccount.bm_name || undefined,
                  owner_business: originalAccount.owner_business || null
                });
              });
            }
            
            const accountsAddedInBatch = detailedAccounts.length - (i > 0 ? Math.min(i, detailedAccounts.length - batch.length) : 0);
            // Delay ngắn hơn cho hàng nghìn accounts
            if (i + batchSize < accountsToProcess.length) {
              checkCanceled()
              await new Promise(resolve => setTimeout(resolve, 500)); // Giảm từ 1s xuống 0.5s
            }
            
          } catch (error) {
          }
        }
        
        // FORCE: Đảm bảo TẤT CẢ accounts đều có trong kết quả cuối
        const processedAccountIds = new Set(detailedAccounts.map(acc => acc.account_id));
        const missingAccounts = accountsToProcess.filter(acc => !processedAccountIds.has(acc.account_id));
        
        if (missingAccounts.length > 0) {
          missingAccounts.forEach(originalAccount => {
            // Get current user ID for owner comparison
            const currentUserId = results.account_info?.id || '';
            
            // Apply same processing logic as batch processing
            const currency = originalAccount.currency || 'USD';
            const { type: accountType, ownerDisplay } = detectAccountType(originalAccount.owner || '', currentUserId);
            const accountStatusText = mapAccountStatus(originalAccount.account_status);
            
            detailedAccounts.push({
              // Basic info
              account_id: originalAccount.account_id,
              name: originalAccount.name,
              account_status: originalAccount.account_status,
              account_status_text: accountStatusText,
              
              // Financial info
              balance: originalAccount.balance || '',
              currency: currency,
              adtrust_dsl: originalAccount.adtrust_dsl || 0,
              adtrust_dsl_formatted: formatAdtrustDsl(originalAccount.adtrust_dsl || 0, currency),
              threshold_amount: originalAccount.threshold_amount || 0,
              threshold_amount_formatted: convertCurrencyValue(originalAccount.threshold_amount || 0, currency),
              amount_spent: '0',
              amount_spent_formatted: '0',
              spend_cap: '0',
              spend_cap_formatted: '0',
              total_prepay_balance: '0',
              total_prepay_balance_formatted: '0',
              lifetime_spend: '0',
              lifetime_spend_formatted: '0',
              
              // Account details
              disable_reason: originalAccount.disable_reason || 0,
              owner: originalAccount.owner || '',
              owner_display: ownerDisplay,
              account_type: accountType,
              created_time: originalAccount.created_time || '',
              next_bill_date: originalAccount.next_bill_date || '',
              is_prepay_account: originalAccount.is_prepay_account || false,
              
              // Location & timezone
              business_country_code: 'No.QG',
              timezone_name: undefined,
              timezone_offset_hours_utc: undefined,
              
              // Permissions & users
              user_role: originalAccount.user_role || '',
              hidden_admins_count: 0,
              total_permissions: 0,
              visible_users: 0,
              
              // Payment methods
              payment_methods: {
                credit_cards: [],
                direct_debits: [],
                paypal_emails: [],
                other_methods: []
              },
              funding_source_details: null,
              
              // Source info
              spend: originalAccount.spend || '0',
              source: originalAccount.source || 'Personal',
              bm_id: originalAccount.bm_id || undefined,
              bm_name: originalAccount.bm_name || undefined,
              owner_business: originalAccount.owner_business || null
            });
          });
        } else {
        }
        
        // Cập nhật results với thông tin chi tiết
        results.tkqc_list = detailedAccounts;
      } else {
        // Nếu không có accounts nào hoặc quá nhiều accounts, sử dụng basic info
        results.tkqc_list = allAdAccounts.map(account => ({
          ...account,
          // Đảm bảo có đầy đủ field cần thiết
          adtrust_dsl: account.adtrust_dsl || 0,
          disable_reason: account.disable_reason || 0,
          owner: account.owner || '',
          created_time: account.created_time || '',
          next_bill_date: account.next_bill_date || '',
          is_prepay_account: account.is_prepay_account || false,
          threshold_amount: account.threshold_amount || 0,
          user_role: account.user_role || '',
          spend: account.spend || '0',
          source: account.source || 'Personal',
          bm_id: account.bm_id || undefined,
          bm_name: account.bm_name || undefined,
          owner_business: account.owner_business || null
        }));
      }
      
      // Nếu có quá nhiều accounts và không yêu cầu lấy tất cả, chỉ lưu top accounts
      if (allAdAccounts.length > 1000 && !getAllAccounts) {
        results.tkqc_list = results.tkqc_list.slice(0, 1000);
      }

      // 4. Check restriction status cho từng BM (optional)
      if (results.bm_list.length > 0) {
        for (const bm of results.bm_list) {
          try {
            const restrictionResponse = await fetch(
              'https://www.facebook.com/api/graphql/',
              {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded',
                  'Cookie': cookie || ''
                },
                body: new URLSearchParams({
                  '__a': '1',
                  'fb_dtsg': 'NAfvENmKZN2vU5KJ8371WtiBzoZPs2ke3WUPdXABbf0DJYpFlHCHnUw:30:1754418524',
                  'lsd': 'b7hsQf2IrA4NbJDj5WEVt5',
                  'locale': 'en_US',
                  'dpr': '1',
                  'variables': JSON.stringify({"id": bm.id}),
                  'doc_id': '7820136481365487',
                  'server_timestamps': 'true'
                })
              }
            );

            if (restrictionResponse.ok) {
              const restrictionData = await parseFacebookResponse(restrictionResponse);
              const restrictionType = restrictionData?.data?.node?.advertising_restriction_info?.restriction_type;
              bm.restriction_type = restrictionType;
            }
          } catch (error) {
            bm.restriction_type = 'UNKNOWN';
          }
        }
      }

    } catch (error) {
      results.success = false;
      results.message = `Có lỗi xảy ra khi check TKQC: ${error instanceof Error ? error.message : 'Unknown error'}`;
    }
    
    // Cập nhật message dựa trên kết quả
    if (results.success) {
      const personalAccounts = results.tkqc_list.filter(acc => !acc.source || acc.source === 'Personal').length;
      const bmAccounts = results.tkqc_list.filter(acc => acc.source && acc.source.startsWith('BM:')).length;
      
      if (results.tkqc_list.length === 0 && results.bm_list.length === 0) {
        results.message = 'Token hợp lệ nhưng không tìm thấy TKQC hoặc Business Manager nào.';
      } else if (results.tkqc_list.length === 0) {
        results.message = `Token không có quyền truy cập Ad Accounts, nhưng tìm thấy ${results.bm_list.length} Business Manager(s).`;
      } else {
        let message = `Tìm thấy tổng cộng ${results.tkqc_list.length} TKQC`;
        if (personalAccounts > 0 && bmAccounts > 0) {
          message += ` (${personalAccounts} cá nhân + ${bmAccounts} từ BM)`;
        } else if (bmAccounts > 0) {
          message += ` (tất cả từ BM)`;
        } else {
          message += ` (tất cả cá nhân)`;
        }
        message += ` và ${results.bm_list.length} Business Manager(s).`;
        results.message = message;
      }
    }

    // Lưu dữ liệu vào database nếu có accountId
    if (accountId && results.success) {
      try {
        await connectDB();
        
        // Validate và chuẩn hóa dữ liệu trước khi lưu - LỮU TOÀN BỘ THÔNG TIN
        const normalizedTkqcData = results.tkqc_list.map(account => {
          // Helper function để format currency
          const formatCurrency = (amount: string | number, currency: string = 'VND') => {
            if (!amount || amount === '0') return '0';
            const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
            return `${numAmount.toLocaleString()} ${currency}`;
          };

          // Helper function để format account status
          const getAccountStatusText = (status: number | string) => {
            const statusMap: { [key: string]: string } = {
              "1": "Live",
              "2": "Die", 
              "3": "Nợ",
              "100": "Đang Đợi close",
              "101": "close"
            };
            return statusMap[String(status)] || `Unknown(${status})`;
          };

          // Helper function để xác định loại TKQC
          const getAccountType = (owner: string, source: string) => {
            if (source && source.startsWith('BM:')) return 'Tkqc BM';
            if (!owner) return 'Unknown';
            if (owner.length <= 15) return 'Tkqc Cá Nhân';
            const first4 = owner.substring(0, 4);
            return first4.includes('1000') ? 'Tkqc Cá Nhân' : 'Tkqc BM';
          };

          const currency = account.currency || 'VND';
          const accountStatus = getAccountStatusText(account.account_status || 0);
          const accountType = getAccountType(account.owner || '', account.source || '');

          return {
            // Basic info - THÊM CÁC FIELD CÒN THIẾU
            id: account.id || account.account_id || '',
            account_id: account.account_id || '',
            name: account.name || '',
            account_status: account.account_status || 0,
            account_status_text: accountStatus,
            account_status_code: String(account.account_status || 0),
            
            // Financial info với format hiển thị
            balance: account.balance || '',
            balance_formatted: formatCurrency(account.balance || '0', currency),
            currency: currency,
            adtrust_dsl: account.adtrust_dsl || 0,
            adtrust_dsl_formatted: formatCurrency(account.adtrust_dsl || 0, currency),
            limit: account.limit || account.adtrust_dsl || 'N/A',
            threshold_amount: account.threshold_amount || 0,
            threshold_amount_formatted: formatCurrency(account.threshold_amount || 0, currency),
            amount_spent: account.amount_spent || '0',
            amount_spent_formatted: formatCurrency(account.amount_spent || '0', currency),
            spend_cap: account.spend_cap || '0',
            spend_cap_formatted: formatCurrency(account.spend_cap || '0', currency),
            total_prepay_balance: account.total_prepay_balance || '0',
            total_prepay_balance_formatted: formatCurrency(account.total_prepay_balance || '0', currency),
            lifetime_spend: account.lifetime_spend || '0',
            lifetime_spend_formatted: formatCurrency(account.lifetime_spend || '0', currency),
            
            // THÊM CÁC FIELD HIỂN THỊ TIẾNG VIỆT
            "Chi_Tiêu": formatCurrency(account.amount_spent || '0', currency),
            "Lifetime Spend": formatCurrency(account.lifetime_spend || '0', currency),
            "Spend Cap": formatCurrency(account.spend_cap || '0', currency),
            "Prepay Balance": formatCurrency(account.total_prepay_balance || '0', currency),
            "Ngưỡng Thanh Toán": formatCurrency(account.threshold_amount || 0, currency),
            "Nợ": formatCurrency(account.balance || '0', currency),
            
            // Account details
            disable_reason: account.disable_reason || 0,
            owner: account.owner || '',
            owner_display: account.owner_display || '',
            account_type: accountType,
            type: accountType,
            "Loại TKQC": accountType,
            created_time: account.created_time || '',
            "Time Tạo": account.created_time || '',
            next_bill_date: account.next_bill_date || '',
            "Ngày Thanh Toán": account.next_bill_date || '',
            is_prepay_account: account.is_prepay_account || false,
            
            // Location & timezone
            business_country_code: account.business_country_code || '',
            timezone_name: account.timezone_name || '',
            timezone_offset_hours_utc: account.timezone_offset_hours_utc || 0,
            
            // Payment info
            thongtinthanhtoan: account.thongtinthanhtoan || '',
            loaithanhtoan: account.loaithanhtoan || '',
            
            // Permissions & users
            user_role: account.user_role || '',
            hidden_admins_count: account.hidden_admins_count || 0,
            "QTV ẩn": account.hidden_admins_count || 0,
            total_permissions: account.total_permissions || 0,
            visible_users: account.visible_users || 0,
            
            // Payment methods
            payment_methods: account.payment_methods || {
              credit_cards: [],
              direct_debits: [],
              paypal_emails: [],
              other_methods: []
            },
            funding_source_details: account.funding_source_details || null,
            
            // Source info
            spend: account.spend || '0',
            source: account.source || 'Personal',
            bm_id: account.bm_id || undefined,
            bm_name: account.bm_name || undefined,
            owner_business: account.owner_business || null,
            
            // THÊM CÁC FIELD HIỂN THỊ KHÁC
            "ID": account.account_id || '',
            "Tên": account.name || '',
            "Via Tạo": account.owner || '',
            "Tiente": currency
          };
        });

        const updateData = {
          tkqcData: normalizedTkqcData,
          bmData: results.bm_list,
          accountInfo: results.account_info,
          lastTkqcCheck: new Date(),
          tkqcCount: normalizedTkqcData.length,
          bmCount: results.bm_list.length,
          status: 'active',
          log: results.message
        };

        const updatedAccount = await (FacebookAccount as any).findByIdAndUpdate(
          accountId,
          updateData,
          { new: true }
        );
        
      } catch (dbError) {
        console.error('Database error:', dbError);
        // Database error không ảnh hưởng đến response chính
      }
    }
    
    // Enhanced logging với format giống C# code
    const personalAccounts = results.tkqc_list.filter(acc => acc.account_type === 'Tkqc Cá Nhân' && acc.owner_display === 'Chính');
    const bmAccounts = results.tkqc_list.filter(acc => acc.account_type === 'Tkqc BM' || acc.owner_display !== 'Chính');
    const liveAccounts = results.tkqc_list.filter(acc => acc.account_status_text?.includes('Live'));
    const dieAccounts = results.tkqc_list.filter(acc => acc.account_status_text?.includes('Die'));
    // Verify ALL accounts have full details
    const accountsWithFullDetails = results.tkqc_list.filter(acc => 
      acc.account_status_text && 
      acc.adtrust_dsl_formatted && 
      acc.account_type && 
      acc.owner_display
    );
    if (accountsWithFullDetails.length < results.tkqc_list.length) {
      const missingDetails = results.tkqc_list.filter(acc => 
        !acc.account_status_text || 
        !acc.adtrust_dsl_formatted || 
        !acc.account_type || 
        !acc.owner_display
      );
    }
    


    // Optionally run Quality check after TKQC
    if (runQualityAfter && accountId) {
      if (isRunCanceled(runId)) {
        return NextResponse.json({ ...results, success: false, message: 'Canceled' })
      }
      try {
        const qcRes = await fetch('http://localhost:3000/api/check-quality-via', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-internal-call': '1' },
          body: JSON.stringify({ accountId, loginFirst, loginMethod })
        });
        if (qcRes.ok) {
          const qcJson = await qcRes.json();
          results.qualityCheck = {
            success: !!qcJson?.success,
            adsStatus: qcJson?.adsStatus,
            restrictionStatus: qcJson?.restrictionStatus,
            name: qcJson?.name,
            email: qcJson?.email
          };
          results.message += ` | Quality: ${qcJson?.adsStatus || 'unknown'}`;
        } else {
          results.qualityCheck = { success: false };
        }
      } catch (e) {
        results.qualityCheck = { success: false };
      }
    }

    return NextResponse.json(results);

  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'Internal server error', success: false },
      { status: 500 }
    );
  }
}