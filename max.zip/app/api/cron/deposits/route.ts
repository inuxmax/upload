import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import PaymentInfo from '@/models/PaymentInfo'
import Transaction from '@/models/Transaction'
import User from '@/models/User'

export const dynamic = 'force-dynamic'

async function fetchACBHistory(paymentInfo: any) {
  const url = `https://api.web2m.com/historyapiacbv3/${paymentInfo.passwordACB}/${paymentInfo.accountNumber}/${paymentInfo.tokenACB}`
  let res: Response
  try {
    res = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'ftool-cron/1.0 (+https://ftool.vn)'
      },
      // Add a conservative revalidation policy for edge runtimes
      cache: 'no-store'
    })
  } catch (e: any) {
    throw new Error(`ACB API network error: ${e?.message || e}`)
  }
  if (!res.ok) {
    const body = await res.text().catch(() => '')
    throw new Error(`ACB API HTTP ${res.status} - ${body?.slice(0, 200)}`)
  }
  let data: any
  try {
    data = await res.json()
  } catch (e: any) {
    const body = await res.text().catch(() => '')
    throw new Error(`ACB API JSON parse error: ${e?.message || e} - ${body?.slice(0, 200)}`)
  }
  if (!data || data.status !== true || !Array.isArray(data.transactions)) {
    throw new Error('ACB API payload invalid')
  }
  return data.transactions
}

function matchesTransaction(acbTxn: any, pending: any) {
  if (acbTxn.type !== 'IN') return false
  if (Number(acbTxn.amount) !== Number(pending.amount)) return false
  const desc = String(acbTxn.description || '').toUpperCase()
  const needle = String(pending.transferContent || '').toUpperCase()
  if (!needle) return false
  if (desc.includes(needle)) return true
  if (needle.length >= 8 && desc.includes(needle.substring(0, 8))) return true
  return false
}

export async function GET(request: NextRequest) {
  try {
    const key = request.nextUrl.searchParams.get('key') || request.headers.get('x-cron-key') || ''
    const debug = request.nextUrl.searchParams.get('debug') === '1' || request.nextUrl.searchParams.get('debug') === 'true'
    const secret = process.env.CRON_DEPOSITS_KEY || process.env.CRON_SECRET || ''
    if (!secret || key !== secret) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    try {
      await connectMongoDB()
    } catch (e: any) {
      const message = `MongoDB connect error: ${e?.message || e}`
      if (debug) {
        return NextResponse.json({ error: message }, { status: 500 })
      }
      throw new Error(message)
    }

    const paymentInfo = await (PaymentInfo as any).findOne({ isActive: true }).lean()
    if (!paymentInfo) {
      return NextResponse.json({ error: 'No active payment info' }, { status: 500 })
    }

    let acbTxns: any[] = []
    try {
      acbTxns = await fetchACBHistory(paymentInfo)
    } catch (e: any) {
      const message = `Fetch ACB history failed: ${e?.message || e}`
      if (debug) {
        return NextResponse.json({ error: message }, { status: 500 })
      }
      throw new Error(message)
    }
    const pendings = await (Transaction as any).find({ type: 'deposit', status: 'pending' }).limit(200)

    let matched = 0
    for (const pending of pendings) {
      const match = acbTxns.find((t: any) => matchesTransaction(t, pending))
      if (!match) continue

      const user = await (User as any).findById(pending.userId)
      if (!user) continue

      // Idempotency check
      const fresh = await (Transaction as any).findById(pending._id)
      if (!fresh || fresh.status !== 'pending') continue

      user.balance = (user.balance || 0) + Number(pending.amount)
      user.pendingTransferContents = user.pendingTransferContents || []
      if (!user.pendingTransferContents.includes(pending.transferContent)) {
        user.pendingTransferContents.push(pending.transferContent)
      }

      fresh.status = 'completed'
      fresh.completedAt = new Date()
      fresh.description = `Nạp tiền qua ${paymentInfo.bankName || 'ACB'} - ${pending.transferContent}`
      fresh.bankInfo = {
        bankName: paymentInfo.bankName || 'ACB',
        accountNumber: paymentInfo.accountNumber,
        accountHolder: paymentInfo.accountHolder
      }

      await Promise.all([user.save(), fresh.save()])
      matched += 1
    }

    return NextResponse.json({ success: true, checked: pendings.length, matched })
  } catch (error) {
    // Surface error details if debug flag is passed; otherwise keep generic
    const err = error as any
    const body = { error: 'Internal server error' as string, message: undefined as any }
    if (typeof err?.message === 'string') body.message = err.message
    const status = 500
    return NextResponse.json(body, { status })
  }
}


