import { NextRequest, NextResponse } from 'next/server';

// Import cron functions
let initCronJobs: any;
let stopCronJobs: any;
let getCronStatus: any;
let resetCronStats: any;

// Dynamic import để tránh lỗi
try {
  const cronModule = require('@/lib/cron');
  initCronJobs = cronModule.initCronJobs;
  stopCronJobs = cronModule.stopCronJobs;
  getCronStatus = cronModule.getCronStatus;
  resetCronStats = cronModule.resetCronStats;
} catch (error) {
  console.error('Error importing cron module:', error);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    if (action === 'start') {
      if (initCronJobs) {
        initCronJobs();
        return NextResponse.json({ 
          message: 'Cron jobs started successfully',
          schedule: 'Every 30 seconds',
          timezone: 'Asia/Ho_Chi_Minh',
          autoStart: true
        });
      } else {
        return NextResponse.json(
          { error: 'Cron module not available' },
          { status: 500 }
        );
      }
    } else if (action === 'stop') {
      if (stopCronJobs) {
        stopCronJobs();
        return NextResponse.json({ 
          message: 'Cron jobs stopped successfully' 
        });
      } else {
        return NextResponse.json(
          { error: 'Cron module not available' },
          { status: 500 }
        );
      }
    } else if (action === 'reset') {
      if (resetCronStats) {
        resetCronStats();
        return NextResponse.json({ 
          message: 'Cron stats reset successfully' 
        });
      } else {
        return NextResponse.json(
          { error: 'Cron module not available' },
          { status: 500 }
        );
      }
    } else {
      return NextResponse.json(
        { error: 'Invalid action. Use "start", "stop", or "reset"' },
        { status: 400 }
      );
    }
  } catch (error) {
    console.error('Cron API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    let status = null;
    if (getCronStatus) {
      status = getCronStatus();
    }
    
    return NextResponse.json({
      message: 'Cron API is running',
      status,
      endpoints: {
        start: 'POST /api/cron with {"action": "start"}',
        stop: 'POST /api/cron with {"action": "stop"}',
        reset: 'POST /api/cron with {"action": "reset"}'
      },
      schedule: 'Every 30 seconds',
      timezone: 'Asia/Ho_Chi_Minh',
      autoStart: true
    });
  } catch (error) {
    console.error('Cron API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 