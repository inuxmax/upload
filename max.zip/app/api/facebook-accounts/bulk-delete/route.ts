import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import FacebookAccount from '@/models/FacebookAccount';
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to get user from token
async function getUserFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// DELETE bulk delete Facebook accounts with high performance
export async function DELETE(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const ids = searchParams.get('ids');
    
    if (!ids) {
      return NextResponse.json({ error: 'No account IDs provided' }, { status: 400 });
    }

    const accountIds = ids.split(',').filter(id => id.trim());
    
    if (accountIds.length === 0) {
      return NextResponse.json({ error: 'Invalid account IDs' }, { status: 400 });
    }

    console.log(`Starting bulk delete for ${accountIds.length} accounts...`);
    const startTime = Date.now();

    // Use bulk delete operation for better performance
    const deleteResult = await FacebookAccount.deleteMany({
      _id: { $in: accountIds },
      userId: user.userId
    });

    const processingTime = Date.now() - startTime;
    
    console.log(`Bulk delete completed: ${deleteResult.deletedCount} accounts deleted in ${processingTime}ms`);

    return NextResponse.json({
      success: true,
      message: `Successfully deleted ${deleteResult.deletedCount} accounts`,
      stats: {
        total: accountIds.length,
        deleted: deleteResult.deletedCount,
        processingTime
      }
    });
    
  } catch (error) {
    console.error('Error in bulk delete API:', error);
    return NextResponse.json({ 
      error: 'Bulk delete failed', 
      details: (error as any).message 
    }, { status: 500 });
  }
}
