import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import FacebookAccount from '@/models/FacebookAccount';
import { getUserEncryptionKey, encryptFields } from '@/lib/encryption'
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to get user from token
async function getUserFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// POST bulk insert Facebook accounts with high performance
export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const body = await request.json();
    const { accounts, batchSize = 1000 } = body;
    
    if (!Array.isArray(accounts) || accounts.length === 0) {
      return NextResponse.json({ error: 'Invalid accounts data' }, { status: 400 });
    }

    console.log(`Starting bulk insert for ${accounts.length} accounts...`);
    const startTime = Date.now();

    const { enabled } = await getUserEncryptionKey(user.userId);
    const userKey = request.headers.get('x-user-key') || '';
    const fieldsToProtect = ['pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token'];
    
    // Check for existing accounts in bulk to avoid duplicates
    const uids = accounts.map(acc => acc.uid).filter(Boolean);
    console.log(`Checking for ${uids.length} existing UIDs...`);
    
    const existingAccounts = await (FacebookAccount as any).find({ 
      uid: { $in: uids },
      userId: user.userId
    }, { uid: 1 }).lean();
    
    const existingUids = new Set(existingAccounts.map((acc: any) => acc.uid));
    const newAccounts = accounts.filter(acc => !existingUids.has(acc.uid));
    const duplicateCount = accounts.length - newAccounts.length;
    
    console.log(`Found ${duplicateCount} duplicates, ${newAccounts.length} new accounts to insert`);
    
    if (newAccounts.length === 0) {
      return NextResponse.json({
        success: true,
        savedAccounts: [],
        errors: [`All ${duplicateCount} accounts already exist`],
        stats: {
          total: accounts.length,
          inserted: 0,
          duplicates: duplicateCount,
          processingTime: Date.now() - startTime
        }
      });
    }
    
    // Process in batches for better memory management
    const batches = [];
    for (let i = 0; i < newAccounts.length; i += batchSize) {
      batches.push(newAccounts.slice(i, i + batchSize));
    }
    
    console.log(`Processing ${batches.length} batches of ${batchSize} accounts each`);
    
    let totalInserted = 0;
    const allErrors: string[] = [];
    const allInsertedIds: any[] = [];
    
    for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
      const batch = batches[batchIndex];
      console.log(`Processing batch ${batchIndex + 1}/${batches.length} with ${batch.length} accounts`);
      
      // Prepare bulk insert operations for this batch
      const bulkOps = batch.map(accountData => {
        const protectedData = enabled && userKey ? encryptFields(accountData, fieldsToProtect, userKey) : accountData;
        
        return {
          insertOne: {
            document: {
              uid: protectedData.uid || '',
              pass: protectedData.pass || '',
              twofa: protectedData.twofa || '',
              mail: protectedData.mail || '',
              passmail: protectedData.passmail || '',
              mailkp: protectedData.mailkp || '',
              cookie: protectedData.cookie || '',
              token: protectedData.token || '',
              name: accountData.name || 'Chưa có',
              friends: accountData.friends || 'Chưa có',
              gender: accountData.gender || 'Chưa có',
              creationDate: accountData.creationDate || 'Chưa có',
              status: accountData.status || 'active',
              log: accountData.log || 'Tài khoản mới được thêm',
              userId: user.userId,
              createdAt: new Date(),
              updatedAt: new Date()
            }
          }
        };
      });
      
      // Execute bulk insert for this batch
      try {
        const batchResult = await (FacebookAccount as any).bulkWrite(bulkOps, { 
          ordered: false,
          writeConcern: { w: 1, j: false } // Optimize for speed
        });
        
        if (batchResult.insertedIds) {
          allInsertedIds.push(...Object.values(batchResult.insertedIds));
          totalInserted += Object.keys(batchResult.insertedIds).length;
        }
        
        if (batchResult.writeErrors && batchResult.writeErrors.length > 0) {
          batchResult.writeErrors.forEach((writeError: any) => {
            allErrors.push(`Batch ${batchIndex + 1}: ${writeError.errmsg}`);
          });
        }
        
        console.log(`Batch ${batchIndex + 1} completed: ${Object.keys(batchResult.insertedIds || {}).length} inserted`);
        
      } catch (error) {
        console.error(`Batch ${batchIndex + 1} failed:`, error);
        allErrors.push(`Batch ${batchIndex + 1} failed: ${(error as any).message}`);
      }
    }
    
    // Fetch the newly inserted accounts (only if needed)
    let savedAccounts: any[] = [];
    if (allInsertedIds.length > 0) {
      try {
        savedAccounts = await (FacebookAccount as any).find({
          _id: { $in: allInsertedIds }
        }, { uid: 1, mail: 1, status: 1, createdAt: 1 }).sort({ createdAt: -1 }).lean();
      } catch (error) {
        console.error('Error fetching inserted accounts:', error);
      }
    }
    
    const processingTime = Date.now() - startTime;
    console.log(`Bulk insert completed in ${processingTime}ms: ${totalInserted} inserted, ${allErrors.length} errors`);
    
    return NextResponse.json({
      success: true,
      savedAccounts,
      errors: allErrors.length > 0 ? allErrors : undefined,
      stats: {
        total: accounts.length,
        inserted: totalInserted,
        duplicates: duplicateCount,
        processingTime,
        batches: batches.length,
        batchSize
      }
    });
    
  } catch (error) {
    console.error('Error in bulk insert:', error);
    return NextResponse.json({ 
      error: 'Bulk insert failed', 
      details: (error as any).message 
    }, { status: 500 });
  }
}
