import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import FacebookAccount from '@/models/FacebookAccount';
import { getUserEncryptionKey, encryptFields, decryptFields, isEncrypted } from '@/lib/encryption'
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to get user from token
async function getUserFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// GET Facebook accounts for the authenticated user (non-admins only see their own)
export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    // Default: users only see their own accounts
    const query: any = { userId: user.userId };
    const accounts = await (FacebookAccount as any).find(query).sort({ createdAt: -1 });
    // Per-session key header; if absent, do not auto-decrypt -> client must provide key each session
    const userKey = request.headers.get('x-user-key') || ''
    const { enabled } = await getUserEncryptionKey(user.userId)
    if (enabled && userKey) {
      const sensitive = ['pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token', 'accessToken', 'cookies', 'sessionKey', 'secret', 'eaagToken', 'eaabToken']
      const decrypted = accounts.map((a: any) => decryptFields(a.toObject ? a.toObject() : a, sensitive, userKey))
      return NextResponse.json(decrypted)
    }
    return NextResponse.json(accounts);
  } catch (error) {
    console.error('Error fetching Facebook accounts:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// POST new Facebook account(s)
export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const body = await request.json();
    
    // Handle both single account and array of accounts
    let accounts = [];
    if (Array.isArray(body)) {
      accounts = body;
    } else if (body.accounts && Array.isArray(body.accounts)) {
      accounts = body.accounts;
    } else if (body.uid) {
      // Single account
      accounts = [body];
    } else {
      return NextResponse.json({ error: 'Invalid account data' }, { status: 400 });
    }

    const { enabled } = await getUserEncryptionKey(user.userId)
    const userKey = request.headers.get('x-user-key') || ''
    const fieldsToProtect = ['pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token']
    
    // Check for existing accounts in bulk to avoid duplicates
    const uids = accounts.map(acc => acc.uid).filter(Boolean);
    const existingAccounts = await (FacebookAccount as any).find({ 
      uid: { $in: uids },
      userId: user.userId
    });
    const existingUids = new Set(existingAccounts.map((acc: any) => acc.uid));
    
    // Filter out existing accounts
    const newAccounts = accounts.filter(acc => !existingUids.has(acc.uid));
    const duplicateErrors = accounts.filter(acc => existingUids.has(acc.uid))
      .map(acc => `Account with UID ${acc.uid} already exists`);
    
    if (newAccounts.length === 0) {
      return NextResponse.json({
        success: true,
        savedAccounts: [],
        errors: duplicateErrors
      });
    }
    
    // Prepare bulk insert operations
    const bulkOps = newAccounts.map(accountData => {
      const protectedData = enabled && userKey ? encryptFields(accountData, fieldsToProtect, userKey) : accountData;
      
      return {
        insertOne: {
          document: {
            uid: protectedData.uid || '',
            pass: protectedData.pass || '',
            twofa: protectedData.twofa || '',
            mail: protectedData.mail || '',
            passmail: protectedData.passmail || '',
            mailkp: protectedData.mailkp || '',
            cookie: protectedData.cookie || '',
            token: protectedData.token || '',
            name: accountData.name || 'Chưa có',
            friends: accountData.friends || 'Chưa có',
            gender: accountData.gender || 'Chưa có',
            creationDate: accountData.creationDate || 'Chưa có',
            status: accountData.status || 'active',
            log: accountData.log || '',
            userId: user.userId,
            createdAt: new Date(),
            updatedAt: new Date()
          }
        }
      };
    });
    
    // Execute bulk insert
    let bulkResult;
    try {
      bulkResult = await (FacebookAccount as any).bulkWrite(bulkOps, { ordered: false });
    } catch (error) {
      console.error('Bulk insert error:', error);
      return NextResponse.json({ 
        error: 'Bulk insert failed', 
        details: (error as any).message 
      }, { status: 500 });
    }
    
    // Fetch the newly inserted accounts
    const savedAccounts = await (FacebookAccount as any).find({
      _id: { $in: Object.values(bulkResult.insertedIds || {}) }
    }).sort({ createdAt: -1 });
    
    const errors = [...duplicateErrors];
    if (bulkResult.writeErrors && bulkResult.writeErrors.length > 0) {
      bulkResult.writeErrors.forEach((writeError: any) => {
        errors.push(`Failed to save account: ${writeError.errmsg}`);
      });
    }

    return NextResponse.json({
      success: true,
      savedAccounts,
      errors: errors.length > 0 ? errors : undefined
    });
  } catch (error) {
    console.error('Error creating Facebook accounts:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// PUT update Facebook account
export async function PUT(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const body = await request.json();
    const { accountId, updates } = body;

    if (!accountId || !updates) {
      return NextResponse.json({ error: 'Account ID and updates are required' }, { status: 400 });
    }

    // Enforce ownership: non-admin users can only update their own accounts
    const existing = await (FacebookAccount as any).findById(accountId);
    if (!existing) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 });
    }
    if ((existing.userId?.toString?.() || '') !== String(user.userId)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const updatedAccount = await (FacebookAccount as any).findByIdAndUpdate(
      accountId,
      { $set: updates },
      { new: true }
    );

    if (!updatedAccount) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 });
    }

    return NextResponse.json(updatedAccount);
  } catch (error) {
    console.error('Error updating Facebook account:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// DELETE Facebook account
export async function DELETE(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const accountId = searchParams.get('id');

    if (!accountId) {
      return NextResponse.json({ error: 'Account ID is required' }, { status: 400 });
    }

    // Enforce ownership: non-admin users can only delete their own accounts
    const existing = await (FacebookAccount as any).findById(accountId);
    if (!existing) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 });
    }
    if ((existing.userId?.toString?.() || '') !== String(user.userId)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const deletedAccount = await (FacebookAccount as any).findByIdAndDelete(accountId);

    if (!deletedAccount) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, deletedAccount });
  } catch (error) {
    console.error('Error deleting Facebook account:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
} 