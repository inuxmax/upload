import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import FacebookAccount from '@/models/FacebookAccount'
import Settings from '@/models/Settings'
import { emitLog } from '@/lib/log-bus'
import { getEAAGToken, getEAABToken } from '@/lib/facebook-login.js'
import { getProxyFromProxyFB, forceChangeProxyFB, type ProxyConfig } from '@/lib/proxyfb'
import { HttpsProxyAgent } from 'https-proxy-agent'

type ChangeMailMethod = 'mail1s' | 'outlook'

interface ChangeMailRequest {
  accountId: string
  method: ChangeMailMethod
  mail1sAddress?: string
  autoConfirm?: boolean
  loginFirst?: boolean
  useProxy?: boolean
}

const MAIL1S_DEFAULT_API_KEY = 'b67c74dd-299b-4e66-87e9-5a0736952b42'

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function buildProxyAgent(proxy?: ProxyConfig | null) {
  if (!proxy) return undefined
  const auth = (proxy as any).username && (proxy as any).password
    ? `${encodeURIComponent((proxy as any).username)}:${encodeURIComponent((proxy as any).password)}@`
    : ''
  return new HttpsProxyAgent(`${proxy.protocol}://${auth}${proxy.host}:${proxy.port}`)
}

async function tryGraphQLFetch(url: string, body: URLSearchParams, headers: Record<string, string>, proxy?: ProxyConfig | null) {
  const agent = buildProxyAgent(proxy)
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), 20000)
  try {
    const res = await fetch(url, { method: 'POST', headers, body, ...(agent ? { agent } : {}), signal: controller.signal } as any)
    const text = await res.text()
    return { ok: res.ok, status: res.status, text }
  } finally {
    clearTimeout(timeoutId)
  }
}

async function sendVerificationEmail(targetEmail: string, uid: string, token: string, cookie: string, proxy?: ProxyConfig | null) {
  // Use exact same payload as C# code
  const variables = `%7B%22input%22%3A%7B%22should_attempt_auto_confirm%22%3Afalse%2C%22contact_point%22%3A%22${encodeURIComponent(targetEmail)}%22%2C%22client_mutation_id%22%3A%22${encodeURIComponent(String(Date.now()))}%22%2C%22contactpoint_is_primary%22%3Atrue%2C%22actor_id%22%3A%22${encodeURIComponent(uid)}%22%7D%7D`
  const payload = new URLSearchParams(
    `client_doc_id=41510488434396029940579328634&method=post&locale=vi_VN&pretty=false&format=json&variables=${variables}&fb_api_req_friendly_name=NDXEMUSendVerificationEmail_v2&fb_api_caller_class=graphservice&fb_api_analytics_tags=%5B%22nav_attribution_id%3D%7B%7D%22%2C%22visitation_id%3Dnull%22%2C%22GraphServices%22%5D&server_timestamps=true`
  )

  // Use exact same headers as C# code
  const headers = {
    'accept': 'application/json, text/plain, */*',
    'content-type': 'application/x-www-form-urlencoded; charset=utf-8',
    'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 9; SM-A505F Build/PQ3.0.190605.09261202) [FBAN/FB4A;FBAV/396.1.0.28.104;FBPN/com.facebook.katana;FBLC/vi_VN;FBBV/429651049;FBCR/MobiFone;FBMF/samsung;FBBD/samsung;FBDV/SM-A505F;FBSV/9;FBCA/armeabi-v7a;FBDM/{density=3.0,width=1440,height=2560};FB_FW/1;FBRV/0;]',
    'priority': 'u=3, i',
    'x-graphql-client-library': 'graphservice',
    'authorization': `OAuth ${token}`,
    'x-fb-friendly-name': 'NDXEMUSendVerificationEmail_v2',
    'x-fb-request-analytics-tags': 'graphservice',
    'cookie': cookie
  }

  // Try both endpoints like C# code
  const urls = ['https://graph.facebook.com/graphql', 'https://b-graph.facebook.com/graphql']
  
  for (const url of urls) {
    try {
      const res = await tryGraphQLFetch(url, payload, headers, proxy)
      if (res.ok) {
        // Check response exactly like C# code
        if (res.text.includes('true')) {
          console.log(`✅ Send verification email success at ${url}`)
          return { success: true }
        }
      }
    } catch (error) {
      console.log(`⚠️ Send verification email failed at ${url}: ${error}`)
    }
  }
  
  return { success: false, message: 'Failed to send verification email' }
}

async function confirmEmail(targetEmail: string, pinCode: string, token: string, cookie: string, proxy?: ProxyConfig | null) {
  // Use exact same payload as C# code
  const variables = `%7B%22contact_point%22%3A%22${encodeURIComponent(targetEmail)}%22%2C%22source_type%22%3A%22change_pending_contact%22%2C%22pin_code%22%3A%22${encodeURIComponent(pinCode)}%22%7D`
  const payload = new URLSearchParams(
    `client_doc_id=363964717211084159108724354799&method=post&locale=vi_VN&pretty=false&format=json&variables=${variables}&fb_api_req_friendly_name=NDXEMUVerifyEmail_v2&fb_api_caller_class=graphservice&fb_api_analytics_tags=%5B%22nav_attribution_id%3D%7B%7D%22%2C%22visitation_id%3Dnull%22%2C%22GraphServices%22%5D&server_timestamps=true`
  )

  // Use exact same headers as C# code
  const headers = {
    'accept': 'application/json, text/plain, */*',
    'content-type': 'application/x-www-form-urlencoded; charset=utf-8',
    'user-agent': 'Dalvik/2.1.0 (Linux; U; Android 9; SM-A505F Build/PQ3A.190605.09261202) [FBAN/FB4A;FBAV/396.1.0.28.104;FBPN/com.facebook.katana;FBLC/vi_VN;FBBV/429651049;FBCR/MobiFone;FBMF/samsung;FBBD/samsung;FBDV/SM-A505F;FBSV/9;FBCA/armeabi-v7a;FBDM/{density=3.0,width=1440,height=2560};FB_FW/1;FBRV/0;]',
    'priority': 'u=3, i',
    'x-graphql-client-library': 'graphservice',
    'authorization': `OAuth ${token}`,
    'x-fb-friendly-name': 'NDXEMUVerifyEmail_v2',
    'x-fb-request-analytics-tags': 'graphservice',
    'cookie': cookie
  }

  // Try both endpoints like C# code
  const urls = ['https://graph.facebook.com/graphql', 'https://b-graph.facebook.com/graphql']
  
  for (const url of urls) {
    try {
      const res = await tryGraphQLFetch(url, payload, headers, proxy)
      if (res.ok) {
        // Check response exactly like C# code
        if (res.text.includes('true')) {
          console.log(`✅ Confirm email success at ${url}`)
          return { success: true }
        }
      }
    } catch (error) {
      console.log(`⚠️ Confirm email failed at ${url}: ${error}`)
    }
  }
  
  return { success: false, message: 'Failed to confirm email' }
}

async function createMail1sEmail(address: string | undefined, apiKey: string) {
  const desired = address && /@/.test(address) ? address : `fb_${Math.random().toString(36).slice(2, 10)}@mail1s.net`
  const res = await fetch('https://mail1s.net/api/v1/email', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'wrdo-api-key': apiKey },
    body: JSON.stringify({ emailAddress: desired })
  })
  if (!res.ok && res.status !== 409) {
    const t = await res.text()
    throw new Error(`Mail1s create failed: ${t}`)
  }
  return desired
}

async function pollMail1sCode(address: string, apiKey: string, timeoutMs = 60000) {
  const started = Date.now()
  // Multiple regex patterns to catch different code formats
  const patterns = [
    /(\b|>)(?:\d{5,8})(<|\b)/,           // 5-8 digits
    /(\b|>)(?:\d{6})(<|\b)/,              // Exactly 6 digits
    /(\b|>)(?:\d{4,6})(<|\b)/,            // 4-6 digits
    /code[:\s]*(\d{4,8})/i,               // "code: 123456"
    /verification[:\s]*(\d{4,8})/i,       // "verification: 123456"
    /pin[:\s]*(\d{4,8})/i,                // "pin: 123456"
    /(\d{4,8})/                            // Any 4-8 digits
  ]
  
  let attemptCount = 0
  while (Date.now() - started < timeoutMs) {
    attemptCount++
    try {
      console.log(`🔍 Mail1s poll attempt ${attemptCount} for ${address}`)
      
      const url = `https://mail1s.net/api/v1/email/inbox?emailAddress=${encodeURIComponent(address)}&page=1&size=20`
      const res = await fetch(url, { 
        headers: { 'wrdo-api-key': apiKey }
      })
      
      if (res.ok) {
        const json = await res.json() as any
        const list = Array.isArray(json?.list) ? json.list : []
        console.log(`📧 Found ${list.length} emails in Mail1s inbox`)
        
        // Sort by date (newest first)
        list.sort((a, b) => new Date(b.date || b.createdAt || 0).getTime() - new Date(a.date || a.createdAt || 0).getTime())
        
        for (const item of list) {
          const src = String(item?.html || item?.text || '')
          console.log(`📄 Email subject: ${item?.subject || 'No subject'}, from: ${item?.from || 'Unknown'}`)
          
          // Try each pattern
          for (const pattern of patterns) {
            const m = src.match(pattern)
            if (m) {
              const code = (m[1] || m[0] || '').replace(/[<>]/g, '').trim()
              if (code && /^\d{4,8}$/.test(code)) {
                console.log(`✅ Found code with pattern: ${pattern.source} - Code: ${code}`)
                return code
              }
            }
          }
        }
      } else {
        console.log(`⚠️ Mail1s API error: ${res.status} ${res.statusText}`)
      }
      
      // Wait before next poll
      await sleep(3000) // Reduced from 5s to 3s for faster response
      
    } catch (error) {
      console.log(`⚠️ Mail1s poll error: ${error}`)
      await sleep(5000)
    }
  }
  
  throw new Error('Không tìm thấy mã xác nhận trong Mail1s inbox sau nhiều lần thử')
}

async function pollOutlookCode(email: string, password: string, accountId: string, timeoutMs = 60000) {
  const started = Date.now()
  const rx = /(\b|>)(?:\d{5,8})(<|\b)/
  while (Date.now() - started < timeoutMs) {
    const resp = await fetch('http://localhost:3000/api/outlook/emails', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ accountId, email, password, count: 10, keyword: 'Facebook' })
    })
    if (resp.ok) {
      const json = await resp.json() as any
      const items = Array.isArray(json?.emails) ? json.emails : Array.isArray(json?.data) ? json.data : []
      for (const it of items) {
        const src = String(it?.html || it?.text || it?.body || '')
        const m = src.match(rx)
        if (m) return (m[0] || '').replace(/[<>]/g, '')
      }
    }
    await sleep(5000)
  }
  throw new Error('Không tìm thấy mã xác nhận trong Outlook inbox')
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB()

    const token = request.cookies.get('token')?.value || request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json() as ChangeMailRequest
    const { accountId, method, mail1sAddress, autoConfirm = true, loginFirst = true, useProxy = true } = body
    if (!accountId || !method) {
      return NextResponse.json({ success: false, message: 'accountId và method là bắt buộc' }, { status: 400 })
    }

    const account: any = await (FacebookAccount as any).findById(accountId)
    if (!account) {
      return NextResponse.json({ success: false, message: 'Account not found' }, { status: 404 })
    }

    const userId = String(account.userId || '')
    const uid = String(account.uid || '')
    emitLog(userId, `✉️ Change Mail: Bắt đầu (${method})`, String(account._id))

    // Proxy preference from Settings
    let proxyConfig: ProxyConfig | null = null
    if (useProxy) {
      try {
        const settings = await (Settings as any).findOne({ userId }).lean()
        const keys: string[] = Array.isArray(settings?.proxyFBKeys) ? settings.proxyFBKeys : []
        const locationId: number = typeof settings?.proxyFBLocationId === 'number' ? settings.proxyFBLocationId : 1
        if (keys.length > 0) {
          proxyConfig = await getProxyFromProxyFB(keys, locationId, 8000, userId)
          if (!proxyConfig) {
            for (const k of keys) {
              const forced = await forceChangeProxyFB(k, locationId, 8000)
              if (forced) { proxyConfig = forced; break }
            }
          }
        }
      } catch {}
    }

         // 1) Ensure fresh tokens via cookie login
     let eaag = String(account.eaagToken || account.token || '')
     let eaab = String(account.eaabToken || '')
     let cookies = String(account.cookie || account.cookies || '')
     
     // Log current token status
     console.log(`🔑 Current tokens - EAAG: ${eaag ? 'Yes' : 'No'}, EAAB: ${eaab ? 'Yes' : 'No'}, Cookies: ${cookies ? 'Yes' : 'No'}`)

    if (loginFirst) {
      emitLog(userId, '🔐 Change Mail: Đang đăng nhập cookie để làm mới token...', String(account._id))
      try {
        const resp = await fetch('http://localhost:3000/api/facebook/login-cookie', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}`, 'x-internal-call': '1' },
          body: JSON.stringify({ accountId, useProxy: true })
        })
        const j = await resp.json()
        if (resp.ok && j?.success) {
          eaag = j.data?.eaag_token || eaag
          eaab = j.data?.eaab_token || eaab
          cookies = j.data?.cookies || cookies
        } else {
          emitLog(userId, `⚠️ Change Mail: Login cookie thất bại (${j?.message || 'Unknown'})`, String(account._id))
        }
      } catch {}
    }

    // Fallback self-derive tokens if missing
    if (!eaag && !eaab && cookies) {
      try {
        const [t1, t2] = await Promise.all([
          getEAAGToken(cookies, uid, proxyConfig || undefined),
          getEAABToken(cookies, uid, proxyConfig || undefined)
        ])
        eaag = t1 || eaag
        eaab = t2 || eaab
      } catch {}
    }

    const finalToken = eaag || eaab || String(account.accessToken || account.token || '')
    if (!finalToken) {
      emitLog(userId, '❌ Change Mail: Không có token hợp lệ (EAAG/EAAB)', String(account._id))
      return NextResponse.json({ success: false, message: 'Không có token hợp lệ' }, { status: 400 })
    }

    // 2) Prepare target email
    let targetEmail = ''
    let createdVia = ''
    if (method === 'mail1s') {
      emitLog(userId, '📧 Change Mail: Tạo email qua Mail1s...', String(account._id))
      const apiKey = MAIL1S_DEFAULT_API_KEY
      targetEmail = await createMail1sEmail(mail1sAddress, apiKey)
      createdVia = 'mail1s'
      emitLog(userId, `✅ Change Mail: Đã tạo ${targetEmail}`, String(account._id))
    } else {
      // outlook: dùng account.mail làm email nhận và account.passmail để đọc inbox
      targetEmail = String(account.mail || account.email || '')
      if (!targetEmail) {
        return NextResponse.json({ success: false, message: 'Thiếu email Outlook trong tài khoản (trường mail)' }, { status: 400 })
      }
      createdVia = 'outlook'
      emitLog(userId, `📧 Change Mail: Dùng Outlook ${targetEmail}`, String(account._id))
    }

    // 3) Send verification email
    emitLog(userId, '📨 Change Mail: Gửi mã xác minh...', String(account._id))
    const sendRes = await sendVerificationEmail(targetEmail, uid, finalToken, cookies, proxyConfig)
    if (!sendRes.success) {
      emitLog(userId, `❌ Change Mail: Gửi mã thất bại`, String(account._id))
      return NextResponse.json({ success: false, message: sendRes.message || 'Gửi mã thất bại' }, { status: 400 })
    }
    emitLog(userId, '✅ Change Mail: Đã gửi mã xác minh', String(account._id))

    let code = ''
    let confirmationSuccess = false
    if (autoConfirm) {
      // 4) Poll inbox to get code with retry
      emitLog(userId, '🔎 Change Mail: Đang đọc inbox lấy mã...', String(account._id))
      let retryCount = 0
      const maxRetries = 3
      
      while (retryCount < maxRetries && !confirmationSuccess) {
        try {
          if (createdVia === 'mail1s') {
            code = await pollMail1sCode(targetEmail, MAIL1S_DEFAULT_API_KEY, 60000) // Reduced timeout
          } else {
            const pass = String(account.passmail || '')
            if (!pass) throw new Error('Thiếu mật khẩu mail Outlook (passmail)')
            code = await pollOutlookCode(targetEmail, pass, String(account._id), 60000)
          }
          emitLog(userId, `✅ Change Mail: Đã lấy mã (lần ${retryCount + 1})`, String(account._id))
          
          // 5) Confirm email with code
          emitLog(userId, '🔏 Change Mail: Xác nhận email...', String(account._id))
          const conf = await confirmEmail(targetEmail, code, finalToken, cookies, proxyConfig)
          if (conf.success) {
            confirmationSuccess = true
            emitLog(userId, '🎉 Change Mail: Xác nhận thành công!', String(account._id))
            break
          } else {
            emitLog(userId, `⚠️ Change Mail: Xác nhận thất bại lần ${retryCount + 1}`, String(account._id))
            retryCount++
            if (retryCount < maxRetries) {
              emitLog(userId, `🔄 Change Mail: Thử lại lần ${retryCount + 1}...`, String(account._id))
              await sleep(10000) // Wait 10s before retry
            }
          }
        } catch (e: any) {
          emitLog(userId, `⚠️ Change Mail: Lỗi lần ${retryCount + 1} - ${e?.message || 'Unknown'}`, String(account._id))
          retryCount++
          if (retryCount < maxRetries) {
            emitLog(userId, `🔄 Change Mail: Thử lại lần ${retryCount + 1}...`, String(account._id))
            await sleep(10000)
          }
        }
      }
      
      if (!confirmationSuccess) {
        emitLog(userId, '❌ Change Mail: Không thể xác nhận sau nhiều lần thử', String(account._id))
        // Don't return error here; final response below will handle outcome
      }
    }

    // 6) Update DB and respond based on confirmation result
    if (autoConfirm && confirmationSuccess) {
      await (FacebookAccount as any).findByIdAndUpdate(accountId, {
        email: targetEmail,
        mail: targetEmail,
        lastUpdated: new Date(),
        log: 'Đổi mail thành công - đã xác nhận'
      })
      return NextResponse.json({
        success: true,
        message: 'Change mail thành công',
        data: { email: targetEmail, via: createdVia, confirmed: true }
      })
    }

    if (autoConfirm && !confirmationSuccess) {
      await (FacebookAccount as any).findByIdAndUpdate(accountId, {
        lastUpdated: new Date(),
        log: 'Change Mail: không thành công'
      })
      emitLog(userId, '❌ Change Mail: không thành công', String(account._id))
      return NextResponse.json({
        success: false,
        message: 'Change mail không thành công',
        data: { email: targetEmail, via: createdVia, confirmed: false }
      }, { status: 400 })
    }

    // autoConfirm === false
    await (FacebookAccount as any).findByIdAndUpdate(accountId, {
      lastUpdated: new Date(),
      log: 'Đã thêm mail mới - chưa xác nhận'
    })
    return NextResponse.json({
      success: true,
      message: 'Đã thêm mail mới',
      data: { email: targetEmail, via: createdVia, confirmed: false }
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: 'Internal server error' }, { status: 500 })
  }
}


