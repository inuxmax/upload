import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import FacebookAccount from '@/models/FacebookAccount'
import Settings from '@/models/Settings'

// Helper function to retry API calls (from check-tkqc)
async function retryApiCall(
  url: string, 
  options: RequestInit, 
  maxRetries: number = 2,
  delay: number = 1000
): Promise<Response> {
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(url, options);
      
      // If successful or client error (4xx), don't retry
      if (response.ok || (response.status >= 400 && response.status < 500)) {
        return response;
      }
      
      // For server errors (5xx), retry
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2; // Exponential backoff
        continue;
      }
      
      return response;
    } catch (error) {
      lastError = error as Error;
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2;
        continue;
      }
    }
  }
  
  throw lastError || new Error('Max retries exceeded');
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Get parameters (similar to check-tkqc)
    const { token, cookie, accountId, facebookToken, accessToken, updateToken, loginFirst = false, loginMethod = 'cookie' } = await request.json()
    
    console.log('=== Check Info Via Debug ===')
    console.log('Token present:', !!token)
    console.log('Cookie present:', !!cookie)
    console.log('AccountId:', accountId)
    console.log('FacebookToken present:', !!facebookToken)
    console.log('AccessToken present:', !!accessToken)
    console.log('UpdateToken present:', !!updateToken)

    // Optional login-first step to refresh session/tokens
    if (loginFirst && accountId) {
      try {
        // Load settings for ProxyFB keys
        		// Kiểm tra nếu accountId là local ID (không phải ObjectId hợp lệ)
		const isValidObjectId = /^[a-fA-F0-9]{24}$/.test(String(accountId))
		
		let accountDoc: any
		if (isValidObjectId) {
			// Tìm trong database nếu là ObjectId hợp lệ
			accountDoc = await (FacebookAccount as any).findById(accountId)
			if (!accountDoc) {
				return NextResponse.json({ error: 'Account not found in database' }, { status: 404 })
			}
		} else {
			// Nếu là local ID, trả về lỗi vì API này cần account trong database
			return NextResponse.json({ 
				error: 'Local accounts are not supported for this operation. Please use server-stored accounts.' 
			}, { status: 400 })
		}
        let proxyFBKeys: string[] | undefined
        let proxyFBLocationId: number | undefined
        try {
          const s = await (Settings as any).findOne({ userId: accountDoc?.userId }).lean()
          if (Array.isArray(s?.proxyFBKeys) && s.proxyFBKeys.length > 0) proxyFBKeys = s.proxyFBKeys
          if (typeof s?.proxyFBLocationId === 'number') proxyFBLocationId = s.proxyFBLocationId
        } catch {}
        const payload: any = { accountId, useProxy: true, ...(proxyFBKeys ? { proxyFBKeys } : {}), ...(typeof proxyFBLocationId === 'number' ? { proxyFBLocationId } : {}) }
        if (isValidObjectId) {
          if (loginMethod === 'password') {
            const authHeader = request.headers.get('authorization') || ''
            await fetch('http://localhost:3000/api/facebook/login', { method: 'POST', headers: { 'Content-Type': 'application/json', ...(authHeader ? { Authorization: authHeader } : {}) }, body: JSON.stringify({ accountId, useProxy: true }) })
          } else {
            await fetch('http://localhost:3000/api/facebook/login-cookie', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-internal-call': '1' }, body: JSON.stringify(payload) })
          }
        }
      } catch {}
    }

    // Fallback: nếu không có token từ frontend, lấy từ database
    let finalToken = token || facebookToken
    let dbAccessToken = null
    
    // Always try to get tokens from database if accountId provided
    if (accountId) {
      try {
        // Kiểm tra nếu accountId là local ID (không phải ObjectId hợp lệ)
        const isValidObjectId = /^[a-fA-F0-9]{24}$/.test(String(accountId))
        
        let account: any
        if (isValidObjectId) {
          // Tìm trong database nếu là ObjectId hợp lệ
          account = await (FacebookAccount as any).findById(accountId)
          if (!account) {
            console.log('❌ Account not found in database')
            return
          }
        } else {
          // Nếu là local ID, bỏ qua phần này
          console.log('⚠️ Local account ID detected, skipping database lookup')
          return
        }
        
        // Get token if not available from frontend
        if (!finalToken && account && account.token) {
          finalToken = account.token
          console.log('✅ Found token in database')
        }
        
        // Debug: Show all token fields in account
        if (account) {
          console.log('🔍 DEBUG: All token fields in account:')
          console.log('  - token:', account.token ? account.token.substring(0, 20) + '...' : 'null')
          console.log('  - accessToken:', account.accessToken ? account.accessToken.substring(0, 20) + '...' : 'null')
          console.log('  - eaabToken:', account.eaabToken ? account.eaabToken.substring(0, 20) + '...' : 'null')
          console.log('  - eaagToken:', account.eaagToken ? account.eaagToken.substring(0, 20) + '...' : 'null')
        }

        // Always get accessToken from database (priority: eaabToken > eaagToken > accessToken)
        if (account && account.eaabToken) {
          dbAccessToken = account.eaabToken
          console.log('✅ Found eaabToken in database')
          console.log('📊 eaabToken length:', account.eaabToken.length)
          console.log('📊 eaabToken prefix:', account.eaabToken.substring(0, 20) + '...')
          console.log('📊 eaabToken suffix:', '...' + account.eaabToken.substring(account.eaabToken.length - 20))
        } else if (account && account.eaagToken) {
          dbAccessToken = account.eaagToken
          console.log('✅ Found eaagToken in database')
        } else if (account && account.accessToken) {
          dbAccessToken = account.accessToken
          console.log('✅ Found accessToken in database')
          console.log('📊 accessToken length:', account.accessToken.length)
          console.log('📊 accessToken prefix:', account.accessToken.substring(0, 20) + '...')
          console.log('📊 accessToken suffix:', '...' + account.accessToken.substring(account.accessToken.length - 20))
        } else {
          console.log('❌ No eaabToken or accessToken found in database')
          if (account) {
            console.log('📊 Available fields in account:', Object.keys(account.toObject()))
          }
        }
        
        // Update token if updateToken is provided
        if (updateToken && account) {
          console.log('🔄 Updating eaabToken in database...')
          console.log('📊 Old token length:', account.eaabToken?.length || 0)
          console.log('📊 New token length:', updateToken.length)
          
          await (FacebookAccount as any).findByIdAndUpdate(accountId, {
            eaabToken: updateToken
          })
          
          dbAccessToken = updateToken
          console.log('✅ Token updated successfully!')
        }
        
        // DETECT EXPIRED TOKEN: Check if token is too short (truncated)
        if (dbAccessToken && dbAccessToken.length < 100) {
          console.log('⚠️ WARNING: Token appears to be truncated!')
          console.log('💡 Current token length:', dbAccessToken.length, '(should be ~200+ chars)')
          console.log('💡 Please login again to get a fresh token')
          
          // Mark token as invalid so it won't be used
          dbAccessToken = null
        }
      } catch (dbError) {
        console.log('❌ Database lookup failed:', dbError)
      }
    }

    if (!finalToken) {
      console.log('❌ No token available from any source')
      return NextResponse.json({ 
        success: false,
        error: 'EAAG token is required. Please login first to get a valid token.' 
      }, { status: 400 })
    }
    
    console.log('✅ Using token for validation:', finalToken.substring(0, 20) + '...')
    console.log('🔍 Token type:', finalToken.startsWith('EAAB') ? 'EAAB (Ads Manager)' : finalToken.startsWith('EAAG') ? 'EAAG (Business)' : 'Other')

    // Validate EAAG token first (similar to check-tkqc)
    let tokenValidationResponse;
    
    try {
      console.log('🔍 Validating EAAG token...')
      tokenValidationResponse = await retryApiCall(
        `https://graph.facebook.com/v18.0/me?access_token=${finalToken}&fields=id,name`,
        {
          method: 'GET',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Cookie': cookie || ''
          },
          signal: AbortSignal.timeout(15000)
        }
      );
      
      console.log('📡 Token validation response status:', tokenValidationResponse.status)
      
      if (!tokenValidationResponse.ok) {
        const errorText = await tokenValidationResponse.text()
        console.log('❌ Token validation failed:', errorText)
        return NextResponse.json({ 
          success: false, 
          message: `EAAG token không hợp lệ: ${errorText}`,
          needsLogin: true
        }, { status: 400 })
      }
    } catch (error) {
      console.log('💥 Token validation error:', error)
      return NextResponse.json({ 
        success: false, 
        message: `Không thể xác thực EAAG token: ${error instanceof Error ? error.message : 'Unknown error'}`,
        needsLogin: true
      }, { status: 400 })
    }

    const validationData = await tokenValidationResponse.json()
    const currentUserId = validationData.id
    
    // Lấy UID đầu tiên từ chuỗi UID phức tạp (100051380686515|2406214018yucxj|YF4WY73RA2LOOVPUAK22C63WZLU4BOFM)
    const extractFirstUID = (uidString: string) => {
      if (!uidString) return null
      // Tách theo dấu | và lấy phần đầu tiên
      const parts = uidString.split('|')
      return parts[0] || null
    }

    // Sử dụng currentUserId từ token validation làm UID chính
    const userUID = extractFirstUID(currentUserId) || currentUserId
    console.log('Current User ID from token:', currentUserId)
    console.log('Extracted UID for friends API:', userUID)
    console.log('EAAG Token:', finalToken ? 'Present' : 'Missing')

    // Get user info from Graph API với EAAG token và retry logic
    const userInfoUrl = `https://graph.facebook.com/me?fields=name,first_name,last_name,gender,email,picture.width(200).height(200),link,birthday&access_token=${finalToken}`
    
    let userInfo = null
  

    try {
      const userResponse = await retryApiCall(
        userInfoUrl,
        {
          method: 'GET',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Cookie': cookie || ''
          },
          signal: AbortSignal.timeout(15000)
        }
      )
      
      if (!userResponse.ok) {
        const errorText = await userResponse.text()
        return NextResponse.json({ 
          success: false, 
          message: `Graph API Error: ${errorText}` 
        }, { status: 400 })
      }
      
      userInfo = await userResponse.json()
      
      if (userInfo.error) {
        return NextResponse.json({ 
          success: false, 
          message: `Graph API Error: ${userInfo.error.message}` 
        }, { status: 400 })
      }
    } catch (error) {
      console.error('Error fetching user info:', error)
      return NextResponse.json({ 
        success: false, 
        message: 'Failed to fetch user info from Graph API' 
      }, { status: 500 })
    }

    // Try Graph API with accessToken (from frontend or database)
    const finalAccessToken = accessToken || dbAccessToken
    if (finalAccessToken) {
      try {
        console.log('🔍 Trying Graph API with accessToken...')
        const tokenSource = accessToken ? 'Frontend' : 'Database'
        const tokenType = finalAccessToken.startsWith('EAAB') ? 'EAAB Token' : finalAccessToken.startsWith('EAAG') ? 'EAAG Token' : 'AccessToken'
        console.log('AccessToken source:', tokenSource)
        console.log('Token type:', tokenType)
        console.log('Token length:', finalAccessToken.length)
        console.log('Token prefix:', finalAccessToken.substring(0, 20) + '...')
        console.log('Token suffix:', '...' + finalAccessToken.substring(finalAccessToken.length - 20))
        
        // First, test if token is valid with a simple API call
        console.log('🧪 Testing token validity with basic /me call...')
        try {
          const testResponse = await fetch(`https://graph.facebook.com/me?access_token=${encodeURIComponent(finalAccessToken)}`)
          console.log('🔍 Token validation response status:', testResponse.status)
          
          if (testResponse.ok) {
            const testData = await testResponse.json()
            console.log('✅ Token is valid. User ID:', testData.id, 'Name:', testData.name)
          } else {
            const testError = await testResponse.text()
            console.log('❌ Token validation failed:', testError)
            console.log('🔄 This might explain why friends API is failing')
            
            // If database token is invalid/expired
            if (testError.includes('Invalid request') && !accessToken) {
              console.log('💡 Database token appears to be expired')
              console.log('💡 Facebook tokens expire regularly and need to be refreshed')
              console.log('💡 Solution: Please login again to get a fresh token')
              console.log('🔄 Continuing to try quality check anyway...')
            }
          }
        } catch (validationError) {
          console.log('❌ Token validation error:', validationError)
        }

      } catch (error) {
        console.error('Error with Graph API token validation:', error)
      }
    }

    // Update account in database if accountId provided
    if (accountId) {
      try {
        const updateData: any = {
          lastUpdated: new Date().toISOString(),
          status: 'active',
          log: 'Check info via thành công'
        }

        if (userInfo.name) updateData.name = userInfo.name
        if (userInfo.gender) updateData.gender = userInfo.gender
        if (userInfo.birthday) updateData.birthday = userInfo.birthday
  
        
        // Lưu EAAG token mới
        if (finalToken) {
          updateData.token = finalToken
        }

        await (FacebookAccount as any).findByIdAndUpdate(
          accountId,
          { $set: updateData },
          { new: true }
        )
      } catch (dbError) {
        console.error('Database update error:', dbError)
        // Continue without failing the response
      }
    }

    return NextResponse.json({
      success: true,
      message: 'Check info via completed successfully',
      data: {
        name: userInfo.name,
        gender: userInfo.gender,
        birthday: userInfo.birthday,
        email: userInfo.email,
        picture: userInfo.picture?.data?.url
      }
    })

  } catch (error) {
    console.error('Error in check-info-via API:', error)
    return NextResponse.json({ 
      success: false, 
      message: 'Internal server error' 
    }, { status: 500 })
  }
}

// Add GET method for testing
export async function GET() {
  return NextResponse.json({ 
    message: 'Check Info Via API is working',
    timestamp: new Date().toISOString()
  })
}