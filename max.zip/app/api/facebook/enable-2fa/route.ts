import { NextRequest, NextResponse } from 'next/server'
import mongoose from 'mongoose'
import { emitLog } from '@/lib/log-bus'
import Settings from '@/models/Settings'
import FacebookAccount from '@/models/FacebookAccount'
import crypto from 'crypto'

interface Enable2FARequest {
  facebookAccountId: string
}

interface Enable2FAResponse {
  success: boolean
  message: string
  data?: {
    twoFASecret: string
  }
}

// TOTP generation function
function generateTOTP(secret: string): string {
  try {
    // Remove spaces and convert to base32
    const cleanSecret = secret.replace(/\s/g, '')
    
    // Convert base32 to bytes
    const base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'
    let bits = 0
    let value = 0
    const bytes: number[] = []
    
    for (let i = 0; i < cleanSecret.length; i++) {
      const char = cleanSecret[i].toUpperCase()
      const index = base32Chars.indexOf(char)
      if (index === -1) continue
      
      value = (value << 5) | index
      bits += 5
      
      if (bits >= 8) {
        bytes.push((value >>> (bits - 8)) & 0xFF)
        bits -= 8
      }
    }
    
    // Generate TOTP using HMAC-SHA1
    const time = Math.floor(Date.now() / 30000) // 30 second window
    const timeBuffer = Buffer.alloc(8)
    timeBuffer.writeBigUInt64BE(BigInt(time), 0)
    
    const hmac = crypto.createHmac('sha1', Buffer.from(bytes))
    hmac.update(timeBuffer)
    const hash = hmac.digest()
    
    // Generate 6-digit code
    const offset = hash[hash.length - 1] & 0x0F
    const code = ((hash[offset] & 0x7F) << 24) |
                 ((hash[offset + 1] & 0xFF) << 16) |
                 ((hash[offset + 2] & 0xFF) << 8) |
                 (hash[offset + 3] & 0xFF)
    
    return (code % 1000000).toString().padStart(6, '0')
  } catch (error) {
    console.error('TOTP generation error:', error)
    return ''
  }
}

// Try to extract fb_dtsg token from various HTML patterns
function extractFbDtsgFromHtml(html: string): string | null {
  const m1 = html.match(/\"DTSGInitialData\"\,\[\],\{\"token\":\"([^\"]+)\"/)
  if (m1 && m1[1]) return m1[1]
  const m2 = html.match(/\"token\":\"([^\"]+)\"/)
  if (m2 && m2[1]) return m2[1]
  const m3 = html.match(/name=\"fb_dtsg\"\s+value=\"([^\"]+)\"/)
  if (m3 && m3[1]) return m3[1]
  return null
}

// Try to extract lsd token from HTML
function extractLsdFromHtml(html: string): string | null {
  const m1 = html.match(/\"LSD\"\,\[\],\{\"token\":\"([^\"]+)\"/)
  if (m1 && m1[1]) return m1[1]
  const m2 = html.match(/\"lsd\"\s*:\s*\{\s*\"token\"\s*:\s*\"([^\"]+)\"/)
  if (m2 && m2[1]) return m2[1]
  return null
}

async function fetchWithCookies(url: string, cookieHeader: string, referer: string) {
  const headers: any = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'Cookie': cookieHeader,
    'Referer': referer
  }
  const res = await fetch(url, { headers })
  const text = await res.text()
  const fbDtsg = extractFbDtsgFromHtml(text) || undefined
  const lsd = extractLsdFromHtml(text) || undefined
  return { ok: res.ok, status: res.status, text, fbDtsg, lsd }
}

// Enable 2FA function
async function enableTwoFA(account: any): Promise<{ success: boolean; twoFASecret?: string; message: string }> {
  try {
    console.log(`🔄 Enabling 2FA for account: ${account.uid}`)
    
    const url = 'https://accountscenter.facebook.com/api/graphql/'
    
    // Setup headers
    const headers: any = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36',
      'Accept': 'text/html',
      'Upgrade-Insecure-Requests': '1',
      'Referer': 'https://accountscenter.facebook.com'
    }
    
    // Setup cookies
    if (account.cookie) {
      headers['Cookie'] = account.cookie
    }
    
    // Pre-step: Validate session via cookie ("login bằng cookie")
    try {
      console.log('🔐 Validating cookie session...')
      emitLog(String(account.userId || ''), '🔐 Enable2FA: Validating cookie session...', String(account._id))

      const sessionCheckUrls = [
        'https://m.facebook.com/home.php',
        'https://www.facebook.com/',
        'https://accountscenter.facebook.com/password_and_security/two_factor'
      ]

      let sessionValid = false
      for (const u of sessionCheckUrls) {
        try {
          const resp = await fetch(u, {
            headers: {
              'User-Agent': headers['User-Agent'],
              'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
              'Accept-Language': 'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',
              'Cache-Control': 'no-cache',
              'Pragma': 'no-cache',
              'Cookie': headers['Cookie'],
              'Referer': u.includes('accountscenter') ? 'https://accountscenter.facebook.com' : 'https://www.facebook.com/'
            }
          })
          const text = await resp.text()
          // Some FB frontends return 400/403 but still deliver HTML with session markers
          const hasMarkers = /DTSGInitialData|fb_dtsg|LSD|c_user=/.test(text)
          emitLog(String(account.userId || ''), `🔎 Cookie probe ${u} status ${resp.status} markers=${hasMarkers}`, String(account._id))
          if (hasMarkers) {
            sessionValid = true
            break
          }
        } catch {}
      }

      if (!sessionValid) {
        const rawCookie = String(headers['Cookie'] || '')
        if (/c_user=\d+/.test(rawCookie) && /\bxs=/.test(rawCookie)) {
          emitLog(String(account.userId || ''), 'ℹ️ Enable2FA: Cookie lacks HTML markers but has c_user+xs; proceeding', String(account._id))
          sessionValid = true
        }
      }

      if (!sessionValid) {
        console.log('❌ Cookie session validation failed (no markers found)')
        emitLog(String(account.userId || ''), '❌ Enable2FA: Cookie session invalid (no markers)', String(account._id))
        return { success: false, message: 'Cookie session invalid. Please update cookies.' }
      }

      console.log('✅ Cookie session valid')
      emitLog(String(account.userId || ''), '✅ Enable2FA: Cookie session valid', String(account._id))
    } catch (e) {
      console.log('❌ Cookie session validation error:', (e as any)?.message || e)
      emitLog(String(account.userId || ''), '❌ Enable2FA: Cookie validation error', String(account._id))
      return { success: false, message: 'Cookie validation error' }
    }
    
    // Step 1: Get the 2FA page to extract fb_dtsg/lsd tokens (try multiple pages)
    console.log('📄 Step 1: Getting 2FA page and tokens...')
    emitLog(String(account.userId || ''), '📄 Enable2FA: Getting tokens...', String(account._id))
    const cookieHeader = headers['Cookie']
    const candidates = [
      { url: 'https://accountscenter.facebook.com/password_and_security/two_factor', ref: 'https://accountscenter.facebook.com' },
      { url: 'https://www.facebook.com/password_and_security', ref: 'https://www.facebook.com/' },
      { url: 'https://www.facebook.com/security/2fac/settings/', ref: 'https://www.facebook.com/' },
      { url: 'https://www.facebook.com/security/2fac/setup/totp/', ref: 'https://www.facebook.com/' },
      { url: 'https://m.facebook.com/security/2fac/setup/totp/', ref: 'https://m.facebook.com/' }
    ] as const

    let fbDtsg: string | undefined
    let lsdToken: string | undefined
    let opened = false
    let lastHtml: string | null = null
    for (const c of candidates) {
      try {
        const r = await fetchWithCookies(c.url, cookieHeader, c.ref)
        console.log(`🔍 Token page ${c.url} status: ${r.status}`)
        emitLog(String(account.userId || ''), `🔍 Token page ${c.url} status: ${r.status}`, String(account._id))
        if (r.text && r.text.length > 0) {
          opened = true
          lastHtml = r.text
        }
        if (!fbDtsg && r.fbDtsg) fbDtsg = r.fbDtsg
        if (!lsdToken && r.lsd) lsdToken = r.lsd
        if (fbDtsg) break
      } catch (e) {
        // ignore
      }
    }

    if (!opened) {
      emitLog(String(account.userId || ''), '❌ Enable2FA: Failed to open token pages', String(account._id))
      throw new Error('Failed to open token pages')
    }

    // Ensure we are on the right account context (like the C# check: response contains UID)
    if (lastHtml && !String(lastHtml).includes(String(account.uid))) {
      console.log('⚠️ Token page HTML does not include UID; proceeding but may fail later')
      emitLog(String(account.userId || ''), '⚠️ Enable2FA: Token page lacks UID marker', String(account._id))
    }

    if (!fbDtsg) {
      emitLog(String(account.userId || ''), '❌ Enable2FA: Could not extract fb_dtsg token', String(account._id))
      throw new Error('Could not extract fb_dtsg token')
    }

    console.log('✅ Extracted fb_dtsg token')
    if (lsdToken) console.log('✅ Extracted lsd token')
    emitLog(String(account.userId || ''), `✅ Tokens: dtsg=${!!fbDtsg}, lsd=${!!lsdToken}`, String(account._id))
    
    // Step 2: Try to enable 2FA (up to 8 attempts)
    for (let count = 0; count < 8; count++) {
      console.log(`🔄 Attempt ${count + 1}/8: Enabling 2FA...`)
      
      // Step 2a: Get 2FA method selection
      const methodData = new URLSearchParams({
        'av': account.uid,
        '__user': account.uid,
        '__a': '1',
        '__req': 'h',
        '__hs': '19979.HYP:accounts_center_pkg.2.1..0.0',
        'dpr': '1',
        '__ccg': 'GOOD',
        '__rev': '1016466820',
        '__s': '3jxio0:lsyvzo:1majbn',
        '__hsi': '7414029279091283622',
        '__dyn': '7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0om0MU2awpUO0n24o5-0Bo7O2l0Fwqo31w9O1lwlE-U2zxe2GewbS361qw8Xwn82Lx-0lK3qazo7u0zE2ZwrUdUcobU3Cwr86C1nwro2PxW1owmU',
        '__csr': 'gon8HlFFjYBSJsgJt4FpFiqJlRRly7l9RN1njGiJbhvlVbpm8AWKiVvryojiCip29CG8gNBJ4BAFenLWAgSamDUFelF4xHhdQLXHAG26moyu6bAHzEkz42Gm9Cglx13UHgiz8-cXx6XUy9G2y5OdAh6Xprw04ROwKxfKeZ0soCFZ1i0CAFq_iBKuEDHZai0jm1Bg0xKhCg08ZosAw87jh8owiE760fgwg84GS2dADgad3Qm9w59IAWx11fafg9QQ0C40luhi55ojU178O68yFEy23c5zkah44YUrxCEKUS7o24GEgG1fyWG04qC3fw',
        '__comet_req': '5',
        'fb_dtsg': fbDtsg,
        'jazoest': '25321',
        'lsd': lsdToken || 'hykYIjP60BiGaacl54r98X',
        '__spin_r': '1016466820',
        '__spin_b': 'trunk',
        '__spin_t': Math.floor(Date.now() / 1000).toString(),
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'FXAccountsCenterTwoFactorSelectMethodDialogQuery',
        'variables': JSON.stringify({
          account_id: account.uid,
          account_type: 'FACEBOOK',
          interface: 'FB_WEB'
        }),
        'server_timestamps': 'true',
        'doc_id': '7291183827635193'
      })
      
      // Retry up to 2 times like the C# code
      let methodHtml = ''
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const methodResponse = await fetch(url, {
            method: 'POST',
            headers: {
              ...headers,
              'Content-Type': 'application/x-www-form-urlencoded',
              'Accept': '*/*',
              ...(lsdToken ? { 'X-FB-LSD': lsdToken } : {}),
              'X-FB-Friendly-Name': 'FXAccountsCenterTwoFactorSelectMethodDialogQuery',
              'X-FB-Request-Analytics-Tags': 'graphservice',
              'Origin': 'https://accountscenter.facebook.com',
              'Referer': 'https://accountscenter.facebook.com/password_and_security/two_factor',
              'X-ASBD-ID': '129477',
              'Sec-Fetch-Site': 'same-origin',
              'Sec-Fetch-Mode': 'cors',
              'Sec-Fetch-Dest': 'empty'
            },
            body: methodData
          })
          if (!methodResponse.ok) {
            console.log(`❌ Method selection failed: ${methodResponse.status}`)
            continue
          }
          methodHtml = await methodResponse.text()
          break
        } catch {}
      }
      if (!methodHtml) {
        console.log('❌ Method selection: empty response after retries')
        continue
      }
      const cleanHtml = methodHtml.replace(/\\/g, '').replace(/\/\//g, '')
      
      // Check if password challenge is required
      if (cleanHtml.includes('challenge_type":"password')) {
        console.log('🔐 Password challenge required, authenticating...')
        emitLog(String(account.userId || ''), '🔐 Enable2FA: Password challenge...', String(account._id))
        
        // Step 2b: Handle password challenge
        const passwordData = new URLSearchParams({
          'av': account.uid,
          '__user': account.uid,
          '__a': '1',
          '__req': 't',
          '__hs': '19979.HYP:accounts_center_pkg.2.1..0.0',
          'dpr': '1',
          '__ccg': 'GOOD',
          '__rev': '1016466820',
          '__s': '3jxio0:lsyvzo:1majbn',
          '__hsi': '7414029279091283622',
          '__dyn': '7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0om0MU2awpUO0n24o5-0Bo7O2l0Fwqo31w9O1lwlE-U2zxe2GewbS361qw8Xwn82Lx-0lK3qazo7u0zE2ZwrUdUcobU3Cwr86C1nwro2PxW1owmU',
          '__csr': 'gon8HlFFjYBTlsgJt4lpAgCGtttlpJRkBsglQWHHi8nRuiSkzajGVbBZK9_zkFACgypeEx4DpriVkWjBX-F4dyBF-ajBqh8qQjtb-RVawxBBaDxyVaUW58N0GBypA5ogg-aQ4EOfzeUhK-8yqwExszp4hKSmU01dsEbEjXy9vg769Gvgkw9FamLQFrDG9W_iAw4Rwpk08rApA7E08REsAw87jh8KcwiE760fgwg84GS2dADgad3Qm9w59IAWx11fafg9QQ0C40luhi55ojU178O68yFEy23c5zkah44YUrxCEKUS7o24GEgG1fyWG04qC3fw',
          '__comet_req': '5',
          'fb_dtsg': fbDtsg,
          'jazoest': '25321',
          'lsd': lsdToken || 'hykYIjP60BiGaacl54r98X',
          '__spin_r': '1016466820',
          '__spin_b': 'trunk',
          '__spin_t': Math.floor(Date.now() / 1000).toString(),
          'fb_api_caller_class': 'RelayModern',
          'fb_api_req_friendly_name': 'FXPasswordReauthenticationMutation',
          'variables': JSON.stringify({
            input: {
              account_id: account.uid,
              account_type: 'FACEBOOK',
              password: {
                sensitive_string_value: `#PWD_BROWSER:0:${Math.floor(Date.now() / 1000)}:${account.pass}`
              },
              actor_id: account.uid,
              client_mutation_id: '1'
            }
          }),
          'server_timestamps': 'true',
          'doc_id': '5864546173675027'
        })
        
        const passwordResponse = await fetch(url, {
          method: 'POST',
          headers: {
            ...headers,
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: passwordData
        })
        
        if (!passwordResponse.ok) {
          console.log(`❌ Password authentication failed: ${passwordResponse.status}`)
          continue
        }
        
        console.log('✅ Password authentication successful')
        emitLog(String(account.userId || ''), '✅ Enable2FA: Password OK, retrying...', String(account._id))
        continue // Try again after password auth
      }
      
      // Step 2c: Generate TOTP key
      console.log('🔑 Generating TOTP key...')
      emitLog(String(account.userId || ''), '🔑 Enable2FA: Generating TOTP key...', String(account._id))
      const totpKeyData = new URLSearchParams({
        'av': account.uid,
        '__user': account.uid,
        '__a': '1',
        '__req': 'y',
        '__hs': '19979.HYP:accounts_center_pkg.2.1..0.0',
        'dpr': '1',
        '__ccg': 'GOOD',
        '__rev': '1016466820',
        '__s': '3jxio0:lsyvzo:1majbn',
        '__hsi': '7414029279091283622',
        '__dyn': '7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0om0MU2awpUO0n24o5-0Bo7O2l0Fwqo31w9O1lwlE-U2zxe2GewbS361qw8Xwn82Lx-0lK3qazo7u0zE2ZwrUdUcobU3Cwr86C1nwro2PxW1owmU',
        '__csr': 'gon8HlFFjYBTlsgJt4lpAgCGtttlpJRkBsglQWHHi8nRuiSkzajGVbBZK9_zkFACgypeEx4DpriVkWjBX-F4dyBF-ajBqh8qQjtb-RVawxBBaDxyVaUW58N0GBypA5ogg-aQ4EOfzeUhK-8yqwExszp4hKSmU01dsEbEjXy9vg769Gvgkw9FamLQFrDG9W_iAw4Rwpk08rApA7E08REsAw87jh8KcwiE760fgwg84GS2dADgad3Qm9w59IAWx11fafg9QQ0C40luhi55ojU178O68yFEy23c5zkah44YUrxCEKUS7o24GEgG1fyWG04qC3fw',
        '__comet_req': '5',
        'fb_dtsg': fbDtsg,
        'jazoest': '25321',
        'lsd': lsdToken || 'hykYIjP60BiGaacl54r98X',
        '__spin_r': '1016466820',
        '__spin_b': 'trunk',
        '__spin_t': Math.floor(Date.now() / 1000).toString(),
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'useFXSettingsTwoFactorGenerateTOTPKeyMutation',
        'variables': JSON.stringify({
          input: {
            client_mutation_id: crypto.randomUUID(),
            actor_id: account.uid,
            account_id: account.uid,
            account_type: 'FACEBOOK',
            device_id: 'device_id_fetch_datr',
            fdid: 'device_id_fetch_datr'
          }
        }),
        'server_timestamps': 'true',
        'doc_id': '6282672078501565'
      })
      
      const totpKeyResponse = await fetch(url, {
        method: 'POST',
        headers: {
          ...headers,
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': '*/*',
          ...(lsdToken ? { 'X-FB-LSD': lsdToken } : {}),
          'X-FB-Friendly-Name': 'useFXSettingsTwoFactorGenerateTOTPKeyMutation',
          'X-FB-Request-Analytics-Tags': 'graphservice',
          'Origin': 'https://accountscenter.facebook.com',
          'Referer': 'https://accountscenter.facebook.com/password_and_security/two_factor',
          'X-ASBD-ID': '129477',
          'Sec-Fetch-Site': 'same-origin',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Dest': 'empty'
        },
        body: totpKeyData
      })
      
      if (!totpKeyResponse.ok) {
        console.log(`❌ TOTP key generation failed: ${totpKeyResponse.status}`)
        continue
      }
      
      const totpKeyHtml = await totpKeyResponse.text()
      const cleanTotpHtml = totpKeyHtml.replace(/^for \(;;\);/, '').replace(/\\/g, '').replace(/\/\//g, '')
      
      // Extract TOTP secret key (JSON first, regex fallback)
      let twoFASecret = ''
      let parsedJson: any = null
      try {
        parsedJson = JSON.parse(cleanTotpHtml)
        const keyFromJson = parsedJson?.data?.xfb_two_factor_generate_totp_key?.totp_key?.key_text
        if (typeof keyFromJson === 'string' && keyFromJson.length > 0) {
          twoFASecret = keyFromJson.replace(/\s/g, '')
        }
      } catch {}
      // Log GraphQL errors if present
      if (!twoFASecret && parsedJson?.errors?.length) {
        const firstErr = parsedJson.errors[0]
        const errMsg = typeof firstErr?.message === 'string' ? firstErr.message : JSON.stringify(firstErr)
        emitLog(String(account.userId || ''), `❌ Enable2FA: TOTP key GraphQL error: ${errMsg}`, String(account._id))
      }
      if (!twoFASecret) {
        const totpKeyMatch = cleanTotpHtml.match(/\"key_text\"\s*:\s*\"([^\"]+)\"/) || cleanTotpHtml.match(/\"keyText\"\s*:\s*\"([^\"]+)\"/)
        if (totpKeyMatch) {
          twoFASecret = totpKeyMatch[1].replace(/\s/g, '')
        }
      }
      // Detect if 2FA is already enabled from response hints
      if (!twoFASecret) {
        const snippet = cleanTotpHtml.slice(0, 400)
        emitLog(String(account.userId || ''), `🧩 Enable2FA: TOTP raw snippet: ${snippet}`, String(account._id))
        const alreadyEnabled = /already\s*enabled|already_enabled|two[\s_-]*factor[\s_-]*enabled/i.test(cleanTotpHtml)
          || parsedJson?.data?.xfb_two_factor_generate_totp_key?.already_enabled === true
        if (alreadyEnabled) {
          try {
            await (FacebookAccount as any).findByIdAndUpdate(account._id, { $set: { has2FA: true, updatedAt: new Date() } })
          } catch {}
          emitLog(String(account.userId || ''), 'ℹ️ Enable2FA: 2FA appears to be already enabled. Marking has2FA=true', String(account._id))
          return { success: true, message: '2FA already enabled' }
        }
      }
      if (!twoFASecret) {
        console.log('❌ Could not extract TOTP key')
        emitLog(String(account.userId || ''), '❌ Enable2FA: Cannot extract TOTP key', String(account._id))
        continue
      }
      // Save 2FA secret immediately
      try {
        await (FacebookAccount as any).findByIdAndUpdate(account._id, {
          $set: { twoFASecret: twoFASecret, updatedAt: new Date() }
        })
        emitLog(String(account.userId || ''), `💾 Enable2FA: Saved 2FA secret to DB (${twoFASecret.slice(0,4)}****)`, String(account._id))
      } catch {}
      
      console.log('✅ TOTP key generated successfully')
      emitLog(String(account.userId || ''), '✅ Enable2FA: TOTP key generated', String(account._id))
      
      // Step 2d: Get confirmation dialog
      console.log('📋 Getting confirmation dialog...')
      emitLog(String(account.userId || ''), '📋 Enable2FA: Getting confirm dialog...', String(account._id))
      const confirmData = new URLSearchParams({
        'av': account.uid,
        '__user': account.uid,
        '__a': '1',
        '__req': 'z',
        '__hs': '19979.HYP:accounts_center_pkg.2.1..0.0',
        'dpr': '1',
        '__ccg': 'GOOD',
        '__rev': '1016466820',
        '__s': '3jxio0:lsyvzo:1majbn',
        '__hsi': '7414029279091283622',
        '__dyn': '7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0om0MU2awpUO0n24o5-0Bo7O2l0Fwqo31w9O1lwlE-U2zxe2GewbS361qw8Xwn82Lx-0lK3qazo7u0zE2ZwrUdUcobU3Cwr86C1nwro2PxW1owmU',
        '__csr': 'gon8HlFFjYBTlsgJt4lpAgCGtttlpJRkAAglQWHHi8nRuiSkzajGVbBtK9_zkFACgypeEx4DpriVkWjBX-F4dyBF-ajBqh8qQjtb-RVawxBBaDxyVaUW58N0GBypA5ogg-aQ4EOfzeUhK-8yqwExszp4hKSmU01dsEbEjXy9vg769Gvgkw9FamLQFrDG9W_iAw4Rwpk08rApA7E08REsAw87jh8KcwiE760fgwg84GS2dADgad3Qm9w59IAWx11fafg9QQ0C40luhi55ojU178O68yFEy23c5zkah44YUrxCEKUS7o24GEgG1fyWG04qC3fw',
        '__comet_req': '5',
        'fb_dtsg': fbDtsg,
        'jazoest': '25321',
        'lsd': lsdToken || 'hykYIjP60BiGaacl54r98X',
        '__spin_r': '1016466820',
        '__spin_b': 'trunk',
        '__spin_t': Math.floor(Date.now() / 1000).toString(),
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'FXAccountsCenterTwoFactorConfirmCodeDialogQuery',
        'variables': JSON.stringify({
          interface: 'FB_WEB'
        }),
        'server_timestamps': 'true',
        'doc_id': '6792696137448786'
      })
      
      await new Promise(resolve => setTimeout(resolve, 1000)) // Wait 1 second
      
      const confirmResponse = await fetch(url, {
        method: 'POST',
        headers: {
          ...headers,
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': '*/*',
          ...(lsdToken ? { 'X-FB-LSD': lsdToken } : {}),
          'X-FB-Friendly-Name': 'FXAccountsCenterTwoFactorConfirmCodeDialogQuery',
          'X-FB-Request-Analytics-Tags': 'graphservice',
          'Origin': 'https://accountscenter.facebook.com',
          'Referer': 'https://accountscenter.facebook.com/password_and_security/two_factor',
          'X-ASBD-ID': '129477',
          'Sec-Fetch-Site': 'same-origin',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Dest': 'empty'
        },
        body: confirmData
      })
      
      if (!confirmResponse.ok) {
        console.log(`❌ Confirmation dialog failed: ${confirmResponse.status}`)
        continue
      }
      
      // Step 2e: Generate TOTP code and enable 2FA
      console.log('🔢 Generating TOTP code...')
      emitLog(String(account.userId || ''), '🔢 Enable2FA: Generating TOTP code...', String(account._id))
      let otp = generateTOTP(twoFASecret)
      let attempts = 0
      
      while ((!otp || otp.length !== 6) && attempts < 10) {
        otp = generateTOTP(twoFASecret)
        attempts++
        await new Promise(resolve => setTimeout(resolve, 100))
      }
      
      if (!otp || otp.length !== 6) {
        console.log('❌ Failed to generate valid TOTP code')
        continue
      }
      
      console.log(`✅ Generated TOTP code: ${otp}`)
      
      // Step 2f: Enable 2FA with TOTP code
      console.log('🔐 Enabling 2FA with TOTP code...')
      emitLog(String(account.userId || ''), '🔐 Enable2FA: Enabling with TOTP code...', String(account._id))
      const enableData = new URLSearchParams({
        'av': account.uid,
        '__user': account.uid,
        '__a': '1',
        '__req': '12',
        '__hs': '19979.HYP:accounts_center_pkg.2.1..0.0',
        'dpr': '1',
        '__ccg': 'GOOD',
        '__rev': '1016466820',
        '__s': '3jxio0:lsyvzo:1majbn',
        '__hsi': '7414029279091283622',
        '__dyn': '7xeUmwlEnwn8K2Wmh0no6u5U4e0yoW3q32360CEbo19oe8hw2nVE4W0om0MU2awpUO0n24o5-0Bo7O2l0Fwqo31w9O1lwlE-U2zxe2GewbS361qw8Xwn82Lx-0lK3qazo7u0zE2ZwrUdUcobU3Cwr86C1nwro2PxW1owmU',
        '__csr': 'gon8HlFFjYBTlsgJt4lpAgCGttsJCTliih1njGKJ8xvlVbpicFeHAKlSUD-diCip29AWy4itBJbBjFenLWAgSamDUFelF4xHhdQLXnAG26mkGu6bAHzEkz42Gm9Cglx13UHgiz8-cXx6XUy9G2y5OdAh6Xprw04ROwKxfK8BZ0soCFZ1i0CAFq_iBKuEDHZai0jm1Bg0xKhCguw0zmxOi0wtd4yUO1awso0Z210wiHo8Sit0EQfhoC0kCOjG444YEZ0Djg2og1lV58klxfw4sz8oyaCy88cMmdgF4gjPxK6qyXzotw8iGx2E4-bGE0hGoc-',
        '__comet_req': '5',
        'fb_dtsg': fbDtsg,
        'jazoest': '25321',
        'lsd': lsdToken || 'hykYIjP60BiGaacl54r98X',
        '__spin_r': '1016466820',
        '__spin_b': 'trunk',
        '__spin_t': Math.floor(Date.now() / 1000).toString(),
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'useFXSettingsTwoFactorEnableTOTPMutation',
        'variables': JSON.stringify({
          input: {
            client_mutation_id: crypto.randomUUID(),
            actor_id: account.uid,
            account_id: account.uid,
            account_type: 'FACEBOOK',
            verification_code: otp,
            device_id: 'device_id_fetch_datr',
            fdid: 'device_id_fetch_datr'
          }
        }),
        'server_timestamps': 'true',
        'doc_id': '7032881846733167'
      })
      
      const enableResponse = await fetch(url, {
        method: 'POST',
        headers: {
          ...headers,
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': '*/*',
          ...(lsdToken ? { 'X-FB-LSD': lsdToken } : {}),
          'X-FB-Friendly-Name': 'useFXSettingsTwoFactorEnableTOTPMutation',
          'X-FB-Request-Analytics-Tags': 'graphservice',
          'Origin': 'https://accountscenter.facebook.com',
          'Referer': 'https://accountscenter.facebook.com/password_and_security/two_factor',
          'X-ASBD-ID': '129477',
          'Sec-Fetch-Site': 'same-origin',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Dest': 'empty'
        },
        body: enableData
      })
      
      if (!enableResponse.ok) {
        console.log(`❌ Enable 2FA failed: ${enableResponse.status}`)
        continue
      }
      
      const enableHtml = await enableResponse.text()
      
      if (enableHtml.includes('xfb_two_factor_enable_totp')) {
        console.log('✅ 2FA enabled successfully!')
        emitLog(String(account.userId || ''), '✅ Enable2FA: Success!', String(account._id))
        return { success: true, twoFASecret, message: '2FA enabled successfully' }
      } else {
        console.log('❌ 2FA enable response does not contain success indicator')
        continue
      }
    }
    
    throw new Error('Failed to enable 2FA after 8 attempts')
  } catch (error) {
    console.error('❌ Enable 2FA error:', error)
    return { success: false, message: `Enable 2FA error: ${error instanceof Error ? error.message : 'Unknown error'}` }
  }
}

export async function POST(request: NextRequest): Promise<NextResponse<Enable2FAResponse>> {
  try {
    console.log('🔄 Enable 2FA API: Starting...')
    
    const raw = await request.json()
    const body: Enable2FARequest & { loginFirst?: boolean; loginMethod?: 'cookie' | 'password' } = raw
    console.log('📥 Enable 2FA API: Request body:', body)
    
    if (!body.facebookAccountId) {
      return NextResponse.json({
        success: false,
        message: 'Facebook account ID is required'
      }, { status: 400 })
    }
    
    // Connect to database
    if (mongoose.connection.readyState !== 1) {
      await mongoose.connect(process.env.MONGODB_URI!)
    }
    
    // Load Facebook account
    console.log('🔍 Enable 2FA API: Loading Facebook account...')
    const accountDoc = await (FacebookAccount as any).findById(body.facebookAccountId)
    const account = accountDoc?.toObject?.() ?? accountDoc

    if (!account) {
      return NextResponse.json({
        success: false,
        message: 'Facebook account not found'
      }, { status: 404 })
    }
    
    console.log(`✅ Enable 2FA API: Found Facebook account: ${account.uid}`)
    
    // Check if account has required fields
    if (!account.uid || !account.pass || !account.cookie) {
      return NextResponse.json({
        success: false,
        message: 'Account missing required fields (uid, password, or cookies)'
      }, { status: 400 })
    }
    
    // Step 0: Optional login-first (default true for this route)
    const shouldLoginFirst = body.loginFirst !== false
    if (shouldLoginFirst) try {
      const authHeader = request.headers.get('authorization') || ''
      console.log('🔁 Enable 2FA API: Refreshing cookie session via login-cookie...')
      // Load ProxyFB settings for this account's owner to pass along (since internal call bypasses auth)
      let proxyFBKeys: string[] | undefined
      let proxyFBLocationId: number | undefined
      try {
        const s = await (Settings as any).findOne({ userId: account.userId }).lean()
        if (Array.isArray(s?.proxyFBKeys) && s.proxyFBKeys.length > 0) proxyFBKeys = s.proxyFBKeys
        if (typeof s?.proxyFBLocationId === 'number') proxyFBLocationId = s.proxyFBLocationId
      } catch {}
      const resp = body.loginMethod === 'password'
        ? await fetch('http://localhost:3000/api/facebook/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', ...(authHeader ? { 'Authorization': authHeader } : {}) },
            body: JSON.stringify({ accountId: body.facebookAccountId, useProxy: true })
          })
        : await fetch('http://localhost:3000/api/facebook/login-cookie', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(authHeader ? { 'Authorization': authHeader } : {}),
          'x-internal-call': '1'
        },
        body: JSON.stringify({ accountId: body.facebookAccountId, useProxy: true, ...(proxyFBKeys ? { proxyFBKeys } : {}), ...(typeof proxyFBLocationId === 'number' ? { proxyFBLocationId } : {}) })
      })
      const j = await resp.json().catch(() => ({}))
      console.log(`🔁 Enable 2FA API: login-cookie result ${resp.status} success=${j?.success}`)
      if (!resp.ok || j?.success === false) {
        return NextResponse.json({ success: false, message: `Cookie login failed: ${j?.message || resp.status}` }, { status: 400 })
      }
      // Use freshest cookies and uid from login-cookie step
      if (j?.data?.cookies) {
        ;(account as any).cookie = j.data.cookies
      }
      if (j?.data?.user_id) {
        ;(account as any).uid = j.data.user_id
      }
    } catch (e) {
      console.log('⚠️ Enable 2FA API: login-cookie pre-step error:', (e as any)?.message || e)
    }
    
    // Enable 2FA
    console.log('🔐 Enable 2FA API: Starting 2FA enable process...')
    const result = await enableTwoFA(account)
    
    if (result.success && result.twoFASecret) {
      // Update account with 2FA secret
      console.log('💾 Enable 2FA API: Saving 2FA secret to database...')
      await (FacebookAccount as any).findByIdAndUpdate(
        body.facebookAccountId,
        {
          $set: {
            twoFASecret: result.twoFASecret,
            has2FA: true,
            updatedAt: new Date()
          }
        },
        { new: true }
      )
      
      console.log('✅ Enable 2FA API: 2FA enabled and saved successfully')
      return NextResponse.json({
        success: true,
        message: '2FA enabled successfully',
        data: {
          twoFASecret: result.twoFASecret
        }
      })
    } else {
      console.log('❌ Enable 2FA API: Failed to enable 2FA')
      return NextResponse.json({
        success: false,
        message: result.message
      }, { status: 500 })
    }
  } catch (error) {
    console.error('💥 Enable 2FA API: Error:', error)
    return NextResponse.json({
      success: false,
      message: `Enable 2FA error: ${error instanceof Error ? error.message : 'Unknown error'}`
    }, { status: 500 })
  }
}
