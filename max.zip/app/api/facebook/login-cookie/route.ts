import { NextRequest, NextResponse } from 'next/server'
import { isRunCanceled } from '@/lib/cancel-jobs'
import connectMongoDB from '@/lib/mongodb'
import FacebookAccount from '@/models/FacebookAccount'
import Settings from '@/models/Settings'
import { getProxyFromProxyFB, forceChangeProxyFB, type ProxyConfig } from '@/lib/proxyfb'
import { getEAAGToken, getEAABToken } from '@/lib/facebook-login.js'
import { emitLog } from '@/lib/log-bus'
import { HttpsProxyAgent } from 'https-proxy-agent'

interface LoginCookieRequest {
  accountId: string
  useProxy?: boolean
  proxyFBKeys?: string[]
  proxyFBLocationId?: number
}

export async function POST(request: NextRequest) {
  try {
    console.log('🔍 Facebook Login-Cookie API - Starting')
    await connectMongoDB()

    // Allow trusted internal calls (e.g., from Enable 2FA route) to bypass auth
    const isInternal = request.headers.get('x-internal-call') === '1'

    // Verify user auth
    const token = request.cookies.get('token')?.value || request.headers.get('authorization')?.replace('Bearer ', '')
    let verifiedUserId: string | null = null
    if (!isInternal) {
      if (!token) {
        console.log('❌ Login-Cookie: Unauthorized (missing token)')
        return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })
      }

      // Optional: validate token via internal endpoint
      try {
        const verify = await fetch('http://localhost:3000/api/auth/verify', { headers: { Authorization: `Bearer ${token}` } })
        if (!verify.ok) {
          console.log('❌ Login-Cookie: Invalid token from /api/auth/verify')
          emitLog(String((await verify.json())?.userId || ''), '❌ Login-Cookie: Invalid token')
          return NextResponse.json({ success: false, message: 'Invalid token' }, { status: 401 })
        }
        try {
          const v = await verify.json()
          verifiedUserId = String(v?.userId || v?.id || '') || null
          console.log('🔐 Login-Cookie: Verified user id =', verifiedUserId)
        } catch {}
      } catch {}
    } else {
      console.log('🛡️ Login-Cookie: Internal call bypassing auth checks')
    }

    const body = await request.json() as LoginCookieRequest & { runId?: string }
    const { accountId, useProxy = true } = body
    const runId = (body as any)?.runId
    if (!accountId) {
      console.log('❌ Login-Cookie: Missing accountId')
      emitLog('', '❌ Login-Cookie: Missing accountId')
      return NextResponse.json({ success: false, message: 'Account ID is required' }, { status: 400 })
    }

    const account: any = await (FacebookAccount as any).findById(accountId)
    if (!account) {
      console.log(`❌ Login-Cookie: Account not found: ${accountId}`)
      emitLog('', `❌ Login-Cookie: Account not found: ${accountId}`)
      return NextResponse.json({ success: false, message: 'Account not found' }, { status: 404 })
    }

    if (!account.cookie) {
      console.log(`❌ Login-Cookie: No cookies stored for account ${accountId}`)
      emitLog(String(account.userId || ''), `❌ Login-Cookie: No cookies stored for account ${accountId}`)
      return NextResponse.json({ success: false, message: 'No cookies stored for this account' }, { status: 400 })
    }

    // Proxy setup (reuse settings like login route) with strict preference for ProxyFB keys
    let proxyConfig: ProxyConfig | null = null
    if (useProxy) {
      // Prefer keys from body (internal calls)
      const bodyProxyFBKeys: string[] = Array.isArray(body.proxyFBKeys) ? body.proxyFBKeys : []
      const bodyLocationId: number = typeof body.proxyFBLocationId === 'number' ? body.proxyFBLocationId : 1

      let settingsProxyFBKeys: string[] = []
      let settingsProxyFBLocationId: number = 1

      if (bodyProxyFBKeys.length === 0) {
        const settingsLookupUserId = verifiedUserId || String(account.userId || '')
        const isValidObjectId = !!settingsLookupUserId && /^[a-fA-F0-9]{24}$/.test(settingsLookupUserId)
        if (isValidObjectId) {
          try {
            const userSettings = await (Settings as any).findOne({ userId: settingsLookupUserId }).lean()
            settingsProxyFBKeys = Array.isArray(userSettings?.proxyFBKeys) ? userSettings.proxyFBKeys : []
            settingsProxyFBLocationId = typeof userSettings?.proxyFBLocationId === 'number' ? userSettings.proxyFBLocationId : 1
          } catch {}
        } else {
          console.log('ℹ️ Login-Cookie: Skipping Settings lookup (invalid userId)')
        }
      }

      const effectiveProxyFBKeys: string[] = bodyProxyFBKeys.length > 0 ? bodyProxyFBKeys : settingsProxyFBKeys
      const effectiveLocationId: number = bodyProxyFBKeys.length > 0 ? bodyLocationId : settingsProxyFBLocationId
      console.log('🔧 Login-Cookie: ProxyFB keys source =', effectiveProxyFBKeys.length > 0 ? (bodyProxyFBKeys.length > 0 ? 'Body' : 'Settings') : 'None')

      if (Array.isArray(effectiveProxyFBKeys) && effectiveProxyFBKeys.length > 0) {
        try {
          proxyConfig = await getProxyFromProxyFB(
            effectiveProxyFBKeys,
            effectiveLocationId,
            8000,
            String(verifiedUserId || account.userId || '')
          )
          if (proxyConfig) {
            console.log('🔍 Login-Cookie: Using ProxyFB proxy:', proxyConfig)
          } else {
            console.log('⚠️ Login-Cookie: ProxyFB returned no proxy; trying forceChangeProxyFB per key...')
            for (const key of effectiveProxyFBKeys) {
              try {
                const forced = await forceChangeProxyFB(key, effectiveLocationId, 8000)
                if (forced) {
                  proxyConfig = forced
                  console.log('✅ Login-Cookie: Got ProxyFB proxy via forceChange:', proxyConfig)
                  break
                }
              } catch {}
            }
            if (!proxyConfig) {
              console.log('⚠️ Login-Cookie: ProxyFB still unavailable; strict mode: no admin fallback')
            }
          }
        } catch (e) {
          console.log('⚠️ Login-Cookie: ProxyFB fetch error (strict mode, no admin fallback):', e)
        }
      } else {
        // Only allow admin proxy when NOT an internal call; internal calls should not fallback
        if (!isInternal) {
          try {
            if (token) {
              const resp = await fetch('http://localhost:3000/api/proxy/get-proxy', { method: 'POST', headers: { Authorization: `Bearer ${token}` } })
              if (resp.ok) {
                const data = await resp.json()
                if (data.success && data.proxy) {
                  proxyConfig = {
                    host: data.proxy.split(':')[0],
                    port: parseInt(data.proxy.split(':')[1], 10),
                    protocol: 'http'
                  } as ProxyConfig
                  console.log('🔍 Login-Cookie: Using admin proxy:', proxyConfig)
                }
              }
            }
          } catch {}
        } else {
          console.log('ℹ️ Login-Cookie: Internal call without ProxyFB keys; skipping admin proxy fallback')
        }
      }
    }

    // Validate cookie session first (now with proxy support)
    try {
      emitLog(String(account.userId || ''), '🔐 Login-Cookie: Validating cookie session...', String(account._id))
      const urls = [
        'https://m.facebook.com/home.php',
        'https://www.facebook.com/',
        'https://business.facebook.com/'
      ]
      let valid = false
      for (const u of urls) {
        if (isRunCanceled(runId)) {
          return NextResponse.json({ success: false, message: 'Canceled' }, { status: 499 })
        }
        try {
          // Try via proxy first if available
          const headers = { 'User-Agent': 'Mozilla/5.0', 'Accept': 'text/html', 'Cookie': account.cookie } as Record<string, string>
          let r: Response | null = null
          let html = ''
          if (proxyConfig) {
            try {
              // Only use auth if username and password exist on proxyConfig
              let auth = '';
              if (
                typeof (proxyConfig as any).username === 'string' &&
                typeof (proxyConfig as any).password === 'string' &&
                (proxyConfig as any).username &&
                (proxyConfig as any).password
              ) {
                auth = `${encodeURIComponent((proxyConfig as any).username)}:${encodeURIComponent((proxyConfig as any).password)}@`;
              }
              const agent = new HttpsProxyAgent(`${proxyConfig.protocol}://${auth}${proxyConfig.host}:${proxyConfig.port}`);
              r = await fetch(u, { headers, ...(agent ? { agent } : {}) } as any);
              html = await r.text();
              const markers = /DTSGInitialData|fb_dtsg|LSD|c_user=/.test(html);
              emitLog(String(account.userId || ''), `🔎 Cookie probe ${u} via proxy status ${r.status} markers=${markers}`, String(account._id))
              if (markers) { valid = true; break }
            } catch {}
          }
          // Fallback: direct without proxy
          if (!valid) {
            try {
              r = await fetch(u, { headers })
              html = await r.text()
              const markers = /DTSGInitialData|fb_dtsg|LSD|c_user=/.test(html)
              emitLog(String(account.userId || ''), `🔎 Cookie probe ${u} direct status ${r.status} markers=${markers}`, String(account._id))
              if (markers) { valid = true; break }
            } catch {}
          }
        } catch {}
      }
      if (!valid) {
        emitLog(String(account.userId || ''), '❌ Login-Cookie: Cookie session invalid', String(account._id))
        return NextResponse.json({ success: false, message: 'Cookie session invalid' }, { status: 400 })
      }
      emitLog(String(account.userId || ''), '✅ Login-Cookie: Cookie session valid', String(account._id))
    } catch {}

    // Derive tokens from cookies
    const cookies = account.cookie as string
    const uid = account.uid || (cookies.match(/c_user=([^;]+)/)?.[1] || '')

    console.log(`🔑 Login-Cookie: Fetching tokens for uid=${uid}`)
    emitLog(String(account.userId || ''), `🔑 Login-Cookie: Fetching tokens for uid=${uid}` , String(account._id))
    if (isRunCanceled(runId)) {
      return NextResponse.json({ success: false, message: 'Canceled' }, { status: 499 })
    }
    let [eaagToken, eaabToken] = await Promise.all([
      getEAAGToken(cookies, uid, proxyConfig || undefined),
      getEAABToken(cookies, uid, proxyConfig || undefined)
    ])
    console.log(`🔍 Login-Cookie: EAAG? ${!!eaagToken}, EAAB? ${!!eaabToken} (via proxy: ${!!proxyConfig})`)
    emitLog(String(account.userId || ''), `🔍 Login-Cookie: EAAG? ${!!eaagToken}, EAAB? ${!!eaabToken} (via proxy: ${!!proxyConfig})`, String(account._id))

    // Fallback: retry without proxy if proxy attempt failed
    if (!eaagToken && !eaabToken && proxyConfig) {
      console.log('↩️ Login-Cookie: Proxy attempt failed, retrying without proxy...')
      emitLog(String(account.userId || ''), '↩️ Login-Cookie: Proxy attempt failed, retrying without proxy...', String(account._id))
      ;[eaagToken, eaabToken] = await Promise.all([
        getEAAGToken(cookies, uid, undefined),
        getEAABToken(cookies, uid, undefined)
      ])
      console.log(`🔁 Login-Cookie (no proxy): EAAG? ${!!eaagToken}, EAAB? ${!!eaabToken}`)
      emitLog(String(account.userId || ''), `🔁 Login-Cookie (no proxy): EAAG? ${!!eaagToken}, EAAB? ${!!eaabToken}`, String(account._id))
    }

    if (!eaagToken && !eaabToken) {
      console.log('❌ Login-Cookie: Token retrieval failed from cookies')
      emitLog(String(account.userId || ''), '❌ Login-Cookie: Token retrieval failed from cookies', String(account._id))
      await (FacebookAccount as any).findByIdAndUpdate(accountId, {
        status: 'error',
        log: 'Đăng nhập cookie thất bại: không lấy được token',
        lastUpdated: new Date()
      })
      return NextResponse.json({ success: false, message: 'Không lấy được token từ cookie' }, { status: 400 })
    }

    const updateData: any = {
      token: eaagToken || account.token || '',
      eaagToken: eaagToken || account.eaagToken || '',
      eaabToken: eaabToken || account.eaabToken || '',
      cookie: cookies,
      lastUpdated: new Date(),
      status: 'active',
      log: 'Đăng nhập bằng cookie thành công'
    }

    await (FacebookAccount as any).findByIdAndUpdate(accountId, updateData)
    emitLog(String(account.userId || ''), `✅ Login-Cookie: Updated DB (EAAG:${!!updateData.eaagToken}, EAAB:${!!updateData.eaabToken})`, String(account._id))
    console.log(`✅ Login-Cookie: Updated DB for ${accountId} (EAAG:${!!updateData.eaagToken}, EAAB:${!!updateData.eaabToken})`)

    return NextResponse.json({
      success: true,
      message: 'Đăng nhập bằng cookie thành công',
      data: {
        eaag_token: updateData.eaagToken,
        eaab_token: updateData.eaabToken,
        cookies,
        user_id: uid
      }
    })
  } catch (error) {
    console.error('💥 Facebook Login-Cookie API Error:', error)
    return NextResponse.json({ success: false, message: 'Internal server error' }, { status: 500 })
  }
}
