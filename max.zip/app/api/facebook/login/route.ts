import { NextRequest, NextResponse } from 'next/server';
import { isRunCanceled } from '@/lib/cancel-jobs'
import connectMongoDB from '@/lib/mongodb';
import FacebookAccount from '@/models/FacebookAccount';
import { getUserEncryptionKey, decryptFields } from '@/lib/encryption'
import Settings from '@/models/Settings';
import { loginFacebook } from '@/lib/facebook-login.js';
import { getProxyFromProxyFB, type ProxyConfig } from '@/lib/proxyfb';

interface LoginRequest {
  accountId: string;
  useProxy?: boolean;
  fastMode?: boolean;
  proxyFBKeys?: string[];
  proxyFBLocationId?: number;
}

interface LoginResponse {
  success: boolean;
  message: string;
  access_token?: string;
  eaag_token?: string;
  eaab_token?: string;
  cookies?: string;
  user_id?: string;
  session_key?: string;
  machine_id?: string;
  secret?: string;
  dtsg?: string;
  data?: {
    access_token?: string;
    eaag_token?: string;
    eaab_token?: string;
    cookies?: string;
    user_id?: string;
    session_key?: string;
    machine_id?: string;
    secret?: string;
  };
}

// Helper function to get user from token
async function getUserFromToken(token: string) {
  try {
    const response = await fetch('http://localhost:3000/api/auth/verify', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (response.ok) {
      return await response.json();
    }
    return null;
  } catch (error) {
    return null;
  }
}

export async function POST(request: NextRequest) {
  try {
    console.log('🔍 Facebook Login API - Starting request processing');
    await connectMongoDB();
    
    // Verify user authentication
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    console.log('🔍 Token found:', !!token);
    
    if (!token) {
      console.log('❌ No token found - returning 401');
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    console.log('🔍 User validation result:', !!user);
    
    if (!user) {
      console.log('❌ Invalid token - returning 401');
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    console.log('🔍 Parsing request body...');
    let body: (LoginRequest & { runId?: string }) | null = null;
    try {
      body = await request.json();
    } catch (e) {
      console.log('⚠️ Body parse failed (possibly canceled).');
      return NextResponse.json({ success: false, error: 'Canceled or invalid body' }, { status: 499 });
    }
    console.log('🔍 Request body:', { accountId: body.accountId, useProxy: body.useProxy, fastMode: body.fastMode, hasProxyFBKeys: Array.isArray((body as any).proxyFBKeys) && (body as any).proxyFBKeys.length > 0 });

    const { accountId, useProxy = true, fastMode = false } = body as any;
    const runId = (body as any)?.runId

    if (!accountId) {
      console.log('❌ No accountId provided - returning 400');
      return NextResponse.json({ 
        error: 'Account ID is required' 
      }, { status: 400 });
    }

    console.log('🔍 Looking up account in database...');
    const isValidObjectId = /^[a-fA-F0-9]{24}$/.test(String(accountId));
    let account: any = null;
    if (!isValidObjectId) {
      console.log('ℹ️ Non-ObjectId accountId detected (local temp id). Using credentials from request body.');
      const base = (body as any) || {};
      const provided = base.localAccount || base.account || base.accountData || {
        uid: base.uid || base.username || '',
        pass: base.pass || base.password || '',
        twofa: base.twofa || base.otp || '',
        mail: base.mail || base.email || '',
        passmail: base.passmail || base.emailPassword || '',
        mailkp: base.mailkp || '',
        cookie: base.cookie || base.cookies || '',
        token: base.token || base.access_token || base.eaag_token || ''
      };
      if (!provided || (!provided.uid && !provided.mail)) {
        return NextResponse.json({ 
          error: 'Missing local account data',
          hint: 'Provide fields: localAccount or top-level uid/pass[/twofa/mail/passmail/cookie/token] when using local IDs.'
        }, { status: 400 });
      }
      account = provided;
    } else {
      // Get account details
      account = await (FacebookAccount as any).findOne({ _id: accountId });
    }

    console.log('🔍 Account found:', !!account);
    if (account) {
      console.log('🔍 Account details:', {
        _id: account._id,
        uid: account.uid ? account.uid.substring(0, 50) + '...' : 'null',
        hasUid: !!account.uid,
        uidLength: account.uid?.length || 0
      });
    }

    if (!account) {
      console.log('❌ Account not found - returning 404');
      return NextResponse.json({ 
        error: 'Account not found' 
      }, { status: 404 });
    }

    // Decrypt sensitive fields if user-level encryption is enabled
    try {
      const { enabled, key } = await getUserEncryptionKey(String(user.userId))
      if (enabled && key && account) {
        account = decryptFields(account.toObject ? account.toObject() : account, ['uid','pass','twofa','mail','passmail','mailkp','cookie','token','accessToken','cookies','sessionKey','secret','eaagToken','eaabToken'], key)
      }
    } catch {}

    console.log('🔍 Parsing account string...');
    // Parse account data from uid field with new format
    const accountData = parseAccountString(account.uid, account);
    console.log('🔍 Parsed account data:', {
      username: accountData.username,
      hasPassword: !!accountData.password,
      hasTwoFA: !!accountData.twofa,
      hasMail: !!accountData.mail,
      uid: accountData.uid
    });
    
    if (!accountData.username || !accountData.password) {
      console.log('❌ Invalid account format - missing username or password');
      console.log('🔍 Account string:', account.uid);
      console.log('🔍 Parsed data:', accountData);
      return NextResponse.json({ 
        error: 'Invalid account format - missing username or password' 
      }, { status: 400 });
    }

    console.log('🔍 Loading user settings for proxy configuration...');
    const userSettings = await (Settings as any).findOne({ userId: user.userId }).lean();
    const settingsProxyFBKeys: string[] = Array.isArray(userSettings?.proxyFBKeys) ? userSettings.proxyFBKeys : [];
    const settingsProxyFBLocationId: number = typeof userSettings?.proxyFBLocationId === 'number' ? userSettings.proxyFBLocationId : 1;
    const settingsHttpProxies: string[] = Array.isArray(userSettings?.httpProxies) ? userSettings.httpProxies : [];
    const settingsSelectedProxyId: string = userSettings?.selectedProxyId || '';

    // Effective keys: prefer saved settings; fallback to request body for backward compatibility
    const effectiveProxyFBKeys: string[] = (settingsProxyFBKeys && settingsProxyFBKeys.length > 0)
      ? settingsProxyFBKeys
      : (Array.isArray((body as any).proxyFBKeys) ? (body as any).proxyFBKeys : []);
    const effectiveLocationId: number = (settingsProxyFBKeys && settingsProxyFBKeys.length > 0)
      ? settingsProxyFBLocationId
      : (typeof (body as any).proxyFBLocationId === 'number' ? (body as any).proxyFBLocationId : 1);

    if (isRunCanceled(runId)) {
      return NextResponse.json({ error: 'Canceled', success: false }, { status: 499 })
    }
    console.log('🔍 Setting up proxy...');
    console.log('🔍 Proxy settings:', {
      hasSelectedProxyId: !!settingsSelectedProxyId,
      hasProxyFBKeys: effectiveProxyFBKeys.length > 0,
      hasHttpProxies: settingsHttpProxies.length > 0,
      useProxy
    });
    
    // Proxy priority order: 1) Admin Proxy Server, 2) ProxyFB Keys, 3) HTTP Proxy List
    let proxyConfig: ProxyConfig | null = null;
    if (useProxy) {
      // Priority 1: Admin Proxy Server (if selected)
      if (settingsSelectedProxyId) {
        try {
          console.log('🔍 Attempting to get admin proxy server...');
          const proxyResponse = await fetch('http://localhost:3000/api/proxy/get-proxy', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          if (proxyResponse.ok) {
            const proxyData = await proxyResponse.json();
            if (proxyData.success && proxyData.proxy) {
              proxyConfig = {
                host: proxyData.proxy.split(':')[0],
                port: parseInt(proxyData.proxy.split(':')[1], 10),
                protocol: 'http'
              } as ProxyConfig;
              console.log('🔍 Using admin proxy server:', proxyConfig);
            }
          }
        } catch (error) {
          console.log('⚠️ Admin proxy server fetch error:', error);
        }
      }
      
      // Priority 2: ProxyFB Keys (if no admin proxy and ProxyFB keys exist)
      if (!proxyConfig && Array.isArray(effectiveProxyFBKeys) && effectiveProxyFBKeys.length > 0) {
        try {
          console.log('🔍 Attempting to get ProxyFB proxy...');
          proxyConfig = await getProxyFromProxyFB(
            effectiveProxyFBKeys,
            effectiveLocationId || 1,
            8000,
            String(user.userId || user.id || '') || undefined
          );
          if (proxyConfig) {
            console.log('🔍 Using ProxyFB proxy:', proxyConfig);
          } else {
            console.log('⚠️ ProxyFB returned no proxy');
          }
        } catch (e) {
          console.log('⚠️ ProxyFB fetch error:', e);
        }
      }
      
      // Priority 3: HTTP Proxy List (if no admin proxy and no ProxyFB proxy)
      if (!proxyConfig && Array.isArray(settingsHttpProxies) && settingsHttpProxies.length > 0) {
        try {
          console.log('🔍 Attempting to get HTTP proxy from list...');
          // Randomly select a proxy from the HTTP proxy list
          const randomIndex = Math.floor(Math.random() * settingsHttpProxies.length);
          const selectedProxy = settingsHttpProxies[randomIndex];
          
          if (selectedProxy && selectedProxy.includes(':')) {
            const parts = selectedProxy.split(':');
            if (parts.length >= 2) {
              const host = parts[0];
              const port = parseInt(parts[1], 10);
              
              if (host && port && !isNaN(port)) {
                proxyConfig = {
                  host,
                  port,
                  protocol: 'http',
                  // Add auth if available
                  ...(parts.length === 4 && {
                    auth: `${parts[2]}:${parts[3]}`
                  })
                } as ProxyConfig;
                console.log('🔍 Using HTTP proxy from list:', proxyConfig);
              }
            }
          }
        } catch (error) {
          console.log('⚠️ HTTP proxy list error:', error);
        }
      }
      
      if (!proxyConfig) {
        console.log('⚠️ No proxy available from any source');
      }
    }

    if (isRunCanceled(runId)) {
      return NextResponse.json({ error: 'Canceled', success: false }, { status: 499 })
    }
    console.log('🔍 Calling Facebook login function...');
    // Call JavaScript Facebook login function
    const loginResult = await loginFacebook(
      accountData.username,
      accountData.password,
      accountData.twofa || '',
      (proxyConfig as any) || undefined
    ) as LoginResponse;

    console.log('🔍 Login result:', {
      success: loginResult.success,
      message: loginResult.message,
      hasAccessToken: !!loginResult.access_token,
      hasEaagToken: !!loginResult.eaag_token,
      hasEaabToken: !!loginResult.eaab_token
    });

    // Update account status based on result
    if (loginResult.success) {
      // Debug log the tokens received
      console.log('🔍 Login result tokens:');
      console.log(`  - access_token: ${loginResult.access_token ? loginResult.access_token.substring(0, 20) + '...' : 'null'}`);
      console.log(`  - eaag_token: ${loginResult.eaag_token ? loginResult.eaag_token.substring(0, 20) + '...' : 'null'}`);
      console.log(`  - eaab_token: ${loginResult.eaab_token ? loginResult.eaab_token.substring(0, 20) + '...' : 'null'}`);
      
      let qualityResult = 'Chưa check';
      let graphInfo = null;
      
      // Update account with all information
      const updateData: any = {
        status: qualityResult.includes('Live Ads') || qualityResult.includes('Tích Xanh') ? 'active' : 'checking',
        log: `Đăng nhập thành công - Quality: ${qualityResult}`,
        lastUpdated: new Date(),
        uid: accountData.uid,               // Store clean UID (without pipe format)
        pass: accountData.password,         // Store password separately
        twofa: accountData.twofa,          // Store 2FA separately
        mail: accountData.mail,            // Store mail separately
        passmail: accountData.passmail,    // Store passmail separately
        mailkp: accountData.mailkp,        // Store mailkp separately
        cookie: loginResult.cookies || '', // Store cookies in cookie field
        token: loginResult.eaag_token || '', // Store EAAG token in token field
        accessToken: loginResult.access_token,
        cookies: loginResult.cookies,
        sessionKey: loginResult.session_key,
        machineId: loginResult.machine_id,
        secret: loginResult.secret,
        eaagToken: loginResult.eaag_token,   // Store EAAG token separately too
        eaabToken: loginResult.eaab_token,   // Store EAAB token for Ads Manager
        dtsg: loginResult.dtsg || '',        // Store DTSG token for API calls
        quality: qualityResult,
        lastQualityCheck: new Date()
      };
      
      // Add comprehensive graph info from v23.0 API if available
      if (graphInfo) {
        updateData.graphInfo = graphInfo;
        updateData.lastGraphUpdate = new Date();
        updateData.apiVersion = 'v23.0';
        
        // Friends data
        if (graphInfo && (graphInfo as any).friends && !(graphInfo as any).friends.error) {
          updateData.friends = (graphInfo as any).friends.totalCount?.toString() || (graphInfo as any).friends.data?.length?.toString() || account.friends;
          updateData.friendsList = (graphInfo as any).friends.data || [];
        }
        
        // Personal data from v23.0 API
        if (graphInfo && (graphInfo as any).personal && !(graphInfo as any).personal.error) {
          const personal = (graphInfo as any).personal;
          updateData.name = personal.name || account.name;
          updateData.firstName = personal.first_name || account.firstName;
          updateData.lastName = personal.last_name || account.lastName;
          updateData.middleName = personal.middle_name || account.middleName;
          updateData.gender = personal.gender || account.gender;
          updateData.email = personal.email || account.email;
          updateData.birthday = personal.birthday || account.birthday;
          updateData.picture = personal.picture?.data?.url || account.picture;
          updateData.link = personal.link || account.link;
          updateData.locale = personal.locale || account.locale;
          updateData.timezone = personal.timezone || account.timezone;
          updateData.verified = personal.verified || account.verified;
          updateData.ageRange = personal.age_range || account.ageRange;
          updateData.facebookUserId = personal.id || account.facebookUserId;
        }
        
      }
      
      console.log('💾 Saving to database:');
      console.log(`  - eaagToken: ${updateData.eaagToken ? updateData.eaagToken.substring(0, 20) + '...' : 'null'}`);
      console.log(`  - eaabToken: ${updateData.eaabToken ? updateData.eaabToken.substring(0, 20) + '...' : 'null'}`);
      
      if (isValidObjectId) {
        await (FacebookAccount as any).findByIdAndUpdate(accountId, updateData);
      } else {
        console.log('ℹ️ Skipping DB update for local temp id');
      }
      
      console.log('✅ Database update completed');
    } else {
      console.log('❌ Login failed, updating account status');
      if (isValidObjectId) {
        await (FacebookAccount as any).findByIdAndUpdate(accountId, {
          status: 'error',
          log: loginResult.message,
          lastUpdated: new Date(),
          // Also update individual fields to maintain consistency
          uid: account.uid,
          pass: account.pass,
          twofa: account.twofa,
          mail: account.mail,
          passmail: account.passmail,
          mailkp: account.mailkp,
          cookie: account.cookie,
          token: account.token
        });
      } else {
        console.log('ℹ️ Skipping error DB update for local temp id');
      }
    }

    console.log('🔍 Returning response to client');
    return NextResponse.json({
      success: loginResult.success,
      message: loginResult.message,
      data: loginResult.success ? {
        access_token: loginResult.access_token,
        eaag_token: loginResult.eaag_token,
        eaab_token: loginResult.eaab_token,
        cookies: loginResult.cookies,
        user_id: loginResult.user_id,
        session_key: loginResult.session_key,
        machine_id: loginResult.machine_id,
        secret: loginResult.secret
      } : undefined
    });

  } catch (error) {
    console.error('💥 Facebook Login API Error:', error);
    console.error('💥 Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    return NextResponse.json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// Helper function to parse account data - supports both new format (separate fields) and legacy format (UID string)
function parseAccountString(accountString: string, account?: any) {
  // If we have the full account object, use individual fields first (new format)
  if (account) {
    console.log('🔍 Using new format - individual fields from database');
    
    let uid = account.uid || accountString;
    let password = account.pass || '';
    let twofa = account.twofa || '';
    
    // Check if uid contains the old pipe-delimited format
    if (uid && uid.includes('|')) {
      console.log('🔍 Detected old pipe-delimited format in uid field');
      const parts = uid.trim().split('|');
      if (parts.length >= 3) {
        uid = parts[0]; // First part is the actual UID
        password = parts[1] || account.pass || ''; // Second part is password
        twofa = parts[2] || account.twofa || ''; // Third part is 2FA
        console.log(`🔍 Parsed from pipe format: uid=${uid}, password=${password ? '***' : 'empty'}, 2fa=${twofa ? '***' : 'empty'}`);
      }
    }
    
    const result = {
      uid: uid,
      password: password,
      twofa: twofa,
      mail: account.mail || '',
      passmail: account.passmail || '',
      mailkp: account.mailkp || '',
      cookie: account.cookie || '',
      token: account.token || '',
      // Prefer UID as username to match new schema usage
      username: uid || account.mail || accountString
    };
    
    console.log(`🔍 Final parsed result: username=${result.username}, hasPassword=${!!result.password}, hasTwoFA=${!!result.twofa}`);
    return result;
  }
  
  // Legacy format no longer supported; always require structured fields
  console.log('⚠️ Legacy UID string format not supported. Using structured fields only.');
  return {
    uid: accountString,
    password: '',
    twofa: '',
    mail: '',
    passmail: '',
    mailkp: '',
    cookie: '',
    token: '',
    username: accountString
  };
}
