import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import FacebookAccount from '@/models/FacebookAccount';

interface RegisterBMRequest {
  accountId: string;
  useProxy?: boolean;
  options?: {
    businessData?: any;
    createAdAccount?: boolean; // default true
    createPixel?: boolean; // default false
    createCatalog?: boolean; // default false
    pixelName?: string;
    catalogName?: string;
    method?: 'graph' | 'server2'; // graph: Graph API (mặc định), server2: GraphQL endpoint
    businessName?: string; // override tên doanh nghiệp
  };
}

interface RegisterBMResponse {
  success: boolean;
  message: string;
  businessManagerId?: string;
  businessManagerUrl?: string;
  data?: any;
}

// Helper function to get user from token
async function getUserFromToken(token: string) {
  try {
    const response = await fetch('http://localhost:3000/api/auth/verify', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (response.ok) {
      return await response.json();
    }
    return null;
  } catch (error) {
    return null;
  }
}

async function registerBusinessManagerServer2({ sessionData, businessName, accessToken }: { sessionData: any; businessName: string; accessToken?: string; }): Promise<RegisterBMResponse & { businessManagerId?: string }> {
  try {
    // Require cookies from sessionData
    const cookies = sessionData?.cookies || ''
    if (!cookies) {
      return { success: false, message: 'Thiếu cookies để gọi Server2' }
    }

    // These values are dynamic on web; try env → session → auto fetch
    let fb_dtsg = process.env.FB_DTSG || sessionData.fb_dtsg || ''
    let lsd = process.env.FB_LSD || sessionData.lsd || ''
    const userIdMatch = /c_user=(\d+)/.exec(cookies)
    const userId = userIdMatch ? userIdMatch[1] : ''
    if (!userId) return { success: false, message: 'Không xác định được __user từ cookie' }

    // Auto-fetch tokens if missing
    if (!fb_dtsg || !lsd) {
      try {
        const fetched = await fetchServer2Tokens(cookies)
        fb_dtsg = fb_dtsg || fetched.fb_dtsg
        lsd = lsd || fetched.lsd
      } catch {}
    }

    const form = new URLSearchParams()
    form.set('av', userId)
    form.set('__usid', '6-')
    form.set('__user', userId)
    form.set('__a', '1')
    form.set('__dyn', '7xeUmwkHgmwn8K2WnFwn84a2i5U4e1Fx-ewSyo9Euxa0z8S2S7o760Boe8hwem0nCq1ewcG0KEswaq1xwEwlU-0nSUS1vwnEfU7e2l0Fwwwi85W1ywnEfogwh85qfK6E28xe3C16wlo5a2W2K1HwywnEhwxwuUvwbW1fxW4UpwSyES0gq5o2DwiU8UdUco')
    form.set('__csr', '')
    form.set('__req', 's')
    form.set('__hs', '19187.BP:bizweb_pkg.2.0.0.0.0')
    form.set('dpr', '1')
    form.set('__ccg', 'GOOD')
    form.set('__rev', '1005843971')
    form.set('__s', 'xpxflz:1mkqgj:vof03o')
    form.set('__hsi', '7120240829090214250')
    form.set('__comet_req', '0')
    form.set('fb_dtsg', fb_dtsg)
    form.set('jazoest', '25414')
    form.set('lsd', lsd)
    form.set('__spin_r', '1005843971')
    form.set('__spin_b', 'trunk')
    form.set('__spin_t', 'mftool')
    form.set('__jssesw', '1')
    form.set('fb_api_caller_class', 'RelayModern')
    form.set('fb_api_req_friendly_name', 'FBEGeoBMCreation_CreateBusinessMutation')
    form.set('variables', JSON.stringify({ input: { client_mutation_id: '6', actor_id: userId, business_name: businessName } }))
    form.set('server_timestamps', 'true')
    // Allow override/try multiple doc ids
    const tryDocIds = (process.env.FB_SERVER2_DOC_IDS || process.env.FB_SERVER2_DOC_ID || '5232196050177866')
      .split(',')
      .map(s => s.trim())

    let lastText = ''
    for (const docId of tryDocIds) {
      form.set('doc_id', docId)

      const res = await fetch('https://business.facebook.com/api/graphql/', {
        method: 'POST',
        headers: {
          'accept': '*/*',
          'content-type': 'application/x-www-form-urlencoded',
          'user-agent': 'Mozilla/5.0',
          'cookie': cookies,
          'origin': 'https://www.facebook.com',
          'referer': 'https://www.facebook.com',
          'x-fb-lsd': lsd
        },
        body: form
      })

      const text = await res.text()
      lastText = text
      if (!res.ok) {
        continue
      }

      let cleaned = text.trim()
      cleaned = cleaned.replace(/^for \(;;\);/, '').replace(/^\)]}'/, '')
      let json: any = null
      try { json = JSON.parse(cleaned) } catch {}

      // Try extract id directly
      const bmId = json?.data?.fbe_geo_bm_creation_create_business?.business?.id || json?.data?.create_business?.business?.id || json?.data?.business_create?.business?.id
      if (bmId) {
        return { success: true, message: 'OK', businessManagerId: bmId }
      }

      // Regex fallback
      const m = cleaned.match(/"business"\s*:\s*\{[^}]*"id"\s*:\s*"(\d+)"/)
      if (m && m[1]) {
        return { success: true, message: 'OK', businessManagerId: m[1] }
      }
    }
    // If all doc ids failed, attempt Graph fallback
    {
      // Fallback: query Graph API for recently created business by name (if we have token)
      if (accessToken) {
        try {
          const q = new URL(`https://graph.facebook.com/v19.0/me/businesses`)
          q.searchParams.set('access_token', accessToken)
          q.searchParams.set('limit', '25')
          q.searchParams.set('fields', 'id,name,created_time')
          const listRes = await fetch(q.toString())
          const listJson: any = await listRes.json()
          if (Array.isArray(listJson?.data)) {
            const byName = listJson.data.filter((b: any) => String(b.name || '').toLowerCase() === String(businessName).toLowerCase())
            if (byName.length > 0) {
              // pick the most recent
              byName.sort((a: any, b: any) => new Date(b.created_time).getTime() - new Date(a.created_time).getTime())
              return { success: true, message: 'OK', businessManagerId: byName[0].id }
            }
          }
        } catch {}
      }
      const preview = (lastText || '').slice(0, 300)
      return { success: false, message: `Server2 không trả về Business ID`, data: { preview } }
    }
  } catch (e: any) {
    return { success: false, message: e?.message || 'Server2 error' }
  }
}

async function fetchServer2Tokens(cookies: string): Promise<{ fb_dtsg: string; lsd: string }> {
  const headers = {
    'cookie': cookies,
    'user-agent': 'Mozilla/5.0',
    'accept': 'text/html,application/xhtml+xml'
  } as any
  const urls = [
    'https://business.facebook.com/business_creation',
    'https://www.facebook.com/business',
    'https://www.facebook.com/'
  ]
  let fb_dtsg = ''
  let lsd = ''
  for (const url of urls) {
    try {
      const r = await fetch(url, { headers })
      const html = await r.text()
      if (!fb_dtsg) {
        let m = html.match(/name=\"fb_dtsg\"\s+value=\"([^\"]+)\"/)
        if (!m) m = html.match(/\"DTSGInitialData\"\}\,\{\"token\":\"([^\"]+)\"/)
        if (m) fb_dtsg = m[1]
      }
      if (!lsd) {
        let m = html.match(/name=\"lsd\"\s+value=\"([^\"]+)\"/)
        if (!m) m = html.match(/\"LSD\"\,\{\"token\":\"([^\"]+)\"/)
        if (m) lsd = m[1]
      }
      if (fb_dtsg && lsd) break
    } catch {}
  }
  return { fb_dtsg, lsd }
}

// Helper function to parse account data - supports both new format (separate fields) and legacy format (UID string)
function parseAccountString(accountString: string, account?: any) {
  // If we have the full account object, use individual fields first (new format)
  if (account) {
    const result = {
      uid: account.uid || accountString,
      password: account.pass || '',
      twofa: account.twofa || '',
      mail: account.mail || '',
      passmail: account.passmail || '',
      mailkp: account.mailkp || '',
      cookie: account.cookie || '',
      token: account.token || '',
      username: account.mail || account.uid || accountString
    };
    
    // If we have individual fields with data, use them
    if (result.password) {
      return result;
    }
  }
  
  // Legacy format: parse from UID string
  if (accountString && accountString.includes('|')) {
    const parts = accountString.trim().split('|');
    
    if (parts.length >= 3) {
      return {
        uid: parts[0] || '',
        password: parts[1] || '',
        twofa: parts[2] || '',
        mail: parts[3] || '',
        passmail: parts[4] || '',
        mailkp: parts[5] || '',
        cookie: parts[6] || '',
        token: parts[7] || '',
        username: parts[3] || parts[0]
      };
    }
  }
  return {
    uid: accountString,
    password: '',
    twofa: '',
    mail: '',
    passmail: '',
    mailkp: '',
    cookie: '',
    token: '',
    username: accountString
  };
}

// Function to generate random business data
function generateBusinessData() {
  const businessNames = [
    'MAX Digital Marketing', 'Professional Marketing Agency', 'Tech Innovation Hub'
  ];

  const domains = [
    'gmail.com', 'outlook.com', 'yahoo.com', 'hotmail.com', 'business.com',
    'company.com', 'enterprise.com', 'solutions.com', 'services.com', 'group.com'
  ];

  const categories = [
    'ADVERTISING', 'AUTOMOTIVE', 'CONSUMER_PACKAGED_GOODS', 'ECOMMERCE', 
    'EDUCATION', 'ENERGY_AND_UTILITIES', 'ENTERTAINMENT_AND_MEDIA', 
    'FINANCIAL_SERVICES', 'GAMING', 'GOVERNMENT_AND_POLITICS', 'MARKETING', 
    'ORGANIZATIONS_AND_ASSOCIATIONS', 'PROFESSIONAL_SERVICES', 'RETAIL', 
    'TECHNOLOGY', 'TELECOM', 'TRAVEL', 'NON_PROFIT', 'RESTAURANT', 
    'HEALTH', 'LUXURY', 'OTHER'
  ];

  const addresses = [
    'Ho Chi Minh City, Vietnam', 'Hanoi, Vietnam', 'Da Nang, Vietnam',
    'Can Tho, Vietnam', 'Hai Phong, Vietnam', 'Bien Hoa, Vietnam',
    'Hue, Vietnam', 'Nha Trang, Vietnam', 'Buon Ma Thuot, Vietnam',
    'Vung Tau, Vietnam', 'Quy Nhon, Vietnam', 'Thai Nguyen, Vietnam'
  ];

  const randomBusinessName = businessNames[Math.floor(Math.random() * businessNames.length)];
  const randomDomain = domains[Math.floor(Math.random() * domains.length)];
  const randomCategory = categories[Math.floor(Math.random() * categories.length)];
  const randomAddress = addresses[Math.floor(Math.random() * addresses.length)];
  
  // Generate random numbers for phone and website
  const randomNum = Math.floor(Math.random() * 9999) + 1000;
  const phoneNum = Math.floor(Math.random() * 900000000) + 100000000;
  
  return {
    businessName: `${randomBusinessName} ${randomNum}`,
    businessEmail: `contact${randomNum}@${randomDomain}`,
    businessPhone: `+84${phoneNum}`,
    businessAddress: randomAddress,
    businessWebsite: `https://www.${randomBusinessName.toLowerCase().replace(/\s+/g, '')}.com`,
    businessCategory: randomCategory
  };
}

// Function to register Business Manager
async function registerBusinessManager(
  accessToken: string,
  sessionData: any,
  businessData?: any,
  proxyConfig?: any,
  options?: RegisterBMRequest['options']
): Promise<RegisterBMResponse> {
  try {
    // Generate random business data if not provided
    const baseData = businessData || generateBusinessData();
    const autoBusinessData = {
      ...baseData,
      businessName: options?.businessName || baseData.businessName
    };
    const createAdAccount = options?.createAdAccount !== false; // default true
    const createPixel = options?.createPixel === true; // default false
    const createCatalog = options?.createCatalog === true; // default false
    
    console.log('🏢 Bắt đầu đăng ký Business Manager:', autoBusinessData.businessName);
    console.log('📊 Dữ liệu tự động:', autoBusinessData);

    // Helper: register via Server2 GraphQL if requested
    if (options?.method === 'server2') {
      const server2 = await registerBusinessManagerServer2({
        sessionData,
        accessToken,
        businessName: autoBusinessData.businessName
      });
      if (server2.success && server2.businessManagerId) {
        const businessManagerId = server2.businessManagerId as string;
        const bmDetails = { link: `https://business.facebook.com/settings/info?business_id=${businessManagerId}` } as any;
        return {
          success: true,
          message: `Đăng ký Business Manager (Server2) thành công: ${autoBusinessData.businessName}`,
          businessManagerId,
          businessManagerUrl: bmDetails.link,
          data: {
            id: businessManagerId,
            name: autoBusinessData.businessName,
            link: bmDetails.link,
            generatedData: autoBusinessData
          }
        };
      }
      // Fall back to Graph API creation if Server2 fails
      console.log('⚠️ Server2 không tạo được BM, fallback sang Graph API...', server2?.message || '');
    }

    // Step 1: Create Business Manager (Graph API)
    const bmCreateUrl = 'https://graph.facebook.com/v19.0/me/businesses';
    const bmCreateData: any = {
      name: autoBusinessData.businessName,
      vertical: autoBusinessData.businessCategory || 'BUSINESS',
      access_token: accessToken
    };

    // Add optional fields
    if (autoBusinessData.businessEmail) {
      bmCreateData.primary_email = autoBusinessData.businessEmail;
    }
    if (autoBusinessData.businessPhone) {
      bmCreateData.primary_phone = autoBusinessData.businessPhone;
    }
    if (autoBusinessData.businessWebsite) {
      bmCreateData.website = autoBusinessData.businessWebsite;
    }
    if (autoBusinessData.businessAddress) {
      bmCreateData.address = autoBusinessData.businessAddress;
    }

    console.log('📝 Tạo Business Manager với dữ liệu:', bmCreateData);
    console.log('🍪 Session data:', {
      cookies: sessionData.cookies ? sessionData.cookies.substring(0, 50) + '...' : 'none',
      sessionKey: sessionData.sessionKey ? sessionData.sessionKey.substring(0, 20) + '...' : 'none',
      machineId: sessionData.machineId || 'none'
    });

    // Prepare headers with session data
    const headers: any = {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'application/json',
      'Accept-Language': 'en-US,en;q=0.9',
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
      'Origin': 'https://business.facebook.com',
      'Referer': 'https://business.facebook.com/',
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-site'
    };

    // Add cookies if available
    if (sessionData.cookies) {
      headers['Cookie'] = sessionData.cookies;
    }

    // Add session key and machine ID if available
    if (sessionData.sessionKey) {
      headers['X-FB-Session-Key'] = sessionData.sessionKey;
    }
    if (sessionData.machineId) {
      headers['X-FB-Machine-ID'] = sessionData.machineId;
    }

    const bmCreateResponse = await fetch(bmCreateUrl, {
      method: 'POST',
      headers: { ...headers, ...(sessionData.cookies ? { Cookie: sessionData.cookies } : {}) },
      body: JSON.stringify(bmCreateData)
    });

    const bmCreateResult = await bmCreateResponse.json();
    console.log('📊 Kết quả tạo BM:', bmCreateResult);

    if (bmCreateResult.error) {
      console.error('❌ Lỗi tạo Business Manager:', bmCreateResult.error);
      return {
        success: false,
        message: `Lỗi tạo Business Manager: ${bmCreateResult.error.error_user_title || 'Unknown error'}`
      };
    }

    if (!bmCreateResult.id) {
      return {
        success: false,
        message: 'Không nhận được Business Manager ID từ Facebook'
      };
    }

    const businessManagerId = bmCreateResult.id;
    console.log('✅ Tạo Business Manager thành công, ID:', businessManagerId);

    // Step 2: Get Business Manager details
    const bmDetailsUrl = `https://graph.facebook.com/v19.0/${businessManagerId}?fields=id,name,link,primary_email,primary_phone,website,verification_status,created_time&access_token=${accessToken}`;
    
    const bmDetailsResponse = await fetch(bmDetailsUrl, {
      headers: { ...headers, 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', ...(sessionData.cookies ? { Cookie: sessionData.cookies } : {}) }
    });

    const bmDetails = await bmDetailsResponse.json();
    console.log('📋 Chi tiết Business Manager:', bmDetails);

    // Step 3: Create Ad Account (optional)
    if (createAdAccount) {
      try {
        const adAccountUrl = `https://graph.facebook.com/v19.0/${businessManagerId}/adaccount`;
        const adAccountData = {
          name: `${autoBusinessData.businessName} Ad Account`,
          currency: 'USD',
          timezone_id: 7, // UTC+7 for Vietnam
          access_token: accessToken
        } as any;

        console.log('💳 Tạo Ad Account với dữ liệu:', adAccountData);

        const adAccountResponse = await fetch(adAccountUrl, {
          method: 'POST',
          headers: { ...headers, ...(sessionData.cookies ? { Cookie: sessionData.cookies } : {}) },
          body: JSON.stringify(adAccountData)
        });

        const adAccountResult = await adAccountResponse.json();
        console.log('💳 Kết quả tạo Ad Account:', adAccountResult);

        if (adAccountResult.id) {
          console.log('✅ Tạo Ad Account thành công, ID:', adAccountResult.id);
          bmDetails.adAccountId = adAccountResult.id;
        }

        // Step 3.1: Create Pixel under Ad Account (optional)
        if (createPixel && adAccountResult.id) {
          try {
            const actId = `act_${adAccountResult.id.replace('act_', '')}`;
            const pixelUrl = `https://graph.facebook.com/v19.0/${actId}/adspixels`;
            const pixelData: any = {
              name: options?.pixelName || `${autoBusinessData.businessName} Pixel`,
              access_token: accessToken
            };
            console.log('📈 Tạo Pixel:', pixelData);
            const pixelResp = await fetch(pixelUrl, { method: 'POST', headers: { ...headers, ...(sessionData.cookies ? { Cookie: sessionData.cookies } : {}) }, body: JSON.stringify(pixelData) });
            const pixelRes = await pixelResp.json();
            console.log('📈 Kết quả tạo Pixel:', pixelRes);
            if (pixelRes?.id) {
              bmDetails.pixelId = pixelRes.id;
            }
          } catch (pixelErr) {
            console.log('⚠️ Không thể tạo Pixel:', pixelErr);
          }
        }
      } catch (adAccountError) {
        console.log('⚠️ Không thể tạo Ad Account (có thể do hạn chế):', adAccountError);
      }
    }

    // Step 3.2: Create Product Catalog under Business (optional)
    if (createCatalog) {
      try {
        const catalogUrl = `https://graph.facebook.com/v19.0/${businessManagerId}/owned_product_catalogs`;
        const catalogData: any = {
          name: options?.catalogName || `${autoBusinessData.businessName} Catalog`,
          access_token: accessToken
        };
        console.log('🛍️ Tạo Catalog:', catalogData);
        const catalogResp = await fetch(catalogUrl, { method: 'POST', headers: { ...headers, ...(sessionData.cookies ? { Cookie: sessionData.cookies } : {}) }, body: JSON.stringify(catalogData) });
        const catalogRes = await catalogResp.json();
        console.log('🛍️ Kết quả tạo Catalog:', catalogRes);
        if (catalogRes?.id) {
          bmDetails.catalogId = catalogRes.id;
        }
      } catch (catalogErr) {
        console.log('⚠️ Không thể tạo Catalog:', catalogErr);
      }
    }

    return {
      success: true,
      message: `Đăng ký Business Manager thành công: ${autoBusinessData.businessName}`,
      businessManagerId: businessManagerId,
      businessManagerUrl: bmDetails.link || `https://business.facebook.com/settings/info?business_id=${businessManagerId}`,
      data: {
        id: businessManagerId,
        name: bmDetails.name,
        link: bmDetails.link,
        email: bmDetails.primary_email,
        phone: bmDetails.primary_phone,
        website: bmDetails.website,
        verification_status: bmDetails.verification_status,
        created_time: bmDetails.created_time,
        adAccountId: bmDetails.adAccountId,
        pixelId: bmDetails.pixelId,
        catalogId: bmDetails.catalogId,
        generatedData: autoBusinessData
      }
    };

  } catch (error) {
    console.error('❌ Lỗi đăng ký Business Manager:', error);
    return {
      success: false,
      message: `Lỗi hệ thống: ${error instanceof Error ? error.message : 'Unknown error'}`
    };
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Verify user authentication
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const raw = await request.json();
    const body: RegisterBMRequest & { loginFirst?: boolean; loginMethod?: 'cookie' | 'password' } = raw as any;
    const { 
      accountId, 
      useProxy = true,
      options
    } = body;

    if (!accountId) {
      return NextResponse.json({ 
        error: 'Account ID is required' 
      }, { status: 400 });
    }

    // Get account details
    const account = await (FacebookAccount as any).findOne({ 
      _id: accountId
    });

    if (!account) {
      return NextResponse.json({ 
        error: 'Account not found' 
      }, { status: 404 });
    }

    // Parse account data
    const accountData = parseAccountString(account.uid, account);
    
    // Prepare session data first
    let sessionData = {
      cookies: (account as any).cookie || account.cookies || '',
      sessionKey: account.sessionKey || '',
      machineId: account.machineId || '',
      secret: account.secret || ''
    };

    // Optional login-first to refresh cookies/session/token before registering BM
    let accessToken = account.eaabToken || account.eaagToken || account.accessToken;
    if (body.loginFirst !== false) {
      try {
        console.log('🔐 Đang thực hiện đăng nhập trước khi reg BM để làm mới session...');
        const endpoint = body.loginMethod === 'cookie' ? 'login-cookie' : 'login';
        const headers: any = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };
        const payload: any = { accountId: accountId, useProxy: true, fastMode: false };
        const resp = await fetch(`http://localhost:3000/api/facebook/${endpoint}`, { method: 'POST', headers, body: JSON.stringify(payload) });
        const loginResult = await resp.json();
        if (!loginResult.success) {
          console.log('⚠️ Đăng nhập trước thất bại, tiếp tục với session hiện có:', loginResult.message);
        } else {
          console.log('✅ Đăng nhập thành công, cập nhật session/token mới');
          const updatedAccount = await (FacebookAccount as any).findOne({ _id: accountId });
          accessToken = updatedAccount.eaabToken || updatedAccount.eaagToken || updatedAccount.accessToken || accessToken;
          sessionData.cookies = updatedAccount.cookie || updatedAccount.cookies || sessionData.cookies;
          sessionData.sessionKey = updatedAccount.sessionKey || sessionData.sessionKey;
          sessionData.machineId = updatedAccount.machineId || sessionData.machineId;
          sessionData.secret = updatedAccount.secret || sessionData.secret;
        }
      } catch (loginError) {
        console.log('⚠️ Không thể đăng nhập trước, tiếp tục với session hiện có');
      }
    }

    // Get proxy if needed
    let proxyConfig = null;
    if (useProxy) {
      try {
        const proxyResponse = await fetch('http://localhost:3000/api/proxy/get-proxy', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (proxyResponse.ok) {
          const proxyData = await proxyResponse.json();
          if (proxyData.success && proxyData.proxy) {
            proxyConfig = {
              host: proxyData.proxy.split(':')[0],
              port: parseInt(proxyData.proxy.split(':')[1]),
              protocol: 'http'
            };
          }
        }
      } catch (error) {
        console.log('⚠️ Proxy error - continuing without proxy');
      }
    }

    // Ensure cookies exist for Server2 method
    if (options?.method === 'server2' && (!sessionData.cookies || sessionData.cookies.length < 40)) {
      try {
        console.log('🍪 Server2 cần cookies, tiến hành đăng nhập để lấy cookies mới...');
        const endpoint = (body as any).loginMethod === 'cookie' ? 'login-cookie' : 'login';
        const headers: any = { 'Content-Type': 'application/json' };
        if (endpoint === 'login') headers['Authorization'] = `Bearer ${token}`;
        if (endpoint === 'login-cookie') headers['x-internal-call'] = '1';
        // Load ProxyFB keys if available for cookie login
        let proxyFBKeys: string[] | undefined; let proxyFBLocationId: number | undefined;
        // Fix: Ensure Settings is imported and handle missing Settings gracefully
        try {
          // Dynamically import Settings if not already imported
          const { default: Settings } = await import('@/models/Settings').catch(() => ({ default: undefined }));
          if (endpoint === 'login-cookie' && Settings) {
            const s = await (Settings as any).findOne({ userId: account.userId }).lean();
            if (Array.isArray(s?.proxyFBKeys) && s.proxyFBKeys.length > 0) proxyFBKeys = s.proxyFBKeys;
            if (typeof s?.proxyFBLocationId === 'number') proxyFBLocationId = s.proxyFBLocationId;
          }
        } catch (err) {
          console.log('⚠️ Could not load Settings for proxyFBKeys:', err);
        }
        const payload: any = { accountId, useProxy: true, fastMode: false, ...(proxyFBKeys ? { proxyFBKeys } : {}), ...(typeof proxyFBLocationId === 'number' ? { proxyFBLocationId } : {}) };
        const resp = await fetch(`http://localhost:3000/api/facebook/${endpoint}`, { method: 'POST', headers, body: JSON.stringify(payload) });
        const loginResult = await resp.json();
        if (loginResult?.success) {
          const refreshed = await (FacebookAccount as any).findOne({ _id: accountId });
          sessionData.cookies = refreshed.cookie || refreshed.cookies || sessionData.cookies;
          sessionData.sessionKey = refreshed.sessionKey || sessionData.sessionKey;
          sessionData.machineId = refreshed.machineId || sessionData.machineId;
          sessionData.secret = refreshed.secret || sessionData.secret;
          accessToken = refreshed.eaabToken || refreshed.eaagToken || refreshed.accessToken || accessToken;
        } else {
          console.log('⚠️ Đăng nhập để lấy cookies thất bại, tiếp tục với cookies hiện có');
        }
      } catch {}
    }

    // Register Business Manager with auto-generated data
    let bmResult = await registerBusinessManager(
      accessToken,
      sessionData,
      null, // Will auto-generate business data
      proxyConfig,
      options
    );

    // If failed due to token issue, try to login again and retry
    if (!bmResult.success && bmResult.message.includes('OAuthException')) {
      console.log('🔄 Token có thể hết hạn, thử đăng nhập lại...');
      
      try {
        const retryLoginResponse = await fetch('http://localhost:3000/api/facebook/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            accountId: accountId,
            useProxy: true,
            fastMode: false
          })
        });

        const retryLoginResult = await retryLoginResponse.json();
        
        if (retryLoginResult.success) {
          console.log('✅ Đăng nhập lại thành công, thử đăng ký BM lần nữa...');
          
          // Get new token and session data
          const refreshedAccount = await (FacebookAccount as any).findOne({ _id: accountId });
          const newAccessToken = refreshedAccount.eaagToken || refreshedAccount.accessToken;
          
          if (newAccessToken) {
            // Prepare new session data
            const newSessionData = {
              cookies: refreshedAccount.cookies || '',
              sessionKey: refreshedAccount.sessionKey || '',
              machineId: refreshedAccount.machineId || '',
              secret: refreshedAccount.secret || ''
            };

            // Retry Business Manager registration with new token and session
            bmResult = await registerBusinessManager(
              newAccessToken,
              newSessionData,
              null,
              proxyConfig,
              options
            );
          }
        }
      } catch (retryError) {
        console.log('⚠️ Không thể đăng nhập lại:', retryError);
      }
    }

    // Update account with BM info if successful
    if (bmResult.success && bmResult.businessManagerId) {
      const currentBmCount = account.bmCount || 0;
      const newBmCount = currentBmCount + 1;
      
      const updateData: any = {
        lastUpdated: new Date(),
        bmCount: newBmCount,
        log: `${account.log || ''}\n[${new Date().toLocaleString('vi-VN')}] Đăng ký BM thành công: ${bmResult.data?.generatedData?.businessName || 'Unknown'} (ID: ${bmResult.businessManagerId})`
      };

      // Update bmData with latest BM info
      const bmInfo = {
        id: bmResult.businessManagerId,
        name: bmResult.data?.generatedData?.businessName || 'Auto Generated BM',
        url: bmResult.businessManagerUrl,
        verification_status: bmResult.data?.verification_status || 'UNVERIFIED',
        created_time: new Date().toISOString(),
        email: bmResult.data?.email || bmResult.data?.generatedData?.businessEmail,
        phone: bmResult.data?.phone || bmResult.data?.generatedData?.businessPhone,
        website: bmResult.data?.website || bmResult.data?.generatedData?.businessWebsite,
        category: bmResult.data?.generatedData?.businessCategory || 'OTHER',
        adAccountId: bmResult.data?.adAccountId
      };

      // Add to bmData array if exists, otherwise create new
      if (account.bmData && Array.isArray(account.bmData)) {
        updateData.bmData = [...account.bmData, bmInfo];
      } else {
        updateData.bmData = [bmInfo];
      }
      
      updateData.$push = {
        businessManagers: {
          id: bmResult.businessManagerId,
          name: bmResult.data?.generatedData?.businessName || 'Auto Generated BM',
          url: bmResult.businessManagerUrl,
          createdAt: new Date(),
          data: bmResult.data
        }
      };

      console.log('💾 Lưu thông tin BM vào database:', {
        bmCount: newBmCount,
        bmId: bmResult.businessManagerId,
        bmName: bmResult.data?.generatedData?.businessName
      });

      await (FacebookAccount as any).findByIdAndUpdate(accountId, updateData);
    } else {
      // Update account with error log
      await (FacebookAccount as any).findByIdAndUpdate(accountId, {
        lastUpdated: new Date(),
        log: `${account.log || ''}\n[${new Date().toLocaleString('vi-VN')}] Lỗi đăng ký BM: ${bmResult.message}`
      });
    }

    return NextResponse.json({
      success: bmResult.success,
      message: bmResult.message,
      data: bmResult.success ? {
        businessManagerId: bmResult.businessManagerId,
        businessManagerUrl: bmResult.businessManagerUrl,
        details: bmResult.data
      } : undefined
    });

  } catch (error) {
    console.error('❌ Server error:', error);
    return NextResponse.json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
