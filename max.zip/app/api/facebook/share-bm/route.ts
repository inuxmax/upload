import { NextRequest, NextResponse } from 'next/server'
import mongoose from 'mongoose'
import connectMongoDB from '@/lib/mongodb'
import FacebookAccount from '@/models/FacebookAccount'
import Settings from '@/models/Settings'
import { emitLog } from '@/lib/log-bus'
import { getEAABToken, getEAAGToken } from '@/lib/facebook-login.js'
import { getProxyFromProxyFB, type ProxyConfig } from '@/lib/proxyfb'
import { HttpsProxyAgent } from 'https-proxy-agent'

type ShareBMRequest = {
  accountId: string
  bmId?: string
  shareAll?: boolean
  roles?: string[]
  role?: 'ADMIN' | 'EMPLOYEE'
  quantity?: number
  email?: string
  useMail1s?: boolean
  mail1sApiKey?: string
  mail1sAddress?: string
  loginFirst?: boolean
  loginMethod?: 'cookie' | 'password'
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB()
    const body = (await request.json()) as ShareBMRequest

    const {
      accountId,
      bmId,
      shareAll = false,
      roles = [
        'DEFAULT',
        'MANAGE',
        'DEVELOPER',
        'EMPLOYEE',
        'ASSET_MANAGE',
        'ASSET_VIEW',
        'PEOPLE_MANAGE',
        'PEOPLE_VIEW',
        'PARTNERS_VIEW',
        'PARTNERS_MANAGE',
        'PROFILE_MANAGE'
      ],
      role,
      quantity = 1,
      email,
      useMail1s = false,
      mail1sApiKey,
      mail1sAddress,
      loginFirst = false,
      loginMethod = 'cookie'
    } = body

    if (!accountId) {
      return NextResponse.json({ success: false, message: 'accountId is required' }, { status: 400 })
    }

    const account: any = await (FacebookAccount as any).findById(accountId)
    if (!account) {
      return NextResponse.json({ success: false, message: 'Account not found' }, { status: 404 })
    }

    const userId = String(account.userId || '')
    const authHeader = request.headers.get('authorization') || ''

    // Optional login-first
    if (loginFirst) {
      try {
        // Load ProxyFB keys to pass along for cookie login
        let proxyFBKeys: string[] | undefined
        let proxyFBLocationId: number | undefined
        try {
          const s = await (Settings as any).findOne({ userId }).lean()
          if (Array.isArray(s?.proxyFBKeys) && s.proxyFBKeys.length > 0) proxyFBKeys = s.proxyFBKeys
          if (typeof s?.proxyFBLocationId === 'number') proxyFBLocationId = s.proxyFBLocationId
        } catch {}

        const endpoint = loginMethod === 'password' ? 'login' : 'login-cookie'
        const headers: any = { 'Content-Type': 'application/json' }
        if (endpoint === 'login') headers['Authorization'] = authHeader
        if (endpoint === 'login-cookie') headers['x-internal-call'] = '1'
        const payload: any = { accountId, useProxy: true, ...(proxyFBKeys ? { proxyFBKeys } : {}), ...(typeof proxyFBLocationId === 'number' ? { proxyFBLocationId } : {}) }
        const resp = await fetch(`http://localhost:3000/api/facebook/${endpoint}`, { method: 'POST', headers, body: JSON.stringify(payload) })
        const j = await resp.json().catch(() => ({}))
        if (!resp.ok || j?.success === false) {
          return NextResponse.json({ success: false, message: `Login-first failed: ${j?.message || resp.status}` }, { status: 400 })
        }
      } catch (e) {
        return NextResponse.json({ success: false, message: `Login-first error: ${(e as any)?.message || e}` }, { status: 500 })
      }
    }

    // Ensure EAAB token
    let eaabToken: string | null = account.eaabToken || null
    let eaagToken: string | null = account.eaagToken || null

    // Prefer proxy when fetching tokens if available
    let proxyConfig: ProxyConfig | null = null
    try {
      const settings = await (Settings as any).findOne({ userId }).lean()
      const keys: string[] = Array.isArray(settings?.proxyFBKeys) ? settings.proxyFBKeys : []
      const locationId: number = typeof settings?.proxyFBLocationId === 'number' ? settings.proxyFBLocationId : 1
      if (keys.length > 0) {
        proxyConfig = await getProxyFromProxyFB(keys, locationId, 8000, userId)
      }
    } catch {}

    if (!eaabToken) {
      try {
        eaabToken = await getEAABToken(account.cookie, account.uid, proxyConfig || undefined)
      } catch {}
    }
    if (!eaagToken) {
      try {
        eaagToken = await getEAAGToken(account.cookie, account.uid, proxyConfig || undefined)
      } catch {}
    }

    if (!eaabToken && !eaagToken) {
      return NextResponse.json({ success: false, message: 'Không có EAAB/EAAG token. Hãy đăng nhập lại.' }, { status: 400 })
    }

    // Determine target email
    let targetEmail = email || ''
    let createdEmail = ''
    if (useMail1s) {
      const DEFAULT_MAIL1S = '4dec550e-b261-422a-8f7d-ac364177643d'
      const effectiveApiKey = String(mail1sApiKey || DEFAULT_MAIL1S)
      // Create or use provided address
      const desired = mail1sAddress || `fb_${Math.random().toString(36).slice(2, 10)}@mail1s.net`
      const createRes = await fetch('https://mail1s.net/api/v1/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'wrdo-api-key': effectiveApiKey },
        body: JSON.stringify({ emailAddress: desired })
      })
      if (!createRes.ok && createRes.status !== 409) {
        const t = await createRes.text()
        return NextResponse.json({ success: false, message: `Mail1s create failed: ${t}` }, { status: 400 })
      }
      targetEmail = desired
      createdEmail = desired
    }

    if (!targetEmail) {
      return NextResponse.json({ success: false, message: 'Thiếu email để share (hoặc bật useMail1s)' }, { status: 400 })
    }

    // Discover BM IDs
    const tokenForGraph = eaabToken || eaagToken!
    let bmIds: string[] = []
    if (shareAll) {
      try {
        const url = new URL('https://graph.facebook.com/v19.0/me/businesses')
        url.searchParams.set('fields', 'id,name')
        url.searchParams.set('access_token', tokenForGraph)
        const res = await fetch(url.toString())
        const js = await res.json()
        bmIds = Array.isArray(js?.data) ? js.data.map((b: any) => b.id).filter(Boolean) : []
      } catch {}
    } else if (bmId) {
      bmIds = [bmId]
    }

    if (bmIds.length === 0) {
      return NextResponse.json({ success: false, message: 'Không tìm thấy BM để share' }, { status: 400 })
    }

    const shared: any[] = []
    const failed: any[] = []

    for (const id of bmIds) {
      try {
        // Resolve role from input
        let effectiveRole = role && (role === 'ADMIN' || role === 'EMPLOYEE') ? role : undefined
        if (!effectiveRole) {
          const wantsAdmin = roles.some(r => ['MANAGE','PEOPLE_MANAGE','PROFILE_MANAGE','PARTNERS_MANAGE','DEFAULT'].includes(r))
          effectiveRole = wantsAdmin ? 'ADMIN' : 'EMPLOYEE'
        }
        const roleForGraph = effectiveRole

        // Primary: Marketing API invitation edge
        const formInvite = new URLSearchParams()
        formInvite.set('email', targetEmail)
        formInvite.set('role', roleForGraph)
        formInvite.set('invite', 'true')

        const inviteUrl = `https://graph.facebook.com/v19.0/${encodeURIComponent(id)}/userinvitations?access_token=${encodeURIComponent(tokenForGraph)}`
        const cookies = (account as any)?.cookie || (account as any)?.cookies || ''
        const headers: any = {
          'accept': '*/*',
          'content-type': 'application/x-www-form-urlencoded',
          'user-agent': 'Mozilla/5.0',
          ...(cookies ? { Cookie: cookies } : {}),
          'origin': 'https://www.facebook.com',
          'referer': 'https://www.facebook.com'
        }
        const agent = proxyConfig ? new HttpsProxyAgent(`${proxyConfig.protocol}://${proxyConfig.host}:${proxyConfig.port}`) : undefined

        let resp = await fetch(inviteUrl, { method: 'POST', headers, body: formInvite, ...(agent ? { agent } : {}) } as any)
        let text = await resp.text()
        if (!resp.ok) {
          // Fallback: legacy business_users (rarely works, but keep as backup)
          const formLegacy = new URLSearchParams()
          formLegacy.set('brandId', id)
          formLegacy.set('email', targetEmail)
          // If single role selected, map to full roles list accordingly
          const adminRoles = ['DEFAULT','MANAGE','DEVELOPER','EMPLOYEE','ASSET_MANAGE','ASSET_VIEW','PEOPLE_MANAGE','PEOPLE_VIEW','PARTNERS_VIEW','PARTNERS_MANAGE','PROFILE_MANAGE']
          const employeeRoles = ['EMPLOYEE','ASSET_VIEW','PEOPLE_VIEW','PARTNERS_VIEW']
          const legacyRoles = effectiveRole === 'ADMIN' ? adminRoles : employeeRoles
          formLegacy.set('roles', JSON.stringify(legacyRoles))
          formLegacy.set('method', 'post')
          formLegacy.set('suppress_http_code', '1')
          // extra scenario flags for parity with curl
          formLegacy.set('__activeScenarioIDs', '[]')
          formLegacy.set('__activeScenarios', '[]')
          formLegacy.set('__interactionsMetadata', '[]')
          formLegacy.set('pretty', '0')
          const legacyUrl = `https://z-p3-graph.facebook.com/v3.0/${encodeURIComponent(id)}/business_users?access_token=${encodeURIComponent(tokenForGraph)}&__cppo=1`
          resp = await fetch(legacyUrl, { method: 'POST', headers, body: formLegacy, ...(agent ? { agent } : {}) } as any)
          text = await resp.text()
        }
        if (!resp.ok) {
          failed.push({ bmId: id, status: resp.status, body: text })
          continue
        }
        shared.push({ bmId: id, body: text })
      } catch (e: any) {
        failed.push({ bmId: id, error: e?.message || String(e) })
      }
    }

    // If Mail1s used, wait then poll inbox and try find Facebook invitation URL
    let confirmations: { title: string; url: string }[] = []
    if (useMail1s && createdEmail) {
      const sleep = (ms: number) => new Promise(res => setTimeout(res, ms))
      try {
        // Wait 10s for email delivery
        await sleep(10000)
        const invitationRegex = /https:\/\/business\.facebook\.com\/invitation\/\?token=[^"'\s<>]+/i
        for (let attempt = 0; attempt < 5; attempt++) {
          const inboxUrl = `https://mail1s.net/api/v1/email/inbox?emailAddress=${encodeURIComponent(createdEmail)}&page=1&size=10`
          const DEFAULT_MAIL1S = '4dec550e-b261-422a-8f7d-ac364177643d'
          const effectiveApiKey = String(mail1sApiKey || DEFAULT_MAIL1S)
          const inboxRes = await fetch(inboxUrl, { headers: { 'wrdo-api-key': effectiveApiKey } })
          const js = await inboxRes.json()
          const list: any[] = Array.isArray(js?.list) ? js.list : []
          confirmations = []
          for (const m of list) {
            const title: string = m?.subject || m?.title || ''
            const content: string = m?.html || m?.text || ''
            const match = String(content).match(invitationRegex)
            if (match) {
              confirmations.push({ title: title || 'Facebook invitation', url: match[0] })
            }
          }
          if (confirmations.length > 0) break
          await sleep(2000)
        }
      } catch {}
    }

    return NextResponse.json({ success: true, message: 'Share BM completed', data: { email: targetEmail, shared, failed, confirmations } })
  } catch (e: any) {
    return NextResponse.json({ success: false, message: e?.message || 'Internal error' }, { status: 500 })
  }
}


