import { NextRequest, NextResponse } from 'next/server'
import FacebookAccount from '@/models/FacebookAccount'
import connectDB from '@/lib/mongodb'
import jwt from 'jsonwebtoken'

export async function POST(request: NextRequest) {
  try {
    // Verify JWT token
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    
    await connectDB()

    const { accountId, tkqcData, bmData, accountInfo, tkqcCount, bmCount } = await request.json()

    if (!accountId) {
      return NextResponse.json({ error: 'Account ID is required' }, { status: 400 })
    }

    // Cập nhật Facebook account với dữ liệu TKQC
    const updatedAccount = await (FacebookAccount as any).findByIdAndUpdate(
      accountId,
      {
        $set: {
          tkqcData: tkqcData || [],
          bmData: bmData || [],
          accountInfo: accountInfo || {},
          tkqcCount: tkqcCount || 0,
          bmCount: bmCount || 0,
          lastTkqcCheck: new Date(),
          log: `TKQC: ${tkqcCount || 0} accounts, ${bmCount || 0} BM`,
          status: 'active'
        }
      },
      { new: true }
    )

    if (!updatedAccount) {
      return NextResponse.json({ error: 'Account not found' }, { status: 404 })
    }

    return NextResponse.json({
      success: true,
      message: 'TKQC data updated successfully',
      data: {
        accountId: updatedAccount._id,
        tkqcCount: updatedAccount.tkqcCount,
        bmCount: updatedAccount.bmCount
      }
    })

  } catch (error) {
    console.error('Error updating TKQC data:', error)
    return NextResponse.json(
      { error: 'Internal server error', success: false },
      { status: 500 }
    )
  }
}
