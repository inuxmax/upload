'use server'

import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import FacebookAccount from '@/models/FacebookAccount'
import OutlookAccount from '@/models/OutlookAccount'
import Transaction from '@/models/Transaction'
import ShopOrder from '@/models/ShopOrder'
import { promises as fs } from 'fs'
import path from 'path'
import SystemSettings from '@/models/SystemSettings'
import mongoose from 'mongoose'

async function getUserFromToken(token: string) {
  try {
    const response = await fetch('http://localhost:3000/api/auth/verify', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
    if (response.ok) return await response.json()
  } catch {}
  return null
}

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '') || ''
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const user = await getUserFromToken(token)
    if (!user) return NextResponse.json({ error: 'Invalid token' }, { status: 401 })

    await connectMongoDB()

    const userId = user.userId
    const userIdObj = new mongoose.Types.ObjectId(String(userId))

    const [fbCount, outlookCount] = await Promise.all([
      FacebookAccount.countDocuments({ userId: userIdObj }),
      OutlookAccount.countDocuments({ userId: String(userId) })
    ])

    const [orders, deposits, welcome, purchasedAgg] = await Promise.all([
      (ShopOrder as any)
        .find({ userId })
        .sort({ createdAt: -1 })
        .limit(10)
        .lean(),
      (Transaction as any)
        .find({ userId, type: 'deposit' })
        .sort({ createdAt: -1 })
        .limit(10)
        .lean(),
      (SystemSettings as any).findOne({ type: 'welcome_popup' }).lean(),
      (ShopOrder as any).aggregate([
        { $match: { userId: userIdObj, status: 'completed' } },
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ])
    ])

    // Read CHANGELOG.md (best-effort)
    let changelog: string[] = []
    try {
      const changelogPath = path.join(process.cwd(), 'CHANGELOG.md')
      const content = await fs.readFile(changelogPath, 'utf8')
      changelog = content.split('\n').slice(0, 100)
    } catch {}

    return NextResponse.json({
      success: true,
      data: {
        totals: {
          facebookAccounts: fbCount,
          outlookAccounts: outlookCount,
          purchasedAccounts: Array.isArray(purchasedAgg) && purchasedAgg[0]?.total ? purchasedAgg[0].total : 0
        },
        orders,
        deposits,
        changelog,
        notifications: (welcome?.data?.enabled && welcome?.data?.showOnDashboard)
          ? [{ id: 'welcome', message: `${welcome?.data?.title || ''}: ${welcome?.data?.message || ''}` }]
          : []
      }
    })
  } catch (err: any) {
    return NextResponse.json({ error: 'Internal server error', details: err?.message }, { status: 500 })
  }
}


