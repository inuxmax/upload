import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import ShopOrder from '@/models/ShopOrder'

function toTextLines(order: any): string {
  // If accounts exist, join them; else produce one line with product summary
  const lines: string[] = []
  if (Array.isArray(order?.accounts) && order.accounts.length > 0) {
    for (const acc of order.accounts) {
      lines.push(String(acc))
    }
  } else {
    lines.push(`${order?.productName || order?.product?.name || 'Product'} x${order?.amount || 0}`)
  }
  return lines.join('\n')
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '') || ''
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    await connectMongoDB()
    const order = await (ShopOrder as any).findById(params.id).lean()
    if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const content = toTextLines(order)
    return new NextResponse(content, {
      status: 200,
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Disposition': `attachment; filename="order-${order.transId || order._id}.txt"`
      }
    })
  } catch (e: any) {
    return NextResponse.json({ error: 'Internal server error', details: e?.message }, { status: 500 })
  }
}


