import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import OutlookAccount from '@/models/OutlookAccount';
import { loginOutlook } from '@/lib/outlook-login.js';

async function verifyUserToken(request: NextRequest) {
  try {
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return null;
    }

    const jwt = (await import('jsonwebtoken')).default;
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key') as any;
    
    return decoded;
  } catch (error) {
    return null;
  }
}

// GET - Lấy danh sách Outlook accounts của user
export async function GET(request: NextRequest) {
  try {
    const user = await verifyUserToken(request);
    if (!user?.userId) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }

    await dbConnect();
    
    const accounts = await (OutlookAccount as any).find({ userId: user.userId }).sort({ createdAt: -1 });

    // Include password for copy functionality
    const safeAccounts = accounts.map((account: any) => ({
      _id: account._id,
      email: account.email,
      password: account.password, // Include password
      status: account.status,
      lastLogin: account.lastLogin,
      lastMailCheck: account.lastMailCheck,
      errorMessage: account.errorMessage,
      lastError: account.lastError,
      createdAt: account.createdAt,
      updatedAt: account.updatedAt
    }));

    return NextResponse.json({
      success: true,
      data: safeAccounts
    });

  } catch (error) {
    // Reduced logging to prevent console spam
    return NextResponse.json(
      { success: false, message: 'Lỗi server nội bộ' },
      { status: 500 }
    );
  }
}

// POST - Thêm Outlook account mới
export async function POST(request: NextRequest) {
  try {
    const user = await verifyUserToken(request);
    if (!user?.userId) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Unauthorized',
          error_type: 'auth_error'
        },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { email, password, proxy, skipValidation = false, refreshToken, clientId } = body;
    
    // Reduced logging to prevent console spam

    // Validate required fields
    if (!email || !password) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Email và mật khẩu là bắt buộc',
          error_type: 'validation_error'
        },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Định dạng email không hợp lệ',
          error_type: 'validation_error'
        },
        { status: 400 }
      );
    }

    await dbConnect();

    // Check if account already exists
    const existingAccount = await (OutlookAccount as any).findOne({ email: email.toLowerCase() });
    if (existingAccount) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Email này đã được thêm vào hệ thống',
          error_type: 'duplicate_error'
        },
        { status: 409 }
      );
    }

    // Reduced logging to prevent console spam

    // Create new account
    const accountData: any = {
      userId: user.userId,
      email: email.toLowerCase(),
      password: password,
      proxy: proxy || null
    }
    
    // Add refresh_token and client_id if provided
    if (refreshToken) {
      accountData.refreshToken = refreshToken
    }
    if (clientId) {
      accountData.clientId = clientId
    }
    
    const newAccount = new OutlookAccount(accountData);

    if (!skipValidation) {
      // Try to login to validate credentials
      const loginResult = await loginOutlook(email, password, proxy);

      if (!loginResult.success) {
        return NextResponse.json(
          { 
            success: false, 
            message: `Không thể đăng nhập: ${loginResult.message}`,
            error_type: 'auth_error'
          },
          { status: 401 }
        );
      }

      // Update with token information
      await newAccount.updateTokens(loginResult);
    } else {
      // For bulk import, just save without validation
      await (newAccount as any).save();
    }

    // Reduced logging to prevent console spam

    return NextResponse.json({
      success: true,
      message: 'Thêm tài khoản Outlook thành công',
      data: {
        _id: newAccount._id,
        email: newAccount.email,
        status: newAccount.status,
        lastLogin: newAccount.lastLogin,
        createdAt: newAccount.createdAt
      }
    });

  } catch (error) {
    // Reduced logging to prevent console spam
    return NextResponse.json(
      { success: false, message: 'Lỗi server nội bộ' },
      { status: 500 }
    );
  }
}

// DELETE - Xóa Outlook account
export async function DELETE(request: NextRequest) {
  try {
    const user = await verifyUserToken(request);
    if (!user?.userId) {
      return NextResponse.json(
        { success: false, message: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const accountId = searchParams.get('id');

    if (!accountId) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Account ID là bắt buộc',
          error_type: 'validation_error'
        },
        { status: 400 }
      );
    }

    await dbConnect();

    // Find and delete account (only if it belongs to the user)
    const deletedAccount = await (OutlookAccount as any).findOneAndDelete({
      _id: accountId,
      userId: user.userId
    });

    if (!deletedAccount) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Không tìm thấy tài khoản hoặc bạn không có quyền xóa',
          error_type: 'not_found'
        },
        { status: 404 }
      );
    }

    // Reduced logging - only log errors

    return NextResponse.json({
      success: true,
      message: 'Xóa tài khoản Outlook thành công'
    });

  } catch (error) {
    // Reduced logging to prevent console spam
    return NextResponse.json(
      { success: false, message: 'Lỗi server nội bộ' },
      { status: 500 }
    );
  }
}