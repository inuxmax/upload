import { NextRequest, NextResponse } from 'next/server';
import { loginOutlook } from '@/lib/outlook-login.js';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, proxy } = body;

    // Validate required fields
    if (!email || !password) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Email và mật khẩu là bắt buộc',
          error_type: 'validation_error'
        },
        { status: 400 }
      );
    }

    console.log(`🔄 DEBUG: Testing Outlook login for ${email}`);
    console.log(`🔧 DEBUG: Using proxy: ${proxy || 'No proxy'}`);

    // Call the login function with detailed logging
    const result = await loginOutlook(email, password, proxy);

    console.log(`🔍 DEBUG: Login result:`, {
      success: result.success,
      message: result.message,
      hasAccessToken: !!result.access_token,
      hasRefreshToken: !!result.refresh_token
    });

    if (result.success) {
      return NextResponse.json({
        success: true,
        message: result.message,
        debug: {
          hasAccessToken: !!result.access_token,
          hasRefreshToken: !!result.refresh_token,
          tokenType: result.token_type,
          expiresIn: result.expires_in,
          scope: result.scope
        }
      });
    } else {
      return NextResponse.json(
        { 
          success: false, 
          message: result.message,
          error_type: 'auth_error'
        },
        { status: 401 }
      );
    }

  } catch (error) {
    console.error('❌ DEBUG: Lỗi server khi test Outlook login:', error);
    return NextResponse.json(
      { 
        success: false, 
        message: `Lỗi server: ${error.message}`,
        error_type: 'server_error'
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Outlook Debug API - Use POST method to test login',
    usage: {
      method: 'POST',
      body: {
        email: 'your-email@outlook.com',
        password: 'your-password',
        proxy: 'http://proxy:port (optional)'
      }
    }
  });
}
