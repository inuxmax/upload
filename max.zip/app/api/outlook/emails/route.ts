import { NextRequest, NextResponse } from 'next/server'
import { isRunCanceled } from '@/lib/cancel-jobs'
export const dynamic = 'force-dynamic'
import { publish } from '@/lib/outlook-logs'

const FTOOL_API_BASE = 'https://api.ftool.vn/api'

async function verifyUserToken(request: NextRequest) {
  try {
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) return null
    const jwt = (await import('jsonwebtoken')).default
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key') as any
    return decoded
  } catch (error) {
    return null
  }
}

// POST - Get emails using ftool.vn API
export async function POST(request: NextRequest) {
  try {
    let body: any = null
    try { body = await request.json() } catch { return NextResponse.json({ success: false, error: 'Canceled or invalid body' }, { status: 499 }) }
    console.log('🔍 DEBUG - Request body:', JSON.stringify(body, null, 2))
    
    let { email, password, count = 10, keyword = '', accountId, runId } = body as any
    if (isRunCanceled(runId)) { return NextResponse.json({ success: false, error: 'Canceled' }, { status: 499 }) }
    let resolvedAccountId: string | undefined = accountId

    // If password not provided, try to load from DB using accountId or email
    if (!password) {
      try {
        const user = await verifyUserToken(request)
        if (user?.userId) {
          const dbConnect = (await import('@/lib/mongodb')).default
          await dbConnect()
          const OutlookAccount = (await import('@/models/OutlookAccount')).default as any
          let accountDoc = null
          if (accountId) {
            accountDoc = await (OutlookAccount as any).findOne({ _id: accountId, userId: user.userId })
          } else if (email) {
            accountDoc = await (OutlookAccount as any).findOne({ email: (email as string).toLowerCase(), userId: user.userId })
          }
          if (accountDoc) {
            email = accountDoc.email
            password = accountDoc.password
            try { resolvedAccountId = accountDoc._id?.toString?.() || resolvedAccountId } catch {}
            console.log('🔍 DEBUG - Loaded password from DB for email:', email)
          }
        }
      } catch (e) {
        console.log('⚠️ Could not load password from DB:', e instanceof Error ? e.message : e)
      }
    }

    if (!email || !password) {
      console.log('❌ Missing email or password after DB fallback:', { email: !!email, password: !!password, accountId: !!accountId })
      return NextResponse.json({
        success: false,
        error: 'Email and password are required'
      }, { status: 400 })
    }

    console.log('📧 Getting emails for:', email)

    // Publish realtime log: reading
    try {
      await publish({
        accountId: resolvedAccountId,
        level: 'info',
        status: 'reading',
        message: `Đang đọc mail: ${email}`
      })
    } catch {}

    // Use the correct endpoint and format based on our testing
    const apiUrl = `${FTOOL_API_BASE}/emails`
    const requestBody = {
      email: `${email}|${password}`,
      count: parseInt(count),
      keyword: keyword
    }

    console.log('🔍 DEBUG - Calling ftool.vn API with:', {
      url: apiUrl,
      requestBody
    })
    
    // External request with abort support
    const controller = new AbortController()
    const cancelPoll = setInterval(() => {
      if (isRunCanceled(runId)) {
        try { controller.abort() } catch {}
      }
    }, 200)

    let response: Response
    try {
      response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json'
        },
        body: JSON.stringify(requestBody),
        signal: controller.signal
      })
    } catch (err: any) {
      clearInterval(cancelPoll)
      if (err?.name === 'AbortError' || isRunCanceled(runId)) {
        return NextResponse.json({ success: false, error: 'Canceled' }, { status: 499 })
      }
      throw err
    } finally {
      clearInterval(cancelPoll)
    }
    
    console.log('🔍 DEBUG - ftool.vn API response status:', response.status, response.statusText)

    if (!response.ok) {
      const errorText = await response.text()
      console.log('❌ ftool.vn API HTTP error:', errorText)
      try {
        await publish({
          accountId: resolvedAccountId,
          level: 'error',
          status: 'error',
          message: `API lỗi: ${response.status} - ${errorText}`
        })
      } catch {}
      return NextResponse.json({
        success: false,
        error: `ftool.vn API error: ${response.status} - ${errorText}`
      }, { status: response.status })
    }

    const result = await response.json()
    console.log('🔍 DEBUG - ftool.vn API response:', JSON.stringify(result, null, 2))

    if (result.success) {
      console.log('✅ Successfully got response from ftool.vn API')
      
      // Extract emails from the nested structure: result.data.data.messages
      let emails: any[] = []
      let emailCount = 0
      
      if (result.data && result.data.data && result.data.data.messages) {
        emails = result.data.data.messages
        emailCount = emails.length
        console.log('🔍 DEBUG - Found emails in data.data.messages:', emailCount)
      } else if (result.data && result.data.messages) {
        emails = result.data.messages
        emailCount = emails.length
        console.log('🔍 DEBUG - Found emails in data.messages:', emailCount)
      } else if (result.data && Array.isArray(result.data)) {
        emails = result.data
        emailCount = emails.length
        console.log('🔍 DEBUG - Found emails as direct data array:', emailCount)
      }
      
      console.log('🔍 DEBUG - Final email extraction result:', {
        emailsFound: emails.length,
        emailCount: emailCount,
        hasEmailsArray: Array.isArray(emails),
        responseKeys: Object.keys(result),
        dataKeys: result.data ? Object.keys(result.data) : [],
        nestedDataKeys: result.data?.data ? Object.keys(result.data.data) : []
      })
      
      // Publish realtime log: success + completed
      try {
        await publish({
          accountId: resolvedAccountId,
          level: 'info',
          status: 'success',
          emailCount,
          message: `Đăng nhập thành công - ${emailCount} email`
        })
        await publish({
          accountId: resolvedAccountId,
          level: 'debug',
          status: 'completed',
          emailCount,
          message: 'Hoàn thành đọc mail'
        })
      } catch {}

      return NextResponse.json({
        success: true,
        data: {
          emails: emails,
          messages: emails, // Also provide as messages for compatibility
          count: emailCount,
          total: emailCount
        },
        message: 'Emails retrieved successfully',
        emailCount: emailCount
      })
    } else {
      console.log('❌ ftool.vn API returned success: false:', result.error || result.message)
      try {
        await publish({
          accountId: resolvedAccountId,
          level: 'error',
          status: 'error',
          message: result.error?.message || result.message || 'API trả về success=false'
        })
      } catch {}
      return NextResponse.json({
        success: false,
        error: result.error?.message || result.message || 'ftool.vn API returned success: false'
      }, { status: 400 })
    }

  } catch (error) {
    console.error('❌ Outlook emails API error:', error)
    try {
      await publish({
        accountId: undefined,
        level: 'error',
        status: 'error',
        message: error instanceof Error ? error.message : 'Unknown error'
      })
    } catch {}
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

// DELETE - Delete all emails using ftool.vn API
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json({
        success: false,
        error: 'Email and password are required'
      }, { status: 400 })
    }

    console.log('🗑️ Deleting emails for:', email)

    // Format email for ftool API
    const emailFormat = `${email}|${password}`

    // Call ftool.vn API
    const response = await fetch(`${FTOOL_API_BASE}/emails/delete`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      body: JSON.stringify({
        email: emailFormat
      })
    })

    const result = await response.json()

    if (result.success) {
      console.log('✅ Successfully deleted emails:', result.data?.deleted_count || 0)
      return NextResponse.json({
        success: true,
        data: result.data,
        message: 'Emails deleted successfully'
      })
    } else {
      console.log('❌ Failed to delete emails:', result.error?.message || 'Unknown error')
      return NextResponse.json({
        success: false,
        error: result.error?.message || 'Failed to delete emails'
      }, { status: 400 })
    }

  } catch (error) {
    console.error('❌ Outlook delete API error:', error)
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

// GET - API documentation
export async function GET() {
  return NextResponse.json({
    message: 'Outlook Emails API (using ftool.vn)',
    endpoints: {
      get_emails: {
        method: 'POST',
        body: {
          accountId: 'optional-preferred',
          email: 'user@outlook.com (optional if accountId provided)',
          password: 'password123 (optional if accountId provided)',
          count: 10,
          keyword: 'verification,code'
        }
      },
      delete_emails: {
        method: 'DELETE',
        body: {
          email: 'user@outlook.com',
          password: 'password123'
        }
      }
    },
    powered_by: 'https://api.ftool.vn'
  })
}
