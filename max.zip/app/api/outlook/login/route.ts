import { NextRequest, NextResponse } from 'next/server';
import { loginOutlook } from '@/lib/outlook-login.js';
import { isRunCanceled } from '@/lib/cancel-jobs'
export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    // Defensive body parse (abort may cut the body)
    let body: any = null
    try { body = await request.json() } catch { return NextResponse.json({ success: false, message: 'Canceled or invalid body' }, { status: 499 }) }
    const { email, password, proxy, runId } = body;

    // Validate required fields
    if (!email || !password) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Email và mật khẩu là bắt buộc',
          error_type: 'validation_error'
        },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Định dạng email không hợp lệ',
          error_type: 'validation_error'
        },
        { status: 400 }
      );
    }

    if (isRunCanceled(runId)) {
      return NextResponse.json({ success: false, message: 'Canceled' }, { status: 499 })
    }
    console.log(`🔄 API: Đang xử lý đăng nhập Outlook cho ${email}`);

    // Call the login function
    const result = await loginOutlook(email, password, proxy, runId);

    if (result.success) {
      console.log(`✅ API: Đăng nhập Outlook thành công cho ${email}`);
      return NextResponse.json({
        success: true,
        message: result.message,
        data: {
          access_token: result.access_token,
          refresh_token: result.refresh_token,
          expires_in: result.expires_in,
          scope: result.scope,
          token_type: result.token_type
        }
      });
    } else {
      console.log(`❌ API: Đăng nhập Outlook thất bại cho ${email}: ${result.message}`);
      
      // Determine appropriate status code based on error type
      let statusCode = 400;
      if (result.message.includes('không chính xác') || result.message.includes('incorrect')) {
        statusCode = 401;
      } else if (result.message.includes('khóa') || result.message.includes('locked')) {
        statusCode = 403;
      } else if (result.message.includes('proxy')) {
        statusCode = 502;
      }

      return NextResponse.json(
        { 
          success: false, 
          message: result.message,
          error_type: 'auth_error'
        },
        { status: statusCode }
      );
    }

  } catch (error) {
    console.error('❌ API: Lỗi server khi đăng nhập Outlook:', error);
    return NextResponse.json(
      { 
        success: false, 
        message: 'Lỗi server nội bộ',
        error_type: 'server_error'
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json(
    { 
      success: false, 
      message: 'Method not allowed. Use POST instead.',
      error_type: 'method_not_allowed'
    },
    { status: 405 }
  );
}
