import { NextRequest, NextResponse } from 'next/server'
import dbConnect from '../../../../lib/mongodb'
import OutlookAccount from '../../../../models/OutlookAccount'

interface ScrapingSettings {
  headless: boolean
  timeout: number
  waitForLoad: number
  debugMode?: boolean
}

interface EmailData {
  subject: string
  sender: string
  from: string
  received_time: string
  body: string
  body_type: string
  folder: string
}

export async function POST(request: NextRequest) {
  try {
    const { accountId, scrapingSettings, filterSender, minutes } = await request.json()

    if (!accountId) {
      return NextResponse.json({
        success: false,
        message: 'Account ID is required'
      }, { status: 400 })
    }

    // Connect to database
    await dbConnect()

    // Get account details
    const account = await (OutlookAccount as any).findById(accountId)
    if (!account) {
      return NextResponse.json({
        success: false,
        message: 'Account not found'
      }, { status: 404 })
    }

    // Default scraping settings
    const settings: ScrapingSettings = {
      headless: scrapingSettings?.headless !== false,
      timeout: scrapingSettings?.timeout || 120,
      waitForLoad: scrapingSettings?.waitForLoad || 5000,
      debugMode: scrapingSettings?.debugMode || false
    }

    console.log(`[SCRAPING] Starting web scraping for ${account.email}`)
    console.log(`[SCRAPING] Settings:`, settings)

    // Check if Puppeteer is available
    let puppeteer
    try {
      puppeteer = require('puppeteer')
      console.log(`[SCRAPING] Puppeteer loaded successfully`)
    } catch (error: any) {
      console.error(`[SCRAPING] Puppeteer not found:`, error.message)
      return NextResponse.json({
        success: false,
        message: 'Puppeteer is not installed. Please install it with: npm install puppeteer',
        error: 'PUPPETEER_NOT_FOUND',
        emails: []
      }, { status: 500 })
    }
    
    try {
      
      console.log(`[SCRAPING] Launching browser (headless: ${settings.headless})`)
      
      const browser = await puppeteer.launch({
        headless: settings.headless,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--no-first-run',
          '--no-zygote',
          '--disable-gpu',
          '--disable-web-security',
          '--disable-features=VizDisplayCompositor'
        ],
        timeout: 60000 // 60 second timeout for browser launch
      })

      const page = await browser.newPage()
      
      // Set viewport and timeouts
      await page.setViewport({ width: 1366, height: 768 })
      page.setDefaultTimeout(settings.timeout * 1000)
      page.setDefaultNavigationTimeout(settings.timeout * 1000)
      
      // Set modern user agent to avoid detection
      await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')

      console.log(`[SCRAPING] Navigating to Outlook login page`)
      
      // Try multiple Outlook URLs (prioritize login.live.com as confirmed working)
      const outlookUrls = [
        'https://login.live.com/', // Prioritized - confirmed working with #usernameEntry/#passwordEntry
        'https://account.microsoft.com/auth/signin',
        'https://login.microsoftonline.com/',
        'https://outlook.live.com/owa/',
        'https://outlook.office.com/mail/',
        'https://outlook.live.com/mail/0/inbox'
      ]
      
      let loginSuccess = false
      
      for (const url of outlookUrls) {
        try {
          console.log(`[SCRAPING] Trying URL: ${url}`)
          
          // Try navigation with retries
          let navigationSuccess = false
          for (let retry = 0; retry < 3; retry++) {
            try {
              console.log(`[SCRAPING] Navigation attempt ${retry + 1}/3 for ${url}`)
              
              await page.goto(url, { 
                waitUntil: 'networkidle2',
                timeout: 30000
              })
              
              navigationSuccess = true
              console.log(`[SCRAPING] Successfully navigated to ${url}`)
              break
            } catch (navError: any) {
              console.log(`[SCRAPING] Navigation attempt ${retry + 1} failed:`, navError.message)
              if (retry === 2) {
                throw navError
              }
              await new Promise(resolve => setTimeout(resolve, 2000)) // Wait before retry
            }
          }
          
          if (!navigationSuccess) {
            throw new Error(`Failed to navigate to ${url} after 3 attempts`)
          }

          // Wait longer for JavaScript to render the login form
          await new Promise(resolve => setTimeout(resolve, 5000))

          console.log(`[SCRAPING] Looking for login elements...`)
          
          // First check if we're already in Outlook (already logged in)
          const currentUrl = page.url()
          const isAlreadyInOutlook = currentUrl.includes('outlook.live.com/mail') || 
                                   currentUrl.includes('outlook.office.com/mail') ||
                                   await page.evaluate(() => {
                                     return document.title.toLowerCase().includes('outlook') &&
                                            (document.body.innerText.toLowerCase().includes('inbox') ||
                                             document.querySelector('[aria-label*="inbox"]') !== null ||
                                             document.querySelector('[data-testid*="inbox"]') !== null)
                                   })
          
          if (isAlreadyInOutlook) {
            console.log(`[SCRAPING] User appears to be already logged in to Outlook, skipping login...`)
            loginSuccess = true
            break
          }
          
          // Check if this is actually a Microsoft login page
          const isMicrosoftPage = await page.evaluate(() => {
            const title = document.title.toLowerCase()
            const bodyText = document.body.innerText.toLowerCase()
            return title.includes('microsoft') || 
                   title.includes('outlook') || 
                   title.includes('sign in') ||
                   bodyText.includes('microsoft') ||
                   bodyText.includes('outlook') ||
                   document.querySelector('[data-testid*="microsoft"]') !== null ||
                   document.querySelector('.ms-') !== null
          })
          
          console.log(`[SCRAPING] Is Microsoft page: ${isMicrosoftPage}`)
          
          if (!isMicrosoftPage) {
            console.log(`[SCRAPING] Page doesn't appear to be Microsoft login, looking for sign-in links...`)
            
            // Try to find and click sign-in links
            const signInSelectors = [
              'a[href*="login"]',
              'a[href*="signin"]',
              'a[href*="sign-in"]',
              'button:contains("Sign in")',
              'a:contains("Sign in")',
              '.signin-link',
              '[data-testid*="signin"]',
              '[aria-label*="sign in"]'
            ]
            
            let foundSignIn = false
            for (const selector of signInSelectors) {
              try {
                const signInElement = await page.$(selector)
                if (signInElement) {
                  console.log(`[SCRAPING] Found sign-in element: ${selector}`)
                  await signInElement.click()
                  await new Promise(resolve => setTimeout(resolve, 3000)) // Wait for navigation
                  foundSignIn = true
                  break
                }
              } catch (e) {
                continue
              }
            }
            
            if (!foundSignIn) {
              console.log(`[SCRAPING] No sign-in links found, trying next URL...`)
              continue
            }
          }

          // Try multiple selectors for email input (prioritize current login.live.com selectors)
          const emailSelectors = [
            '#usernameEntry', // Current login.live.com selector (2025)
            '#i0116', // Classic Microsoft selector
            'input[name="loginfmt"]',
            'input[type="email"]',
            'input[placeholder*="Email hoặc điện thoại"]',
            'input[placeholder*="email"]',
            'input[placeholder*="Email"]',
            'input[placeholder*="phone"]',
            'input[placeholder*="Phone"]',
            'input[placeholder*="Skype"]',
            '#i0118',
            '.form-control[type="email"]',
            '.form-control[type="text"]',
            'input[data-testid="i0116"]',
            'input[aria-label*="email"]',
            'input[aria-label*="Email"]',
            'input[autocomplete="username"]',
            'input[autocomplete="email"]',
            '[data-report-event="Signin_Email"]',
            '.login-paginated-page input[type="email"]',
            '.login-paginated-page input[type="text"]',
            '[role="main"] input[type="email"]',
            '[role="main"] input[type="text"]'
          ]

          let emailInput = null
          for (const selector of emailSelectors) {
            try {
              await page.waitForSelector(selector, { timeout: 5000 })
              emailInput = selector
              console.log(`[SCRAPING] Found email input: ${selector}`)
              break
            } catch (e) {
              continue
            }
          }

          if (!emailInput) {
            console.log(`[SCRAPING] No email input found on ${url}`)
            
            // Debug: Log what we actually found on the page
            if (settings.debugMode) {
              try {
                const allInputs = await page.$$eval('input', (inputs: any[]) => 
                  inputs.map((input: any) => ({
                    type: input.type,
                    name: input.name,
                    id: input.id,
                    placeholder: input.placeholder,
                    className: input.className,
                    ariaLabel: input.getAttribute('aria-label')
                  }))
                )
                console.log(`[SCRAPING] Found ${allInputs.length} input elements:`, allInputs)
                
                const pageText = await page.evaluate(() => document.body.innerText.substring(0, 500))
                console.log(`[SCRAPING] Page text preview:`, pageText)
              } catch (debugErr: any) {
                console.log(`[SCRAPING] Debug error:`, debugErr.message)
              }
            }
            
            continue
          }

          console.log(`[SCRAPING] Entering credentials for ${account.email}`)

          // Clear and type email
          await page.click(emailInput, { clickCount: 3 })
          await page.type(emailInput, account.email)
          
          // Try multiple selectors for Next/Submit button (updated for Vietnamese)
          const submitSelectors = [
            'input[type="submit"]',
            'button[type="submit"]',
            '#idSIButton9',
            '.btn-primary',
            '[data-report-event="Signin_Submit"]',
            'input[value="Next"]',
            'input[value="Tiếp theo"]',
            'button:contains("Tiếp theo")',
            'button:contains("Next")',
            'button:contains("Sign in")',
            'button:contains("Đăng nhập")',
            '[data-testid="idSIButton9"]',
            '.win-button-primary',
            '.button-primary',
            '[role="button"]'
          ]

          let submitButton = null
          for (const selector of submitSelectors) {
            try {
              await page.waitForSelector(selector, { timeout: 3000 })
              submitButton = selector
              console.log(`[SCRAPING] Found submit button: ${selector}`)
              break
            } catch (e) {
              continue
            }
          }

          if (submitButton) {
            await page.click(submitButton)
          } else {
            // Try pressing Enter
            await page.keyboard.press('Enter')
          }
          
          // Wait for password page
          await new Promise(resolve => setTimeout(resolve, 3000))

          // Try multiple selectors for password input (prioritize current selectors)
          const passwordSelectors = [
            '#passwordEntry', // Current login.live.com selector (2025)
            '#i0118', // Classic Microsoft selector
            'input[type="password"]',
            'input[name="passwd"]',
            '.form-control[type="password"]',
            'input[data-testid="i0118"]',
            'input[aria-label*="password"]',
            'input[aria-label*="Password"]'
          ]

          let passwordInput = null
          for (const selector of passwordSelectors) {
            try {
              await page.waitForSelector(selector, { timeout: 5000 })
              passwordInput = selector
              console.log(`[SCRAPING] Found password input: ${selector}`)
              break
            } catch (e) {
              continue
            }
          }

          if (!passwordInput) {
            console.log(`[SCRAPING] No password input found, trying next URL...`)
            continue
          }

          // Clear and type password
          await page.click(passwordInput, { clickCount: 3 })
          await page.type(passwordInput, account.password)
          
          // Try to find and click Sign in button
          let signInButton = null
          for (const selector of submitSelectors) {
            try {
              await page.waitForSelector(selector, { timeout: 3000 })
              signInButton = selector
              break
            } catch (e) {
              continue
            }
          }

          if (signInButton) {
            await page.click(signInButton)
          } else {
            await page.keyboard.press('Enter')
          }

          loginSuccess = true
          break

        } catch (error: any) {
          console.log(`[SCRAPING] Failed with ${url}:`, error.message)
          
          // Debug info for this URL
          if (settings.debugMode) {
            try {
              console.log(`[SCRAPING] Debug - Current URL: ${page.url()}`)
              console.log(`[SCRAPING] Debug - Page title: ${await page.title()}`)
              
              // Take screenshot for this failed URL
              await page.screenshot({ path: `outlook-debug-${url.replace(/[^a-zA-Z0-9]/g, '_')}.png` })
              console.log(`[SCRAPING] Debug screenshot saved for ${url}`)
            } catch (debugError: any) {
              console.log(`[SCRAPING] Debug info error:`, debugError.message)
            }
          }
          continue
        }
      }

      if (!loginSuccess) {
        // Final debug info if all URLs failed
        if (settings.debugMode) {
          try {
            console.log(`[SCRAPING] All URLs failed. Final page info:`)
            console.log(`[SCRAPING] Current URL: ${page.url()}`)
            console.log(`[SCRAPING] Page title: ${await page.title()}`)
            
            const pageContent = await page.content()
            console.log(`[SCRAPING] Page content preview:`, pageContent.substring(0, 500))
          } catch (finalDebugError: any) {
            console.log(`[SCRAPING] Final debug error:`, finalDebugError.message)
          }
        }
        
        // Last attempt: try to go directly to inbox in case user is already logged in
        console.log(`[SCRAPING] All login attempts failed, trying direct inbox access...`)
        try {
          await page.goto('https://outlook.live.com/mail/0/inbox', { 
            waitUntil: 'networkidle2',
            timeout: 30000
          })
          
          // Check if we're in the inbox (already logged in)
          await new Promise(resolve => setTimeout(resolve, 3000))
          const isInInbox = await page.evaluate(() => {
            return document.body.innerText.toLowerCase().includes('inbox') ||
                   document.querySelector('[aria-label*="inbox"]') !== null ||
                   document.querySelector('[data-testid*="inbox"]') !== null ||
                   window.location.href.includes('inbox')
          })
          
          if (isInInbox) {
            console.log(`[SCRAPING] User appears to be already logged in, proceeding to email extraction...`)
            loginSuccess = true
          } else {
            throw new Error(`Could not find valid Outlook login page with any URL. Tried: ${outlookUrls.join(', ')}. User may need to login manually first.`)
          }
        } catch (inboxError: any) {
          throw new Error(`Could not find valid Outlook login page with any URL. Tried: ${outlookUrls.join(', ')}. Final inbox check failed: ${inboxError.message}`)
        }
      }
      
      console.log(`[SCRAPING] Waiting for Outlook to load...`)
      
      // Wait for Outlook interface to load with multiple fallback selectors
      console.log(`[SCRAPING] Waiting for Outlook interface to load...`)
      
      const outlookSelectors = [
        '[data-testid="message-list"]',
        '.ms-List-cell',
        '[role="listbox"]',
        '.ms-FocusZone',
        '[aria-label*="Message list"]',
        '.ms-DetailsList',
        '#MailList',
        '.ConversationList'
      ]

      let outlookLoaded = false
      for (const selector of outlookSelectors) {
        try {
          await page.waitForSelector(selector, { timeout: settings.waitForLoad })
          console.log(`[SCRAPING] Outlook loaded with selector: ${selector}`)
          outlookLoaded = true
          break
        } catch (e) {
          console.log(`[SCRAPING] Selector ${selector} not found, trying next...`)
          continue
        }
      }

      if (!outlookLoaded) {
        // Take screenshot for debugging
        if (settings.debugMode || !settings.headless) {
          try {
            await page.screenshot({ path: 'outlook-debug.png', fullPage: true })
            console.log(`[SCRAPING] Debug screenshot saved as outlook-debug.png`)
          } catch (screenshotError) {
            console.log(`[SCRAPING] Could not save screenshot:`, screenshotError)
          }
        }
        
        // Get page content for debugging
        if (settings.debugMode) {
          try {
            const pageContent = await page.content()
            console.log(`[SCRAPING] Page content length: ${pageContent.length}`)
            console.log(`[SCRAPING] Page title: ${await page.title()}`)
            console.log(`[SCRAPING] Current URL: ${page.url()}`)
          } catch (debugError) {
            console.log(`[SCRAPING] Debug info error:`, debugError)
          }
        }
        
        throw new Error('Outlook interface did not load - no message list found. Enable debug mode for more info.')
      }

      console.log(`[SCRAPING] Outlook loaded, extracting emails...`)

      // Extract emails from the page with multiple selector strategies
      const emails = await page.evaluate(() => {
        // Try multiple selectors for email list items
        const emailSelectors = [
          '[data-testid="message-item"]',
          '.ms-List-cell',
          '[role="option"]',
          '.ms-DetailsRow',
          '.ConversationItem',
          '[aria-label*="message"]'
        ]

        let emailElements: NodeListOf<Element> | null = null
        for (const selector of emailSelectors) {
          emailElements = document.querySelectorAll(selector)
          if (emailElements.length > 0) {
            console.log(`Found ${emailElements.length} emails with selector: ${selector}`)
            break
          }
        }

        if (!emailElements || emailElements.length === 0) {
          console.log('No email elements found with any selector')
          return []
        }

        const extractedEmails: any[] = []

        emailElements.forEach((element, index) => {
          if (index >= 10) return // Limit to 10 emails

          try {
            // Try multiple selectors for subject
            const subjectSelectors = [
              '[data-testid="message-subject"]',
              '.ms-font-weight-semibold',
              '.subject',
              '[aria-label*="Subject"]',
              '.ms-TooltipHost'
            ]

            let subject = 'No Subject'
            for (const selector of subjectSelectors) {
              const subjectElement = element.querySelector(selector)
              if (subjectElement?.textContent?.trim()) {
                subject = subjectElement.textContent.trim()
                break
              }
            }

            // Try multiple selectors for sender
            const senderSelectors = [
              '[data-testid="message-sender"]',
              '.ms-font-weight-regular',
              '.sender',
              '[aria-label*="From"]',
              '.ms-Persona-primaryText'
            ]

            let sender = 'Unknown Sender'
            for (const selector of senderSelectors) {
              const senderElement = element.querySelector(selector)
              if (senderElement?.textContent?.trim()) {
                sender = senderElement.textContent.trim()
                break
              }
            }

            // Try multiple selectors for time
            const timeSelectors = [
              '[data-testid="message-time"]',
              '.ms-font-size-xs',
              '.time',
              '[aria-label*="Received"]',
              '.ms-TooltipHost'
            ]

            let receivedTime = new Date().toISOString()
            for (const selector of timeSelectors) {
              const timeElement = element.querySelector(selector)
              if (timeElement?.textContent?.trim()) {
                receivedTime = timeElement.textContent.trim()
                break
              }
            }

            const email = {
              subject: subject,
              sender: sender,
              from: sender,
              received_time: receivedTime,
              body: 'Content extracted via web scraping - click email to view in Outlook',
              body_type: 'text',
              folder: 'INBOX'
            }

            extractedEmails.push(email)
          } catch (error) {
            console.error('Error extracting email:', error)
          }
        })

        return extractedEmails
      })

      await browser.close()

      console.log(`[SCRAPING] Successfully extracted ${emails.length} emails for ${account.email}`)

      // Update account last mail check
      await (OutlookAccount as any).findByIdAndUpdate(accountId, {
        lastMailCheck: new Date(),
        status: 'active'
      })

      return NextResponse.json({
        success: true,
        emails: emails,
        emailCount: emails.length,
        message: `Successfully read ${emails.length} emails via Web Scraping`
      })

    } catch (puppeteerError: any) {
      console.error(`[SCRAPING] Puppeteer error:`, puppeteerError)
      
      if (puppeteerError.message?.includes('Cannot find module')) {
        return NextResponse.json({
          success: false,
          message: 'Puppeteer not installed. Run: npm install puppeteer',
          error_type: 'missing_package',
          suggestion: 'Install Puppeteer or use REST API/IMAP instead'
        }, { status: 501 })
      }

      let errorMessage = puppeteerError.message || 'Web scraping failed'
      let errorCode = 'SCRAPING_ERROR'
      let suggestions = []
      
      if (errorMessage.includes('TimeoutError') || errorMessage.includes('timeout')) {
        errorMessage = `Timeout after ${settings.timeout}s - Outlook page took too long to load`
        errorCode = 'TIMEOUT_ERROR'
        suggestions.push('Increase timeout in settings (try 180-300 seconds)')
        suggestions.push('Check internet connection speed')
        suggestions.push('Try IMAP method instead')
      } else if (errorMessage.includes('net::ERR_INTERNET_DISCONNECTED')) {
        errorMessage = 'No internet connection available'
        errorCode = 'NO_INTERNET'
        suggestions.push('Check internet connection')
        suggestions.push('Try again when connection is restored')
      } else if (errorMessage.includes('net::ERR_NAME_NOT_RESOLVED')) {
        errorMessage = 'Cannot resolve Outlook domain'
        errorCode = 'DNS_ERROR'
        suggestions.push('Check DNS settings')
        suggestions.push('Try different network')
      } else if (errorMessage.includes('Navigation failed') || errorMessage.includes('Could not find valid Outlook login page')) {
        errorMessage = 'Microsoft Outlook login page has changed or is not accessible'
        errorCode = 'LOGIN_PAGE_CHANGED'
        suggestions.push('Microsoft may have updated their interface')
        suggestions.push('Try IMAP method instead')
        suggestions.push('Enable Debug Mode to see screenshots')
      } else if (errorMessage.includes('Protocol error') || errorMessage.includes('Target closed')) {
        errorMessage = 'Browser connection lost during scraping'
        errorCode = 'BROWSER_ERROR'
        suggestions.push('Try again - this is usually temporary')
        suggestions.push('Disable headless mode to see what happens')
      }

      return NextResponse.json({
        success: false,
        message: errorMessage,
        error_type: errorCode,
        suggestions: suggestions,
        debug_info: settings.debugMode ? {
          originalError: puppeteerError.message,
          stack: puppeteerError.stack,
          settings: settings
        } : undefined
      }, { status: 500 })
    }

  } catch (error) {
    console.error('[SCRAPING] API Error:', error)
    return NextResponse.json({
      success: false,
      message: 'Internal server error',
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
