import { NextResponse } from 'next/server';
import PaymentInfo from '@/models/PaymentInfo';
import connectMongoDB from '@/lib/mongodb';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    await connectMongoDB();
    
    // Get payment info from admin settings
    const paymentInfo = await (PaymentInfo as any).findOne({ isActive: true });
    
    if (!paymentInfo) {
      // Return default if not configured
      return NextResponse.json({
        bankName: 'ACB Bank',
        accountNumber: '123456789',
        accountHolder: 'CÔNG TY ABC',
        transferContent: 'WALLET_DEPOSIT'
      });
    }

    return NextResponse.json({
      bankName: paymentInfo.bankName,
      accountNumber: paymentInfo.accountNumber,
      accountHolder: paymentInfo.accountHolder,
      transferContent: paymentInfo.transferContent
    });
  } catch (error) {
    console.error('Error getting payment info:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}