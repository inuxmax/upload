import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export async function POST(request: NextRequest) {
  try {
    // Kiểm tra authentication từ JWT token
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized - No token provided' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET) as any;
    } catch (error) {
      return NextResponse.json(
        { error: 'Unauthorized - Invalid token' },
        { status: 401 }
      );
    }

    const { transferContent } = await request.json();

    if (!transferContent) {
      return NextResponse.json(
        { error: 'Transfer content is required' },
        { status: 400 }
      );
    }

    // Sử dụng dynamic import để tránh lỗi TypeScript
    const connectMongoDB = (await import('@/lib/mongodb')).default;
    const User = (await import('@/models/User')).default;
    
    await connectMongoDB();

    // Tìm user và thêm transfer content vào array
    const user = await (User as any).findById(decoded.userId);
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Khởi tạo array nếu chưa có
    if (!user.pendingTransferContents) {
      user.pendingTransferContents = [];
    }

    // Thêm transfer content vào array (không trùng lặp)
    if (!user.pendingTransferContents.includes(transferContent)) {
      user.pendingTransferContents.push(transferContent);
    }

    await user.save();

    console.log(`User ${user.username} initiated payment with transfer content: ${transferContent}`);
    console.log(`Total pending transfer contents: ${user.pendingTransferContents.length}`);

    return NextResponse.json({
      success: true,
      message: 'Payment initiated successfully',
      transferContent,
      totalPending: user.pendingTransferContents.length
    });

  } catch (error) {
    console.error('Payment initiation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 