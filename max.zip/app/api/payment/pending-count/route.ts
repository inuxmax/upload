import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

export async function GET(request: NextRequest) {
  try {
    // Kiểm tra authentication từ JWT token
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized - No token provided' },
        { status: 401 }
      );
    }

    const token = authHeader.substring(7);
    
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET) as any;
    } catch (error) {
      return NextResponse.json(
        { error: 'Unauthorized - Invalid token' },
        { status: 401 }
      );
    }

    // Sử dụng dynamic import để tránh lỗi TypeScript
    const connectMongoDB = (await import('@/lib/mongodb')).default;
    const User = (await import('@/models/User')).default;
    
    await connectMongoDB();

    // Tìm user và lấy số lượng pendingTransferContents
    const user = await (User as any).findById(decoded.userId);
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const pendingCount = user.pendingTransferContents?.length || 0;

    return NextResponse.json({
      success: true,
      pendingCount,
      pendingContents: user.pendingTransferContents || []
    });

  } catch (error) {
    console.error('Get pending count error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 