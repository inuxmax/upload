import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import ProxySettings from '@/models/ProxySettings';
import jwt from 'jsonwebtoken';

async function verifyUserToken(request: NextRequest) {
  try {
    // Thử lấy token từ Authorization header trước
    const authHeader = request.headers.get('authorization');
    let token = null;
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7);
    } else {
      // Fallback: lấy từ cookies
      token = request.cookies.get('token')?.value;
    }
    
    if (!token) {
      return null;
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// GET - Lấy danh sách proxy servers có sẵn cho user
export async function GET(request: NextRequest) {
  try {
    console.log('🔍 GET /api/proxy/available called');
    
    const user = await verifyUserToken(request);
    if (!user) {
      console.log('❌ Unauthorized - No valid token found');
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    
    console.log('✅ User authenticated:', user.email);

    await connectMongoDB();
    
    // Lấy tất cả proxy settings đang active và chưa đạt giới hạn user
    const availableProxies = await (ProxySettings as any).find({
      isActive: true,
      $expr: {
        $lt: ['$currentUsers', '$maxUsers']
      }
    }).select('_id name isResidential currentUsers maxUsers').sort({ name: 1 });
    
    console.log('📊 Found available proxies:', availableProxies.length);
    
    return NextResponse.json({ 
      availableProxies,
      message: 'Lấy danh sách proxy thành công'
    });
  } catch (error) {
    console.error('Error fetching available proxies:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
} 