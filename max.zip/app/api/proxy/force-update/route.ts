import { NextRequest, NextResponse } from 'next/server';
import { runProxyUpdateNow } from '@/lib/proxy-cron';

export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Force updating proxy IPs...');
    
    // Chạy proxy update ngay lập tức
    await runProxyUpdateNow();
    
    return NextResponse.json({
      success: true,
      message: 'Proxy IPs updated successfully'
    });
  } catch (error) {
    console.error('Error force updating proxy:', error);
    return NextResponse.json({ 
      error: 'Failed to update proxy IPs',
      details: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
} 