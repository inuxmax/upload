import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import ProxySettings from '@/models/ProxySettings';
import { runProxyUpdateNow, initProxyCronJob } from '@/lib/proxy-cron';

// Biến để theo dõi xem cron job đã được khởi tạo chưa
let cronJobInitialized = false;

// GET - Lấy proxy mới từ tất cả các API key đang hoạt động
export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Khởi tạo cron job nếu chưa được khởi tạo
    if (!cronJobInitialized) {
      initProxyCronJob();
      cronJobInitialized = true;
    }
    
    // Lấy tất cả proxy settings đang hoạt động
    const activeProxies = await (ProxySettings as any).find({ isActive: true });
    
    if (activeProxies.length === 0) {
      return NextResponse.json({ 
        error: 'No active proxy settings found' 
      }, { status: 404 });
    }

    // Chọn ngẫu nhiên một proxy setting có IP hiện tại
    const proxiesWithIP = activeProxies.filter(p => p.currentProxy);
    
    if (proxiesWithIP.length === 0) {
      return NextResponse.json({ 
        error: 'No current proxy available' 
      }, { status: 404 });
    }

    const randomIndex = Math.floor(Math.random() * proxiesWithIP.length);
    const selectedProxy = proxiesWithIP[randomIndex];

    return NextResponse.json({
      success: true,
      proxy: selectedProxy.currentProxy,
      proxyName: selectedProxy.name,
      nextChange: selectedProxy.nextChange,
      refreshAt: selectedProxy.refreshAt,
      message: `Using proxy from ${selectedProxy.name}`
    });

  } catch (error) {
    console.error('Error getting proxy:', error);
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 });
  }
}

// POST - Lấy thông tin proxy hiện tại
export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Lấy tất cả proxy settings đang hoạt động
    const activeProxies = await (ProxySettings as any).find({ isActive: true });
    
    if (activeProxies.length === 0) {
      return NextResponse.json({ 
        error: 'No active proxy settings found' 
      }, { status: 404 });
    }

    // Chọn proxy setting có proxy hiện tại
    const proxyWithCurrent = activeProxies.find(p => p.currentProxy);
    
    if (!proxyWithCurrent) {
      return NextResponse.json({ 
        error: 'No current proxy available' 
      }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      proxy: proxyWithCurrent.currentProxy,
      proxyName: proxyWithCurrent.name,
      nextChange: proxyWithCurrent.nextChange,
      refreshAt: proxyWithCurrent.refreshAt
    });

  } catch (error) {
    console.error('Error getting current proxy:', error);
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 });
  }
} 