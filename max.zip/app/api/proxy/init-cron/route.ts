import { NextRequest, NextResponse } from 'next/server';
import { initProxyCronJob } from '@/lib/proxy-cron';

// POST - Khởi tạo cron job cho proxy
export async function POST(request: NextRequest) {
  try {
    // Khởi tạo cron job
    initProxyCronJob();
    
    return NextResponse.json({
      success: true,
      message: 'Proxy cron job initialized successfully'
    });
  } catch (error) {
    console.error('Error initializing proxy cron job:', error);
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 });
  }
} 