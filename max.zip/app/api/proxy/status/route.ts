import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import ProxySettings from '@/models/ProxySettings';

// GET - Kiểm tra trạng thái proxy và cron job
export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Lấy tất cả proxy settings
    const allProxies = await (ProxySettings as any).find({}).sort({ name: 1 });
    
    // Tính toán thống kê
    const activeProxies = allProxies.filter(p => p.isActive);
    const proxiesWithIP = activeProxies.filter(p => p.currentProxy);
    const totalUsers = activeProxies.reduce((sum, p) => sum + (p.currentUsers || 0), 0);
    
    // Kiểm tra proxy nào cần cập nhật (dựa trên nextChange)
    const now = Date.now();
    const proxiesNeedingUpdate = activeProxies.filter(p => {
      if (!p.nextChange) return true;
      return now >= p.nextChange;
    });
    
    return NextResponse.json({
      success: true,
      stats: {
        totalProxies: allProxies.length,
        activeProxies: activeProxies.length,
        proxiesWithIP: proxiesWithIP.length,
        totalUsers: totalUsers,
        proxiesNeedingUpdate: proxiesNeedingUpdate.length
      },
      proxies: allProxies.map(p => ({
        id: p._id,
        name: p.name,
        isActive: p.isActive,
        currentProxy: p.currentProxy,
        currentUsers: p.currentUsers || 0,
        maxUsers: p.maxUsers || 10,
        refreshAt: p.refreshAt,
        nextChange: p.nextChange,
        needsUpdate: p.nextChange ? now >= p.nextChange : true
      })),
      message: 'Proxy status retrieved successfully'
    });
  } catch (error) {
    console.error('Error getting proxy status:', error);
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 });
  }
} 