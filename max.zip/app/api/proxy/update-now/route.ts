import { NextRequest, NextResponse } from 'next/server';
import { runProxyUpdateNow } from '@/lib/proxy-cron';

// POST - Chạy cập nhật proxy ngay lập tức
export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Manual proxy update requested...');
    await runProxyUpdateNow();
    
    return NextResponse.json({
      success: true,
      message: 'Proxy update completed'
    });
  } catch (error) {
    console.error('Error in manual proxy update:', error);
    return NextResponse.json({ 
      error: 'Internal server error' 
    }, { status: 500 });
  }
} 