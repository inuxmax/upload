import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import ProxySettings from '@/models/ProxySettings';
import Settings from '@/models/Settings';
import jwt from 'jsonwebtoken';

async function verifyUserToken(request: NextRequest) {
  try {
    const token = request.cookies.get('token')?.value;
    if (!token) {
      return null;
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// POST - Cập nhật số user đang sử dụng proxy
export async function POST(request: NextRequest) {
  try {
    console.log('🔄 POST /api/proxy/update-usage called');
    
    const user = await verifyUserToken(request);
    if (!user) {
      console.log('❌ Unauthorized - no valid token');
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    console.log('✅ User authenticated:', user.userId);

    await connectMongoDB();
    
    const { selectedProxyId } = await request.json();
    console.log('📊 Request data:', { selectedProxyId });
    
    // Lấy settings hiện tại của user
    const currentSettings = await (Settings as any).findOne({ userId: user.userId });
    const previousProxyId = currentSettings?.selectedProxyId;
    
    console.log('📋 Current settings:', { 
      userId: user.userId, 
      previousProxyId, 
      newProxyId: selectedProxyId 
    });
    
    // Nếu user đang chọn proxy mới
    if (selectedProxyId && selectedProxyId !== previousProxyId) {
      console.log('🔄 User changing proxy:', { from: previousProxyId, to: selectedProxyId });
      
      // Tăng số user cho proxy mới
      if (selectedProxyId) {
        const updatedProxy = await (ProxySettings as any).findByIdAndUpdate(selectedProxyId, {
          $inc: { currentUsers: 1 }
        }, { new: true });
        console.log('✅ Increased users for new proxy:', selectedProxyId, 'New count:', updatedProxy?.currentUsers);
      }
      
      // Giảm số user cho proxy cũ (nếu có)
      if (previousProxyId) {
        const updatedOldProxy = await (ProxySettings as any).findByIdAndUpdate(previousProxyId, {
          $inc: { currentUsers: -1 }
        }, { new: true });
        console.log('✅ Decreased users for old proxy:', previousProxyId, 'New count:', updatedOldProxy?.currentUsers);
      }
    }
    
    // Nếu user bỏ chọn proxy (selectedProxyId = null hoặc empty)
    if (!selectedProxyId && previousProxyId) {
      console.log('🔄 User removing proxy:', previousProxyId);
      
      // Giảm số user cho proxy cũ
      const updatedProxy = await (ProxySettings as any).findByIdAndUpdate(previousProxyId, {
        $inc: { currentUsers: -1 }
      }, { new: true });
      console.log('✅ Decreased users for removed proxy:', previousProxyId, 'New count:', updatedProxy?.currentUsers);
    }
    
    return NextResponse.json({ 
      message: 'Cập nhật số user thành công',
      previousProxyId,
      newProxyId: selectedProxyId
    });
  } catch (error) {
    console.error('Error updating proxy usage:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
} 