import { NextRequest, NextResponse } from 'next/server';
import { runProxyUpdateNow } from '@/lib/proxy-cron';

// POST - Cập nhật proxy IP
export async function POST(request: NextRequest) {
  try {
    console.log('🔄 Proxy update requested...');
    
    // Chạy proxy update ngay lập tức
    await runProxyUpdateNow();
    
    return NextResponse.json({
      success: true,
      message: 'Proxy updated successfully'
    });
  } catch (error) {
    console.error('Error updating proxy:', error);
    return NextResponse.json({ 
      error: 'Failed to update proxy',
      details: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
