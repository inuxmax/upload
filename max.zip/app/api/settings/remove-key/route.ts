import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import Settings from '@/models/Settings'
import jwt from 'jsonwebtoken'
import { decryptUserKey, isValidAdminKey } from '@/lib/encryption'

export const dynamic = 'force-dynamic'

async function getUserFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    return decoded
  } catch {
    return null
  }
}

export async function POST(req: NextRequest) {
  try {
    await connectMongoDB()
    const token = req.cookies.get('token')?.value || req.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })

    const user = await getUserFromToken(token)
    if (!user?.userId) return NextResponse.json({ success: false, message: 'Invalid token' }, { status: 401 })

    const { userKeyPlain, adminKey } = await req.json()
    if (!userKeyPlain) return NextResponse.json({ success: false, message: 'Key required' }, { status: 400 })

    const settings: any = await (Settings as any).findOne({ userId: user.userId })
    const encrypted = settings?.encryption?.userKeyEncrypted || settings?.userEncryptionKey || null
    if (!encrypted) {
      return NextResponse.json({ success: false, message: 'No key to delete', error_type: 'no_key' }, { status: 404 })
    }

    const savedKey = decryptUserKey(encrypted)
    if (!(savedKey === String(userKeyPlain) || isValidAdminKey(adminKey))) {
      return NextResponse.json({ success: false, message: 'Invalid key', error_type: 'invalid_key' }, { status: 401 })
    }

    // Clear key and disable encryption
    settings.encryption = settings.encryption || {}
    settings.encryption.userKeyEncrypted = null
    settings.encryption.enabled = false
    settings.userEncryptionKey = null
    settings.encryptionEnabled = false
    await settings.save()

    return NextResponse.json({ success: true })
  } catch (e) {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 })
  }
}


