import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import Settings from '@/models/Settings';
import { encryptUserKey } from '@/lib/encryption'
import AdminSettings from '@/models/AdminSettings';
import ProxySettings from '@/models/ProxySettings';
import Subscription from '@/models/Subscription';
import SubscriptionPlan from '@/models/SubscriptionPlan';
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to get user from token
async function getUserFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// GET settings for current user
export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    // Get admin settings first
    const adminSettings = await (AdminSettings as any).findOne();
    const globalMaxThreads = adminSettings?.globalMaxThreads || 50;
    const defaultUserThreads = adminSettings?.defaultUserThreads || 10;
    const allowUserThreadSettings = adminSettings?.allowUserThreadSettings !== false; // Default to true

    let settings = await (Settings as any).findOne({ userId: user.userId });
    
    // Create default settings if none exist
    if (!settings) {
      settings = await (Settings as any).create({
        userId: user.userId,
        httpProxies: [],
        hotmailAccounts: [],
        enable2FA: false,
        changeName: false,
        checkBM: false,
        checkTKQC: false,
        checkFullInfo: false,
        autoLogin: false,
        notifications: true,
        maxThreads: defaultUserThreads,
        theme: 'auto',
        language: 'vi',
        selectedProxyId: null
      });
    }

    // Get user subscription to apply plan limits
    const subscription = await (Subscription as any).findOne({ 
      userId: user.userId,
      status: { $in: ['active', 'pending'] }
    }).sort({ createdAt: -1 });
    
    let subscriptionMaxThreads = 50; // Default high limit
    if (subscription) {
      const planInfo = await (SubscriptionPlan as any).findOne({ plan: subscription.plan });
      subscriptionMaxThreads = planInfo?.maxThreads || 2;
    } else {
      // If no subscription, use free plan limit
      const freePlan = await (SubscriptionPlan as any).findOne({ plan: 'free' });
      subscriptionMaxThreads = freePlan?.maxThreads || 2;
    }

    // Apply admin thread limits to user settings
    let effectiveMaxThreads = settings.maxThreads;
    
    if (!allowUserThreadSettings) {
      // If admin disabled user thread settings, use default
      effectiveMaxThreads = defaultUserThreads;
    } else {
      // If user settings are allowed, respect global max and subscription limits
      effectiveMaxThreads = Math.min(settings.maxThreads, globalMaxThreads, subscriptionMaxThreads);
    }

    // Get selected proxy details if exists
    let selectedProxyDetails = null;
    if (settings.selectedProxyId) {
      try {
        selectedProxyDetails = await (ProxySettings as any).findById(settings.selectedProxyId)
          .select('_id name isResidential currentUsers maxUsers isActive');
      } catch (error) {
        console.error('Error fetching selected proxy details:', error);
        // If proxy not found, clear the selection
        settings.selectedProxyId = null;
        await (settings as any).save();
      }
    }

    // Return settings with applied limits
    return NextResponse.json({
      ...settings.toObject(),
      encryption: settings.encryption || { enabled: settings.encryptionEnabled || false, userKeyEncrypted: settings.userEncryptionKey || null },
      maxThreads: effectiveMaxThreads,
      globalMaxThreads: globalMaxThreads,
      allowUserThreadSettings: allowUserThreadSettings,
      selectedProxyId: settings.selectedProxyId || null,
      selectedProxyDetails: selectedProxyDetails
    });
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// PUT/UPDATE settings for current user
export async function PUT(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.cookies.get('token')?.value || 
                  request.headers.get('authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    // Get admin settings to check limits
    const adminSettings = await (AdminSettings as any).findOne();
    const globalMaxThreads = adminSettings?.globalMaxThreads || 50;
    const allowUserThreadSettings = adminSettings?.allowUserThreadSettings !== false;

    // Get user subscription to apply plan limits
    const subscription = await (Subscription as any).findOne({ 
      userId: user.userId,
      status: { $in: ['active', 'pending'] }
    }).sort({ createdAt: -1 });
    
    let subscriptionMaxThreads = 50; // Default high limit
    if (subscription) {
      const planInfo = await (SubscriptionPlan as any).findOne({ plan: subscription.plan });
      subscriptionMaxThreads = planInfo?.maxThreads || 2;
    } else {
      // If no subscription, use free plan limit
      const freePlan = await (SubscriptionPlan as any).findOne({ plan: 'free' });
      subscriptionMaxThreads = freePlan?.maxThreads || 2;
    }

    const body = await request.json();
    
    // Apply thread limits
    let maxThreads = body.maxThreads || 10;
    if (!allowUserThreadSettings) {
      maxThreads = adminSettings?.defaultUserThreads || 10;
    } else {
      maxThreads = Math.min(maxThreads, globalMaxThreads, subscriptionMaxThreads);
    }
    
    // Update or create settings
    // Enforce mutual exclusivity on the server: if ProxyFB keys exist, clear admin proxy; if admin proxy selected, clear ProxyFB keys
    let proxyFBKeysUpdate: string[] = Array.isArray(body.proxyFBKeys) ? body.proxyFBKeys : [];
    let selectedProxyIdUpdate = body.selectedProxyId || null;
    if (proxyFBKeysUpdate.length > 0) {
      selectedProxyIdUpdate = null;
    } else if (selectedProxyIdUpdate) {
      proxyFBKeysUpdate = [];
    }

    // Load current settings to enforce key immutability
    const currentSettings: any = await (Settings as any).findOne({ userId: user.userId }).lean()

    // Build encryption update safely (support plain key)
    let encryptionUpdate: any = undefined
    if (body.encryption) {
      encryptionUpdate = {
        enabled: !!body.encryption.enabled,
        userKeyEncrypted: body.encryption.userKeyEncrypted || null
      }
      if (body.encryption.userKeyPlain) {
        try {
          const { encrypted } = encryptUserKey(String(body.encryption.userKeyPlain))
          encryptionUpdate.userKeyEncrypted = encrypted
        } catch {}
      }
    }

    // If a key already exists, do not allow setting a new one
    const existingEncryptedKey = currentSettings?.encryption?.userKeyEncrypted || currentSettings?.userEncryptionKey || null
    if (existingEncryptedKey && encryptionUpdate && encryptionUpdate.userKeyEncrypted) {
      return NextResponse.json({
        success: false,
        error: 'User key already set. Cannot replace existing key.',
        error_type: 'key_already_set'
      }, { status: 409 })
    }

    // Build $set with only defined keys to avoid overwriting
    const setPayload: any = {
      httpProxies: Array.isArray(body.httpProxies) ? body.httpProxies : [],
      hotmailAccounts: Array.isArray(body.hotmailAccounts) ? body.hotmailAccounts : [],
      enable2FA: !!body.enable2FA,
      changeName: !!body.changeName,
      checkBM: !!body.checkBM,
      checkTKQC: !!body.checkTKQC,
      checkFullInfo: !!body.checkFullInfo,
      autoLogin: !!body.autoLogin,
      notifications: body.notifications !== undefined ? !!body.notifications : true,
      maxThreads: maxThreads,
      theme: body.theme || 'auto',
      language: body.language || 'vi',
      selectedProxyId: selectedProxyIdUpdate,
      proxyFBKeys: proxyFBKeysUpdate,
      proxyFBLocationId: typeof body.proxyFBLocationId === 'number' ? body.proxyFBLocationId : 1
    }
    if (encryptionUpdate) setPayload.encryption = encryptionUpdate
    if (body.encryptionEnabled !== undefined) setPayload.encryptionEnabled = !!body.encryptionEnabled
    if (body.userEncryptionKey !== undefined) setPayload.userEncryptionKey = body.userEncryptionKey

    const settings = await (Settings as any).findOneAndUpdate(
      { userId: user.userId },
      { $set: setPayload },
      { upsert: true, new: true }
    );

    return NextResponse.json(settings);
  } catch (error) {
    console.error('Error updating settings:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
} 