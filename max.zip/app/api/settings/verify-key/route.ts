import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import Settings from '@/models/Settings'
import jwt from 'jsonwebtoken'
import { decryptUserKey, isValidAdminKey } from '@/lib/encryption'

export const dynamic = 'force-dynamic'

async function getUserFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    return decoded
  } catch {
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB()

    const token = request.cookies.get('token')?.value || request.headers.get('authorization')?.replace('Bearer ', '')
    if (!token) return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 })

    const user = await getUserFromToken(token)
    if (!user?.userId) return NextResponse.json({ success: false, message: 'Invalid token' }, { status: 401 })

    const { userKeyPlain, adminKey } = await request.json()
    const settings: any = await (Settings as any).findOne({ userId: user.userId }).lean()
    const encrypted = settings?.encryption?.userKeyEncrypted || settings?.userEncryptionKey || null

    if (!encrypted) {
      return NextResponse.json({ success: true, hasKey: false, message: 'No key saved yet' })
    }

    const savedKey = decryptUserKey(encrypted)
    const isMatch = !!userKeyPlain && savedKey === String(userKeyPlain)
    const adminBypass = isValidAdminKey(adminKey)
    return NextResponse.json({ success: true, hasKey: true, match: isMatch || adminBypass, adminBypass })
  } catch (e) {
    return NextResponse.json({ success: false, message: 'Server error' }, { status: 500 })
  }
}


