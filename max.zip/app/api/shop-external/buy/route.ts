import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import ShopOrder from '@/models/ShopOrder';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const SHOP_API_KEY = 'b836bc0c8f08ecf98682850db0e85b40';
const SHOP_API_URL = 'https://shop.ftool.vn/api/buy_product';

export async function POST(request: NextRequest) {
  try {
    await dbConnect();
    
    // Get token from Authorization header
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = authHeader.substring(7);
    let userId: string;
    
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      userId = decoded.userId;
    } catch (error) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const body = await request.json();
    const { productId, quantity = 1, coupon = '', productPrice, productName } = body;

    if (!productId) {
      return NextResponse.json({ error: 'Product ID is required' }, { status: 400 });
    }

    // Check minimum quantity requirements for specific products
    const minQuantityProducts = {
      '26': 10,
      '27': 10,
      '28': 10, // Facebook Account Checkpoint Database - minimum 50 accounts
      '29': 10, // Add other products that require minimum quantity
      '30': 10,
      '31': 10,
      '32': 10,
      '33': 10,
      '34': 10,
      '35': 10,
      '36': 10,
      '37': 10,
      '38': 10,
      '39': 10,
      '40': 10,
      '41': 10,
      '42': 10,
      '43': 10
    };

    const minQuantity = minQuantityProducts[productId] || 1;
    if (quantity < minQuantity) {
      return NextResponse.json({ 
        error: `Minimum purchase quantity is ${minQuantity} accounts for this product`,
        minQuantity: minQuantity,
        requestedQuantity: quantity,
        productId: productId
      }, { status: 400 });
    }

    // Get user from database
    const user = await (User as any).findById(userId);
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Call external shop API
    const formData = new FormData();
    formData.append('action', 'buyProduct');
    formData.append('id', productId);
    formData.append('amount', quantity.toString());
    formData.append('coupon', coupon);
    formData.append('api_key', SHOP_API_KEY);

    try {
      const shopResponse = await fetch(SHOP_API_URL, {
        method: 'POST',
        body: formData
      });

      const shopData = await shopResponse.json();

             if (shopData.status !== 'success') {
         return NextResponse.json({ 
           error: shopData.msg || 'Purchase failed from external API',
           shopError: shopData
         }, { status: 400 });
       }

               // Sử dụng giá từ frontend hoặc fallback
        const unitPrice = productPrice || 30000; // Ưu tiên giá từ frontend
        const totalPrice = unitPrice * quantity;

               // Check if user has enough balance
        if (user.balance < totalPrice) {
          return NextResponse.json({ 
            error: 'Insufficient balance',
            required: totalPrice,
            current: user.balance,
            productId: productId,
            quantity: quantity,
            unitPrice: unitPrice // Thêm thông tin giá đơn vị để debug
          }, { status: 400 });
        }

       // Deduct balance from user
       user.balance -= totalPrice;
       await user.save();

      // Save order to database
      const order = new ShopOrder({
        userId: userId,
        transId: shopData.trans_id,
        productId: productId,
        productName: (typeof productName === 'string' && productName.trim()) ? productName.trim() : `Product ${productId}`,
        amount: quantity,
        price: totalPrice,
        coupon: coupon || null,
        status: 'completed',
        accounts: shopData.data || [],
        apiResponse: shopData
      });

      await order.save();

      return NextResponse.json({
        success: true,
        message: shopData.msg || 'Purchase successful',
        transId: shopData.trans_id,
        accounts: shopData.data || [],
        order: {
          _id: order._id,
          productName: order.productName,
          quantity: order.amount,
          totalPrice: order.price,
          status: order.status,
          createdAt: order.createdAt
        }
      });

    } catch (shopError) {
      console.error('External shop API error:', shopError);
      return NextResponse.json({ 
        error: 'Failed to connect to external shop API',
        details: shopError instanceof Error ? shopError.message : 'Unknown error'
      }, { status: 500 });
    }

  } catch (error) {
    console.error('Error processing purchase:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Purchase failed' },
      { status: 500 }
    );
  }
}
