import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import ShopOrder from '@/models/ShopOrder';

// Force dynamic rendering
export const dynamic = 'force-dynamic';
// Ensure absolutely no caching for this route
export const revalidate = 0;
export const fetchCache = 'force-no-store';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';

const API_KEY = 'b836bc0c8f08ecf98682850db0e85b40';
const BASE_URL = 'https://shop.ftool.vn/api';

// Sample products with purchased data
const sampleProducts = [
  {
    id: '1',
    name: 'Facebook Accounts Fresh Database - Account LIVE',
    description: 'This is private Facebook account data. Quality data, purchased to scan advertising accounts.',
    price: 3000,
    category_id: '1',
    category: 'Facebook Database',
    stock: 33361,
    content: '• Facebook Accounts Fresh\n• Account LIVE\n• Quality data\n• For advertising scanning',
    sold: 1250,
    purchased: 850
  },
  {
    id: '2',
    name: 'Facebook Account Checkpoint Database (Checkpoint 282,956,...)',
    description: 'FACEBOOK ACCOUNT 100% DEAD FULL DEAD (Very PHONE, Checkpoint 282, Checkpoint 956,...) Có sai pass,...',
    price: 200,
    category_id: '1',
    category: 'Facebook Database',
    stock: 139262,
    content: '• Facebook Account Checkpoint\n• 100% DEAD FULL DEAD\n• Very PHONE\n• Checkpoint 282, 956',
    sold: 8900,
    purchased: 3200
  },
  {
    id: '3',
    name: 'Tri ân khách hàng Facebook Accounts Fresh Database - Account LIVE',
    description: 'Không bảo hành gì',
    price: 500,
    category_id: '1',
    category: 'Facebook Database',
    stock: 1115,
    content: '• Facebook Accounts Fresh\n• Account LIVE\n• Tri ân khách hàng\n• Không bảo hành',
    sold: 450,
    purchased: 180
  }
];

export async function GET(request: NextRequest) {
  try {
    await dbConnect();
    
    // Get token from Authorization header
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = authHeader.substring(7);
    
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      const user = await (User as any).findById(decoded.userId);
      if (!user) {
        return NextResponse.json({ error: 'User not found' }, { status: 401 });
      }
    } catch (error) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');

    // Fetch products from external API with cache busting and no-store
    const url = `${BASE_URL}/products.php?api_key=${API_KEY}&_t=${Date.now()}`;
    const response = await fetch(url, {
      cache: 'no-store',
      headers: {
        'Cache-Control': 'no-cache'
      },
      next: { revalidate: 0 }
    });
    
    if (!response.ok) {
      throw new Error(`External API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.status !== 'success') {
      throw new Error(data.msg || 'Failed to fetch products');
    }

    // Extract products from categories structure
    let products: any[] = [];
    if (data.categories && Array.isArray(data.categories)) {
      data.categories.forEach((category: any) => {
        if (category.products && Array.isArray(category.products)) {
          category.products.forEach((product: any) => {
            products.push({
              ...product,
              category_id: category.id,
              category: category.name,
              stock: product.amount || 0,
              sold: product.sold || 0,
              content: product.content || product.description || '',
              features: product.features || []
            });
          });
        }
      });
    }

    // Filter by category if provided
    if (category) {
      products = products.filter((product: any) => 
        product.category_id === category || product.category === category
      );
    }

    // Filter by search term if provided
    if (search) {
      const searchLower = search.toLowerCase();
      products = products.filter((product: any) =>
        product.name?.toLowerCase().includes(searchLower) ||
        product.description?.toLowerCase().includes(searchLower)
      );
    }

    // Get purchase counts from database for each product
    const productsWithPurchaseCounts = await Promise.all(
      products.map(async (product) => {
        try {
          // Get total quantity purchased for this product (sum of amounts from completed orders)
          const purchaseResult = await ShopOrder.aggregate([
            {
              $match: {
                productId: product.id,
                status: 'completed'
              }
            },
            {
              $group: {
                _id: null,
                totalPurchased: { $sum: '$amount' }
              }
            }
          ]);
          
          const totalPurchased = purchaseResult.length > 0 ? purchaseResult[0].totalPurchased : 0;
          
          return {
            ...product,
            purchased: totalPurchased
          };
        } catch (error) {
          console.error(`Error counting purchases for product ${product.id}:`, error);
          return {
            ...product,
            purchased: 0
          };
        }
      })
    );

    return NextResponse.json(
      {
        success: true,
        products: productsWithPurchaseCounts
      },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0',
          'Surrogate-Control': 'no-store'
        }
      }
    );

  } catch (error) {
    console.error('Error fetching products:', error);
    
    // Fallback to sample products if external API fails
    try {
      await dbConnect();
      
      // Get purchase counts for sample products from database
      const sampleProductsWithPurchaseCounts = await Promise.all(
        sampleProducts.map(async (product) => {
          try {
            // Get total quantity purchased for this product (sum of amounts from completed orders)
            const purchaseResult = await ShopOrder.aggregate([
              {
                $match: {
                  productId: product.id,
                  status: 'completed'
                }
              },
              {
                $group: {
                  _id: null,
                  totalPurchased: { $sum: '$amount' }
                }
              }
            ]);
            
            const totalPurchased = purchaseResult.length > 0 ? purchaseResult[0].totalPurchased : 0;
            
            return {
              ...product,
              purchased: totalPurchased
            };
          } catch (error) {
            console.error(`Error counting purchases for sample product ${product.id}:`, error);
            return {
              ...product,
              purchased: 0
            };
          }
        })
      );
      
      return NextResponse.json({
        success: true,
        products: sampleProductsWithPurchaseCounts,
        message: 'Using fallback products with real purchase data'
      });
    } catch (fallbackError) {
      console.error('Fallback error:', fallbackError);
      return NextResponse.json({
        success: false,
        error: 'Failed to fetch products and fallback failed',
        products: []
      }, { status: 500 });
    }
  }
}
