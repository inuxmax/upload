import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    console.log('Subscription downgrade check started:', new Date().toISOString());
    
    const connectMongoDB = (await import('@/lib/mongodb')).default;
    const Subscription = (await import('@/models/Subscription')).default;
    
    await connectMongoDB();

    const now = new Date();
    console.log('Current time:', now.toISOString());

    const expiredSubscriptions = await (Subscription as any).find({
      status: 'active',
      endDate: { $lt: now }
    }).populate('userId', 'username email');

    console.log(`Found ${expiredSubscriptions.length} expired subscriptions`);

    let downgradedCount = 0;
    for (const subscription of expiredSubscriptions) {
      try {
        const username = subscription.userId?.username || subscription.userId;
        console.log(`Downgrading subscription for user: ${username}`);
        
        subscription.plan = 'free';
        subscription.status = 'expired';
        subscription.autoRenew = false;
        subscription.endDate = now;
        
        await subscription.save();
        
        console.log(`Successfully downgraded subscription for user: ${username}`);
        downgradedCount++;
        
      } catch (error) {
        console.error(`Error downgrading subscription for user ${subscription.userId}:`, error);
      }
    }

    console.log(`Downgraded ${downgradedCount} expired subscriptions`);
    
    return NextResponse.json({
      success: true,
      message: `Checked and downgraded ${downgradedCount} expired subscriptions`,
      checked: expiredSubscriptions.length,
      downgraded: downgradedCount,
      timestamp: now.toISOString()
    });

  } catch (error) {
    console.error('Error checking expired subscriptions:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Internal server error', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    console.log('Subscription status check started:', new Date().toISOString());
    
    const connectMongoDB = (await import('@/lib/mongodb')).default;
    const Subscription = (await import('@/models/Subscription')).default;
    
    await connectMongoDB();

    const now = new Date();
    
    // Lấy thống kê subscription
    const totalSubscriptions = await Subscription.countDocuments();
    const activeSubscriptions = await Subscription.countDocuments({ status: 'active' });
    const expiredSubscriptions = await Subscription.countDocuments({ 
      status: 'active', 
      endDate: { $lt: now } 
    });
    const freeSubscriptions = await Subscription.countDocuments({ plan: 'free' });
    const paidSubscriptions = await Subscription.countDocuments({ 
      plan: { $in: ['basic', 'premium', 'enterprise'] } 
    });

    return NextResponse.json({
      success: true,
      stats: {
        total: totalSubscriptions,
        active: activeSubscriptions,
        expired: expiredSubscriptions,
        free: freeSubscriptions,
        paid: paidSubscriptions
      },
      timestamp: now.toISOString()
    });

  } catch (error) {
    console.error('Error getting subscription stats:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Internal server error', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    );
  }
} 