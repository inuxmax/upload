import { NextRequest, NextResponse } from 'next/server';
import SubscriptionPlan from '@/models/SubscriptionPlan';
import connectMongoDB from '@/lib/mongodb';

// Force dynamic rendering and disable caching
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  try {
    await connectMongoDB();
    
    const plans = await (SubscriptionPlan as any).find({ isActive: true }).sort({ price: 1 });
    
    const response = NextResponse.json(plans);
    
    // Disable caching
    response.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    response.headers.set('Pragma', 'no-cache');
    response.headers.set('Expires', '0');
    
    return response;
  } catch (error) {
    console.error('Error fetching subscription plans:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 