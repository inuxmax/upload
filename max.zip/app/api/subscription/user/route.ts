import { NextRequest, NextResponse } from 'next/server';
import Subscription from '../../../../models/Subscription';
import SubscriptionPlan from '../../../../models/SubscriptionPlan';
import connectMongoDB from '../../../../lib/mongodb';
import jwt from 'jsonwebtoken';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to get user from token
async function getUserFromToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = request.headers.get('authorization')?.replace('Bearer ', '');
    if (!token) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const user = await getUserFromToken(token);
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    const subscription = await (Subscription as any).findOne({ 
      userId: user.userId,
      status: { $in: ['active', 'pending'] }
    }).sort({ createdAt: -1 });

    if (!subscription) {
      // Tạo subscription free mặc định
      const now = new Date();
      const endDate = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000); // 1 năm
      const freeSubscription = new Subscription({
        userId: user.userId,
        plan: 'free',
        status: 'active',
        startDate: now,
        endDate: endDate,
        amount: 0,
        currency: 'VND',
        autoRenew: false
      });
      await (freeSubscription as any).save();
      
      // Lấy thông tin gói free từ SubscriptionPlan
      const freePlan = await (SubscriptionPlan as any).findOne({ plan: 'free' });
      const maxThreads = freePlan?.maxThreads || 2;

      // Tính số ngày còn lại
      const daysLeft = Math.max(0, Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
      
      return NextResponse.json({
        ...freeSubscription.toObject(),
        maxThreads: maxThreads,
        daysLeft
      });
    }

    // Lấy thông tin gói từ SubscriptionPlan
    const planInfo = await (SubscriptionPlan as any).findOne({ plan: subscription.plan });
    const maxThreads = planInfo?.maxThreads || 2;

    // Tính số ngày còn lại cho subscription hiện tại
    const now = new Date();
    const endDate = new Date(subscription.endDate);
    const baseDaysLeft = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    const daysLeft = subscription.status === 'expired' ? 0 : Math.max(0, baseDaysLeft);
    
    return NextResponse.json({
      ...subscription.toObject(),
      maxThreads: maxThreads,
      daysLeft
    });
  } catch (error) {
    console.error('Error fetching user subscription:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 