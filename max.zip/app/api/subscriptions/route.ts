import { NextRequest, NextResponse } from 'next/server';
import connectMongoDB from '@/lib/mongodb';
import Subscription from '@/models/Subscription';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Import User model để đảm bảo schema được đăng ký
    const User = (await import('@/models/User')).default;
    
    const subscriptions = await (Subscription as any).find().populate('userId', 'username email');
    
    return NextResponse.json({
      success: true,
      subscriptions: subscriptions
    });
  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 