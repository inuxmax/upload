import { NextRequest, NextResponse } from 'next/server'

// Cấu hình Telegram Bot
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID

export async function POST(request: NextRequest) {
  try {
    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
      console.warn('Telegram bot token hoặc chat ID chưa được cấu hình')
      return NextResponse.json(
        { success: false, error: 'Telegram chưa được cấu hình' },
        { status: 400 }
      )
    }

    const body = await request.json()
    const { title, content, ticketId, username, subject } = body

    if (!title || !ticketId || !username) {
      return NextResponse.json(
        { success: false, error: 'Thiếu thông tin bắt buộc' },
        { status: 400 }
      )
    }

    // Tạo message gửi telegram
    const message = `
🎫 *TICKET MỚI*

📋 *Tiêu đề:* ${title}
👤 *Người tạo:* ${username}
🏷️ *Chủ đề:* ${subject || 'Khác'}
🆔 *Ticket ID:* #${ticketId.slice(-6)}

📝 *Nội dung:*
${content || 'Không có nội dung'}

🔗 *Link xử lý:* ${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/admin/tickets

⏰ *Thời gian:* ${new Date().toLocaleString('vi-VN')}
    `.trim()

    // Gửi message đến Telegram
    const telegramResponse = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: TELEGRAM_CHAT_ID,
          text: message,
          parse_mode: 'Markdown',
          disable_web_page_preview: true,
        }),
      }
    )

    const telegramData = await telegramResponse.json()

    if (!telegramResponse.ok) {
      console.error('Lỗi gửi Telegram:', telegramData)
      return NextResponse.json(
        { success: false, error: 'Không thể gửi thông báo Telegram', details: telegramData },
        { status: 500 }
      )
    }

    console.log('Đã gửi thông báo Telegram thành công:', telegramData)
    return NextResponse.json({
      success: true,
      message: 'Thông báo đã được gửi đến Telegram',
      telegramMessageId: telegramData.result?.message_id
    })

  } catch (error) {
    console.error('Lỗi gửi thông báo Telegram:', error)
    return NextResponse.json(
      { success: false, error: 'Lỗi server khi gửi thông báo Telegram' },
      { status: 500 }
    )
  }
}

