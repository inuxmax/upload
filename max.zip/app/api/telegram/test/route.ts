import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    // Kiểm tra cấu hình Telegram
    const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN
    const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID

    if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
      return NextResponse.json({
        success: false,
        error: 'Telegram chưa được cấu hình',
        details: {
          hasBotToken: !!TELEGRAM_BOT_TOKEN,
          hasChatId: !!TELEGRAM_CHAT_ID,
          message: 'Vui lòng thêm TELEGRAM_BOT_TOKEN và TELEGRAM_CHAT_ID vào file .env.local'
        }
      }, { status: 400 })
    }

    // Gửi tin nhắn test
    const testMessage = `
🧪 *TEST THÔNG BÁO*

✅ Telegram Bot đã được cấu hình thành công!
🤖 Bot Token: ${TELEGRAM_BOT_TOKEN.substring(0, 10)}...
💬 Chat ID: ${TELEGRAM_CHAT_ID}

⏰ Thời gian test: ${new Date().toLocaleString('vi-VN')}

📌 *Hệ thống ticket notification đã sẵn sàng!*
    `.trim()

    const telegramResponse = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: TELEGRAM_CHAT_ID,
          text: testMessage,
          parse_mode: 'Markdown',
          disable_web_page_preview: true,
        }),
      }
    )

    const telegramData = await telegramResponse.json()

    if (!telegramResponse.ok) {
      console.error('Lỗi test Telegram:', telegramData)
      return NextResponse.json({
        success: false,
        error: 'Không thể gửi tin nhắn test',
        details: telegramData
      }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: 'Tin nhắn test đã được gửi thành công!',
      telegramResponse: telegramData.result
    })

  } catch (error) {
    console.error('Lỗi test Telegram:', error)
    return NextResponse.json({
      success: false,
      error: 'Lỗi server khi test Telegram',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}

