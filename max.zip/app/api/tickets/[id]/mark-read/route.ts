import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import { verifyToken, extractTokenFromRequest } from '@/lib/jwt'
import Ticket from '@/models/Ticket'
import TicketMessage from '@/models/TicketMessage'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const decoded: any = verifyToken(token)
    const userId = decoded.userId || decoded.id || decoded._id

    // Verify ticket belongs to user
    const ticket = await (Ticket as any).findOne({ _id: params.id, userId })
    if (!ticket) {
      return NextResponse.json({ error: 'Ticket not found' }, { status: 404 })
    }

    // Mark all admin messages in this ticket as read
    await (TicketMessage as any).updateMany(
      { 
        ticketId: params.id, 
        senderType: 'admin',
        isRead: false 
      },
      { isRead: true }
    )

    return NextResponse.json({ success: true })

  } catch (error) {
    console.error('Error marking messages as read:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
