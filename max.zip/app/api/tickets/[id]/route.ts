import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import { verifyToken, extractTokenFromRequest } from '@/lib/jwt'
import Ticket from '@/models/Ticket'
import TicketMessage from '@/models/TicketMessage'


export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const decoded: any = verifyToken(token)
    const userId = decoded.userId || decoded.id || decoded._id

    const ticket = await (Ticket as any).findOne({ _id: params.id, userId })
    if (!ticket) {
      return NextResponse.json({ error: 'Ticket not found' }, { status: 404 })
    }

    const messages = await (TicketMessage as any).find({ ticketId: params.id })
      .sort({ createdAt: 1 })
      .lean()

    return NextResponse.json({
      success: true,
      ticket,
      messages
    })

  } catch (error) {
    console.error('Error fetching ticket:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  let body: any = null;
  
  try {
    console.log('=== POST /api/tickets/[id] START ===')
    console.log('Params:', params)
    console.log('Request method:', request.method)
    console.log('Request headers:', Object.fromEntries(request.headers.entries()))
    console.log('Request URL:', request.url)
    console.log('Request nextUrl:', request.nextUrl)
    console.log('Request body type:', request.body ? typeof request.body : 'No body')
    console.log('Request body readable:', request.body ? 'Yes' : 'No')
    console.log('Request body constructor:', request.body?.constructor?.name)
    console.log('Request body keys:', request.body ? Object.keys(request.body) : 'No body')
    
    console.log('Connecting to MongoDB...')
    await connectMongoDB()
    console.log('MongoDB connected successfully')
    
    console.log('Extracting token...')
    const token = extractTokenFromRequest(request)
    console.log('Token extracted:', token ? 'Present' : 'Missing')
    if (!token) {
      console.log('No token found, returning 401')
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    console.log('Verifying token...')
    const decoded: any = verifyToken(token)
    console.log('Token decoded:', { userId: decoded?.userId, id: decoded?.id, _id: decoded?._id })
    const userId = decoded.userId || decoded.id || decoded._id
    console.log('Final userId:', userId)
    console.log('UserId type:', typeof userId)
    console.log('UserId value:', userId)
    console.log('UserId truthy:', !!userId)

    console.log('Parsing request body...')
    try {
      body = await request.json()
      console.log('Request body:', body)
      console.log('Request body type:', typeof body)
      console.log('Request body keys:', Object.keys(body))
    } catch (parseError) {
      console.error('Error parsing request body:', parseError)
      throw new Error(`Failed to parse request body: ${parseError.message}`)
    }
    
    const content = body.content ? String(body.content).trim() : ''
    const imageUrl = body.imageUrl
    console.log('Processed content:', content, 'imageUrl:', imageUrl)

    console.log('Validation check:', { hasContent: !!content, hasImage: !!imageUrl })
    console.log('Content length:', content.length)
    console.log('ImageUrl length:', imageUrl ? imageUrl.length : 0)
    console.log('Content truthy:', !!content)
    console.log('ImageUrl truthy:', !!imageUrl)
    
    if (!content && !imageUrl) {
      console.log('Validation failed: both content and imageUrl are empty')
      return NextResponse.json(
        { error: 'Nội dung tin nhắn hoặc ảnh không được để trống' },
        { status: 400 }
      )
    }
    console.log('Validation passed')

    // Create message
    console.log('Building message data...')
    const messageData: any = {
      ticketId: params.id,
      senderType: 'user',
      senderId: userId
    }
    
    console.log('Initial messageData:', messageData)
    console.log('Content check:', { content, contentLength: content.length, hasContent: !!content })
    console.log('ImageUrl check:', { imageUrl, imageUrlLength: imageUrl ? imageUrl.length : 0, hasImageUrl: !!imageUrl })
    console.log('Content condition:', content && content.length > 0)
    console.log('ImageUrl condition:', imageUrl && imageUrl.length > 0)
    console.log('MessageData before conditions:', { ...messageData })
    console.log('MessageData type check:', { 
      ticketIdType: typeof messageData.ticketId,
      senderTypeType: typeof messageData.senderType,
      senderIdType: typeof messageData.senderId
    })
    
    if (content && content.length > 0) {
      messageData.content = content
      console.log('Added content to message data')
    }
    
    if (imageUrl && imageUrl.length > 0) {
      messageData.imageUrl = imageUrl
      console.log('Added imageUrl to message data')
    }
    
    console.log('Final messageData:', messageData)
    
    console.log('Creating message with data:', messageData)
    console.log('Message data type:', typeof messageData)
    console.log('Message data keys:', Object.keys(messageData))
    console.log('Message data values:', Object.values(messageData))
    console.log('Message data stringified:', JSON.stringify(messageData))
    
    console.log('About to create message in database...')
    console.log('TicketMessage model:', TicketMessage)
    console.log('TicketMessage type:', typeof TicketMessage)
    console.log('TicketMessage constructor:', TicketMessage?.constructor?.name)
    console.log('TicketMessage methods:', Object.getOwnPropertyNames(TicketMessage))
    
    const message = await (TicketMessage as any).create(messageData)
    console.log('Message created successfully:', message)
    console.log('Message ID:', message._id)
    console.log('Message type:', typeof message)

    // Update ticket lastMessageAt
    console.log('Updating ticket lastMessageAt...')
    console.log('Ticket ID:', params.id)
    console.log('Ticket ID type:', typeof params.id)
    console.log('Ticket ID length:', params.id.length)
    
    console.log('About to update ticket in database...')
    console.log('Ticket model:', Ticket)
    console.log('Ticket type:', typeof Ticket)
    console.log('Ticket constructor:', Ticket?.constructor?.name)
    console.log('Ticket methods:', Object.getOwnPropertyNames(Ticket))
    
    const updateResult = await (Ticket as any).findByIdAndUpdate(params.id, {
      lastMessageAt: new Date()
    })
    console.log('Ticket update result:', updateResult)
    console.log('Ticket updated successfully')



    console.log('Sending success response...')
    console.log('Response message:', message)
    console.log('Response message type:', typeof message)
    console.log('Response message keys:', Object.keys(message))
    console.log('Response message stringified:', JSON.stringify(message))
    console.log('Response message constructor:', message?.constructor?.name)
    console.log('Response message methods:', Object.getOwnPropertyNames(message))
    console.log('=== POST /api/tickets/[id] SUCCESS ===')
    return NextResponse.json({
      success: true,
      message
    })

  } catch (error) {
    console.error('=== POST /api/tickets/[id] ERROR ===')
    console.error('Error sending message:', error)
    console.error('Error type:', typeof error)
    console.error('Error constructor:', error?.constructor?.name)
    console.error('Error name:', error?.name)
    console.error('Error message:', error?.message)
    console.error('Error stack:', error?.stack)
    console.error('Error details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : 'No stack trace',
      params: params,
      body: body
    })
    console.error('Error full object:', JSON.stringify(error, Object.getOwnPropertyNames(error)))
    console.error('=== POST /api/tickets/[id] ERROR END ===')
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
