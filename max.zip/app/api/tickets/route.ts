import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import { verifyToken, extractTokenFromRequest } from '@/lib/jwt'
import Ticket from '@/models/Ticket'

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const decoded: any = verifyToken(token)
    const userId = decoded.userId || decoded.id || decoded._id

    const tickets = await (Ticket as any).find({ userId }).sort({ updatedAt: -1 })

    return NextResponse.json({
      success: true,
      tickets
    })

  } catch (error) {
    console.error('Error fetching tickets:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB()
    const token = extractTokenFromRequest(request)
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const decoded: any = verifyToken(token)
    const userId = decoded.userId || decoded.id || decoded._id

    const body = await request.json()
    const title = String(body.title || '').trim()
    const content = String(body.content || '').trim()
    const subject = String(body.subject || '').trim()

    if (!title || !content || !subject) {
      return NextResponse.json(
        { error: 'Thiếu tiêu đề, nội dung hoặc chủ đề' },
        { status: 400 }
      )
    }

    // Create ticket
    const ticket = await (Ticket as any).create({
      userId,
      title,
      subject,
      status: 'open',
      lastMessageAt: new Date()
    })

    // Create initial message
    const TicketMessage = (await import('@/models/TicketMessage')).default
    await (TicketMessage as any).create({
      ticketId: ticket._id,
      senderType: 'user',
      senderId: userId,
      content
    })

    // Gửi thông báo Telegram
    try {
      console.log('Đang gửi thông báo Telegram cho ticket mới:', ticket._id)
      
      // Lấy thông tin user để gửi thông báo
      const User = (await import('@/models/User')).default
      const user = await (User as any).findById(userId).select('username email fullName')
      
      const telegramResponse = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/telegram/send-notification`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title,
          content,
          ticketId: ticket._id,
          username: user?.username || user?.fullName || 'Unknown User',
          subject
        })
      })

      const telegramResult = await telegramResponse.json()
      if (telegramResult.success) {
        console.log('Thông báo Telegram đã được gửi thành công')
      } else {
        console.warn('Không thể gửi thông báo Telegram:', telegramResult.error)
      }
    } catch (telegramError) {
      console.error('Lỗi khi gửi thông báo Telegram:', telegramError)
      // Không throw error để không ảnh hưởng đến việc tạo ticket
    }

    return NextResponse.json({
      success: true,
      ticket
    })

  } catch (error) {
    console.error('Error creating ticket:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}


