import { NextRequest, NextResponse } from 'next/server'
import connectMongoDB from '@/lib/mongodb'
import { checkTokenValidityEdge } from '@/lib/jwt-edge'
import Ticket from '@/models/Ticket'
import TicketMessage from '@/models/TicketMessage'

// Force dynamic rendering
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB()
    const token = request.headers.get('authorization')?.replace('Bearer ', '') || 
                  request.cookies.get('token')?.value
    
    if (!token) {
      return NextResponse.json({ 
        error: 'Unauthorized', 
        message: 'Token không được cung cấp',
        code: 'NO_TOKEN'
      }, { status: 401 })
    }

    // Kiểm tra token validity trước khi verify (sử dụng Edge-compatible)
    const tokenCheck = checkTokenValidityEdge(token)
    if (!tokenCheck.isValid) {
      if (tokenCheck.error === 'TOKEN_EXPIRED') {
        return NextResponse.json({ 
          error: 'Token expired', 
          message: 'Token đã hết hạn, vui lòng đăng nhập lại',
          code: 'TOKEN_EXPIRED'
        }, { status: 401 })
      }
      
      if (tokenCheck.error === 'TOKEN_MALFORMED') {
        return NextResponse.json({ 
          error: 'Invalid token format', 
          message: 'Token có định dạng không đúng',
          code: 'TOKEN_MALFORMED'
        }, { status: 401 })
      }
      
      if (tokenCheck.error === 'TOKEN_INVALID_SIGNATURE') {
        return NextResponse.json({ 
          error: 'Invalid token signature', 
          message: 'Token có chữ ký không hợp lệ',
          code: 'TOKEN_INVALID_SIGNATURE'
        }, { status: 401 })
      }
      
      if (tokenCheck.error === 'TOKEN_NOT_ACTIVE') {
        return NextResponse.json({ 
          error: 'Token not active', 
          message: 'Token chưa có hiệu lực',
          code: 'TOKEN_NOT_ACTIVE'
        }, { status: 401 })
      }
      
      if (tokenCheck.error === 'NO_TOKEN') {
        return NextResponse.json({ 
          error: 'No token provided', 
          message: 'Token không được cung cấp',
          code: 'NO_TOKEN'
        }, { status: 401 })
      }
      
      if (tokenCheck.error === 'TOKEN_INVALID') {
        return NextResponse.json({ 
          error: 'Invalid token', 
          message: 'Token không hợp lệ',
          code: 'TOKEN_INVALID'
        }, { status: 401 })
      }
      
      return NextResponse.json({ 
        error: 'Authentication failed', 
        message: 'Xác thực thất bại',
        code: 'AUTH_FAILED'
      }, { status: 401 })
    }

    // Token hợp lệ, tiếp tục xử lý
    const decoded: any = tokenCheck.decoded
    const userId = decoded.userId || decoded.id || decoded._id

    if (!userId) {
      return NextResponse.json({ 
        error: 'Invalid token payload', 
        message: 'Token không chứa thông tin user hợp lệ',
        code: 'INVALID_PAYLOAD'
      }, { status: 400 })
    }

    // Get all tickets for this user
    const userTickets = await (Ticket as any).find({ userId }).select('_id')
    const ticketIds = userTickets.map((ticket: any) => ticket._id)

    if (ticketIds.length === 0) {
      return NextResponse.json({ count: 0 })
    }

    // Count unread admin messages
    const unreadCount = await (TicketMessage as any).countDocuments({
      ticketId: { $in: ticketIds },
      senderType: 'admin',
      isRead: false
    })

    return NextResponse.json({ count: unreadCount })

  } catch (error) {
    console.error('Error counting unread messages:', error)
    
    return NextResponse.json(
      { 
        error: 'Internal server error',
        message: 'Lỗi server nội bộ',
        code: 'INTERNAL_ERROR'
      },
      { status: 500 }
    )
  }
}
