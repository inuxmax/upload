import { NextRequest, NextResponse } from 'next/server'
import FacebookAccount from '@/models/FacebookAccount'
import connectDB from '@/lib/mongodb'
import jwt from 'jsonwebtoken'

// Force dynamic rendering
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    // Verify JWT token
    const authHeader = request.headers.get('authorization')
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    
    await connectDB()

    // Lấy tất cả accounts có TKQC data
    const accounts = await (FacebookAccount as any).find({
      $or: [
        { tkqcCount: { $gt: 0 } },
        { bmCount: { $gt: 0 } },
        { tkqcData: { $exists: true, $ne: [] } },
        { bmData: { $exists: true, $ne: [] } }
      ]
    }).select({
      uid: 1,
      mail: 1,
      name: 1,
      status: 1,
      tkqcData: 1,
      bmData: 1,
      accountInfo: 1,
      lastTkqcCheck: 1,
      tkqcCount: 1,
      bmCount: 1,
      log: 1,
      birthday: 1,
      gender: 1
    }).sort({ lastTkqcCheck: -1 })

    // Chuyển đổi dữ liệu để phù hợp với TKQCDataTable interface
    const formattedAccounts = accounts.map((account: any) => ({
      _id: account._id.toString(),
      uid: account.uid || account.mail,
      mail: account.mail,
      name: account.name || account.mail,
      status: account.status || 'active',
      tkqcData: account.tkqcData || [],
      bmData: account.bmData || [],
      accountInfo: account.accountInfo,
      lastTkqcCheck: account.lastTkqcCheck || account.updatedAt || new Date().toISOString(),
      tkqcCount: account.tkqcCount || (account.tkqcData ? account.tkqcData.length : 0),
      bmCount: account.bmCount || (account.bmData ? account.bmData.length : 0),
      log: account.log || `TKQC: ${account.tkqcCount || 0} accounts, ${account.bmCount || 0} BM`,
      birthday: account.birthday,
      gender: account.gender
    }))

    return NextResponse.json({
      success: true,
      accounts: formattedAccounts
    })

  } catch (error) {
    console.error('Error fetching TKQC data from server:', error)
    return NextResponse.json(
      { error: 'Internal server error', success: false },
      { status: 500 }
    )
  }
}
