import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import bcryptjs from 'bcryptjs';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

export async function PUT(request: NextRequest) {
  try {
    await dbConnect();
    console.log('Database connected successfully');

    // Get token from header
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = authHeader.substring(7);
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    
    if (!decoded.userId) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    console.log('User ID from token:', decoded.userId);

    const body = await request.json();
    const { currentPassword, newPassword } = body;

    console.log('Request body:', { currentPassword: !!currentPassword, newPassword: !!newPassword, newPasswordLength: newPassword?.length });

    if (!currentPassword || !newPassword) {
      return NextResponse.json({ error: 'Current password and new password are required' }, { status: 400 });
    }

    if (newPassword.length < 6) {
      return NextResponse.json({ error: 'New password must be at least 6 characters long' }, { status: 400 });
    }

    // Get user with password
    const user = await (User as any).findById(decoded.userId).select('+password');
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Verify current password
    const isCurrentPasswordValid = await bcryptjs.compare(currentPassword, user.password);
    if (!isCurrentPasswordValid) {
      return NextResponse.json({ error: 'Current password is incorrect' }, { status: 400 });
    }

    // Set new password directly (will be hashed by pre-save hook)
    user.password = newPassword;
    await user.save();

    console.log('Password updated successfully for user:', user.username);

    // Verify the password was actually updated
    const updatedUser = await (User as any).findById(decoded.userId).select('+password');
    const isNewPasswordValid = await bcryptjs.compare(newPassword, updatedUser.password);
    console.log('New password verification:', isNewPasswordValid);

    return NextResponse.json({
      success: true,
      message: 'Password changed successfully'
    });

  } catch (error) {
    console.error('Error changing password:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
