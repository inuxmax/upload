import { NextRequest, NextResponse } from 'next/server';
import User from '@/models/User';
import Subscription from '@/models/Subscription';
import SubscriptionPlan from '@/models/SubscriptionPlan';
import connectMongoDB from '@/lib/mongodb';
import { verifyToken, extractTokenFromRequest } from '@/lib/jwt';

// Force dynamic to avoid static rendering warnings
export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    await connectMongoDB();
    
    const token = extractTokenFromRequest(request);
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const decoded = verifyToken(token);
    
    if (!decoded || !decoded.userId) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    // Tìm user
    const user = await (User as any).findById(decoded.userId).exec();
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Tìm subscription active
    const subscription = await (Subscription as any).findOne({ 
      userId: decoded.userId, 
      status: 'active' 
    }).exec();

    if (!subscription) {
      // Nếu không có subscription, trả về gói free mặc định
      const freePlan = await (SubscriptionPlan as any).findOne({ name: 'free' }).exec();
      return NextResponse.json({
        success: true,
        subscription: {
          plan: 'free',
          maxThreads: freePlan?.maxThreads || 2,
          status: 'free'
        }
      });
    }

    // Tìm plan tương ứng với subscription.plan
    const plan = await (SubscriptionPlan as any).findOne({ name: subscription.plan }).exec();
    
    return NextResponse.json({
      success: true,
      subscription: {
        id: subscription._id,
        plan: subscription.plan,
        maxThreads: plan?.maxThreads || 2,
        status: subscription.status,
        startDate: subscription.startDate,
        endDate: subscription.endDate
      }
    });
  } catch (error) {
    console.error('Error in /api/user/subscription:', error);
    return NextResponse.json({ 
      error: 'Internal server error',
      details: error instanceof Error ? error.message : String(error)
    }, { status: 500 });
  }
}
