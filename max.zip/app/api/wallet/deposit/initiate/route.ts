import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import User from '@/models/User';
import PaymentInfo from '@/models/PaymentInfo';
import Transaction from '@/models/Transaction';
import connectMongoDB from '@/lib/mongodb';

export const dynamic = 'force-dynamic';

async function verifyToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch {
    return null;
  }
}

function generateTransferContent(username?: string) {
  const prefix = 'FTOOL';
  const userPart = (username || 'USER').toUpperCase();
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `${prefix}${userPart}${ts}${rand}`;
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();

    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = await verifyToken(token);
    if (!decoded) {
      return NextResponse.json({ error: 'Invalid token' }, { status: 401 });
    }

    const { amount } = await request.json();
    if (!amount || typeof amount !== 'number') {
      return NextResponse.json({ error: 'Amount is required' }, { status: 400 });
    }
    if (amount < 10000) {
      return NextResponse.json({ error: 'Minimum deposit amount is 10,000 VND' }, { status: 400 });
    }

    const user = await (User as any).findById(decoded.userId).lean();
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const paymentInfo = await (PaymentInfo as any).findOne({ isActive: true }).lean();
    if (!paymentInfo) {
      return NextResponse.json({ error: 'Payment info not configured' }, { status: 500 });
    }

    const transferContent = generateTransferContent(user.username);

    const transaction = await (Transaction as any).create({
      userId: user._id,
      type: 'deposit',
      amount,
      transferContent,
      status: 'pending',
      bankInfo: {
        bankName: paymentInfo.bankName || 'ACB',
        accountNumber: paymentInfo.accountNumber,
        accountHolder: paymentInfo.accountHolder
      },
      description: `Nạp tiền chờ xử lý qua ${paymentInfo.bankName || 'ACB'} - ${transferContent}`
    });

    return NextResponse.json({
      success: true,
      transactionId: transaction._id,
      amount,
      transferContent,
      bankInfo: transaction.bankInfo
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}


