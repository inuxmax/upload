import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import User from '@/models/User';
import PaymentInfo from '@/models/PaymentInfo';
import Transaction from '@/models/Transaction';
import connectMongoDB from '@/lib/mongodb';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to verify token
async function verifyToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

// Helper function to check ACB transactions
async function checkACBTransaction(amount: number, transferContent: string, paymentInfo: any) {
  try {
    console.log('Checking ACB transaction via API:', { amount, transferContent, accountNumber: paymentInfo.accountNumber });
    
    // Call ACB API to check for matching transactions
    const acbApiUrl = `https://api.web2m.com/historyapiacbv3/${paymentInfo.passwordACB}/${paymentInfo.accountNumber}/${paymentInfo.tokenACB}`;
    
    const response = await fetch(acbApiUrl, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      console.error('ACB API error:', response.status);
      return false;
    }

    const acbData = await response.json();
    
    if (!acbData.status || !acbData.transactions) {
      console.log('No transactions found or API error');
      return false;
    }

    // Check if there's a matching transaction
    for (const transaction of acbData.transactions) {
      if (transaction.type === 'IN' && transaction.amount === amount) {
        const description = transaction.description || '';
        
        // Check if description contains our transfer content
        const isMatching = 
          description.includes(transferContent) ||
          description.toUpperCase().includes(transferContent.toUpperCase()) ||
          (transferContent.length >= 8 && 
           description.toUpperCase().includes(transferContent.substring(0, 8).toUpperCase()));
        
        if (isMatching) {
          console.log('Found matching ACB transaction:', transaction.transactionID);
          return true;
        }
      }
    }
    
    console.log('No matching transaction found');
    return false;
  } catch (error) {
    console.error('Error checking ACB transaction:', error);
    return false;
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Get token from authorization header
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = await verifyToken(token);
    
    if (!decoded) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    const { amount, transferContent } = await request.json();

    // Validate input
    if (!amount || !transferContent) {
      return NextResponse.json(
        { error: 'Amount and transfer content are required' },
        { status: 400 }
      );
    }

    if (amount < 10000) {
      return NextResponse.json(
        { error: 'Minimum deposit amount is 10,000 VND' },
        { status: 400 }
      );
    }

    // Get payment info from admin settings
    const paymentInfo = await (PaymentInfo as any).findOne({ isActive: true });
    if (!paymentInfo) {
      return NextResponse.json(
        { error: 'Payment info not configured' },
        { status: 500 }
      );
    }

    // Check if transaction exists in ACB
    const transactionExists = await checkACBTransaction(amount, transferContent, paymentInfo);
    
    if (!transactionExists) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'Transaction not found or not yet processed' 
        },
        { status: 200 }
      );
    }

    // Find user and update balance
    const user = await (User as any).findById(decoded.userId);
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Check if this transfer content was already used
    if (user.pendingTransferContents?.includes(transferContent)) {
      return NextResponse.json(
        { 
          success: false, 
          message: 'This transfer content has already been used' 
        },
        { status: 400 }
      );
    }

    // Transaction found in ACB - automatically update balance
    // Generate unique transaction ID
    const transactionId = `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Update user balance immediately
    user.balance = (user.balance || 0) + amount;
    
    // Add transfer content to used list to prevent reuse
    user.pendingTransferContents = user.pendingTransferContents || [];
    user.pendingTransferContents.push(transferContent);
    await (user as any).save();
    
    // Create completed transaction record
    const transaction = new Transaction({
      userId: user._id,
      type: 'deposit',
      amount: amount,
      transferContent: transferContent,
      status: 'completed', // Mark as completed since ACB transaction was verified
      bankInfo: {
        bankName: paymentInfo.bankName || 'ACB',
        accountNumber: paymentInfo.accountNumber,
        accountHolder: paymentInfo.accountHolder
      },
      description: `Nạp tiền qua ${paymentInfo.bankName || 'ACB'} - ${transferContent}`,
      completedAt: new Date()
    });

    await transaction.save();

    return NextResponse.json({
      success: true,
      message: 'Nạp tiền thành công! Số dư đã được cập nhật.',
      transactionId: transaction._id,
      newBalance: user.balance,
      status: 'completed'
    });

  } catch (error) {
    console.error('Error processing deposit:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
