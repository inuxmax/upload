import { NextRequest, NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import User from '@/models/User';
import SubscriptionPlan from '@/models/SubscriptionPlan';
import Subscription from '@/models/Subscription';
import connectMongoDB from '@/lib/mongodb';

// Force dynamic rendering
export const dynamic = 'force-dynamic';

// Helper function to verify token
async function verifyToken(token: string) {
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
    return decoded;
  } catch (error) {
    return null;
  }
}

export async function POST(request: NextRequest) {
  try {
    await connectMongoDB();
    
    // Get token from authorization header
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const decoded = await verifyToken(token);
    
    if (!decoded) {
      return NextResponse.json(
        { error: 'Invalid token' },
        { status: 401 }
      );
    }

    const { planId } = await request.json();

    // Validate input
    if (!planId) {
      return NextResponse.json(
        { error: 'Plan ID is required' },
        { status: 400 }
      );
    }

    // Find user
    const user = await (User as any).findById(decoded.userId);
    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Find subscription plan
    const plan = await (SubscriptionPlan as any).findById(planId);
    if (!plan) {
      return NextResponse.json(
        { error: 'Subscription plan not found' },
        { status: 404 }
      );
    }

    // Check if user has sufficient balance
    const userBalance = user.balance || 0;
    if (userBalance < plan.price) {
      return NextResponse.json(
        { 
          error: 'Insufficient balance',
          required: plan.price,
          current: userBalance,
          shortfall: plan.price - userBalance
        },
        { status: 400 }
      );
    }

    // Deduct balance
    user.balance = userBalance - plan.price;
    await user.save();

    // Create or update subscription
    const startDate = new Date();
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + plan.duration);

    // Check if user already has an active subscription
    let subscription = await (Subscription as any).findOne({ 
      userId: user._id,
      status: 'active'
    });

    if (subscription) {
      // Extend existing subscription
      const currentEndDate = new Date(subscription.endDate);
      const newEndDate = new Date(currentEndDate);
      newEndDate.setMonth(newEndDate.getMonth() + plan.duration);
      
      subscription.endDate = newEndDate;
      subscription.plan = plan.plan;
      await subscription.save();
    } else {
      // Create new subscription
      subscription = new Subscription({
        userId: user._id,
        plan: plan.plan,
        status: 'active',
        startDate,
        endDate,
        amount: plan.price,
        autoRenew: false
      });
      await subscription.save();
    }

    return NextResponse.json({
      success: true,
      message: 'Subscription activated successfully',
      subscription: {
        plan: subscription.plan,
        startDate: subscription.startDate,
        endDate: subscription.endDate,
        status: subscription.status
      },
      newBalance: user.balance
    });

  } catch (error) {
    console.error('Error processing subscription payment:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
