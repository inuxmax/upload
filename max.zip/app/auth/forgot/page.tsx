'use client'

import React, { useState } from 'react'
import { Mail, Shield } from 'lucide-react'
import VersionBadge from '@/components/VersionBadge'

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setMessage('')
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      })
      if (!res.ok) throw new Error('Request failed')
      setMessage('Vui lòng kiểm tra email để đặt lại mật khẩu.')
    } catch {
      setMessage('Không gửi được email. Vui lòng thử lại.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      {/* Animated Background for parity with login */}
      <div className="animated-background">
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mr-3">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Ftool.vn</h1>
              <VersionBadge />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Quên mật khẩu</h2>
          <p className="text-gray-200">Nhập email để nhận liên kết đặt lại mật khẩu</p>
        </div>

        {/* Card */}
        <div className="glass-effect rounded-2xl shadow-xl p-8">
          <form onSubmit={submit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-white mb-2">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input type="email" value={email} onChange={e=>setEmail(e.target.value)} required className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500" placeholder="you@example.com" />
              </div>
            </div>
            {message && <div className="bg-white/70 text-gray-800 px-4 py-3 rounded-lg text-sm">{message}</div>}
            <button disabled={loading} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2.5 px-4 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 focus:ring-4 focus:ring-blue-300 transition-all duration-200 disabled:opacity-50">
              {loading? 'Đang gửi...' : 'Gửi liên kết đặt lại mật khẩu'}
            </button>
            <div className="text-center">
              <a href="/auth" className="text-blue-200 hover:text-blue-100 text-sm">Quay lại đăng nhập</a>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}


