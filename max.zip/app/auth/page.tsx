'use client';

import React, { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { User, Lock, Mail, Eye, EyeOff, ArrowRight, Shield } from 'lucide-react';
import Script from 'next/script';

export default function AuthPage() {
  const router = useRouter();
  const [theme, setTheme] = useState('dark');
  const [isLogin, setIsLogin] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState('');
  const [verificationStatus, setVerificationStatus] = useState<any>(null);
  const [checkingVerification, setCheckingVerification] = useState(false);
  const [resendingVerification, setResendingVerification] = useState(false);
  const [message, setMessage] = useState('');
  const googleButtonRef = useRef<HTMLDivElement | null>(null);

  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    fullName: ''
  });

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  const addNotification = (notification: any) => {
    // Simple notification implementation
    console.log('Notification:', notification);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');

    if (!isLogin && formData.password !== formData.confirmPassword) {
      setError('Mật khẩu xác nhận không khớp');
      return;
    }

    setIsLoading(true);

    try {
      const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';
      const payload = isLogin 
        ? { username: formData.username, password: formData.password }
        : { username: formData.username, email: formData.email, password: formData.password, fullName: formData.fullName };

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok) {
        const errorMessage = data.error || 'Đã xảy ra lỗi';
        setError(errorMessage);
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: errorMessage
        });
        setIsLoading(false);
        return;
      }

      if (isLogin) {
        // Store token and redirect to dashboard
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        document.cookie = `token=${data.token}; path=/; max-age=86400; secure; samesite=strict`;
        
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đăng nhập thành công!'
        });
        router.push('/dashboard');
      } else {
        setMessage('Đăng ký thành công! Vui lòng kiểm tra email để xác thực tài khoản.');
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đăng ký thành công!'
        });
        
        setTimeout(() => {
          setIsLogin(true);
          setFormData({
            username: '',
            email: '',
            password: '',
            confirmPassword: '',
            fullName: ''
          });
          setMessage('');
        }, 2000);
      }
    } catch (error) {
      const errorMessage = 'Lỗi mạng. Vui lòng thử lại.';
      setError(errorMessage);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: errorMessage
      });
    } finally {
      setIsLoading(false);
    }
  };

  const checkVerificationStatus = async (username: string) => {
    if (!username) return;
    
    try {
      setCheckingVerification(true);
      const res = await fetch('/api/auth/check-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username })
      });
      
      if (res.ok) {
        const data = await res.json();
        setVerificationStatus(data);
        if (data.isVerified) {
          setMessage('✅ Tài khoản đã được xác thực');
        } else {
          setMessage('❌ Tài khoản chưa được xác thực');
        }
      }
    } catch (e) {
      console.error('Check verification error:', e);
      setMessage('❌ Lỗi kiểm tra trạng thái xác thực');
    } finally {
      setCheckingVerification(false);
    }
  };

  const resendVerification = async () => {
    if (!formData.username) return;
    
    try {
      setResendingVerification(true);
      const res = await fetch('/api/auth/resend-verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: formData.username })
      });
      
      if (res.ok) {
        setMessage('✅ Email xác thực đã được gửi lại');
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error || 'Lỗi gửi email xác thực'}`);
      }
    } catch (e) {
      console.error('Resend verification error:', e);
      setMessage('❌ Lỗi gửi email xác thực');
    } finally {
      setResendingVerification(false);
    }
  };

  const onGoogleScriptLoad = () => {
    if (typeof window !== 'undefined' && (window as any).google) {
      (window as any).google.accounts.id.initialize({
        client_id: process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID,
        callback: handleGoogleSignIn,
      });
      
      if (googleButtonRef.current) {
        (window as any).google.accounts.id.renderButton(googleButtonRef.current, {
          theme: 'outline',
          size: 'large',
          text: 'signin_with',
          shape: 'rectangular',
        });
      }
    }
  };

  const handleGoogleSignIn = async (response: any) => {
    try {
      setGoogleLoading(true);
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken: response.credential }),
      });

      const data = await res.json();

      if (res.ok) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        document.cookie = `token=${data.token}; path=/; max-age=86400; secure; samesite=strict`;
        
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đăng nhập Google thành công!'
        });
        
        router.push('/dashboard');
      } else {
        setError(data.error || 'Đăng nhập Google thất bại');
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: data.error || 'Đăng nhập Google thất bại'
        });
      }
    } catch (error) {
      setError('Lỗi mạng. Vui lòng thử lại.');
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Lỗi mạng. Vui lòng thử lại.'
      });
    } finally {
      setGoogleLoading(false);
    }
  };

  const VersionBadge = () => (
    <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xs px-2 py-1 rounded-full">
      BETA 1.0.6
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      {/* Theme Toggle */}
      <button
        onClick={toggleTheme}
        className="absolute top-4 right-4 p-2 rounded-lg bg-white/10 backdrop-blur-sm text-white hover:bg-white/20 transition-colors"
      >
        {theme === 'dark' ? (
          <div className="w-5 h-5">☀️</div>
        ) : (
          <div className="w-5 h-5">🌙</div>
        )}
      </button>
      
      {/* Animated Background */}
      <div className="animated-background">
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
      </div>
      
      <div className="w-full max-w-md relative z-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mr-3">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Ftool.vn</h1>
              <VersionBadge />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">
            {isLogin ? 'Chào mừng trở lại' : 'Tạo tài khoản'}
          </h2>
          <p className="text-gray-200">
            {isLogin 
              ? 'Đăng nhập vào tài khoản để tiếp tục' 
              : 'Tham gia cùng chúng tôi và bắt đầu quản lý tài khoản'
            }
          </p>
        </div>

        {/* Google API Script */}
        <Script src="https://accounts.google.com/gsi/client" async defer onLoad={onGoogleScriptLoad} />

        {/* Form */}
        <div className="glass-effect rounded-2xl shadow-xl p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Username Field */}
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-white mb-2">
                Tên đăng nhập
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  id="username"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500"
                  placeholder="Nhập tên đăng nhập"
                  required
                />
              </div>
            </div>

            {/* Email Field (Register only) */}
            {!isLogin && (
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-white mb-2">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500"
                    placeholder="Nhập email của bạn"
                    required
                  />
                </div>
              </div>
            )}

            {/* Full Name Field (Register only) */}
            {!isLogin && (
              <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-white mb-2">
                  Họ và tên
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500"
                    placeholder="Nhập họ và tên của bạn"
                    required
                  />
                </div>
              </div>
            )}

            {/* Password Field */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-white mb-2">
                Mật khẩu
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500"
                  placeholder="Nhập mật khẩu"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Verification Status and Resend Button */}
            {isLogin && formData.username && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => checkVerificationStatus(formData.username)}
                    className="text-blue-200 hover:text-blue-100 text-sm underline"
                  >
                    Kiểm tra trạng thái xác thực
                  </button>
                  <button
                    type="button"
                    onClick={() => router.push('/auth/forgot')}
                    className="text-red-200 hover:text-red-100 text-sm underline"
                  >
                    Quên mật khẩu?
                  </button>
                </div>
                
                {/* Verification Status Display */}
                {verificationStatus && (
                  <div className="bg-white/10 rounded-lg p-3">
                    <p className="text-white text-sm">
                      Trạng thái: {verificationStatus.isVerified ? '✅ Đã xác thực' : '❌ Chưa xác thực'}
                    </p>
                    {!verificationStatus.isVerified && (
                      <button
                        type="button"
                        onClick={resendVerification}
                        disabled={resendingVerification}
                        className="mt-2 text-green-200 hover:text-green-100 text-sm underline"
                      >
                        {resendingVerification ? 'Đang gửi...' : 'Gửi lại email xác thực'}
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Confirm Password Field (Register only) */}
            {!isLogin && (
              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-white mb-2">
                  Xác nhận mật khẩu
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    id="confirmPassword"
                    name="confirmPassword"
                    value={formData.confirmPassword}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 text-gray-900 placeholder-gray-500"
                    placeholder="Xác nhận mật khẩu"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            )}

            {/* Error/Success Messages */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}
            {message && (
              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm">
                {message}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2.5 px-4 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 focus:ring-4 focus:ring-blue-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center text-sm"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              ) : (
                <>
                  {isLogin ? 'Đăng nhập' : 'Tạo tài khoản'}
                  <ArrowRight className="w-3.5 h-3.5 ml-2" />
                </>
              )}
            </button>
            
            {!isLogin && (
              <p className="text-white/90 text-sm">Đăng ký xong, bạn cần xác thực email trước khi đăng nhập.</p>
            )}

            {/* Google Login Button */}
            <div className="mt-4">
              <div ref={googleButtonRef} className="flex justify-center" />
            </div>
          </form>

          {/* Toggle Login/Register */}
          <div className="mt-6 text-center">
            <p className="text-gray-200">
              {isLogin ? 'Chưa có tài khoản?' : 'Đã có tài khoản?'}
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setFormData({
                    username: '',
                    email: '',
                    password: '',
                    confirmPassword: '',
                    fullName: ''
                  });
                  setError('');
                  setMessage('');
                  setVerificationStatus(null);
                }}
                className="text-blue-300 hover:text-blue-200 font-medium ml-1 underline"
              >
                {isLogin ? 'Đăng ký' : 'Đăng nhập'}
              </button>
            </p>
          </div>
        </div>
      </div>

      {/* CSS for animated background */}
      <style jsx>{`
        .animated-background {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: -1;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          overflow: hidden;
        }
        
        .floating-element {
          position: absolute;
          width: 100px;
          height: 100px;
          background: rgba(255, 255, 255, 0.1);
          border-radius: 50%;
          animation: float 6s ease-in-out infinite;
        }
        
        .floating-element:nth-child(1) {
          top: 20%;
          left: 10%;
          animation-delay: 0s;
        }
        
        .floating-element:nth-child(2) {
          top: 60%;
          left: 80%;
          animation-delay: 2s;
        }
        
        .floating-element:nth-child(3) {
          top: 80%;
          left: 20%;
          animation-delay: 4s;
        }
        
        .floating-element:nth-child(4) {
          top: 30%;
          left: 70%;
          animation-delay: 1s;
        }
        
        .floating-element:nth-child(5) {
          top: 70%;
          left: 40%;
          animation-delay: 3s;
        }
        
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
            opacity: 0.7;
          }
          50% {
            transform: translateY(-20px) rotate(180deg);
            opacity: 0.3;
          }
        }
        
        .glass-effect {
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
} 