'use client'

import React, { useEffect, useState, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { CheckCircle, Shield } from 'lucide-react'
import VersionBadge from '@/components/VersionBadge'

function VerifyEmailForm() {
  const params = useSearchParams()
  const router = useRouter()
  const token = params.get('token') || ''
  const uid = params.get('uid') || ''
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading')
  const [message, setMessage] = useState('Đang xác thực tài khoản...')

  useEffect(() => {
    const run = async () => {
      try {
        const res = await fetch('/api/auth/verify-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token, uid })
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error || 'Failed')
        setStatus('success')
        setMessage('Xác thực thành công! Bạn có thể đăng nhập.')
      } catch (e: any) {
        setStatus('error')
        setMessage(e.message || 'Xác thực thất bại')
      }
    }
    if (token && uid) run()
  }, [token, uid])

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <div className="animated-background">
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
        <div className="floating-element"></div>
      </div>
      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center mr-3">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Ftool.vn</h1>
              <VersionBadge />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2">Xác thực tài khoản</h2>
        </div>
        <div className="glass-effect rounded-2xl shadow-xl p-8 text-center">
          <div className="flex justify-center mb-3">
            <CheckCircle className={`w-8 h-8 ${status==='success'?'text-green-500':'text-blue-500'}`} />
          </div>
          <p className="text-white mb-4">{message}</p>
          <a href="/auth" className="inline-block bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2.5 px-4 rounded-lg font-medium">Về trang đăng nhập</a>
        </div>
      </div>
    </div>
  )
}

export default function VerifyEmailPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-gray-600 text-xl font-medium">Đang tải...</div>
        </div>
      </div>
    }>
      <VerifyEmailForm />
    </Suspense>
  )
}


