'use client'

import React, { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { 
  Settings, Plus, Search, Play, Square as StopIcon, ChevronDown, FileText, User, Users, Calendar, Eye, Trash, RefreshCw, Shield, Database, Globe, BarChart3, Activity, Target, Lock, Unlock, Download, Upload, Filter, Star, Crown, Home, Menu, X, EyeOff, AlertCircle, UserCheck, UserX, TrendingUp, Edit, LogOut, Bell, Grid3X3, List, MoreVertical, Trash2, Sun, Moon, Mail, Key, Cookie, Hash, Copy, Minus, Terminal, ChevronUp, Building2, DollarSign, CreditCard
} from 'lucide-react'
import SettingsModal from '../../components/SettingsModal'
import AccountManagementModal from '../../components/AccountManagementModal'
import WelcomeModal from '../../components/WelcomeModal'
import TKQCDataTable from '../../components/TKQCDataTable'
import FunctionPanel from '../../components/FunctionPanel'
import { LazyTKQCDataTable, LazyFunctionPanel, LazyAccountManagementModal, LazySettingsModal } from '../../components/LazyComponents'
import VirtualTable from '../../components/VirtualTable'
import { useDebounce } from '../../hooks/useDebounce'

import Navigation from '../../components/Navigation'
import { useNotification } from '../../components/NotificationSystem'
import VersionBadge from '@/components/VersionBadge'
import { useStorage } from '../../contexts/StorageContext'

interface FacebookAccount {
  _id: string;
  uid: string;
  pass: string;
  twofa: string;
  twoFASecret?: string;
  has2FA?: boolean;
  mail: string;
  passmail: string;
  mailkp?: string;
  cookie: string;
  token: string;
  name: string;
  friends: string;
  gender: string;
  creationDate: string;
  status: 'active' | 'checking' | 'error' | 'inactive' | 'processing';
  log: string;
  lastUpdated: string;
  createdAt: string;
  updatedAt: string;
  quality?: string; // Chất lượng via
  birthday?: string; // Sinh nhật từ Graph API
  tkqcData?: any[]; // Array of TKQC accounts from API
  accountInfo?: {
    balance?: string;
    currency?: string;
    amount_spent?: string;
    spend?: string;
  }; // Summary account info
  bmCount?: number; // Số lượng Business Manager
  bmData?: any; // Dữ liệu Business Manager
}

export default function Dashboard() {
  const router = useRouter()

  const { addNotification } = useNotification()
  const { saveToLocalStorage, loadFromLocalStorage } = useStorage()
  const [user, setUser] = useState<any>(null)
  const [accounts, setAccounts] = useState<FacebookAccount[]>([])
  const [loading, setLoading] = useState(true)
  const [showSettings, setShowSettings] = useState(false)

  const [showAccountManagement, setShowAccountManagement] = useState(false)
  const [showWelcomeModal, setShowWelcomeModal] = useState(false)
  const hasShownWelcomeThisLoad = useRef(false)
  const [welcomePopupSettings, setWelcomePopupSettings] = useState({
    enabled: true,
    title: "Thông báo",
    message: "Chào mừng bạn quay trở lại !",
    showDontShowAgain: true,
    showOnLogin: true,
    showOnDashboard: false
  })
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const debouncedSearchTerm = useDebounce(searchTerm, 300)
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>(() => {
    // Load from localStorage on init
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('dashboard_selectedAccounts')
      if (saved) {
        try {
          const parsed = JSON.parse(saved)
          return parsed
        } catch (e) {
          // Failed to parse saved data
        }
      }
    }
    return []
  })
  const [highlightedAccounts, setHighlightedAccounts] = useState<string[]>([])
  const [isProgressMinimized, setIsProgressMinimized] = useState(false)

  const [progressLogs, setProgressLogs] = useState<string[]>([])
  const progressLogsRef = useRef<HTMLDivElement>(null)
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table')
  const [liveLogs, setLiveLogs] = useState<string[]>([])
  const [showTKQCModal, setShowTKQCModal] = useState(false)
  const [selectedAccountForTKQC, setSelectedAccountForTKQC] = useState<string | null>(null)
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState(false)
  const [accountsToDelete, setAccountsToDelete] = useState<string[]>([])
  const [showFunctionPanel, setShowFunctionPanel] = useState(true)
  const [showTopTicker, setShowTopTicker] = useState(true)
  const [topTickerMessages, setTopTickerMessages] = useState<string[]>([
    'Thông báo: Hệ thống đang hoạt động ổn định. Chúc bạn một ngày làm việc hiệu quả!',
    'Mẹo: Lên dùng Proxy riêng để đăng nhập vào tài khoản. vì proxy của chúng tôi nhiều lúc sẽ bị lỗi',
    'Mẹo: Dùng chức năng Check Info Via để cập nhật tên, giới tính, bạn bè nhanh chóng.',
    'Lưu ý: Không tải lại trang khi đang chạy chức năng.'
  ])
  const [topTickerIndex, setTopTickerIndex] = useState(0)
  const [changeMailOptions, setChangeMailOptions] = useState<{ method?: 'mail1s' | 'outlook'; mail1sAddress?: string; autoConfirm?: boolean }>({ method: 'mail1s', autoConfirm: true })
  const [regBmOptions, setRegBmOptions] = useState<{ createAdAccount?: boolean; createPixel?: boolean; createCatalog?: boolean; pixelName?: string; catalogName?: string; method?: 'graph' | 'server2'; businessName?: string }>({ createAdAccount: true, method: 'graph' })
  const [loginOptions, setLoginOptions] = useState<{ loginFirst?: boolean; loginMethod?: 'cookie' | 'password' }>({ loginFirst: false, loginMethod: 'cookie' })
  const [shareBmOptions, setShareBmOptions] = useState<{ mode?: 'single' | 'all'; bmId?: string; email?: string; useMail1s?: boolean; mail1sApiKey?: string; mail1sAddress?: string; role?: 'ADMIN' | 'EMPLOYEE'; quantity?: number }>({ mode: 'single', role: 'ADMIN', quantity: 1 })
  const [shareBmLinks, setShareBmLinks] = useState<{ title: string; url: string }[]>([])

  // Load welcome popup settings
  const loadWelcomePopupSettings = async () => {
    try {
      const response = await fetch('/api/admin/welcome-popup/settings', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setWelcomePopupSettings(data.settings);
      }
    } catch (error) {
      console.error('Error loading welcome popup settings:', error);
    }
  };

  // Function to add logs to progress
  const addProgressLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString('vi-VN', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    })
    const logEntry = `[${timestamp}] ${message}`
    
    setProgressLogs(prev => {
      const newLogs = [...prev, logEntry]
      // Keep only last 100 logs to prevent memory issues
      return newLogs.slice(-100)
    })
    
    // Auto scroll to bottom
    setTimeout(() => {
      if (progressLogsRef.current) {
        progressLogsRef.current.scrollTop = progressLogsRef.current.scrollHeight
      }
    }, 100)
  }

  // Helper function để cập nhật account status với progress log
  const updateAccountStatus = (accountId: string, status: FacebookAccount['status'], log: string, additionalData?: any) => {
    const timestamp = new Date().toLocaleTimeString('vi-VN', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    })
    const logWithTimestamp = `[${timestamp}] ${log}`
    
    // Tìm account để lấy email cho progress log
    let account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || account?.uid || 'Unknown'
    
    setAccounts(prev => prev.map(acc => 
      acc._id === accountId 
        ? { 
            ...acc, 
            status, 
            log: logWithTimestamp,
            lastUpdated: new Date().toISOString(),
            ...additionalData
          }
        : acc
    ))
    
      // Cũng thêm vào progress logs
  addProgressLog(`${email}: ${log}`)
}

// Currency conversion rates to VND
const CURRENCY_RATES = {
  // Major currencies
  'USD': 24000,
  'EUR': 26000,
  'GBP': 30000,
  'JPY': 160,
  'CAD': 18000,
  'AUD': 16000,
  'CHF': 27000,
  'NZD': 15000,
  
  // Asian currencies
  'CNY': 3300,
  'KRW': 18,
  'THB': 700,
  'MYR': 5400,
  'SGD': 18000,
  'IDR': 1.6,
  'PHP': 430,
  'INR': 290,
  'PKR': 86,
  'BDT': 200,
  'LKR': 74,
  'MMK': 11.4,
  'KHR': 5.9,
  'LAK': 1.2,
  
  // Middle East & Africa
  'AED': 6500,
  'SAR': 6400,
  'QAR': 6600,
  'KWD': 78000,
  'BHD': 63600,
  'OMR': 62400,
  'JOD': 33800,
  'ILS': 6500,
  'TRY': 800,
  'EGP': 490,
  'ZAR': 1300,
  'NGN': 15.6,
  'KES': 156,
  'GHS': 1400,
  'MAD': 2400,
  'TND': 7700,
  
  // European currencies
  'NOK': 2200,
  'SEK': 2200,
  'DKK': 3500,
  'PLN': 5900,
  'CZK': 1000,
  'HUF': 65,
  'RON': 5200,
  'BGN': 13300,
  'HRK': 3500,
  'RSD': 220,
  'RUB': 250,
  'UAH': 580,
  'BYN': 7300,
  
  // Latin American currencies
  'BRL': 4800,
  'MXN': 1400,
  'ARS': 24,
  'CLP': 25,
  'COP': 5.6,
  'PEN': 6400,
  'UYU': 610,
  'BOB': 3500,
  'PYG': 3.3,
  'VES': 0.0007,
  
  // Other currencies
  'HKD': 3100,
  'TWD': 750,
  'MOP': 3000,
  'BND': 18000,
  'FJD': 10800,
  'PGK': 6000,
  'SBD': 2900,
  'TOP': 10200,
  'VUV': 200,
  'WST': 8800,
  'XPF': 210,
  
  // Vietnamese Dong variants
  'VND': 1,
  'VNĐ': 1
}

// Helper function để chuyển đổi tiền tệ về VND
const convertToVND = (amount: string | number, currency: string): number => {
  if (!amount || amount === '0' || amount === 0) return 0
  
  const numAmount = typeof amount === 'string' ? parseFloat(amount.replace(/[,$]/g, '')) : amount
  if (isNaN(numAmount)) return 0
  
  const rate = CURRENCY_RATES[currency?.toUpperCase() as keyof typeof CURRENCY_RATES] || CURRENCY_RATES['USD']
  return Math.round(numAmount * rate)
}

// Helper function để format VND
const formatVND = (amount: number): string => {
  if (amount === 0) return '0 VNĐ'
  return new Intl.NumberFormat('vi-VN').format(amount) + ' VNĐ'
}

// Helper function để lấy tổng tài chính từ một account
const getAccountFinancials = (account: FacebookAccount) => {
  let balance = 0
  let amountSpent = 0
  let spend = 0
  let currency = 'USD'
  
  // Nếu có tkqcData (array), tính tổng từ tất cả TKQC
  if (account.tkqcData && Array.isArray(account.tkqcData)) {
    account.tkqcData.forEach((tkqc: any) => {
      const tkqcCurrency = tkqc.currency || 'USD'
      currency = tkqcCurrency // Lấy currency từ TKQC đầu tiên
      
      if (tkqc.balance) {
        balance += convertToVND(tkqc.balance, tkqcCurrency)
      }
      if (tkqc.amount_spent) {
        amountSpent += convertToVND(tkqc.amount_spent, tkqcCurrency)
      }
      if (tkqc.spend) {
        spend += convertToVND(tkqc.spend, tkqcCurrency)
      }
    })
  }
  // Nếu có accountInfo, sử dụng thông tin tổng hợp
  else if (account.accountInfo) {
    currency = account.accountInfo.currency || 'USD'
    if (account.accountInfo.balance) {
      balance = convertToVND(account.accountInfo.balance, currency)
    }
    if (account.accountInfo.amount_spent) {
      amountSpent = convertToVND(account.accountInfo.amount_spent, currency)
    }
    if (account.accountInfo.spend) {
      spend = convertToVND(account.accountInfo.spend, currency)
    }
  }
  
  return {
    balance,
    amountSpent,
    spend,
    currency,
    balanceFormatted: formatVND(balance),
    amountSpentFormatted: formatVND(amountSpent),
    spendFormatted: formatVND(spend)
  }
}

// Helper function để tính tổng từ nhiều TKQC accounts
const calculateTotalFinancials = (accounts: FacebookAccount[]) => {
  let totalBalance = 0
  let totalAmountSpent = 0
  let totalSpend = 0
  
  accounts.forEach(account => {
    const financials = getAccountFinancials(account)
    totalBalance += financials.balance
    totalAmountSpent += financials.amountSpent
    totalSpend += financials.spend
  })
  
  return {
    totalBalance: formatVND(totalBalance),
    totalAmountSpent: formatVND(totalAmountSpent),
    totalSpend: formatVND(totalSpend),
    totalBalanceRaw: totalBalance,
    totalAmountSpentRaw: totalAmountSpent,
    totalSpendRaw: totalSpend
  }
}

  const [isRunning, setIsRunning] = useState(false)
  const [currentThreads, setCurrentThreads] = useState(0)
  const [maxThreads, setMaxThreads] = useState(10)
  const [globalMaxThreads, setGlobalMaxThreads] = useState(50)
  const [allowUserThreadSettings, setAllowUserThreadSettings] = useState(true)
  const [processingAccounts, setProcessingAccounts] = useState<string[]>([])
  const [userSubscription, setUserSubscription] = useState<any>(null)
  const [proxyInfo, setProxyInfo] = useState<any>(null)
  const [proxySettings, setProxySettings] = useState<any>(() => {
    // Load from localStorage on init
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('dashboard_proxySettings')
      if (saved) {
        try {
          return JSON.parse(saved)
        } catch (e) {
          // Failed to parse saved data
        }
      }
    }
    return {
      selectedProxyId: null,
      databaseIP: null
    }
  })
  const [availableProxies, setAvailableProxies] = useState<any[]>([])
  const [settingsLoaded, setSettingsLoaded] = useState(false)

  // Helper function to calculate effective max threads
  const getEffectiveMaxThreads = () => {
    const effective = userSubscription && userSubscription.plan !== 'enterprise' && userSubscription.maxThreads !== -1
      ? Math.min(maxThreads, userSubscription.maxThreads)
      : maxThreads
    
    return effective
  }

  const [selectedFunction, setSelectedFunction] = useState<string | null>(() => {
    // Load from localStorage on init
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('dashboard_selectedFunction')
      if (saved) {
        try {
          return saved
        } catch (e) {
          // Failed to parse saved data
        }
      }
    }
    return null
  })
  
  // Progress tracking states
  const [progress, setProgress] = useState({
    total: 0,
    completed: 0,
    failed: 0,
    current: 0,
    isProcessing: false
  })

  // Ref để theo dõi trạng thái isRunning một cách đồng bộ
  const isRunningRef = useRef(false)
  // Track active network requests to allow cancellation on Stop
  const activeControllersRef = useRef<Map<string, AbortController[]>>(new Map())
  const runIdRef = useRef(0)

  // Helper: controlled fetch that can be aborted on Stop
  const controlledFetch = async (url: string, options: any, accountId: string) => {
    const controller = new AbortController()
    const list = activeControllersRef.current.get(accountId) || []
    activeControllersRef.current.set(accountId, [...list, controller])
    try {
      const res = await fetch(url, { ...(options || {}), signal: controller.signal })
      return res
    } finally {
      // remove controller
      const arr = activeControllersRef.current.get(accountId) || []
      activeControllersRef.current.set(
        accountId,
        arr.filter((c) => c !== controller)
      )
    }
  }

  // Đồng bộ isRunningRef với isRunning state
  useEffect(() => {
    isRunningRef.current = isRunning
  }, [isRunning])

  // Save selectedAccounts to storage when changed
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const data = JSON.stringify(selectedAccounts)
      localStorage.setItem('dashboard_selectedAccounts', data)
      sessionStorage.setItem('dashboard_selectedAccounts', data)
    }
  }, [selectedAccounts])

  // Save selectedFunction to storage when changed
  useEffect(() => {
    if (typeof window !== 'undefined') {
      if (selectedFunction) {
        localStorage.setItem('dashboard_selectedFunction', selectedFunction)
      } else {
        localStorage.removeItem('dashboard_selectedFunction')
      }
    }
  }, [selectedFunction])

  
  // Protection: Restore selectedAccounts if it gets reset unexpectedly
  useEffect(() => {
    const interval = setInterval(() => {
      if (typeof window !== 'undefined' && selectedAccounts.length === 0) {
        // Try both localStorage and sessionStorage
        const savedLocal = localStorage.getItem('dashboard_selectedAccounts')
        const savedSession = sessionStorage.getItem('dashboard_selectedAccounts')
        const saved = savedSession || savedLocal
        
        if (saved) {
          try {
            const parsed = JSON.parse(saved)
            if (parsed.length > 0) {
              setSelectedAccounts(parsed)
            }
          } catch (e) {
            // Failed to restore
          }
        }
      }
    }, 500) // Check every 500ms for faster recovery

    return () => clearInterval(interval)
  }, [selectedAccounts])

  // Wrapper function to protect selectedAccounts during operations
  const setSelectedAccountsWithLog = (newValue: string[] | ((prev: string[]) => string[])) => {
    // PROTECTION: Prevent clearing during login process
    if (isRunning && Array.isArray(newValue) && newValue.length === 0) {
      return
    }
    
    if (typeof newValue === 'function') {
      setSelectedAccounts(prev => {
        const result = newValue(prev)
        
        // PROTECTION: Prevent clearing during login process
        if (isRunning && result.length === 0 && prev.length > 0) {
          return prev
        }
        
        return result
      })
    } else {
      setSelectedAccounts(newValue)
    }
  }

  // Context menu states
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    accountId?: string;
  }>({
    visible: false,
    x: 0,
    y: 0
  })

  const [notifications, setNotifications] = useState<Array<{id: string, message: string, type: 'success' | 'error' | 'info' | 'warning'}>>([])

  // Load settings from API
  const loadSettings = async () => {
    try {
      const response = await fetch('/api/settings', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        // The API now returns the effective maxThreads that respects admin limits
        setMaxThreads(data.maxThreads || 10)
        setGlobalMaxThreads(data.globalMaxThreads || 50)
        setAllowUserThreadSettings(data.allowUserThreadSettings !== false)
        setSettingsLoaded(true)
      }
    } catch (error) {
      // Handle error silently
    }
  }

  // Load user subscription
  const loadUserSubscription = async () => {
    try {
      const response = await fetch('/api/subscription/user', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setUserSubscription(data)
        
        // Chỉ áp dụng giới hạn gói khi settings đã được load
        if (settingsLoaded) {
          // Sử dụng maxThreads từ gói subscription
          const subscriptionMaxThreads = data.maxThreads || 2
          
          // Nếu subscriptionMaxThreads = -1 (enterprise plan), không giới hạn
          if (subscriptionMaxThreads === -1) {
            // Enterprise plan - no thread limit applied
            // Không thay đổi maxThreads hiện tại
          } else {
            // Áp dụng giới hạn gói subscription lên maxThreads hiện tại
            setMaxThreads(prevMaxThreads => Math.min(prevMaxThreads, subscriptionMaxThreads))
          }
        }
      }
    } catch (error) {
      // Handle error silently
    }
  }

  // Refresh subscription data manually
  const refreshSubscription = async () => {
    await loadUserSubscription()
    // Áp dụng giới hạn gói sau khi refresh
    if (settingsLoaded && userSubscription) {
      const subscriptionMaxThreads = userSubscription.maxThreads || 2
      
      if (subscriptionMaxThreads !== -1) {
        setMaxThreads(prevMaxThreads => Math.min(prevMaxThreads, subscriptionMaxThreads))
      }
    }
  }

  // Load accounts from API or localStorage based on storage mode
  const loadAccounts = async (preserveSelection = false) => {
    try {
      // Get storage mode from localStorage
      const storageMode = localStorage.getItem('storage_mode') || 'server'
      
      
      let data: any[] = []
      
      // Load from server if enabled
      if (storageMode === 'server' || storageMode === 'both') {
        
        const response = await fetch('/api/facebook-accounts', {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })
        
        if (response.ok) {
          data = await response.json()
          
        } else {
          
        }
      }
      
      // Load from localStorage if enabled
      if (storageMode === 'local' || storageMode === 'both') {
        
        try {
          const saved = localStorage.getItem('facebook_accounts')
          const localData = saved ? JSON.parse(saved) : []
          
          
          if (storageMode === 'local') {
            data = localData
            
          } else if (storageMode === 'both') {
            // Merge server and local data, prioritize server data; dedupe by uid
            const serverUids = new Set((data || []).map((acc: any) => String(acc.uid || '')))
            const localOnly = (localData || []).filter((acc: any) => !serverUids.has(String(acc.uid || '')))
            data = [...data, ...localOnly]
            
          }
        } catch (error) {
          console.error('Error loading from localStorage:', error)
        }
      }
      
      
      setAccounts(data)
      
      // If preserveSelection is true, filter out non-existent accounts from selection
      if (preserveSelection) {
        const existingAccountIds = data.map((acc: any) => acc._id)
        const filteredSelection = selectedAccounts.filter(id => existingAccountIds.includes(id))
        setSelectedAccountsWithLog(filteredSelection)
      }
    } catch (error) {
      console.error('Error loading accounts:', error)
    } finally {
      setLoading(false)
    }
  }

  // Load proxy information
  const loadProxyInfo = async () => {
    try {
      const response = await fetch('/api/proxy/get-proxy', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setProxyInfo(data)
      }
    } catch (error) {
      // Handle error silently
    }
  }

  // Manual proxy update
  const updateProxyNow = async () => {
    try {
      const response = await fetch('/api/proxy/update-now', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        // Reload proxy info after update
        await loadProxyInfo()
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã cập nhật proxy IP mới'
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể cập nhật proxy IP'
      })
    }
  }

  // Load available proxies
  const loadAvailableProxies = async () => {
    try {
      const response = await fetch('/api/proxy/get-proxy', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({})
      })
      
      if (response.ok) {
        const data = await response.json()
        const proxies = data.proxies || []
        setAvailableProxies(proxies)
        return proxies
      }
    } catch (error) {
      // Handle error silently
    }
    return []
  }

  // Get proxy server info
  const getProxyServer = async (proxyId: string) => {
    try {
      const response = await fetch('/api/proxy/get-proxy', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ proxyId })
      })
      
      if (response.ok) {
        const data = await response.json()
        return data.proxy || null
      }
    } catch (error) {
      // Handle error silently
    }
    return null
  }

  // Check proxy IP from database
  const checkProxyIPFromDatabase = async () => {
    try {
      const response = await fetch('/api/proxy/get-proxy', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ 
          proxyId: proxySettings.selectedProxyId,
          checkDatabase: true 
        })
      })
      
      if (response.ok) {
        const data = await response.json()
        if (data.databaseIP) {
          setProxySettings(prev => ({
            ...prev,
            databaseIP: data.databaseIP
          }))
        }
      }
    } catch (error) {
      console.error('Error checking proxy IP from database:', error)
    }
  }

  // Update proxy IP from database
  const updateProxyIPFromDatabase = async () => {
    await checkProxyIPFromDatabase()
  }

  // Function handlers
  const handleSelectFunction = (functionName: string) => {
    setSelectedFunction(functionName)
    
    addNotification({
      type: 'info',
      title: 'Chức năng đã chọn',
      message: `Đã chọn chức năng: ${functionName}. Bấm "Bắt đầu" để thực hiện.`
    })
  }

  // Function implementations
  const buildLocalAccount = (targetAccountId: string) => {
    const isValidObjectId = /^[a-fA-F0-9]{24}$/.test(String(targetAccountId))
    if (isValidObjectId) return undefined
    let acc: any = accounts.find(a => String(a._id) === String(targetAccountId))
    if (!acc && typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('facebook_accounts')
        const list = saved ? JSON.parse(saved) : []
        if (Array.isArray(list)) {
          acc = list.find((a: any) => String(a?._id || a?.id) === String(targetAccountId)) || null
        }
      } catch {}
    }
    if (!acc) return undefined
    let payload: any = {
      uid: acc.uid || '',
      pass: acc.pass || '',
      twofa: acc.twofa || '',
      mail: acc.mail || '',
      passmail: acc.passmail || '',
      mailkp: acc.mailkp || '',
      cookie: acc.cookie || acc.cookies || '',
      token: acc.token || acc.accessToken || ''
    }
    if ((!payload.pass || payload.pass.length === 0) && typeof payload.uid === 'string' && payload.uid.includes('|')) {
      const parts = payload.uid.split('|')
      payload = {
        uid: parts[0] || payload.uid,
        pass: parts[1] || payload.pass || '',
        twofa: parts[2] || payload.twofa || '',
        mail: parts[3] || payload.mail || '',
        passmail: parts[4] || payload.passmail || '',
        mailkp: parts[5] || payload.mailkp || '',
        cookie: parts[6] || payload.cookie || '',
        token: parts[7] || payload.token || ''
      }
    }
    return payload
  }
  const performFacebookLogin = async (accountId: string) => {
    let account = accounts.find(acc => acc._id === accountId)
    let email = account?.mail || accountId
    // Cập nhật status ban đầu
    updateAccountStatus(accountId, 'processing', '🚀 Đang đăng nhập Facebook...')
    
    try {
      addProgressLog(`📡 Đang gửi yêu cầu đến Facebook API...`)
      const isValidObjectId = /^[a-fA-F0-9]{24}$/.test(String(accountId))
      // If local id and not found in current state, try localStorage
      if (!isValidObjectId && !account && typeof window !== 'undefined') {
        try {
          const saved = localStorage.getItem('facebook_accounts')
          const list = saved ? JSON.parse(saved) : []
          if (Array.isArray(list)) {
            account = list.find((a: any) => String(a?._id || a?.id) === String(accountId)) || account
          }
        } catch {}
      }
      email = account?.mail || accountId
      addProgressLog(`🚀 Bắt đầu đăng nhập: ${email}`)

      const localAccount = !isValidObjectId ? buildLocalAccount(accountId) : undefined

      const response = await controlledFetch('/api/facebook/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          accountId: accountId,
          useProxy: true,
          runId: String(runIdRef?.current),
          ...(localAccount ? { localAccount } : {})
        })
      }, accountId)

      const result = await response.json()
      addProgressLog(`📥 Nhận phản hồi từ server`)
      
      if (result.success) {
        addProgressLog(`✅ Đăng nhập thành công: ${email}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'active', log: 'Đăng nhập thành công' }
            : acc
        ))
        
        // Tự động chạy check chất lượng sau khi đăng nhập thành công
        addProgressLog(`🔍 Tự động check chất lượng via: ${email}`)
        try {
          const qualityResponse = await controlledFetch('/api/facebook/check-quality', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
              accountId: accountId,
              runId: String(runIdRef?.current)
            })
          }, accountId)
          
          const qualityResult = await qualityResponse.json()
          if (qualityResult.success) {
            addProgressLog(`✅ Check chất lượng hoàn tất: ${email} - ${qualityResult.quality}`)
            setAccounts(prev => prev.map(acc => 
              acc._id === accountId 
                ? { ...acc, log: `Đăng nhập + Check chất lượng: ${qualityResult.quality}`, quality: qualityResult.quality }
                : acc
            ))
          } else {
            addProgressLog(`⚠️ Check chất lượng thất bại: ${email} - ${qualityResult.message}`)
          }
        } catch (qualityError) {
          addProgressLog(`💥 Lỗi check chất lượng: ${email} - ${qualityError instanceof Error ? qualityError.message : 'Lỗi không xác định'}`)
        }
        
        // Tự động lấy thông tin từ Graph API
        addProgressLog(`📊 Đang lấy thông tin từ Facebook Graph API: ${email}`)
        try {
          const graphResponse = await controlledFetch('/api/facebook/graph-info', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
              accountId: accountId,
              runId: String(runIdRef?.current)
            })
          }, accountId)
          
          const graphResult = await graphResponse.json()
          if (graphResult.success) {
            const friendsCount = graphResult.data.friends.totalCount || 0
            const personalName = graphResult.data.personal.name || 'N/A'
            const personalGender = graphResult.data.personal.gender || 'N/A'
            const personalBirthday = graphResult.data.personal.birthday || 'N/A'
            
            addProgressLog(`✅ Graph API thành công: ${email}`)
            addProgressLog(`👥 Bạn bè: ${friendsCount} | 👤 Tên: ${personalName} | ⚧ Giới tính: ${personalGender}`)
            
            // Update account with new info
            setAccounts(prev => prev.map(acc => 
              acc._id === accountId 
                ? { 
                    ...acc, 
                    friends: friendsCount.toString(),
                    name: personalName !== 'N/A' ? personalName : acc.name,
                    gender: personalGender !== 'N/A' ? personalGender : acc.gender,
                    log: `Đăng nhập + Check chất lượng + Graph API hoàn tất`
                  }
                : acc
            ))
          } else {
            addProgressLog(`⚠️ Graph API thất bại: ${email} - ${graphResult.message}`)
          }
        } catch (graphError) {
          addProgressLog(`💥 Lỗi Graph API: ${email} - ${graphError instanceof Error ? graphError.message : 'Lỗi không xác định'}`)
        }
      } else {
        addProgressLog(`❌ Đăng nhập thất bại: ${email} - ${result.message || 'Lỗi không xác định'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: result.message || 'Lỗi đăng nhập' }
            : acc
        ))
      }
    } catch (error) {
      console.error(`❌ Lỗi đăng nhập: ${accountId}`, error)
      addProgressLog(`💥 Lỗi kết nối: ${email} - ${error instanceof Error ? error.message : 'Lỗi không xác định'}`)
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId 
          ? { ...acc, status: 'error', log: 'Lỗi kết nối' }
          : acc
      ))
    }
  }

  const performFullInfoCheck = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId
    
    // Cập nhật status ban đầu
    updateAccountStatus(accountId, 'processing', '🔍 Đang kiểm tra thông tin đầy đủ...')
    addProgressLog(`🔍 Bắt đầu kiểm tra chất lượng via: ${email}`)
    
    try {
      addProgressLog(`📡 Đang gửi yêu cầu check chất lượng...`)
      const response = await controlledFetch('/api/facebook/check-quality', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          accountId: accountId
        })
      }, accountId)

      const result = await response.json()
      addProgressLog(`📥 Nhận phản hồi check chất lượng`)
      
      if (result.success) {
        addProgressLog(`✅ Check chất lượng thành công: ${email} - ${result.quality || 'Không xác định'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'active', log: result.quality || 'Đã check chất lượng', quality: result.quality }
            : acc
        ))
      } else {
        addProgressLog(`❌ Check chất lượng thất bại: ${email} - ${result.message || 'Lỗi không xác định'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: result.message || 'Lỗi check chất lượng' }
            : acc
        ))
      }
    } catch (error) {
      console.error(`❌ Lỗi check chất lượng: ${accountId}`, error)
      addProgressLog(`💥 Lỗi kết nối check chất lượng: ${email} - ${error instanceof Error ? error.message : 'Lỗi không xác định'}`)
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId 
          ? { ...acc, status: 'error', log: 'Lỗi kết nối check chất lượng' }
          : acc
      ))
    }
  }

  const performAdAccountCheck = async (accountId: string) => {

    
    // Simulate ad account check
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setAccounts(prev => prev.map(acc => 
      acc._id === accountId 
        ? { ...acc, status: 'active', log: 'Kiểm tra TKQC hoàn tất' }
        : acc
    ))
  }

  const performBusinessManagerCheck = async (accountId: string) => {
    // Cập nhật status ban đầu
    updateAccountStatus(accountId, 'processing', '🏢 Đang kiểm tra Business Manager...')
    
    // Simulate business manager check
    await new Promise(resolve => setTimeout(resolve, 1800))
    
    setAccounts(prev => prev.map(acc => 
      acc._id === accountId 
        ? { ...acc, status: 'active', log: 'Kiểm tra BM hoàn tất' }
        : acc
    ))
  }

  // Login by Cookie
  const performFacebookLoginByCookie = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId
    try {
      addProgressLog(`🔄 Đăng nhập bằng Cookie: ${email}`)
      const response = await controlledFetch('/api/facebook/login-cookie', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accountId, useProxy: true, runId: String(runIdRef.current) })
      }, accountId)
      const result = await response.json()
      if (response.ok && result.success) {
        addProgressLog(`✅ Cookie login thành công: ${email} (EAAG:${result?.data?.eaag_token ? 'yes' : 'no'}, EAAB:${result?.data?.eaab_token ? 'yes' : 'no'})`)
        await loadAccounts(true)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'active', log: 'Đăng nhập bằng cookie thành công' }
            : acc
        ))
      } else {
        addProgressLog(`❌ Cookie login thất bại: ${email} - ${result?.message || 'Lỗi không xác định'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: result?.message || 'Lỗi đăng nhập cookie' }
            : acc
        ))
      }
    } catch (error) {
      addProgressLog(`💥 Lỗi đăng nhập cookie: ${email}`)
    }
  }

  // Reg BM function
  const performEnable2FA = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId

    try {
      addProgressLog(`🔄 Bắt đầu Enable 2FA (cookie session) cho: ${email}`)

      // Dùng trực tiếp cookie/session hiện có, không gọi login
      const updatedAccount = accounts.find(acc => acc._id === accountId)
      if (!updatedAccount) {
        throw new Error('Không tìm thấy tài khoản')
      }

      // Check if we have required fields for cookie-based 2FA (cần uid, pass cho reauth nếu Facebook yêu cầu, và cookie)
      if (!updatedAccount.uid || !updatedAccount.pass || !updatedAccount.cookie) {
        throw new Error('Thiếu uid/pass/cookie để bật 2FA bằng cookie')
      }

      addProgressLog(`🔐 Gửi yêu cầu bật 2FA (cookie) cho: ${email}`)

      const response = await fetch('/api/facebook/enable-2fa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          facebookAccountId: accountId,
          loginFirst: loginOptions.loginFirst !== false,
          loginMethod: loginOptions.loginMethod || 'cookie'
        })
      })

      const result = await response.json()

      if (response.ok && result.success) {
        const twoFASecret = result?.data?.twoFASecret || 'unknown'
        addProgressLog(`✅ Enable 2FA thành công: ${email} - Secret: ${twoFASecret}`)
        setAccounts(prev => prev.map(acc =>
          acc._id === accountId
            ? { ...acc, has2FA: true, twoFASecret, log: `Đã bật 2FA: ${twoFASecret}`, status: 'active' }
            : acc
        ))
      } else {
        addProgressLog(`❌ Enable 2FA thất bại: ${email} - ${result?.message || 'Lỗi không xác định'}`)
        setAccounts(prev => prev.map(acc =>
          acc._id === accountId
            ? { ...acc, status: 'error', log: result?.message || 'Lỗi Enable 2FA' }
            : acc
        ))
      }
    } catch (error) {
      addProgressLog(`💥 Lỗi Enable 2FA: ${email} - ${error instanceof Error ? error.message : 'Không xác định'}`)
      setAccounts(prev => prev.map(acc =>
        acc._id === accountId
          ? { ...acc, status: 'error', log: 'Lỗi Enable 2FA' }
          : acc
      ))
    }
  }

  const performRegBM = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId
    
    // Cập nhật status ban đầu
    updateAccountStatus(accountId, 'processing', '🏢 Đang đăng ký Business Manager...')
    addProgressLog(`🏢 Bắt đầu đăng ký Business Manager: ${email}`)
    
    // Cập nhật progress nếu chưa được khởi tạo
    setProgress(prev => {
      if (prev.total === 0) {
        return {
          total: 1,
          completed: 0,
          failed: 0,
          current: 1,
          isProcessing: true
        }
      }
      return {
        ...prev,
        current: prev.current + 1
      }
    })
    
    try {
      // Step 1: Bắt đầu quá trình
      updateAccountStatus(accountId, 'processing', '🏢 Bắt đầu đăng ký Business Manager...')
      await new Promise(resolve => setTimeout(resolve, 500)) // Delay 500ms để hiển thị log

      // Step 2: Gửi request đăng ký BM
      updateAccountStatus(accountId, 'processing', '📤 Gửi yêu cầu đăng ký Business Manager...')
      
      const response = await fetch('/api/facebook/register-bm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          accountId: accountId,
          useProxy: true,
          loginFirst: loginOptions.loginFirst,
          loginMethod: loginOptions.loginMethod || 'cookie',
          options: {
            createAdAccount: regBmOptions.createAdAccount !== false,
            createPixel: !!regBmOptions.createPixel,
            createCatalog: !!regBmOptions.createCatalog,
            pixelName: regBmOptions.pixelName,
            catalogName: regBmOptions.catalogName,
            method: regBmOptions.method || 'graph',
            businessName: regBmOptions.businessName
          }
        })
      })

      // Step 3: Xử lý response
      updateAccountStatus(accountId, 'processing', '⏳ Đang xử lý phản hồi từ Facebook...')
      
      const result = await response.json()
      
      // Step 4: Phân tích kết quả
      updateAccountStatus(accountId, 'processing', '🔍 Phân tích kết quả từ Facebook...')
      await new Promise(resolve => setTimeout(resolve, 300)) // Delay để hiển thị log
      
      if (result.success) {
        const bmName = result.data?.generatedData?.businessName || 'Auto Generated BM'
        const bmId = result.data?.businessManagerId || 'Unknown'
        
        updateAccountStatus(
          accountId, 
          'active', 
          `✅ Đăng ký BM thành công: ${bmName} (ID: ${bmId})`,
          {
            bmData: result.data,
            bmCount: (account?.bmCount || 0) + 1
          }
        )
        
        // Cập nhật progress - thành công
        setProgress(prev => ({
          ...prev,
          completed: prev.completed + 1,
          current: Math.max(0, prev.current - 1)
        }))
      } else {
        updateAccountStatus(
          accountId, 
          'error', 
          `❌ Đăng ký BM thất bại: ${result.message}`
        )
        
        // Cập nhật progress - thất bại
        setProgress(prev => ({
          ...prev,
          failed: prev.failed + 1,
          current: Math.max(0, prev.current - 1)
        }))
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error'
      console.error('Error registering BM:', error)
      
      updateAccountStatus(
        accountId, 
        'error', 
        `💥 Lỗi đăng ký BM: ${errorMessage}`
      )
      
      // Cập nhật progress - lỗi
      setProgress(prev => ({
        ...prev,
        failed: prev.failed + 1,
        current: Math.max(0, prev.current - 1)
      }))
    }
  }

  const performShareBM = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId
    addProgressLog(`🌐 Share BM bắt đầu: ${email}`)
    try {
      const payload: any = {
        accountId,
        bmId: shareBmOptions.mode === 'single' ? (shareBmOptions.bmId || '') : undefined,
        shareAll: shareBmOptions.mode === 'all',
        email: shareBmOptions.useMail1s ? undefined : (shareBmOptions.email || ''),
        useMail1s: !!shareBmOptions.useMail1s,
        mail1sApiKey: shareBmOptions.mail1sApiKey || undefined,
        mail1sAddress: shareBmOptions.mail1sAddress || undefined,
        role: shareBmOptions.role || 'ADMIN',
        quantity: shareBmOptions.quantity || 1,
        loginFirst: loginOptions.loginFirst,
        loginMethod: loginOptions.loginMethod || 'cookie'
      }
      const res = await fetch('/api/facebook/share-bm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
        body: JSON.stringify(payload)
      })
      const j = await res.json()
      if (!res.ok || j?.success === false) {
        addProgressLog(`❌ Share BM thất bại: ${j?.message || res.status}`)
        setAccounts(prev => prev.map(acc => acc._id === accountId ? { ...acc, status: 'error', log: `Share BM fail: ${j?.message || res.status}` } : acc))
        return
      }
      addProgressLog(`✅ Share BM xong. Email: ${j?.data?.email}`)
      const shared = j?.data?.shared || []
      const failed = j?.data?.failed || []
      if (Array.isArray(shared) && shared.length > 0) addProgressLog(`🔗 Shared: ${shared.length}`)
      if (Array.isArray(failed) && failed.length > 0) addProgressLog(`⚠️ Failed: ${failed.length}`)
      const confirmations = j?.data?.confirmations || []
      if (Array.isArray(confirmations) && confirmations.length > 0) {
        addProgressLog(`📬 Link xác nhận:`)
        confirmations.slice(0, 5).forEach((c: any) => addProgressLog(`• ${c.title || 'Facebook'} → ${c.url}`))
        setShareBmLinks(confirmations)
      }
      setAccounts(prev => prev.map(acc => acc._id === accountId ? { ...acc, status: 'active', log: 'Share BM thành công' } : acc))
    } catch (e: any) {
      addProgressLog(`💥 Lỗi Share BM: ${e?.message || e}`)
      setAccounts(prev => prev.map(acc => acc._id === accountId ? { ...acc, status: 'error', log: 'Lỗi Share BM' } : acc))
    }
  }

  const handleViewTKQC = (accountId: string) => {
    setSelectedAccountForTKQC(accountId)
    setShowTKQCModal(true)
  }

  // TKQC Check function
  const performTKQCCheck = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId
    
    addProgressLog(`🔍 Bắt đầu kiểm tra TKQC: ${email}`)
    
    // Cập nhật progress nếu chưa được khởi tạo
    setProgress(prev => {
      if (prev.total === 0) {
        return {
          total: 1,
          completed: 0,
          failed: 0,
          current: 1,
          isProcessing: true
        }
      }
      return {
        ...prev,
        current: prev.current + 1
      }
    })
    
    try {
      let currentToken = account?.token || ''
      let currentCookie = account?.cookie || ''
      
            // Step 1: Chuẩn bị login
      updateAccountStatus(accountId, 'processing', '🔐 Chuẩn bị đăng nhập để lấy session fresh...')
      await new Promise(resolve => setTimeout(resolve, 500)) // Delay để hiển thị log
      
      // Login theo tuỳ chọn (cookie/password). Nếu không bật, bỏ qua bước này
      if (loginOptions.loginFirst) {
        try {
          updateAccountStatus(accountId, 'processing', `🔑 Đang đăng nhập (${loginOptions.loginMethod})...`)
          await new Promise(resolve => setTimeout(resolve, 300))
          const endpoint = loginOptions.loginMethod === 'cookie' ? '/api/facebook/login-cookie' : '/api/facebook/login'
          const maybeLocal = endpoint.endsWith('/login') ? buildLocalAccount(accountId) : undefined
          const loginResponse = await controlledFetch(endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({ accountId, useProxy: true, runId: String(runIdRef.current), ...(maybeLocal ? { localAccount: maybeLocal } : {}) })
          }, accountId)
          const loginResult = await loginResponse.json()
          if (loginResult.success) {
            addProgressLog(`✅ Login thành công, đã lấy session fresh: ${email}`)
            setAccounts(prev => prev.map(acc => (
              acc._id === accountId
                ? {
                    ...acc,
                    status: 'active',
                    log: 'Đã login và lấy session fresh thành công',
                    token: loginResult.data?.eaag_token || loginResult.data?.access_token || acc.token,
                    cookie: loginResult.data?.cookies || acc.cookie
                  }
                : acc
            )))
            currentToken = loginResult.data?.eaag_token || loginResult.data?.access_token || currentToken
            currentCookie = loginResult.data?.cookies || currentCookie
            addProgressLog(`🔑 EAAG Token mới: ${currentToken ? currentToken.substring(0, 20) + '...' : 'EMPTY'}`)
            addProgressLog(`🍪 Cookie mới: ${currentCookie ? 'Có (' + currentCookie.length + ' chars)' : 'EMPTY'}`)
            addProgressLog(`🔄 Tiếp tục check TKQC với session fresh: ${email}`)
          } else {
            addProgressLog(`❌ Login thất bại: ${email} - ${loginResult.message}`)
            setAccounts(prev => prev.map(acc => (
              acc._id === accountId ? { ...acc, status: 'error', log: `Login thất bại: ${loginResult.message}` } : acc
            )))
            return
          }
        } catch (loginError) {
          addProgressLog(`💥 Lỗi login: ${email} - ${loginError instanceof Error ? loginError.message : 'Lỗi không xác định'}`)
          setAccounts(prev => prev.map(acc => (
            acc._id === accountId ? { ...acc, status: 'error', log: 'Lỗi login để lấy token' } : acc
          )))
          return
        }
      }
      
      // Step 3: Thực hiện TKQC check
      updateAccountStatus(accountId, 'processing', '🔍 Đang kiểm tra TKQC và BM...')
      await new Promise(resolve => setTimeout(resolve, 300)) // Delay để hiển thị log
      
      const response = await controlledFetch('/api/check-tkqc', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          token: currentToken,
          cookie: currentCookie,
          accountId: accountId,
          runQualityAfter: true,
          loginFirst: loginOptions.loginFirst,
          loginMethod: loginOptions.loginMethod || 'cookie',
          runId: String(runIdRef?.current)
        })
      }, accountId)

      // Step 4: Xử lý kết quả
      updateAccountStatus(accountId, 'processing', '📊 Đang phân tích dữ liệu TKQC...')
      await new Promise(resolve => setTimeout(resolve, 300)) // Delay để hiển thị log

      const result = await response.json()
      addProgressLog(`📥 Nhận phản hồi TKQC Check`)
      addProgressLog(`🔍 Response status: ${response.status}`)
      addProgressLog(`🔍 Response success: ${result.success}`)
      addProgressLog(`🔍 Response message: ${result.message || 'No message'}`)
      
      if (result.success) {
        const tkqcCount = result.tkqc_list?.length || 0
        const bmCount = result.bm_list?.length || 0
        const accountInfo = result.account_info
        
        addProgressLog(`✅ TKQC Check thành công: ${email}`)
        addProgressLog(`📊 Tìm thấy ${tkqcCount} TKQC và ${bmCount} BM`)
        
        if (accountInfo) {
          addProgressLog(`💰 Account: ${accountInfo.name} - Status: ${accountInfo.account_status}`)
          addProgressLog(`💳 Balance: ${accountInfo.balance} ${accountInfo.currency}`)
          addProgressLog(`🔒 Ad Trust DSL: ${accountInfo.adtrust_dsl}`)
        }
        
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { 
                ...acc, 
                status: 'active' as const,
                log: `TKQC: ${tkqcCount} accounts, ${bmCount} BM${accountInfo ? ` - ${accountInfo.balance} ${accountInfo.currency}` : ''}`,
                // Cập nhật tkqcData từ result.tkqc_list để tính tổng realtime
                tkqcData: result.tkqc_list || [],
                // Cập nhật accountInfo cho backward compatibility
                accountInfo: accountInfo ? {
                  balance: accountInfo.balance || '0',
                  currency: accountInfo.currency || 'USD',
                  amount_spent: accountInfo.amount_spent || '0',
                  spend: accountInfo.spend || '0'
                } : undefined
              } as FacebookAccount
            : acc
        ))
        
        // Lưu dữ liệu TKQC vào localStorage
        try {
          const tkqcDataToSave = {
            accountId: accountId,
            email: email,
            timestamp: new Date().toISOString(),
            tkqcList: result.tkqc_list || [],
            bmList: result.bm_list || [],
            accountInfo: accountInfo,
            totalTKQC: tkqcCount,
            totalBM: bmCount
          }
          
          // Lấy dữ liệu TKQC cũ từ localStorage
          const existingTKQC = localStorage.getItem('tkqc_data')
          let allTKQCData = existingTKQC ? JSON.parse(existingTKQC) : []
          
          // Cập nhật hoặc thêm mới
          const existingIndex = allTKQCData.findIndex((item: any) => item.accountId === accountId)
          if (existingIndex >= 0) {
            allTKQCData[existingIndex] = tkqcDataToSave
          } else {
            allTKQCData.push(tkqcDataToSave)
          }
          
          // Lưu vào localStorage
          localStorage.setItem('tkqc_data', JSON.stringify(allTKQCData))
          addProgressLog(`💾 Đã lưu dữ liệu TKQC vào localStorage: ${tkqcCount} TKQC, ${bmCount} BM`)
          
          // Thông báo cho TKQCDataTable refresh
          window.dispatchEvent(new CustomEvent('tkqc-data-updated', {
            detail: { accountId, tkqcCount, bmCount }
          }))
        } catch (saveError) {
          console.error('Lỗi lưu TKQC vào localStorage:', saveError)
          addProgressLog(`⚠️ Lỗi lưu TKQC vào localStorage: ${saveError instanceof Error ? saveError.message : 'Không xác định'}`)
        }
        
        // Nếu storage mode là server, cũng lưu vào database
        try {
          const storageMode = localStorage.getItem('storage_mode') || 'server'
          if (storageMode === 'server') {
            // Cập nhật account trong database với dữ liệu TKQC
            const response = await fetch('/api/facebook/update-tkqc', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
              },
              body: JSON.stringify({
                accountId: accountId,
                tkqcData: result.tkqc_list || [],
                bmData: result.bm_list || [],
                accountInfo: accountInfo,
                tkqcCount: tkqcCount,
                bmCount: bmCount
              })
            })
            
            if (response.ok) {
              addProgressLog(`💾 Đã lưu dữ liệu TKQC vào server: ${tkqcCount} accounts, ${bmCount} BM`)
            } else {
              addProgressLog(`⚠️ Lỗi lưu TKQC vào server: ${response.status}`)
            }
          }
        } catch (serverError) {
          console.error('Lỗi lưu TKQC vào server:', serverError)
          addProgressLog(`⚠️ Lỗi lưu TKQC vào server: ${serverError instanceof Error ? serverError.message : 'Không xác định'}`)
        }
        
        // Cập nhật progress - thành công
        setProgress(prev => ({
          ...prev,
          completed: prev.completed + 1,
          current: Math.max(0, prev.current - 1)
        }))
      } else {
        addProgressLog(`❌ TKQC Check thất bại: ${email} - ${result.message || result.error || 'Lỗi không xác định'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: result.message || result.error || 'Lỗi TKQC Check' }
            : acc
        ))
        
        // Cập nhật progress - thất bại
        setProgress(prev => ({
          ...prev,
          failed: prev.failed + 1,
          current: Math.max(0, prev.current - 1)
        }))
      }
    } catch (error) {
      console.error(`❌ Lỗi TKQC Check: ${accountId}`, error)
      addProgressLog(`💥 Lỗi kết nối TKQC Check: ${email} - ${error instanceof Error ? error.message : 'Lỗi không xác định'}`)
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId 
          ? { ...acc, status: 'error', log: 'Lỗi kết nối TKQC Check' }
          : acc
      ))
      
      // Cập nhật progress - lỗi
      setProgress(prev => ({
        ...prev,
        failed: prev.failed + 1,
        current: Math.max(0, prev.current - 1)
      }))
    }
  }

  // TKQC BM Check function
  const performTKQCBMCheck = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId
    
    addProgressLog(`🔍 Bắt đầu kiểm tra TKQC trong BM: ${email}`)
    
    try {
      let currentToken = account?.token || ''
      let currentCookie = account?.cookie || ''
      
      // Login để lấy token fresh (respect loginOptions)
      addProgressLog(`🔐 Đang thực hiện login để lấy session fresh: ${email}`)
      try {
        const endpoint = loginOptions.loginFirst ? (loginOptions.loginMethod === 'cookie' ? '/api/facebook/login-cookie' : '/api/facebook/login') : '/api/facebook/login'
        const maybeLocal = endpoint.endsWith('/login') ? buildLocalAccount(accountId) : undefined
        const loginResponse = await controlledFetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify({
            accountId: accountId,
            useProxy: true,
            ...(maybeLocal ? { localAccount: maybeLocal } : {})
          })
        }, accountId)
        
        const loginResult = await loginResponse.json()
        if (loginResult.success) {
          addProgressLog(`✅ Login thành công, đã lấy token: ${email}`)
          // Cập nhật account với token mới
          setAccounts(prev => prev.map(acc => 
            acc._id === accountId 
              ? { 
                  ...acc, 
                  status: 'active', 
                  log: 'Đã login và lấy token thành công',
                  token: loginResult.data?.eaag_token || loginResult.data?.access_token || acc.token,
                  cookie: loginResult.data?.cookies || acc.cookie
                }
              : acc
          ))
          // Sử dụng token từ login response
          currentToken = loginResult.data?.eaag_token || loginResult.data?.access_token || currentToken
          currentCookie = loginResult.data?.cookies || currentCookie
          addProgressLog(`🔄 Tiếp tục check TKQC BM với token mới: ${email}`)
        } else {
          addProgressLog(`❌ Login thất bại: ${email} - ${loginResult.message}`)
          setAccounts(prev => prev.map(acc => 
            acc._id === accountId 
              ? { ...acc, status: 'error', log: `Login thất bại: ${loginResult.message}` }
              : acc
          ))
          return
        }
      } catch (loginError) {
        addProgressLog(`💥 Lỗi login: ${email} - ${loginError instanceof Error ? loginError.message : 'Lỗi không xác định'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: 'Lỗi login để lấy token' }
            : acc
        ))
        return
      }
      
      addProgressLog(`🔗 Đang kết nối Facebook Graph API...`)
      const response = await controlledFetch('/api/check-tkqc', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          token: currentToken,
          cookie: currentCookie,
          accountId: accountId,
          checkType: 'bm',
          loginFirst: loginOptions.loginFirst,
          loginMethod: loginOptions.loginMethod || 'cookie',
          runQualityAfter: true,
          runId: String(runIdRef?.current ?? '')
        })
      }, accountId)

      const result = await response.json()
      addProgressLog(`📥 Nhận phản hồi TKQC BM Check`)
      
      if (result.success) {
        const tkqcCount = result.tkqc_list?.length || 0
        const bmCount = result.bm_list?.length || 0
        const liveAdsCount = result.bm_list?.filter((bm: any) => bm.restriction_type === null)?.length || 0
        const dieAdsCount = result.bm_list?.filter((bm: any) => bm.restriction_type === 'ALE')?.length || 0
        const accountInfo = result.account_info
        
        addProgressLog(`✅ TKQC BM Check thành công: ${email}`)
        addProgressLog(`📊 Tổng TKQC: ${tkqcCount}`)
        addProgressLog(`🏢 Tổng BM: ${bmCount}`)
        addProgressLog(`✅ Live Ads BM: ${liveAdsCount}`)
        addProgressLog(`❌ Die Ads BM: ${dieAdsCount}`)
        
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { 
                ...acc, 
                status: 'active',
                log: `BM: ${bmCount} total (${liveAdsCount} live, ${dieAdsCount} die) - TKQC: ${tkqcCount}`,
                // Cập nhật tkqcData từ result.tkqc_list để tính tổng realtime
                tkqcData: result.tkqc_list || [],
                // Cập nhật bmData từ result.bm_list
                bmData: result.bm_list || [],
                // Cập nhật accountInfo cho backward compatibility
                accountInfo: accountInfo ? {
                  balance: accountInfo.balance || '0',
                  currency: accountInfo.currency || 'USD',
                  amount_spent: accountInfo.amount_spent || '0',
                  spend: accountInfo.spend || '0'
                } : undefined
              }
            : acc
        ))
      } else {
        addProgressLog(`❌ TKQC BM Check thất bại: ${email} - ${result.message || result.error || 'Lỗi không xác định'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: result.message || result.error || 'Lỗi TKQC BM Check' }
            : acc
        ))
      }
    } catch (error) {
      console.error(`❌ Lỗi TKQC BM Check: ${accountId}`, error)
      addProgressLog(`💥 Lỗi kết nối TKQC BM Check: ${email} - ${error instanceof Error ? error.message : 'Lỗi không xác định'}`)
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId 
          ? { ...acc, status: 'error', log: 'Lỗi kết nối TKQC BM Check' }
          : acc
      ))
    }
  }

  // Facebook login function
  const loginFacebookAccounts = async () => {
    // Set isRunning flag to protect selectedAccounts
    setIsRunning(true)
    
    try {
      const accountsToLogin = selectedAccounts.length > 0 ? selectedAccounts : accounts.map(acc => acc._id)
      
      if (accountsToLogin.length === 0) {
        addNotification({
          type: 'warning',
          title: 'Cảnh báo',
          message: 'Không có tài khoản nào để đăng nhập!'
        })
        return
      }

    addNotification({
      type: 'info',
      title: 'Bắt đầu đăng nhập',
      message: `Đang đăng nhập ${accountsToLogin.length} tài khoản Facebook...`
    })

    let successCount = 0
    let errorCount = 0

    for (const accountId of accountsToLogin) {
      try {
        const response = await controlledFetch('/api/facebook/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify({
            accountId: accountId,
            useProxy: true,
            runId: String(runIdRef.current)
          })
        }, accountId)

        const result = await response.json()
        
        if (result.success) {
          successCount++
          addNotification({
            type: 'success',
            title: 'Đăng nhập thành công',
            message: `Tài khoản ${accountId} đã đăng nhập thành công`
          })
        } else {
          errorCount++
          addNotification({
            type: 'error',
            title: 'Đăng nhập thất bại',
            message: `Tài khoản ${accountId}: ${result.message}`
          })
        }

        // Update account status locally instead of reloading all accounts
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: result.success ? 'active' : 'error', log: result.message }
            : acc
        ))
        
        // Small delay between requests
        await new Promise(resolve => setTimeout(resolve, 1000))
        
      } catch (error) {
        errorCount++
        console.error('Error logging in account:', error)
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: `Lỗi đăng nhập tài khoản ${accountId}`
        })
      }
    }

    // Final reload to sync with server data (preserve selection)
    await loadAccounts(true)
    
    // Optional: Auto-deselect successfully logged in accounts
    // Uncomment the lines below if you want to auto-deselect successful accounts
    // const successfulAccountIds = accountsToLogin.filter((_, index) => 
    //   /* track success per account */
    // )
    // setSelectedAccounts(prev => prev.filter(id => !successfulAccountIds.includes(id)))
    
      addNotification({
        type: 'info',
        title: 'Hoàn tất',
        message: `Đăng nhập hoàn tất: ${successCount} thành công, ${errorCount} lỗi`
      })
    } catch (error) {
      console.error('❌ Error in loginFacebookAccounts:', error)
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Có lỗi xảy ra trong quá trình đăng nhập'
      })
    } finally {
      // Always clear isRunning flag
      setIsRunning(false)
    }
  }

  // Authentication check and load accounts
  useEffect(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')
    
    if (!token || !userData) {
      router.push('/auth')
      return
    }
    
    try {
      setUser(JSON.parse(userData))
      // Load settings first, then subscription to ensure proper order
      loadSettings().then(() => {
        loadUserSubscription()
      })
      loadAccounts()
      loadProxyInfo() // Load proxy info on mount
      loadWelcomePopupSettings() // Load welcome popup settings
      
      // Check if welcome modal should be shown
      const welcomeModalDismissed = localStorage.getItem('welcomeModalDismissed')
      if (!welcomeModalDismissed && welcomePopupSettings.enabled && welcomePopupSettings.showOnDashboard) {
        setShowWelcomeModal(true)
      }
      
      // Xóa các key bảo mật khỏi localStorage để bảo mật
      try { localStorage.removeItem('user_encryption_key') } catch {}
      try { localStorage.removeItem('admin_key') } catch {}

      // Listen for local accounts updates to refresh dashboard list in real-time
      const onLocalUpdated = () => {
        loadAccounts(true)
      }
      const onStorage = (e: StorageEvent) => {
        if (e.key === 'facebook_accounts') {
          loadAccounts(true)
        }
      }
      window.addEventListener('local-accounts-updated', onLocalUpdated)
      window.addEventListener('storage', onStorage)
      return () => {
        window.removeEventListener('local-accounts-updated', onLocalUpdated)
        window.removeEventListener('storage', onStorage)
      }
    } catch (error) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      router.push('/auth')
    }
  }, [router])

  // Apply subscription limits when settings are loaded
  useEffect(() => {
    if (settingsLoaded && userSubscription) {
      const subscriptionMaxThreads = userSubscription.maxThreads || 2
      
      if (subscriptionMaxThreads !== -1) {
        setMaxThreads(prevMaxThreads => Math.min(prevMaxThreads, subscriptionMaxThreads))
      }
    }
  }, [settingsLoaded, userSubscription])

  // Show welcome modal once per page load
  useEffect(() => {
    if (hasShownWelcomeThisLoad.current) return
    const welcomeModalDismissed = localStorage.getItem('welcomeModalDismissed')
    if (!welcomeModalDismissed && welcomePopupSettings.enabled && welcomePopupSettings.showOnDashboard) {
      setShowWelcomeModal(true)
      hasShownWelcomeThisLoad.current = true
    }
  }, [welcomePopupSettings.enabled, welcomePopupSettings.showOnDashboard])

  // Periodically refresh subscription data
  useEffect(() => {
    const interval = setInterval(() => {
      if (user) {
        loadUserSubscription()
        loadProxyInfo() // Refresh proxy info periodically
        // Do not refresh welcome popup settings periodically to avoid re-showing
      }
    }, 30000) // Refresh every 30 seconds

    return () => clearInterval(interval)
  }, [user])

  // Listen for storage changes (when user returns from pricing page)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'subscription_updated' && e.newValue === 'true') {
        loadUserSubscription()
        localStorage.removeItem('subscription_updated')
      }
    }

    const handleFocus = () => {
      // Refresh subscription when user returns to the tab
      if (user) {
        loadUserSubscription()
        loadProxyInfo() // Refresh proxy info when user returns to tab
      }
    }

    window.addEventListener('storage', handleStorageChange)
    window.addEventListener('focus', handleFocus)
    return () => {
      window.removeEventListener('storage', handleStorageChange)
      window.removeEventListener('focus', handleFocus)
    }
  }, [user])

  // Close context menu when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      if (contextMenu.visible) {
        handleContextMenuClose()
      }
    }

    if (contextMenu.visible) {
      document.addEventListener('click', handleClickOutside)
      document.addEventListener('contextmenu', handleClickOutside)
    }

    return () => {
      document.removeEventListener('click', handleClickOutside)
      document.removeEventListener('contextmenu', handleClickOutside)
    }
  }, [contextMenu.visible])

  // Persist proxySettings to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined' && proxySettings) {
      localStorage.setItem('dashboard_proxySettings', JSON.stringify(proxySettings))
    }
  }, [proxySettings])

  // Load available proxies and update proxy IP from database when user or proxySettings change
  useEffect(() => {
    if (user) {
      loadAvailableProxies()
      if (proxySettings.selectedProxyId) {
        updateProxyIPFromDatabase()
      }
    }
  }, [user, proxySettings.selectedProxyId])

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    router.push('/auth')
  }



  // Notification functions
  const showNotification = (message: string, type: 'success' | 'error' | 'info' | 'warning' = 'info') => {
    const id = Date.now().toString()
    setNotifications(prev => [...prev, { id, message, type }])
    
    // Auto remove after 3 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(notification => notification.id !== id))
    }, 3000)
  }

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id))
  }



  const filteredAccounts = accounts.filter(account => {
    const matchesSearch = (account.uid?.toLowerCase() || '').includes(debouncedSearchTerm.toLowerCase()) ||
                         (account.pass?.toLowerCase() || '').includes(debouncedSearchTerm.toLowerCase()) ||
                         (account.mail?.toLowerCase() || '').includes(debouncedSearchTerm.toLowerCase())
    
    const matchesStatus = statusFilter === 'all' || account.status === statusFilter
    
    return matchesSearch && matchesStatus
  })

  const handleSelectAll = () => {
    if (selectedAccounts.length === filteredAccounts.length) {
      setSelectedAccountsWithLog([])
    } else {
      setSelectedAccountsWithLog(filteredAccounts.map(account => account._id))
    }
  }

  const handleDeselectAll = () => {
    setSelectedAccountsWithLog([])
  }

  const handleSelectAccount = (accountId: string) => {
    if (selectedAccounts.includes(accountId)) {
      setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
    } else {
      setSelectedAccountsWithLog([...selectedAccounts, accountId])
    }
  }

  const handleHighlightAccount = (accountId: string) => {
    if (highlightedAccounts.includes(accountId)) {
      setHighlightedAccounts(highlightedAccounts.filter(id => id !== accountId))
    } else {
      setHighlightedAccounts([...highlightedAccounts, accountId])
    }
  }

  const handleDeleteAccount = async (accountId: string) => {
    try {
      const mode = localStorage.getItem('storage_mode') || 'server'
      if (mode === 'local') {
        // Delete from localStorage
        const saved = localStorage.getItem('facebook_accounts')
        const arr = saved ? JSON.parse(saved) : []
        const updated = (arr || []).filter((a: any) => a._id !== accountId)
        localStorage.setItem('facebook_accounts', JSON.stringify(updated))
        setAccounts(accounts.filter(account => account._id !== accountId))
        setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
        try { window.dispatchEvent(new Event('local-accounts-updated')) } catch {}
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã xóa tài khoản local'
        })
        return
      }
      
      // Use bulk delete for better performance (even for single account)
      console.log(`Deleting account ${accountId} using bulk delete API...`)
      const response = await fetch(`/api/facebook-accounts/bulk-delete?ids=${accountId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const result = await response.json()
        console.log('Bulk delete result:', result)
        setAccounts(accounts.filter(account => account._id !== accountId))
        setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
        setHighlightedAccounts(highlightedAccounts.filter(id => id !== accountId))
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Tài khoản đã được xóa bằng bulk delete'
        })
      } else {
        // Fallback to individual delete if bulk delete fails
        console.log('Bulk delete failed, trying individual delete...')
        const fallbackResponse = await fetch(`/api/facebook-accounts?id=${accountId}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })
        
        if (fallbackResponse.ok) {
          setAccounts(accounts.filter(account => account._id !== accountId))
          setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
          setHighlightedAccounts(highlightedAccounts.filter(id => id !== accountId))
          addNotification({
            type: 'success',
            title: 'Thành công',
            message: 'Tài khoản đã được xóa'
          })
        } else {
          addNotification({
            type: 'error',
            title: 'Lỗi',
            message: 'Lỗi khi xóa tài khoản'
          })
        }
      }
    } catch (error) {
      console.error('Error deleting account:', error)
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Lỗi khi xóa tài khoản'
      })
    }
  }

  const handleAddAccount = async (accountData: any) => {
    try {
      const response = await fetch('/api/facebook-accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          accounts: [{
            uid: accountData.uid,
            pass: accountData.pass || '',
            twofa: accountData.twofa || '',
            mail: accountData.mail || '',
            passmail: accountData.passmail || '',
    
            cookie: accountData.cookie || '',
            token: accountData.token || '',
            status: 'active',
            log: 'Tài khoản mới được thêm'
          }]
        })
      })
      
      if (response.ok) {
        const result = await response.json()
        if (result.savedAccounts && result.savedAccounts.length > 0) {
          setAccounts([...accounts, ...result.savedAccounts])
          addNotification({
            type: 'success',
            title: 'Thành công',
            message: 'Tài khoản đã được thêm thành công'
          })
        }
        if (result.errors && result.errors.length > 0) {
          result.errors.forEach((error: string) => {
            addNotification({
              type: 'error',
              title: 'Lỗi',
              message: error
            })
          })
        }
      } else {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Lỗi khi thêm tài khoản'
        })
      }
    } catch (error) {
      console.error('Error adding account:', error)
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Lỗi khi thêm tài khoản'
      })
    }
  }



  // Context menu handlers
  const handleContextMenu = (e: React.MouseEvent, accountId?: string) => {
    e.preventDefault()
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      accountId
    })
  }

  const handleContextMenuClose = () => {
    setContextMenu({
      visible: false,
      x: 0,
      y: 0
    })
  }

  const handleContextMenuCheckQuality = async (accountId: string) => {
    try {
      const account = accounts.find(acc => acc._id === accountId)
      const email = account?.mail || accountId
      updateAccountStatus(accountId, 'processing', '🔐 Đang đăng nhập cookie...')
      addProgressLog(`🔐 Đăng nhập cookie trước khi check chất lượng: ${email}`)

      // Login by cookie first to ensure a fresh session
      const loginRes = await fetch('/api/facebook/login-cookie', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ accountId, useProxy: true })
      })
      const loginJson = await loginRes.json()
      if (!loginRes.ok || !loginJson?.success) {
        addProgressLog(`❌ Login cookie thất bại: ${email} - ${loginJson?.message || 'Unknown'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: loginJson?.message || 'Login cookie thất bại' }
            : acc
        ))
        return
      }

      // Update local account state with fresh cookies/token
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId 
          ? { 
              ...acc, 
              cookie: loginJson?.data?.cookies || acc.cookie,
              token: loginJson?.data?.eaag_token || loginJson?.data?.access_token || acc.token,
              status: 'processing',
              log: 'Đã đăng nhập cookie. Đang check chất lượng...'
            }
          : acc
      ))

      addProgressLog(`🔍 Check chất lượng (menu): ${email}`)
      const response = await fetch('/api/check-quality-via', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ accountId, loginFirst: false, loginMethod: 'cookie' })
      })
      const result = await response.json()
      if (result?.success) {
        const adsStatus: string = result.adsStatus || 'unknown'
        const qualityText = adsStatus === 'live' ? 'Live Ads' : adsStatus === 'die' ? 'HCQC' : 'Không xác định'
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'active', quality: qualityText, log: `Check chất lượng: ${qualityText}` }
            : acc
        ))
        addProgressLog(`✅ Check chất lượng: ${email} - ${qualityText}`)
      } else {
        addProgressLog(`⚠️ Check chất lượng thất bại: ${email} - ${result?.message || 'Unknown'}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId 
            ? { ...acc, status: 'error', log: result?.message || 'Lỗi check chất lượng' }
            : acc
        ))
      }
    } catch (error) {
      // silent
    } finally {
      handleContextMenuClose()
    }
  }

  const handleCopyAccount = (type: string) => {
    if (!contextMenu.accountId) return
    
    const account = accounts.find(acc => acc._id === contextMenu.accountId)
    if (!account) return

    let textToCopy = ''
    const accountData = getAccountData(account)
    switch (type) {
      case 'uid':
        textToCopy = accountData.uid
        break
      case 'pass':
        textToCopy = accountData.pass
        break
      case '2fa':
        textToCopy = accountData.twofa
        break
      case 'cookie':
        textToCopy = accountData.cookie
        break
      case 'mail':
        textToCopy = `${accountData.mail}|${accountData.passmail}`
        break
      case 'token':
        textToCopy = accountData.token
        break
      case 'full':
        textToCopy = account.uid
        break
      default:
        return
    }

    navigator.clipboard.writeText(textToCopy)
    addNotification({
      type: 'success',
      title: 'Thành công',
      message: `Đã copy ${type.toUpperCase()} vào clipboard`
    })
    handleContextMenuClose()
  }

  // Copy selected accounts
  const handleCopySelectedAccounts = (type: string) => {
    if (selectedAccounts.length === 0) {
      addNotification({
        type: 'warning',
        title: 'Cảnh báo',
        message: 'Không có tài khoản nào được chọn!'
      })
      return
    }

    const selectedAccountsData = selectedAccounts.map(accountId => {
      const account = accounts.find(acc => acc._id === accountId)
      if (!account) return null
      
      const accountData = getAccountData(account)
      switch (type) {
        case 'uid':
          return accountData.uid
        case 'pass':
          return accountData.pass
        case '2fa':
          return accountData.twofa
        case 'cookie':
          return accountData.cookie
        case 'mail':
          return `${accountData.mail}|${accountData.passmail}`
        case 'token':
          return accountData.token
        case 'full':
          return `${accountData.uid}|${accountData.pass}|${accountData.twofa}|${accountData.mail}|${accountData.passmail}|${accountData.cookie}|${accountData.token}`
        default:
          return null
      }
    }).filter(Boolean)

    if (selectedAccountsData.length === 0) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không có dữ liệu để copy!'
      })
      return
    }

    const textToCopy = selectedAccountsData.join('\n')
    navigator.clipboard.writeText(textToCopy)
    addNotification({
      type: 'success',
      title: 'Thành công',
      message: `Đã copy ${type.toUpperCase()} của ${selectedAccountsData.length} tài khoản đã chọn vào clipboard`
    })
  }

  const handleContextMenuSelect = (accountId: string) => {
    if (selectedAccounts.includes(accountId)) {
      setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
    } else {
      setSelectedAccountsWithLog([...selectedAccounts, accountId])
    }
    handleContextMenuClose()
  }

       const handleContextMenuDelete = async (accountId: string) => {
    try {
      const mode = localStorage.getItem('storage_mode') || 'server'
      if (mode === 'local') {
        const saved = localStorage.getItem('facebook_accounts')
        const arr = saved ? JSON.parse(saved) : []
        const updated = (arr || []).filter((a: any) => a._id !== accountId)
        localStorage.setItem('facebook_accounts', JSON.stringify(updated))
        setAccounts(accounts.filter(account => account._id !== accountId))
        setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã xóa tài khoản local!'
        })
        try { window.dispatchEvent(new Event('local-accounts-updated')) } catch {}
      } else {
        // Use bulk delete for better performance (even for single account)
        console.log(`Deleting account ${accountId} using bulk delete API...`)
        const response = await fetch(`/api/facebook-accounts/bulk-delete?ids=${accountId}`, {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })
        
        if (response.ok) {
          const result = await response.json()
          console.log('Bulk delete result:', result)
          setAccounts(accounts.filter(account => account._id !== accountId))
          setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
          addNotification({
            type: 'success',
            title: 'Thành công',
            message: 'Đã xóa tài khoản thành công bằng bulk delete!'
          })
        } else {
          // Fallback to individual delete if bulk delete fails
          console.log('Bulk delete failed, trying individual delete...')
          const fallbackResponse = await fetch(`/api/facebook-accounts?id=${accountId}`, {
            method: 'DELETE',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          })
          
          if (fallbackResponse.ok) {
            setAccounts(accounts.filter(account => account._id !== accountId))
            setSelectedAccountsWithLog(selectedAccounts.filter(id => id !== accountId))
            addNotification({
              type: 'success',
              title: 'Thành công',
              message: 'Đã xóa tài khoản thành công!'
            })
          } else {
            addNotification({
              type: 'error',
              title: 'Lỗi',
              message: 'Không thể xóa tài khoản. Vui lòng thử lại!'
            })
          }
        }
      }
    } catch (error) {
      console.error('Error deleting account:', error)
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể xóa tài khoản. Vui lòng thử lại!'
      })
    }
    handleContextMenuClose()
  }



    const handleDeleteSelected = () => {
      if (selectedAccounts.length === 0) {
        addNotification({
          type: 'warning',
          title: 'Cảnh báo',
          message: 'Không có tài khoản nào được chọn để xóa!'
        })
        return
      }

      setAccountsToDelete(selectedAccounts)
      setShowDeleteConfirmModal(true)
    }

    const confirmDeleteSelected = async () => {

    try {
      const mode = localStorage.getItem('storage_mode') || 'server'
      if (mode === 'local') {
        const saved = localStorage.getItem('facebook_accounts')
        const arr = saved ? JSON.parse(saved) : []
        const updated = (arr || []).filter((a: any) => !selectedAccounts.includes(a._id))
        localStorage.setItem('facebook_accounts', JSON.stringify(updated))
        setAccounts(accounts.filter(account => !selectedAccounts.includes(account._id)))
        setSelectedAccountsWithLog([])
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: `Đã xóa ${selectedAccounts.length} tài khoản local!`
        })
        try { window.dispatchEvent(new Event('local-accounts-updated')) } catch {}
        return
      }

          // Use bulk delete for better performance when deleting multiple accounts
    if (selectedAccounts.length > 1) {
      console.log(`Using bulk delete for ${selectedAccounts.length} accounts...`)
      const response = await fetch(`/api/facebook-accounts/bulk-delete?ids=${selectedAccounts.join(',')}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const result = await response.json()
        console.log('Bulk delete result:', result)
        const successCount = result.stats?.deleted || selectedAccounts.length
        const errorCount = selectedAccounts.length - successCount
        
        if (successCount > 0) {
          setAccounts(accounts.filter(account => !selectedAccounts.includes(account._id)))
          setSelectedAccountsWithLog([])
          addNotification({
            type: 'success',
            title: 'Thành công',
            message: `Đã xóa ${successCount} tài khoản thành công bằng bulk delete!${errorCount > 0 ? ` ${errorCount} tài khoản lỗi.` : ''}`
          })
        } else {
          addNotification({
            type: 'error',
            title: 'Lỗi',
            message: 'Không thể xóa tài khoản. Vui lòng thử lại!'
          })
        }
        return
      } else {
        console.error('Bulk delete failed, falling back to individual deletes')
      }
    }
    
    // Fallback to individual deletes for single account or if bulk delete fails
    const deletePromises = selectedAccounts.map(accountId =>
      fetch(`/api/facebook-accounts?id=${accountId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
    )

    const responses = await Promise.all(deletePromises)
    const successCount = responses.filter(response => response.ok).length
    const errorCount = responses.length - successCount

      if (successCount > 0) {
        setAccounts(accounts.filter(account => !selectedAccounts.includes(account._id)))
        setSelectedAccountsWithLog([])
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: `Đã xóa ${successCount} tài khoản thành công!${errorCount > 0 ? ` ${errorCount} tài khoản lỗi.` : ''}`
        })
      } else {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể xóa tài khoản. Vui lòng thử lại!'
        })
      }
    } catch (error) {
      console.error('Error deleting selected accounts:', error)
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể xóa tài khoản. Vui lòng thử lại!'
      })
    } finally {
      setShowDeleteConfirmModal(false)
      setAccountsToDelete([])
      handleContextMenuClose()
    }
  }

  const cancelDeleteSelected = () => {
    setShowDeleteConfirmModal(false)
    setAccountsToDelete([])
  }

  // Check Info Via function
  const performCheckInfoVia = async (accountId: string) => {
    const account = accounts.find(acc => acc._id === accountId)
    const email = account?.mail || accountId
    
    // Cập nhật status ban đầu
    updateAccountStatus(accountId, 'processing', '🔍 Đang check info via...')
    addProgressLog(`🔍 Bắt đầu check info via: ${email}`)
    
    try {
      // Bước 1: Đăng nhập Facebook trước
      addProgressLog(`🚀 Đăng nhập Facebook trước khi check info...`)
      const endpoint = loginOptions.loginFirst ? (loginOptions.loginMethod === 'cookie' ? '/api/facebook/login-cookie' : '/api/facebook/login') : '/api/facebook/login'
      const loginResponse = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          accountId: accountId,
          useProxy: true
        })
      })

      const loginResult = await loginResponse.json()
      
      if (!loginResult.success) {
        addProgressLog(`❌ Đăng nhập thất bại: ${email} - ${loginResult.message}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId
            ? { ...acc, status: 'error', log: `Đăng nhập thất bại: ${loginResult.message}` }
            : acc
        ))
        return
      }
      
      addProgressLog(`✅ Đăng nhập thành công: ${email}`)
      
      // Lưu EAAG token từ đăng nhập để sử dụng cho check info
      const eaagToken = loginResult.data?.eaag_token || 
                       loginResult.eaag_token || 
                       loginResult.data?.access_token ||
                       loginResult.access_token

      
      if (eaagToken) {
        addProgressLog(`🔑 Đã lấy được EAAG token mới`)
      } else {
        addProgressLog(`⚠️ Không tìm thấy EAAG token trong login result`)
      }
      
      // Cập nhật trạng thái đăng nhập trong accounts
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId
          ? { 
              ...acc, 
              status: 'active',
              token: eaagToken || acc.token,
              log: 'Đã đăng nhập thành công'
            }
          : acc
      ))
      
      // Bước 2: Check info via Graph API với EAAG token (theo format check-tkqc)
      addProgressLog(`📡 Đang gửi yêu cầu đến Graph API với EAAG token mới...`)
      const response = await fetch('/api/facebook/check-info-via', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          token: eaagToken, // EAAG token chính
          cookie: loginResult.data?.cookies || loginResult.cookies || '', // Cookie từ đăng nhập
          accountId: accountId,
          facebookToken: eaagToken, // Backup token
          loginFirst: loginOptions.loginFirst,
          loginMethod: loginOptions.loginMethod || 'cookie'
        })
      })

      const result = await response.json()
      addProgressLog(`📥 Nhận phản hồi từ Graph API`)
      
      if (result.success) {
        const { name, gender, birthday, friendsCount } = result.data
        addProgressLog(`✅ Check info via thành công: ${email}`)
        addProgressLog(`👤 Tên: ${name || 'N/A'}`)
        addProgressLog(`⚧ Giới tính: ${gender || 'N/A'}`)
        addProgressLog(`🎂 Sinh nhật: ${birthday || 'N/A'}`)
        addProgressLog(`👥 Số bạn bè: ${friendsCount || 'N/A'}`)
        
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId
            ? { 
                ...acc, 
                status: 'active', 
                log: `Check info via thành công - Tên: ${name}, Giới tính: ${gender}, Sinh nhật: ${birthday}, Bạn bè: ${friendsCount}`,
                name: name || acc.name,
                gender: gender || acc.gender,
                birthday: birthday || acc.birthday,
                friends: friendsCount || acc.friends
              }
            : acc
        ))
      } else {
        addProgressLog(`❌ Check info via thất bại: ${email} - ${result.message}`)
        setAccounts(prev => prev.map(acc => 
          acc._id === accountId
            ? { ...acc, status: 'error', log: `Check info via thất bại: ${result.message}` }
            : acc
        ))
      }
    } catch (error) {
      console.error('Error checking info via:', error)
      const errorMessage = error instanceof Error ? error.message : 'Lỗi không xác định'
      addProgressLog(`💥 Lỗi check info via: ${email} - ${errorMessage}`)
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId
          ? { ...acc, status: 'error', log: `Lỗi check info via: ${errorMessage}` }
          : acc
      ))
    }
  }

  // Multi-threading functions
  const processAccount = async (accountId: string, runId?: number) => {
    const account = accounts.find(acc => acc._id === accountId)
    if (!account) {
      addProgressLog(`⚠️ Không tìm thấy tài khoản: ${accountId}`)
      return
    }

    const email = account.mail || accountId
    addProgressLog(`🔄 Bắt đầu xử lý: ${email} - ${selectedFunction}`)
    
    // Cập nhật progress - bắt đầu xử lý
    setProgress(prev => ({
      ...prev,
      current: prev.current + 1
    }))
    
    // Thực hiện chức năng đã chọn
    try {
      switch (selectedFunction) {
        case 'Đăng nhập Facebook':
  
          await performFacebookLogin(accountId)
          break
        case 'Đăng nhập bằng Cookie':

          await performFacebookLoginByCookie(accountId)
          break
        case 'Check Info Via':
  
          await performCheckInfoVia(accountId)
          break
        case 'Kiểm tra thông tin đầy đủ':
  
          await performFullInfoCheck(accountId)
          break
        case 'Kiểm tra TKQC':
  
          await performTKQCCheck(accountId)
          break
        case 'Kiểm tra TKQC trong BM':
  
          await performTKQCBMCheck(accountId)
          break
        case 'Kiểm tra BM':
  
          await performBusinessManagerCheck(accountId)
          break
                case 'Reg BM':

          await performRegBM(accountId)
          break
        case 'Enable 2FA':

          await performEnable2FA(accountId)
          break
        case 'Share BM':

          await performShareBM(accountId)
          break

        case 'Change Mail':

          await performChangeMail(accountId)
          break

        default:
  
          setAccounts(prev => prev.map(acc => 
            acc._id === accountId 
              ? { ...acc, status: 'error', log: `Chức năng không được hỗ trợ: ${selectedFunction}` }
              : acc
          ))
      }
  
      
      // Cập nhật progress - thành công
      addProgressLog(`✅ Hoàn thành xử lý: ${email}`)
      setProgress(prev => ({
        ...prev,
        completed: prev.completed + 1,
        current: prev.current - 1
      }))
    } catch (error) {
      console.error(`❌ Lỗi khi thực hiện ${selectedFunction} cho tài khoản ${accountId}:`, error)
      const errorMessage = error instanceof Error ? error.message : 'Lỗi không xác định'
      addProgressLog(`💥 Lỗi xử lý: ${email} - ${errorMessage}`)
      setAccounts(prev => prev.map(acc => 
        acc._id === accountId 
          ? { ...acc, status: 'error', log: `Lỗi: ${errorMessage}` }
          : acc
      ))
      
      // Cập nhật progress - thất bại
      setProgress(prev => ({
        ...prev,
        failed: prev.failed + 1,
        current: prev.current - 1
      }))
    }
  }

  const performChangeMail = async (accountId: string) => {
    try {
      const account = accounts.find(acc => acc._id === accountId)
      const email = account?.mail || accountId
      setAccounts(prev => prev.map(acc => acc._id === accountId ? { ...acc, status: 'processing', log: 'Change Mail: bắt đầu...' } : acc))
      addProgressLog(`✉️ Change Mail: ${email}`)

      const body = {
        accountId,
        method: (changeMailOptions?.method || 'mail1s'),
        mail1sAddress: changeMailOptions?.mail1sAddress || '',
        autoConfirm: changeMailOptions?.autoConfirm !== false,
        loginFirst: (loginOptions?.loginFirst !== false),
        useProxy: true
      }

      const res = await fetch('/api/facebook/change-mail', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
        body: JSON.stringify(body)
      })
      const result = await res.json()

      if (res.ok && result?.success) {
        const newEmail = result?.data?.email || account?.mail || ''
        const isConfirmed = result?.data?.confirmed !== false // Check if email was confirmed
        if (isConfirmed) {
          setAccounts(prev => prev.map(acc => acc._id === accountId ? { ...acc, status: 'active', mail: newEmail, log: 'Change Mail: thành công - đã xác nhận' } : acc))
          addProgressLog(`✅ Change Mail thành công: ${email} -> ${newEmail} (đã xác nhận)`)
        } else {
          setAccounts(prev => prev.map(acc => acc._id === accountId ? { ...acc, status: 'active', log: 'Change Mail: đã thêm mail mới - chưa xác nhận' } : acc))
          addProgressLog(`📧 Change Mail: đã thêm mail mới ${newEmail} (chưa xác nhận)`)
        }
      } else {
        setAccounts(prev => prev.map(acc => acc._id === accountId ? { ...acc, status: 'error', log: `Change Mail lỗi: ${result?.message || 'Unknown'}` } : acc))
        addProgressLog(`❌ Change Mail thất bại: ${email} - ${result?.message || 'Unknown'}`)
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Lỗi không xác định'
      addProgressLog(`💥 Lỗi Change Mail: ${msg}`)
    }
  }

  const startMultiThreading = async () => {
    if (isRunningRef.current) {
      addProgressLog(`⚠️ Hệ thống đang chạy, không thể bắt đầu mới`)
      return
    }

    // Kiểm tra xem đã chọn chức năng chưa
    if (!selectedFunction) {
      addNotification({
        type: 'warning',
        title: 'Cảnh báo',
        message: 'Vui lòng chọn chức năng trước khi bắt đầu!'
      })
      return
    }
    
    // Clear logs cũ và bắt đầu mới
    setProgressLogs([])
    addProgressLog(`🚀 Bắt đầu chạy hệ thống - Chức năng: ${selectedFunction}`)

    setIsRunning(true)
    isRunningRef.current = true // Cập nhật ref đồng bộ
    runIdRef.current = Date.now()
    
    // Reset currentThreads về 0 khi bắt đầu mới
    setCurrentThreads(0)
    setProcessingAccounts([])

    const accountsToProcess = selectedAccounts.length > 0 ? selectedAccounts : accounts.map(acc => acc._id)
    
    addProgressLog(`📊 Tổng số tài khoản cần xử lý: ${accountsToProcess.length}`)
    addProgressLog(`⚙️ Số luồng tối đa: ${maxThreads}`)
    
    // Khởi tạo progress
    setProgress({
      total: accountsToProcess.length,
      completed: 0,
      failed: 0,
      current: 0,
      isProcessing: true
    })
    

    
    if (loading) {

      addNotification({
        type: 'warning',
        title: 'Cảnh báo',
        message: 'Đang load tài khoản, vui lòng đợi...'
      })
      return
    }

    if (accountsToProcess.length === 0) {

      addNotification({
        type: 'warning',
        title: 'Cảnh báo',
        message: 'Không có tài khoản nào để xử lý!'
      })
      setIsRunning(false)
      isRunningRef.current = false // Cập nhật ref đồng bộ
      return
    }



    // Sử dụng function helper để tính toán effectiveMaxThreads
    const effectiveMaxThreads = getEffectiveMaxThreads()
    
    addNotification({
      type: 'info',
      title: 'Bắt đầu xử lý',
      message: `Bắt đầu ${selectedFunction} cho ${accountsToProcess.length} tài khoản với ${effectiveMaxThreads} luồng (giới hạn gói: ${userSubscription?.maxThreads || 'không giới hạn'})`
    })

    const processQueue = async () => {

      
      // Sử dụng function helper để tính toán effectiveMaxThreads
      const effectiveMaxThreads = getEffectiveMaxThreads()
      

      
      // Tạo một bản sao của danh sách để theo dõi
      const totalAccounts = accountsToProcess.length
      let processedCount = 0
      let localCurrentThreads = currentThreads // Khởi tạo với số luồng hiện tại
      
      while (accountsToProcess.length > 0 && isRunningRef.current) {

        
        if (localCurrentThreads < effectiveMaxThreads) {
          const accountId = accountsToProcess.shift()
          if (accountId) {
            localCurrentThreads++ // Tăng local counter trước
            setCurrentThreads(prev => prev + 1)
            setProcessingAccounts(prev => [...prev, accountId])
            
            // Chạy processAccount trong background và đợi hoàn thành
            processAccount(accountId, runIdRef.current).finally(() => {
              localCurrentThreads-- // Giảm local counter
              setCurrentThreads(prev => prev - 1)
              setProcessingAccounts(prev => prev.filter(id => id !== accountId))
              processedCount++
              
              // Kiểm tra nếu đã xử lý xong tất cả
              if (processedCount >= totalAccounts) {
                addProgressLog(`🎉 Hoàn thành tất cả! Đã xử lý ${totalAccounts} tài khoản`)
                addProgressLog(`📈 Kết quả: ${progress.completed} thành công, ${progress.failed} thất bại`)
                
                setIsRunning(false)
                isRunningRef.current = false
                // Không reset selectedFunction khi hoàn thành - giữ nguyên chức năng đã chọn
                
                // Reset progress
                setProgress({
                  total: 0,
                  completed: 0,
                  failed: 0,
                  current: 0,
                  isProcessing: false
                })
                
                addNotification({
                  type: 'success',
                  title: 'Hoàn tất',
                  message: 'Đã xử lý tất cả tài khoản!'
                })
              }
            })
          } else {
            break
          }
        } else {
          await new Promise(resolve => setTimeout(resolve, 100))
        }
        
        // Thêm delay nhỏ để tránh vòng lặp quá nhanh
        await new Promise(resolve => setTimeout(resolve, 50))
      }
      

    }
    processQueue()
  }

  const stopMultiThreading = () => {
    addProgressLog(`🛑 Người dùng dừng hệ thống`)
    addProgressLog(`📊 Kết quả tạm thời: ${progress.completed} thành công, ${progress.failed} thất bại, ${progress.current} đang xử lý`)
    
    setIsRunning(false)
    isRunningRef.current = false // Cập nhật ref đồng bộ
    // Abort all pending network requests per account
    activeControllersRef.current.forEach((controllers) => controllers.forEach((c) => {
      try { c.abort() } catch {}
    }))
    activeControllersRef.current.clear()
    // Cancel current run on server using current id, then bump to invalidate local flows
    const cancelId = String(runIdRef.current)
    try { fetch('/api/cancel-run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ runId: cancelId }) }) } catch {}
    // Increase run id to invalidate any async flows relying on stale state
    runIdRef.current += 1
    setSelectedFunction(null) // Reset chức năng đã chọn
    
    // Reset progress
    setProgress({
      total: 0,
      completed: 0,
      failed: 0,
      current: 0,
      isProcessing: false
    })
    
    addNotification({
      type: 'info',
      title: 'Dừng xử lý',
      message: 'Đã dừng xử lý đa luồng'
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-emerald-100 text-emerald-800 border-emerald-200'
      case 'checking': return 'bg-amber-100 text-amber-800 border-amber-200'
      case 'processing': return 'bg-blue-100 text-blue-800 border-blue-200'
      case 'error': return 'bg-red-100 text-red-800 border-red-200'
      case 'inactive': return 'bg-gray-100 text-gray-800 border-gray-200'
      default: return 'bg-purple-100 text-purple-800 border-purple-200'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <UserCheck className="w-4 h-4" />
      case 'checking': return <RefreshCw className="w-4 h-4 animate-spin" />
      case 'processing': return <RefreshCw className="w-4 h-4 animate-spin" />
      case 'error': return <AlertCircle className="w-4 h-4" />
      case 'inactive': return <UserX className="w-4 h-4" />
      default: return <User className="w-4 h-4" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Active'
      case 'checking': return 'Checking'
      case 'processing': return 'Processing'
      case 'error': return 'Error'
      case 'inactive': return 'Inactive'
      default: return 'Pending'
    }
  }

  // Helper functions for quality display
  const getQualityColor = (quality: string) => {
    if (!quality) return 'bg-gray-100 text-gray-800 border-gray-200'
    
    if (quality.includes('Live Ads') || quality.includes('Tích Xanh')) {
      return 'bg-green-100 text-green-800 border-green-200'
    }
    if (quality.includes('HCQC') || quality.includes('Hạn Chế')) {
      return 'bg-red-100 text-red-800 border-red-200'
    }
    if (quality.includes('Đang')) {
      return 'bg-blue-100 text-blue-800 border-blue-200'
    }
    if (quality.includes('IP Spam') || quality.includes('CheckPoint')) {
      return 'bg-orange-100 text-orange-800 border-orange-200'
    }
    return 'bg-yellow-100 text-yellow-800 border-yellow-200'
  }

  const getQualityIcon = (quality: string) => {
    if (!quality) return <Shield className="w-3 h-3" />
    
    if (quality.includes('Live Ads') || quality.includes('Tích Xanh')) {
      return <UserCheck className="w-3 h-3" />
    }
    if (quality.includes('HCQC') || quality.includes('Hạn Chế')) {
      return <AlertCircle className="w-3 h-3" />
    }
    if (quality.includes('Đang')) {
      return <RefreshCw className="w-3 h-3" />
    }
    if (quality.includes('IP Spam') || quality.includes('CheckPoint')) {
      return <X className="w-3 h-3" />
    }
    return <Shield className="w-3 h-3" />
  }

  // Helper function to extract clean UID from account data
  const extractCleanUID = (account: FacebookAccount): string => {
    if (!account.uid) return '';
    
    // If UID contains |, extract the first part (should be the actual UID)
    if (account.uid.includes('|')) {
      const uid = account.uid.split('|')[0];
      // Validate that it looks like a Facebook UID (numeric, 10+ digits)
      if (uid && /^\d{10,}$/.test(uid)) {
        return uid;
      }
    }
    
    // If it's already a clean UID, return as is
    if (/^\d{10,}$/.test(account.uid)) {
      return account.uid;
    }
    
    // Fallback: return the original or empty
    return account.uid || '';
  }

  // Helper function to get account data - prioritizes individual fields over UID string parsing
  const getAccountData = (account: FacebookAccount) => {
    // Always extract clean UID
    const cleanUID = extractCleanUID(account);
    
    // First try to use individual fields from database (new format)
    if (account.pass || account.twofa || account.mail || account.cookie || account.token) {
      return {
        uid: cleanUID,
        pass: account.pass || '',
        twofa: account.twofa || '',
        mail: account.mail || '',
        passmail: account.passmail || '',
        cookie: account.cookie || '',
        token: account.token || ''
      };
    }
    
    // Fallback to parsing UID string (legacy format)
    if (account.uid && account.uid.includes('|') && account.uid.split('|').length >= 7) {
      const parts = account.uid.trim().split('|');
      return {
        uid: cleanUID, // Use clean UID instead of parts[0]
        pass: parts[1] || '',
        twofa: parts[2] || '',
        mail: parts[3] || '',
        passmail: parts[4] || '',
        cookie: parts[5] || '',
        token: parts[6] || ''
      };
    }
    
    // Default fallback
    return {
      uid: cleanUID,
      pass: '',
      twofa: '',
      mail: '',
      passmail: '',
      cookie: '',
      token: ''
    };
  };

  // Legacy function for backward compatibility - now uses getAccountData
  const parseUidString = (uidString: string, account?: FacebookAccount) => {
    if (account) {
      return getAccountData(account);
    }
    
    // Legacy parsing for when only UID string is available
    if (uidString.includes('|') && uidString.split('|').length >= 7) {
      const parts = uidString.trim().split('|');
      return {
        uid: parts[0] || '',
        pass: parts[1] || '',
        twofa: parts[2] || '',
        mail: parts[3] || '',
        passmail: parts[4] || '',
        cookie: parts[5] || '',
        token: parts[6] || ''
      };
    }
    return {
      uid: uidString,
      pass: '',
      twofa: '',
      mail: '',
      passmail: '',
      cookie: '',
      token: ''
    };
  };



  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-gray-600 dark:text-gray-300 text-xl font-medium">Đang tải...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Top Ticker */}
      {showTopTicker && (
        <div className="fixed top-0 left-0 right-0 z-50">
          <div>
            <div className="relative pl-4 pr-10 py-1 overflow-hidden">
              <div
                key={topTickerIndex}
                className="whitespace-nowrap text-blue-500 animate-[ticker_45s_linear_forwards]"
                onAnimationEnd={() => {
                  setTopTickerIndex((prev) => (prev + 1) % (topTickerMessages.length || 1))
                }}
              >
                <span className="mx-8">{topTickerMessages[topTickerIndex] || ''}</span>
              </div>
              <button
                onClick={() => setShowTopTicker(false)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-black/70 hover:text-black"
                aria-label="Đóng thông báo"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
          {/* Keyframes for ticker */}
          <style jsx>{`
            @keyframes ticker {
              0% { transform: translateX(100%); }
              100% { transform: translateX(-100%); }
            }
          `}</style>
        </div>
      )}
      {/* Header */}
      {/* Navigation */}
      <Navigation currentPage="dashboard" />
      {/* Live logs */}
      {liveLogs.length > 0 && (
        <div className="px-4 pt-6">
          <div className="mb-3 rounded-lg border border-blue-200 dark:border-blue-800 bg-blue-50/60 dark:bg-blue-900/20 p-2 text-xs text-blue-900 dark:text-blue-200 max-h-40 overflow-auto">
            {liveLogs.slice(-10).map((l, i) => (
              <div key={i}>• {l}</div>
            ))}
          </div>
        </div>
      )}
      
      {/* Floating Progress Bar - Bottom Right */}
      {progress.isProcessing && (
        <div className={`fixed bottom-2 right-2 md:bottom-4 md:right-4 z-40 bg-white dark:bg-gray-800 shadow-xl border border-gray-200 dark:border-gray-700 rounded-lg transition-all duration-300 ${
          isProgressMinimized ? 'w-12 h-12 md:w-14 md:h-14 rounded-full' : 'w-64 md:w-72'
        } ${!isProgressMinimized ? 'h-40 md:h-40' : ''}`}>
          {isProgressMinimized ? (
            // Minimized view
            <div 
              className="w-full h-full flex items-center justify-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 rounded-full"
              onClick={() => setIsProgressMinimized(false)}
            >
              <div className="relative w-full h-full">
                <div className="absolute inset-0 rounded-full bg-blue-500/10"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-[10px] md:text-[11px] font-bold text-gray-700 dark:text-gray-200">
                    {progress.total > 0 ? Math.round(((progress.completed + progress.failed) / progress.total) * 100) : 0}%
                  </span>
                </div>
              </div>
            </div>
          ) : (
            // Expanded view
            <div className="p-2 h-full flex flex-col">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-[11px] font-semibold text-gray-700 dark:text-gray-300 flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse mr-2"></div>
                  Tiến trình xử lý
                </h3>
                <div className="flex items-center space-x-2">
                  <span className="text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded">
                    {progress.completed + progress.failed}/{progress.total}
                  </span>
                  <button
                    onClick={() => setIsProgressMinimized(true)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                </div>
              </div>
              
              {/* Progress Bar */}
              <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-1 mb-1.5">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-1 rounded-full transition-all duration-500 ease-out"
                  style={{ 
                    width: `${progress.total > 0 ? ((progress.completed + progress.failed) / progress.total) * 100 : 0}%` 
                  }}
                ></div>
              </div>
              
              {/* Progress Details */}
              <div className="flex items-center justify-between text-[10px]">
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-green-600 dark:text-green-400 font-medium">{progress.completed}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-red-600 dark:text-red-400 font-medium">{progress.failed}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                    <span className="text-blue-600 dark:text-blue-400 font-medium">{progress.current}</span>
                  </div>
                </div>
                
                <div className="text-right">
                  <span className="font-bold text-gray-700 dark:text-gray-300 text-xs">
                    {progress.total > 0 ? Math.round(((progress.completed + progress.failed) / progress.total) * 100) : 0}%
                  </span>
                </div>
              </div>

              {/* Logs Section */}
                <div className="mt-2 flex-1 flex flex-col min-h-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-[10px] font-semibold text-gray-600 dark:text-gray-400 flex items-center">
                      <Terminal className="w-3 h-3 mr-1" />
                      Logs realtime
                    </h4>
                    <button
                      onClick={() => setProgressLogs([])}
                      className="text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                      title="Xóa logs"
                    >
                      Xóa
                    </button>
                  </div>
                  <div 
                    ref={progressLogsRef}
                    className="flex-1 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md p-2 overflow-y-auto text-[10px] font-mono"
                    style={{ maxHeight: '80px' }}
                  >
                    {progressLogs.length === 0 ? (
                      <div className="text-gray-400 dark:text-gray-500 text-center py-4">
                        Chưa có logs...
                      </div>
                    ) : (
                      progressLogs.map((log, index) => (
                        <div 
                          key={index} 
                          className="text-gray-700 dark:text-gray-300 mb-1 leading-tight"
                        >
                          {log}
                        </div>
                      ))
                    )}
                  </div>
                </div>
            </div>
          )}
        </div>
      )}

      {/* Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {notifications.map(notification => (
          <div
            key={notification.id}
            className={`bg-white dark:bg-gray-800 shadow-lg border-l-4 px-6 py-4 rounded-lg transform transition-all duration-300 slide-in-right ${
              notification.type === 'success' ? 'border-emerald-400' :
              notification.type === 'error' ? 'border-red-400' :
              notification.type === 'warning' ? 'border-yellow-400' :
              'border-blue-400'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-gray-800 dark:text-gray-200 font-medium">{notification.message}</span>
              <button
                onClick={() => removeNotification(notification.id)}
                className="ml-4 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
 
             {/* Main Container */}
       <div className="lg:ml-64 lg:mr-80 max-w-none mx-auto px-4 sm:px-6 lg:px-10 pt-20 lg:pt-4 pb-4 lg:pb-8 mb-0">
        {/* Control Panel */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-4 lg:p-6 mb-6 lg:mb-8">
          <div className="flex flex-col space-y-4">
            {/* Top Row - Main Actions */}
            <div className="flex flex-wrap items-center gap-2">
              <button 
                onClick={startMultiThreading}
                disabled={isRunning}
                className={`flex items-center space-x-2 px-3 lg:px-4 py-2 rounded-lg transition-colors shadow-md hover:shadow-lg text-sm ${
                  isRunning 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : selectedFunction 
                      ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                      : 'bg-gray-400 cursor-not-allowed'
                }`}
              >
                <Play className="w-4 h-4" />
                <span className="font-medium">
                  {isRunning ? 'Đang chạy...' : 'Bắt đầu'}
                </span>
              </button>
              
              <button 
                onClick={stopMultiThreading}
                disabled={!isRunning}
                className={`flex items-center space-x-2 px-3 lg:px-4 py-2 rounded-lg transition-colors shadow-md hover:shadow-lg text-sm ${
                  !isRunning 
                    ? 'bg-gray-400 cursor-not-allowed' 
                    : 'bg-red-500 hover:bg-red-600 text-white'
                }`}
              >
                <StopIcon className="w-4 h-4" />
                <span className="font-medium">Dừng</span>
              </button>
              
              <button
                onClick={() => setShowFunctionPanel(!showFunctionPanel)}
                className="flex items-center space-x-2 px-3 lg:px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors shadow-md hover:shadow-lg text-sm"
              >
                <Settings className="w-4 h-4" />
                <span className="font-medium">Chức năng</span>
              </button>

              <button
                onClick={() => setShowAccountManagement(true)}
                className="flex items-center space-x-2 px-3 lg:px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors shadow-md hover:shadow-lg text-sm"
              >
                <Users className="w-4 h-4" />
                <span className="font-medium">Quản lý tài khoản</span>
              </button>

              <button
                onClick={() => setShowSettings(true)}
                className="flex items-center space-x-2 px-3 lg:px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors shadow-md hover:shadow-lg text-sm"
              >
                <Settings className="w-4 h-4" />
                <span className="font-medium">Cài đặt</span>
              </button>
            </div>
            {/* Middle Row - Search and Filter */}
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Tìm kiếm tài khoản..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none text-gray-900 placeholder-gray-500 font-medium"
                />
              </div>
              
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none text-gray-900 bg-white dark:bg-gray-800 dark:text-gray-100 dark:border-gray-600"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="active">Active</option>
                <option value="checking">Checking</option>
                <option value="processing">Processing</option>
                <option value="error">Error</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
            {/* Bottom Row - Right Actions */}
            <div className="flex flex-wrap items-center gap-2">
                              {/* View Mode Toggle */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setViewMode('table')}
                  className={`p-2 rounded-lg transition-colors ${viewMode === 'table' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
                >
                  <List className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' : 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300'}`}
                >
                  <Grid3X3 className="w-5 h-5" />
                </button>
              </div>
          </div>
                 </div>
                 </div>

         {/* Financial Summary Card */}
         {(() => {
           const totals = calculateTotalFinancials(filteredAccounts)
           const accountsWithTKQC = filteredAccounts.filter(acc => 
             (acc.tkqcData && acc.tkqcData.length > 0) || acc.accountInfo
           ).length
           
           return (
             <div className="bg-gradient-to-r from-emerald-50 to-blue-50 dark:from-emerald-900/20 dark:to-blue-900/20 rounded-xl shadow-lg border border-emerald-200 dark:border-emerald-700 p-6 mb-6">
               <div className="flex items-center justify-between mb-4">
                 <div className="flex items-center space-x-3">
                   <div className="p-2 bg-emerald-500 rounded-lg">
                     <DollarSign className="w-6 h-6 text-white" />
                   </div>
                   <div>
                     <h3 className="text-lg font-bold text-gray-900 dark:text-white">Tổng Quan Tài Chính 1</h3>
                     <p className="text-sm text-gray-600 dark:text-gray-400">
                       Từ {accountsWithTKQC} tài khoản có dữ liệu TKQC / {filteredAccounts.length} tổng tài khoản
                     </p>
                   </div>
                 </div>
                 <div className="text-xs text-gray-500 dark:text-gray-400 bg-white dark:bg-gray-800 px-3 py-1 rounded-full">
                   Tự động chuyển đổi về VNĐ
                 </div>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                 {/* Tổng Số Dư */}
                 <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-green-200 dark:border-green-700">
                   <div className="flex items-center justify-between">
                     <div>
                       <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Tổng Số Dư</p>
                       <p className="text-2xl font-bold text-green-600 dark:text-green-400">{totals.totalBalance}</p>
                     </div>
                     <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                       <DollarSign className="w-5 h-5 text-green-600 dark:text-green-400" />
                     </div>
                   </div>
                 </div>
                 
                 {/* Tổng Chi Tiêu */}
                 <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-purple-200 dark:border-purple-700">
                   <div className="flex items-center justify-between">
                     <div>
                       <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Tổng Chi Tiêu</p>
                       <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">{totals.totalAmountSpent}</p>
                     </div>
                     <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                       <TrendingUp className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                     </div>
                   </div>
                 </div>
                 
                 {/* Tổng Đã Chi Tiêu */}
                 <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-orange-200 dark:border-orange-700">
                   <div className="flex items-center justify-between">
                     <div>
                       <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Tổng Đã Chi Tiêu</p>
                       <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">{totals.totalSpend}</p>
                     </div>
                     <div className="p-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
                       <CreditCard className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                     </div>
                   </div>
                 </div>
               </div>
               
               {/* Additional Stats */}
               <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                   <div>
                     <p className="text-lg font-bold text-gray-900 dark:text-white">{accountsWithTKQC}</p>
                     <p className="text-xs text-gray-600 dark:text-gray-400">Tài khoản có TKQC</p>
                   </div>
                   <div>
                     <p className="text-lg font-bold text-gray-900 dark:text-white">
                       {Math.round((totals.totalBalanceRaw / 1000000))} M
                     </p>
                     <p className="text-xs text-gray-600 dark:text-gray-400">Số dư (triệu VNĐ)</p>
                   </div>
                   <div>
                     <p className="text-lg font-bold text-gray-900 dark:text-white">
                       {Math.round((totals.totalAmountSpentRaw / 1000000))} M
                     </p>
                     <p className="text-xs text-gray-600 dark:text-gray-400">Chi tiêu (triệu VNĐ)</p>
                   </div>
                   <div>
                     <p className="text-lg font-bold text-gray-900 dark:text-white">
                       {accountsWithTKQC > 0 ? Math.round(totals.totalBalanceRaw / accountsWithTKQC / 1000) + 'K' : '0'}
                     </p>
                     <p className="text-xs text-gray-600 dark:text-gray-400">Số dư TB/TK (nghìn VNĐ)</p>
                   </div>
                 </div>
               </div>
             </div>
           )
         })()}

                 {/* Accounts Display */}
         {viewMode === 'table' ? (
           <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
             {(filteredAccounts.length > 10 || isRunning) && (
               <div className={`p-3 border-b ${
                 isRunning 
                   ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                   : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
               }`}>
                 <div className={`flex items-center space-x-2 ${
                   isRunning 
                     ? 'text-green-700 dark:text-green-300' 
                     : 'text-blue-700 dark:text-blue-300'
                 }`}>
                   <div className={`w-2 h-2 rounded-full animate-pulse ${
                     isRunning 
                       ? 'bg-green-500 dark:bg-green-400' 
                       : 'bg-blue-500 dark:bg-blue-400'
                   }`}></div>
                   <span className="text-sm font-medium">
                     {isRunning 
                       ? `🛡️ Đang bảo vệ ${selectedAccounts.length} tài khoản đã chọn`
                       : `Có ${filteredAccounts.length} tài khoản - Cuộn xuống để xem thêm`
                     }
                   </span>
                 </div>
               </div>
             )}
             <div className="overflow-x-auto max-h-[60vh] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 hover:scrollbar-thumb-gray-400">
               <table className="w-full">
                 <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="text-left py-4 px-4">
                      <input
                        type="checkbox"
                        checked={selectedAccounts.length === filteredAccounts.length && filteredAccounts.length > 0}
                        onChange={handleSelectAll}
                        className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                      />
                    </th>
                                                             <th className="text-left py-4 px-4 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                      <div className="flex items-center space-x-2">
                        <Hash className="w-4 h-4 text-red-600" />
                        <span>UID</span>
                      </div>
                    </th>
                    <th className="text-left py-4 px-4 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-blue-600" />
                        <span>TÊN</span>
                      </div>
                    </th>
                     <th className="text-left py-4 px-4 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                       <div className="flex items-center space-x-2">
                         <DollarSign className="w-4 h-4 text-green-600" />
                         <span>TỔNG SỐ DƯ</span>
                       </div>
                     </th>
                     <th className="text-left py-4 px-4 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                       <div className="flex items-center space-x-2">
                         <TrendingUp className="w-4 h-4 text-purple-600" />
                         <span>TỔNG CHI TIÊU</span>
                       </div>
                     </th>
                     <th className="text-left py-4 px-4 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                       <div className="flex items-center space-x-2">
                         <CreditCard className="w-4 h-4 text-orange-600" />
                         <span>TỔNG ĐÃ CHI TIÊU</span>
                       </div>
                     </th>
                     <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                       <div className="flex items-center space-x-2">
                         <Shield className="w-4 h-4 text-yellow-600" />
                         <span>CHẤT LƯỢNG</span>
                       </div>
                     </th>
                     <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                       <div className="flex items-center space-x-2">
                         <Activity className="w-4 h-4 text-green-600" />
                         <span>TRẠNG THÁI</span>
                       </div>
                     </th>
                     <th className="text-left py-4 px-7 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                       <div className="flex items-center space-x-2">
                         <Settings className="w-4 h-4 text-indigo-600" />
                         <span>THAO TÁC</span>
                       </div>
                     </th>
                  </tr>
                </thead>
                <tbody>
                                     {filteredAccounts.map((account) => (
                                           <tr
                        key={account._id}
                        className={`border-b border-gray-100 dark:border-gray-700 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors cursor-pointer ${
                          highlightedAccounts.includes(account._id) ? 'bg-blue-100 dark:bg-blue-900/30' : ''
                        } ${
                          processingAccounts.includes(account._id) ? 'bg-amber-50 dark:bg-amber-900/20' : ''
                        }`}
                        onClick={() => handleHighlightAccount(account._id)}
                        onContextMenu={(e) => handleContextMenu(e, account._id)}
                      >
                       <td className="py-4 px-6">
                         <input
                           type="checkbox"
                           checked={selectedAccounts.includes(account._id)}
                           onChange={() => handleSelectAccount(account._id)}
                           onClick={(e) => e.stopPropagation()}
                           className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                         />
                       </td>
                       <td className="py-4 px-4 text-gray-900 dark:text-gray-100 font-medium text-sm">{getAccountData(account).uid}</td>
                       <td className="py-4 px-4 text-gray-900 dark:text-gray-100 font-medium text-sm">{account.name}</td>
                       <td className="py-4 px-4 text-gray-700 dark:text-gray-300 text-sm">
                         {(() => {
                           const financials = getAccountFinancials(account)
                           return financials.balance > 0 || (account.tkqcData && account.tkqcData.length > 0) || account.accountInfo ? (
                             <div className="flex flex-col">
                               <span className="font-medium text-green-600 dark:text-green-400">
                                 {financials.balanceFormatted}
                               </span>
                               {account.tkqcData && account.tkqcData.length > 1 && (
                                 <span className="text-xs text-blue-500 dark:text-blue-400">
                                   Từ {account.tkqcData.length} TKQC
                                 </span>
                               )}
                             </div>
                           ) : (
                             <span className="text-gray-400">Chưa có dữ liệu</span>
                           )
                         })()}
                       </td>
                       <td className="py-4 px-6 text-gray-700 dark:text-gray-300 text-sm">
                         {(() => {
                           const financials = getAccountFinancials(account)
                           return financials.amountSpent > 0 || (account.tkqcData && account.tkqcData.length > 0) || account.accountInfo ? (
                             <div className="flex flex-col">
                               <span className="font-medium text-purple-600 dark:text-purple-400">
                                 {financials.amountSpentFormatted}
                               </span>
                               {account.tkqcData && account.tkqcData.length > 1 && (
                                 <span className="text-xs text-blue-500 dark:text-blue-400">
                                   Từ {account.tkqcData.length} TKQC
                                 </span>
                               )}
                             </div>
                           ) : (
                             <span className="text-gray-400">Chưa có dữ liệu</span>
                           )
                         })()}
                       </td>
                       <td className="py-4 px-6 text-gray-700 dark:text-gray-300 text-sm">
                         {(() => {
                           const financials = getAccountFinancials(account)
                           return financials.spend > 0 || (account.tkqcData && account.tkqcData.length > 0) || account.accountInfo ? (
                             <div className="flex flex-col">
                               <span className="font-medium text-orange-600 dark:text-orange-400">
                                 {financials.spendFormatted}
                               </span>
                               {account.tkqcData && account.tkqcData.length > 1 && (
                                 <span className="text-xs text-blue-500 dark:text-blue-400">
                                   Từ {account.tkqcData.length} TKQC
                                 </span>
                               )}
                             </div>
                           ) : (
                             <span className="text-gray-400">Chưa có dữ liệu</span>
                           )
                         })()}
                       </td>
                      <td className="py-4 px-6">
                        <span className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium border ${getQualityColor(account.quality || '')}`}>
                          {getQualityIcon(account.quality || '')}
                          <span className="max-w-32 truncate" title={account.quality || 'Chưa check'}>
                            {account.quality || 'Chưa check'}
                          </span>
                        </span>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex flex-col space-y-1">
                        <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(account.status)}`}>
                          {getStatusIcon(account.status)}
                          <span>{getStatusText(account.status)}</span>
                        </span>
                          {account.log && (
                            <div 
                              className="text-xs text-gray-600 dark:text-gray-400 max-w-48 truncate cursor-help"
                              title={account.log}
                            >
                              {account.log}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-2">
                          <button 
                            onClick={(e) => {
                              e.stopPropagation()
                              handleViewTKQC(account._id)
                            }}
                            className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                            title="Xem TKQC Data"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={(e) => {
                              e.stopPropagation()
                              handleDeleteAccount(account._id)
                            }}
                            className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                          >
                            <Trash className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
                 ) : (
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
             {filteredAccounts.map((account) => (
               <div
                 key={account._id}
                 className={`bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300 cursor-pointer ${
                   highlightedAccounts.includes(account._id) ? 'ring-2 ring-blue-500' : ''
                 }`}
                 onClick={() => handleHighlightAccount(account._id)}
                 onContextMenu={(e) => handleContextMenu(e, account._id)}
               >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={selectedAccounts.includes(account._id)}
                      onChange={() => handleSelectAccount(account._id)}
                      onClick={(e) => e.stopPropagation()}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                      <User className="w-5 h-5 text-white" />
                    </div>
                  </div>
                                     <div className="flex items-center space-x-1">
                     <button className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                       <MoreVertical className="w-4 h-4" />
                     </button>
                   </div>
                 </div>
                 
                 <div className="space-y-3">
                   <div>
                     <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">UID</p>
                     <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{getAccountData(account).uid}</p>
                   </div>
                   <div>
                     <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">TÊN</p>
                     <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{account.name}</p>
                   </div>
                   
                   <div>
                     <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">TỔNG SỐ DƯ</p>
                     {(() => {
                       const financials = getAccountFinancials(account)
                       return financials.balance > 0 || (account.tkqcData && account.tkqcData.length > 0) || account.accountInfo ? (
                         <div>
                           <p className="text-sm font-medium text-green-600 dark:text-green-400">
                             {financials.balanceFormatted}
                           </p>
                           {account.tkqcData && account.tkqcData.length > 1 && (
                             <p className="text-xs text-blue-500 dark:text-blue-400">
                               Từ {account.tkqcData.length} TKQC
                             </p>
                           )}
                         </div>
                       ) : (
                         <p className="text-sm text-gray-400">Chưa có dữ liệu</p>
                       )
                     })()}
                   </div>
                   
                   <div>
                     <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">TRẠNG THÁI</p>
                     <div className="flex flex-col space-y-1">
                     <span className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(account.status)}`}>
                       {getStatusIcon(account.status)}
                       <span>{getStatusText(account.status)}</span>
                     </span>
                       {account.log && (
                         <div 
                           className="text-xs text-gray-600 dark:text-gray-400 max-w-full truncate cursor-help"
                           title={account.log}
                         >
                           {account.log}
                         </div>
                       )}
                     </div>
                   </div>
                   
                   <div className="grid grid-cols-2 gap-3 text-xs">
                     <div>
                       <p className="text-gray-500 dark:text-gray-400 font-medium">TỔNG CHI TIÊU</p>
                       {(() => {
                         const financials = getAccountFinancials(account)
                         return financials.amountSpent > 0 || (account.tkqcData && account.tkqcData.length > 0) || account.accountInfo ? (
                           <div>
                             <p className="text-sm font-medium text-purple-600 dark:text-purple-400">
                               {financials.amountSpentFormatted}
                             </p>
                             {account.tkqcData && account.tkqcData.length > 1 && (
                               <p className="text-xs text-blue-500 dark:text-blue-400">
                                 Từ {account.tkqcData.length} TKQC
                               </p>
                             )}
                           </div>
                         ) : (
                           <p className="text-sm text-gray-400">Chưa có dữ liệu</p>
                         )
                       })()}
                     </div>
                     <div>
                       <p className="text-gray-500 dark:text-gray-400 font-medium">TỔNG ĐÃ CHI TIÊU</p>
                       {(() => {
                         const financials = getAccountFinancials(account)
                         return financials.spend > 0 || (account.tkqcData && account.tkqcData.length > 0) || account.accountInfo ? (
                           <div>
                             <p className="text-sm font-medium text-orange-600 dark:text-orange-400">
                               {financials.spendFormatted}
                             </p>
                             {account.tkqcData && account.tkqcData.length > 1 && (
                               <p className="text-xs text-blue-500 dark:text-blue-400">
                                 Từ {account.tkqcData.length} TKQC
                               </p>
                             )}
                           </div>
                         ) : (
                           <p className="text-sm text-gray-400">Chưa có dữ liệu</p>
                         )
                       })()}
                     </div>
                   </div>
                 </div>
                 
                 <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation()
                      handleDeleteAccount(account._id)
                    }}
                    className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                  >
                    <Trash className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation()
                      handleViewTKQC(account._id)
                    }}
                    className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                    title="Xem TKQC Data"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
                 )}
       </div>


 
       

        {/* Status Bar */}
        <div className="fixed bottom-0 left-0 lg:left-64 right-0 lg:right-80 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-600 px-2 lg:px-4 py-2 z-30">
          <div className="max-w-none mx-auto flex flex-col lg:flex-row lg:items-center lg:justify-between text-xs text-gray-600 dark:text-gray-400 space-y-2 lg:space-y-0">
            {/* Top Row - Counts */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 lg:gap-4">
              <div className="flex items-center space-x-1">
                <span className="text-gray-600 dark:text-gray-400">Bôi đen:</span>
                <span className="text-blue-600 dark:text-blue-400 font-bold">{highlightedAccounts.length}</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-gray-600 dark:text-gray-400">Đã chọn:</span>
                <span className="text-green-600 dark:text-green-400 font-bold">{selectedAccounts.length}</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-gray-600 dark:text-gray-400">Tất cả:</span>
                <span className="text-purple-600 dark:text-purple-400 font-bold">{accounts.length}</span>
              </div>
              <div className="flex items-center space-x-1">
                <span className="text-gray-600 dark:text-gray-400">Đã lọc:</span>
                <span className="text-indigo-600 dark:text-indigo-400 font-bold">{filteredAccounts.length}</span>
              </div>
              {isRunning && (
                <>
                  <div className="flex items-center space-x-1">
                    <span className="text-gray-600 dark:text-gray-400">Đang chạy:</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                      {currentThreads}/{getEffectiveMaxThreads()}
                    </span>
                    {!allowUserThreadSettings && (
                      <span className="text-xs text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/20 px-1 py-0.5 rounded-full">
                        Admin Lock
                      </span>
                    )}
                    {userSubscription && userSubscription.plan !== 'enterprise' && userSubscription.maxThreads !== -1 && (
                      <span className="text-xs text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/20 px-1 py-0.5 rounded-full">
                        Giới hạn: {userSubscription.maxThreads}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className="text-gray-600 dark:text-gray-400">Đang xử lý:</span>
                    <span className="text-blue-600 dark:text-blue-400 font-bold">{processingAccounts.length}</span>
                  </div>
                </>
              )}
            </div>
            
            {/* Center - Subscription Info */}
            <div className="flex items-center justify-center lg:justify-start space-x-2">
              <div className="flex items-center space-x-1">
                <span className="text-gray-600 dark:text-gray-400">Gói:</span>
                <span className={`font-bold px-1 py-0.5 rounded-full text-xs ${
                  userSubscription?.plan === 'free' ? 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300' :
                  userSubscription?.plan === 'basic' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300' :
                  userSubscription?.plan === 'premium' ? 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300' :
                  userSubscription?.plan === 'enterprise' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300' :
                  'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300'
                }`}>
                  {userSubscription?.plan?.toUpperCase() || 'FREE'}
                </span>
              </div>
              {userSubscription && (
                <div className="flex items-center space-x-1">
                  <span className="text-gray-600 dark:text-gray-400">Còn lại:</span>
                  <span className="text-orange-600 dark:text-orange-400 font-bold">
                    {Math.max(0, Math.ceil((new Date(userSubscription.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)))} ngày
                  </span>
                </div>
              )}
              <button
                onClick={refreshSubscription}
                className="p-0.5 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors"
                title="Làm mới thông tin gói"
              >
                <RefreshCw className="w-3 h-3" />
              </button>
            </div>
            
            <div className="flex items-center justify-center lg:justify-end">
              <span className="text-gray-700 dark:text-gray-300 font-medium text-xs"><VersionBadge prefix="FTool - CHECKVIA" /></span>
            </div>
          </div>
        </div>

      {/* Settings Modal */}
      <SettingsModal 
        isOpen={showSettings} 
        onClose={() => setShowSettings(false)}
        userSubscription={userSubscription}
      />

             {/* Account Management Modal */}
       <AccountManagementModal 
         isOpen={showAccountManagement} 
                 onClose={() => setShowAccountManagement(false)}
        refreshAccounts={() => loadAccounts(true)}
      />

      {/* Welcome Modal */}
      <WelcomeModal
        isOpen={showWelcomeModal}
        onClose={() => setShowWelcomeModal(false)}
        title={welcomePopupSettings.title}
        message={welcomePopupSettings.message}
        showDontShowAgain={welcomePopupSettings.showDontShowAgain}
      />

      {/* Context Menu */}
      {contextMenu.visible && (
         <div 
           className="fixed z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border border-gray-200/50 dark:border-gray-700/50 rounded-xl shadow-2xl py-2 min-w-[200px] animate-in fade-in-0 zoom-in-95 duration-200"
           style={{ 
             left: contextMenu.x, 
             top: contextMenu.y,
             transform: 'translate(-50%, -100%)'
           }}
         >
           {/* Header */}
           <div className="px-3 py-2 border-b border-gray-100 dark:border-gray-800">
             <div className="flex items-center space-x-2">
               <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-md flex items-center justify-center">
                 <User className="w-3 h-3 text-white" />
               </div>
               <div>
                 <span className="text-sm font-semibold text-gray-900 dark:text-white">Tài khoản</span>
               </div>
             </div>
           </div>
           
                       {/* Selection Actions */}
            <div className="px-2 py-1">
              <button
                onClick={() => handleContextMenuSelect(contextMenu.accountId!)}
                className="w-full px-3 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-green-50 hover:to-emerald-50 dark:hover:from-green-900/20 dark:hover:to-emerald-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
              >
                <div className="w-6 h-6 bg-green-100 dark:bg-green-900/30 rounded-md flex items-center justify-center group-hover:bg-green-200 dark:group-hover:bg-green-800/40 transition-colors">
                  <UserCheck className="w-3 h-3 text-green-600 dark:text-green-400" />
                </div>
                <span className="font-medium">Chọn</span>
              </button>
              
              <button
                onClick={() => setSelectedAccountsWithLog([...selectedAccounts, ...highlightedAccounts.filter(id => !selectedAccounts.includes(id))])}
                className="w-full px-3 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-orange-50 hover:to-amber-50 dark:hover:from-orange-900/20 dark:hover:to-amber-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
              >
                <div className="w-6 h-6 bg-orange-100 dark:bg-orange-900/30 rounded-md flex items-center justify-center group-hover:bg-orange-200 dark:group-hover:bg-orange-800/40 transition-colors">
                  <Users className="w-3 h-3 text-orange-600 dark:text-orange-400" />
                </div>
                <span className="font-medium">Chọn bôi đen</span>
              </button>
              
              <button
                onClick={handleDeselectAll}
                className="w-full px-3 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-blue-50 hover:to-indigo-50 dark:hover:from-blue-900/20 dark:hover:to-indigo-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
              >
                <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900/30 rounded-md flex items-center justify-center group-hover:bg-blue-200 dark:group-hover:bg-blue-800/40 transition-colors">
                  <X className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                </div>
                <span className="font-medium">Bỏ chọn tất cả</span>
              </button>
              

            </div>
           
              {/* Copy Selected Accounts Section */}
              {selectedAccounts.length > 0 && (
                <div className="px-3 py-2 border-t border-gray-100 dark:border-gray-800">
                  <div className="flex items-center space-x-2 mb-2">
                    <Users className="w-3 h-3 text-green-600 dark:text-green-400" />
                    <span className="text-xs font-semibold text-green-700 dark:text-green-300">
                      Copy {selectedAccounts.length} tài khoản đã chọn
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-1">
                    <button
                      onClick={() => handleCopySelectedAccounts('uid')}
                      className="px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20 rounded transition-colors font-medium"
                    >
                      UID
                    </button>
                    <button
                      onClick={() => handleCopySelectedAccounts('pass')}
                      className="px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20 rounded transition-colors font-medium"
                    >
                      PASS
                    </button>
                    <button
                      onClick={() => handleCopySelectedAccounts('2fa')}
                      className="px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20 rounded transition-colors font-medium"
                    >
                      2FA
                    </button>
                    <button
                      onClick={() => handleCopySelectedAccounts('mail')}
                      className="px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20 rounded transition-colors font-medium"
                    >
                      Mail
                    </button>
                  </div>
                  
                  <button
                    onClick={() => handleCopySelectedAccounts('full')}
                    className="w-full mt-1 px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-gradient-to-r hover:from-green-50 hover:to-emerald-50 dark:hover:from-green-900/20 dark:hover:to-emerald-900/20 rounded transition-all duration-200 font-medium"
                  >
                    Tất cả thông tin
                  </button>
                </div>
              )}
            
                         {/* Actions Section */}
             <div className="px-2 py-1 border-t border-gray-100 dark:border-gray-800">
               <button
                 onClick={() => handleContextMenuCheckQuality(contextMenu.accountId!)}
                 className="w-full px-3 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-emerald-50 hover:to-green-50 dark:hover:from-emerald-900/20 dark:hover:to-green-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
               >
                 <div className="w-6 h-6 bg-emerald-100 dark:bg-emerald-900/30 rounded-md flex items-center justify-center group-hover:bg-emerald-200 dark:group-hover:bg-emerald-800/40 transition-colors">
                   <Shield className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                 </div>
                 <span className="font-medium">Check Quality (Cookie)</span>
               </button>

               <button
                 onClick={() => handleContextMenuDelete(contextMenu.accountId!)}
                 className="w-full px-3 py-2 text-left text-sm text-red-600 dark:text-red-400 hover:bg-gradient-to-r hover:from-red-50 hover:to-pink-50 dark:hover:from-red-900/20 dark:hover:to-pink-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
               >
                 <div className="w-6 h-6 bg-red-100 dark:bg-red-900/30 rounded-md flex items-center justify-center group-hover:bg-red-200 dark:group-hover:bg-red-800/40 transition-colors">
                   <Trash className="w-3 h-3 text-red-600 dark:text-red-400" />
                 </div>
                 <span className="font-medium">Xóa tài khoản</span>
               </button>
               
               {selectedAccounts.length > 0 && (
                 <button
                   onClick={handleDeleteSelected}
                   className="w-full px-3 py-2 text-left text-sm text-red-600 dark:text-red-400 hover:bg-gradient-to-r hover:from-red-50 hover:to-pink-50 dark:hover:from-red-900/20 dark:hover:to-pink-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
                 >
                   <div className="w-6 h-6 bg-red-100 dark:bg-red-900/30 rounded-md flex items-center justify-center group-hover:bg-red-200 dark:group-hover:bg-red-800/40 transition-colors">
                     <Trash2 className="w-3 h-3 text-red-600 dark:text-red-400" />
                   </div>
                   <span className="font-medium">Xóa đã chọn ({selectedAccounts.length})</span>
                 </button>
               )}
             </div>
         </div>
       )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirmModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white flex items-center space-x-3">
                <div className="w-8 h-8 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center">
                  <Trash2 className="w-4 h-4 text-red-600 dark:text-red-400" />
                </div>
                <span>Xác nhận xóa</span>
              </h2>
              <button
                onClick={cancelDeleteSelected}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="p-6">
              <p className="text-gray-700 dark:text-gray-300 mb-6">
                Bạn có chắc chắn muốn xóa <span className="font-semibold text-red-600 dark:text-red-400">{accountsToDelete.length}</span> tài khoản đã chọn?
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                Hành động này không thể hoàn tác. Tất cả dữ liệu của các tài khoản này sẽ bị xóa vĩnh viễn.
              </p>
              <div className="flex space-x-3">
                <button
                  onClick={cancelDeleteSelected}
                  className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors font-medium"
                >
                  Hủy
                </button>
                <button
                  onClick={confirmDeleteSelected}
                  className="flex-1 px-4 py-2 text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors font-medium flex items-center justify-center space-x-2"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Xóa</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TKQC Modal */}
      {showTKQCModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-6xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Thông tin TKQC
              </h2>
              <button
                onClick={() => {
                  setShowTKQCModal(false)
                  setSelectedAccountForTKQC(null)
                }}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              <TKQCDataTable selectedAccountId={selectedAccountForTKQC} />
            </div>
          </div>
        </div>
      )}



      {/* Function Panel */}
      <FunctionPanel
        isOpen={showFunctionPanel}
        onClose={() => setShowFunctionPanel(false)}
        selectedFunction={selectedFunction}
        onFunctionSelect={handleSelectFunction}
        regBmOptions={regBmOptions}
        onRegBmOptionsChange={setRegBmOptions}
        loginOptions={loginOptions}
        onLoginOptionsChange={setLoginOptions}
        shareBmOptions={shareBmOptions}
        onShareBmOptionsChange={setShareBmOptions}
        shareBmLinks={shareBmLinks}
        changeMailOptions={changeMailOptions}
        onChangeMailOptionsChange={setChangeMailOptions}
      />
    </div>
  )
} 