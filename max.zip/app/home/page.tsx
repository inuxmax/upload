'use client'

import React, { useEffect, useState } from 'react'
import { Bell, Clock, Package, Wallet, Users, Mail, Megaphone, Download } from 'lucide-react'
import Navigation from '@/components/Navigation'

type SummaryResponse = {
  success: boolean
  data: {
    totals: { facebookAccounts: number; outlookAccounts: number; purchasedAccounts?: number }
    orders: any[]
    deposits: any[]
    changelog: string[]
    notifications: { id: string; message: string; createdAt?: string }[]
  }
}

export default function HomeSummary() {
  const [summary, setSummary] = useState<SummaryResponse['data'] | null>(null)
  const [loading, setLoading] = useState(true)
  const [downloadingId, setDownloadingId] = useState<string | null>(null)
  const [products, setProducts] = useState<Array<{ id: string; name: string }>>([])
  const [showAnnouncement, setShowAnnouncement] = useState(true)

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetch('/api/home/summary', {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        })
        if (res.ok) {
          const json: SummaryResponse = await res.json()
          setSummary(json.data)
        }
        // Load shop products for proper order names (best-effort)
        try {
          const pr = await fetch(`/api/shop-external/products?_=${Date.now()}`, {
            cache: 'no-store',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
          })
          const pdata = await pr.json().catch(() => ({}))
          const arr = (pdata?.products || []) as Array<{ id: string; name: string }>
          if (Array.isArray(arr) && arr.length > 0) {
            setProducts(arr.map(p => ({ id: String((p as any).id), name: (p as any).name })))
          }
        } catch {}
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const downloadOrder = async (order: any) => {
    try {
      setDownloadingId(order._id)
      const res = await fetch(`/api/orders/${order._id}/download`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      })
      if (!res.ok) return
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `order-${order.transId || order._id}.txt`
      document.body.appendChild(a)
      a.click()
      a.remove()
      URL.revokeObjectURL(url)
    } finally {
      setDownloadingId(null)
    }
  }

  const getOrderProductName = (o: any): string => {
    const found = products.find(p => String(p.id) === String(o.productId))?.name
    return found || o.productName || `Sản phẩm ${o.productId}`
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-gray-600 dark:text-gray-300 text-xl font-medium">Đang tải...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <Navigation currentPage="home" />

      <div className="lg:ml-64 lg:mr-80 max-w-none mx-auto px-4 sm:px-6 lg:px-8 pt-20 lg:pt-6 pb-6 lg:pb-8 mb-0">
        <div className="mb-4 lg:mb-6">
          <h1 className="text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">Trang chủ</h1>
          <p className="text-xs lg:text-sm text-gray-600 dark:text-gray-400">Tổng quan nhanh hệ thống của bạn</p>
        </div>

        {/* Ftool Shop THÔNG BÁO - Compact */}
        {showAnnouncement && (
          <div className="bg-white dark:bg-gray-800 border border-blue-200 dark:border-blue-700 rounded-lg max-w-7xl mx-auto mb-4 lg:mb-6">
            <div className="bg-blue-50 dark:bg-blue-900/20 border-b border-blue-200 dark:border-blue-700 px-3 lg:px-4 py-2 lg:py-3 rounded-t-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-5 h-5 lg:w-6 lg:h-6 bg-blue-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">i</span>
                  </div>
                  <h3 className="text-xs lg:text-sm font-semibold text-blue-900 dark:text-blue-100">Ftool Shop THÔNG BÁO</h3>
                </div>
                <button 
                  onClick={() => setShowAnnouncement(false)}
                  className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 p-1"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
            
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-dashed border-yellow-300 dark:border-yellow-600 m-2 lg:m-3 p-2 lg:p-3 rounded-lg">
              <div className="space-y-1 text-xs text-gray-700 dark:text-gray-300">
                <div>• Tài Khoản của chúng tôi nhập từ bên khác về để bán cho bạn</div>
                <div>• Có nhiều định dạng tài khoản khác nhau</div>
                <div>• Có sai password, sai email, sai 2fa</div>
                <div className="text-green-600 dark:text-green-400 font-semibold">• <strong>Vì thế các bạn nên mua với số lượng nhỏ và thử nghiệm trước</strong></div>
                
                <div className="mt-2 pt-2 border-t border-yellow-300 dark:border-yellow-600">
                  <div className="font-semibold text-gray-800 dark:text-gray-200 mb-1 text-xs">LƯU Ý:</div>
                  <div className="text-xs">Shop chỉ cung cấp DATA, <strong>không cam kết bất kỳ mọi trường hợp nào</strong>. Hãy <strong>mua và thử nghiệm trước với số lượng nhỏ</strong>.</div>
                  <div className="text-xs mt-1">Không lạm dụng DATA làm trái pháp luật, chúng tôi sẽ <strong>Không chịu trách nhiệm và không hoàn tiền</strong> nếu phát hiện vi phạm.</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Top Stats Row - Compact */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 lg:gap-4 mb-4 lg:mb-6">
          <div className="p-4 lg:p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div className="text-xs lg:text-sm text-gray-600 dark:text-gray-400">Thông báo</div>
              <Bell className="w-4 h-4 text-amber-500" />
            </div>
            <div className="mt-2 text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">{summary?.notifications?.length ?? 0}</div>
          </div>
          <div className="p-4 lg:p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div className="text-xs lg:text-sm text-gray-600 dark:text-gray-400">Tài khoản đã mua</div>
              <Users className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="mt-2 text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">{summary?.totals.purchasedAccounts ?? 0}</div>
          </div>
        </div>

        {/* Main grid: left (2 cols) with content, right (1 col) updates */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 lg:gap-6">
          {/* Left column */}
          <div className="xl:col-span-2 space-y-4 lg:space-y-6">
            {/* Notifications */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="p-3 lg:p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Bell className="w-4 h-4 text-amber-600" />
                  <h2 className="text-sm lg:text-base font-semibold text-gray-900 dark:text-white">Thông báo</h2>
                </div>
              </div>
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {(summary?.notifications ?? []).length === 0 && (
                  <div className="p-3 lg:p-4 text-xs lg:text-sm text-gray-500 dark:text-gray-400">Chưa có thông báo</div>
                )}
                {(summary?.notifications ?? []).map((n) => (
                  <div key={n.id} className="p-3 lg:p-4 text-xs lg:text-sm text-gray-800 dark:text-gray-200">{n.message}</div>
                ))}
              </div>
            </div>

            {/* Orders */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="p-3 lg:p-4 border-b border-gray-200 dark:border-gray-700 flex items-center space-x-2">
                <Package className="w-4 h-4 text-blue-600" />
                <h2 className="text-sm lg:text-base font-semibold text-gray-900 dark:text-white">Lịch sử mua hàng</h2>
              </div>
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {(summary?.orders ?? []).length === 0 && (
                  <div className="p-3 lg:p-4 text-xs lg:text-sm text-gray-500 dark:text-gray-400">Chưa có đơn hàng</div>
                )}
                {(summary?.orders ?? []).map((o) => (
                  <div key={o._id} className="p-3 lg:p-4 text-xs lg:text-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <div className="space-y-1">
                      <div className="font-medium text-gray-900 dark:text-white">{getOrderProductName(o)}</div>
                      <div className="text-gray-500 dark:text-gray-400 text-xs">Mã: {o.transId} • Số lượng: {o.amount}</div>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-end gap-2 sm:gap-3">
                      <button
                        onClick={() => downloadOrder(o)}
                        className="px-2 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center gap-1 h-7 w-fit"
                        title="Tải xuống đơn hàng"
                        disabled={downloadingId === o._id}
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span className="text-xs">{downloadingId === o._id ? 'Đang tải...' : 'Tải'}</span>
                      </button>
                      <div className="text-left sm:text-right">
                        <div className="font-semibold text-gray-900 dark:text-white">{(o.price || 0).toLocaleString('vi-VN')}₫</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">{new Date(o.createdAt).toLocaleString('vi-VN')}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Deposits */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="p-3 lg:p-4 border-b border-gray-200 dark:border-gray-700 flex items-center space-x-2">
                <Wallet className="w-4 h-4 text-emerald-600" />
                <h2 className="text-sm lg:text-base font-semibold text-gray-900 dark:text-white">Lịch sử nạp tiền</h2>
              </div>
              <div className="divide-y divide-gray-200 dark:divide-gray-700">
                {(summary?.deposits ?? []).length === 0 && (
                  <div className="p-3 lg:p-4 text-xs lg:text-sm text-gray-500 dark:text-gray-400">Chưa có giao dịch</div>
                )}
                {(summary?.deposits ?? []).map((t) => (
                  <div key={t._id} className="p-3 lg:p-4 text-xs lg:text-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                    <div className="space-y-1">
                      <div className="font-medium text-gray-900 dark:text-white">{(t.amount || 0).toLocaleString('vi-VN')}₫</div>
                      <div className="text-gray-500 dark:text-gray-400 text-xs">{t.transferContent}</div>
                    </div>
                    <div className="text-left sm:text-right">
                      <div className="text-xs text-gray-500 dark:text-gray-400">{new Date(t.createdAt).toLocaleString('vi-VN')}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right column */}
          <div className="space-y-4 lg:space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
              <div className="p-3 lg:p-4 border-b border-gray-200 dark:border-gray-700 flex items-center space-x-2">
                <Clock className="w-4 h-4 text-gray-600" />
                <h2 className="text-sm lg:text-base font-semibold text-gray-900 dark:text-white">Chi tiết cập nhật</h2>
              </div>
              <div className="max-h-[400px] lg:max-h-[520px] overflow-auto p-3 lg:p-4 text-xs lg:text-sm whitespace-pre-wrap text-gray-800 dark:text-gray-200">
                {(summary?.changelog ?? []).slice(0, 120).join('\n') || 'Không có dữ liệu'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}


