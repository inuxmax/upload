'use client'

import React, { useEffect, useState } from 'react'
import Link from 'next/link'
import { useTheme } from '@/contexts/ThemeContext'
import {
  Grid,
  Sun,
  Moon,
  Sparkles,
  BarChart3,
  Shield,
  Zap,
  LayoutDashboard,
  Layers,
  Rocket,
  Check,
  Play,
  Settings as SettingsIcon,
  MousePointerClick,
  Settings2,
  Twitter,
  Facebook,
  Github,
  Mail,
  Key,
  Cookie as CookieIcon,
  Globe,
  Share2,
  Building2,
  Bell,
  Activity,
  Database,
} from 'lucide-react'

interface SubscriptionPlan {
  _id: string
  name: string
  plan: string
  duration: number
  price: number
  currency: string
  maxThreads: number
  features: string[]
  isActive: boolean
  description: string
}

function formatCurrency(amount: number, currency: string) {
  if (currency?.toUpperCase() === 'VND') {
    return new Intl.NumberFormat('vi-VN').format(amount) + 'đ'
  }
  try {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount)
  } catch {
    return amount.toString()
  }
}

export default function Ladipage() {
  const { theme, toggleTheme } = useTheme()
  const [plans, setPlans] = useState<SubscriptionPlan[]>([])
  const [loadingPlans, setLoadingPlans] = useState(true)

  useEffect(() => {
    let isMounted = true
    const loadPlans = async () => {
      try {
        const res = await fetch('/api/subscription/plans', { cache: 'no-store' })
        if (res.ok) {
          const data = await res.json()
          if (isMounted) setPlans(Array.isArray(data) ? data : [])
        }
      } catch {}
      finally { if (isMounted) setLoadingPlans(false) }
    }
    loadPlans()
    return () => { isMounted = false }
  }, [])

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Animated background */}
      <div className="animated-background" />

      {/* Navbar */}
      <header className="fixed top-0 inset-x-0 z-40">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8 py-3 sm:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="glass-effect rounded-xl p-1.5 sm:p-2">
              <Grid className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <span className="text-lg sm:text-xl font-extrabold tracking-tight">Ftool.vn</span>
            <span className="ml-2 sm:ml-3 px-1.5 sm:px-2 py-0.5 sm:py-1 text-xs rounded-full border border-white/20 bg-white/10 backdrop-blur">
              All in one
            </span>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-sm text-white/80">
            <a href="#features" className="hover:text-white">Tính năng</a>
            <a href="#steps" className="hover:text-white">Quy trình</a>
            <a href="#pricing" className="hover:text-white">Bảng giá</a>
            <a href="#faq" className="hover:text-white">FAQ</a>
          </nav>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={toggleTheme}
              className="glass-effect px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm flex items-center gap-1 sm:gap-2"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Moon className="w-3 h-3 sm:w-4 sm:h-4" /> : <Sun className="w-3 h-3 sm:w-4 sm:h-4" />}
              <span className="hidden sm:inline">Theme</span>
            </button>
            <Link
              href="/auth"
              className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 transition-opacity px-3 sm:px-4 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold"
            >
              Dùng thử
            </Link>
          </div>
        </div>
      </header>

      <main className="pt-20 sm:pt-28">
        {/* Hero */}
        <section className="relative">
          <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-6 sm:gap-10 items-center">
              <div>
                <div className="inline-flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-1 rounded-full border border-white/15 bg-white/10 backdrop-blur mb-3 sm:mb-4">
                  <Sparkles className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="text-xs">Tối ưu trải nghiệm & chuyển đổi</span>
                </div>
                <h1 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold leading-tight">
                  Check mọi thứ trên facebook với
                  <span className="ml-1 sm:ml-2 bg-gradient-to-r from-indigo-300 via-purple-300 to-pink-300 bg-clip-text text-transparent">Ftool</span>
                </h1>
                <p className="mt-3 sm:mt-4 text-white/80 text-base sm:text-lg">
                  Scan từ via có sẵn, check mail, cookie, proxy, 2FA, subscription, share BM, và nhiều hơn nữa
                </p>

                <div className="mt-4 sm:mt-6 flex flex-col sm:flex-row gap-2 sm:gap-3">
                  <a href="#pricing" className="px-3 sm:px-5 py-2 sm:py-3 rounded-xl font-semibold bg-white/10 hover:bg-white/15 glass-effect text-center">Xem bảng giá</a>
                  <a href="#features" className="px-3 sm:px-5 py-2 sm:py-3 rounded-xl font-semibold bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 transition-opacity text-center">Khám phá tính năng</a>
                </div>

                <div className="mt-6 sm:mt-8 grid grid-cols-3 gap-2 sm:gap-4">
                  <div className="glass-effect rounded-xl p-2 sm:p-4 text-center">
                    <div className="text-lg sm:text-2xl font-extrabold">98%</div>
                    <div className="text-xs text-white/70">Tỷ lệ hài lòng</div>
                  </div>
                  <div className="glass-effect rounded-xl p-2 sm:p-4 text-center">
                    <div className="text-lg sm:text-2xl font-extrabold">5K+</div>
                    <div className="text-xs text-white/70">Người dùng</div>
                  </div>
                  <div className="glass-effect rounded-xl p-2 sm:p-4 text-center">
                    <div className="text-lg sm:text-2xl font-extrabold">24/7</div>
                    <div className="text-xs text-white/70">Hỗ trợ</div>
                  </div>
                </div>
              </div>

              <div className="relative">
                <div className="glass-effect rounded-2xl p-2 sm:p-4">
                  <div className="rounded-xl overflow-hidden border border-white/10">
                    {/* Mock dashboard preview */}
                    <div className="bg-slate-900/60 p-2 sm:p-4 border-b border-white/10 flex items-center justify-between">
                      <div className="flex items-center gap-1 sm:gap-2">
                        <div className="w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-red-400/80" />
                        <div className="w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-amber-400/80" />
                        <div className="w-2 h-2 sm:w-3 sm:h-3 rounded-full bg-emerald-400/80" />
                      </div>
                      <span className="text-xs text-white/60">Preview</span>
                    </div>
                    <div className="p-3 sm:p-6 bg-gradient-to-br from-slate-900/60 via-slate-900/40 to-slate-900/20">
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 sm:gap-4">
                        <div className="glass-effect rounded-xl p-2 sm:p-4">
                          <div className="text-xs sm:text-sm text-white/70">Tài khoản</div>
                          <div className="mt-1 sm:mt-2 text-lg sm:text-2xl font-extrabold">1,248</div>
                        </div>
                        <div className="glass-effect rounded-xl p-2 sm:p-4">
                          <div className="text-xs sm:text-sm text-white/70">Tỉ lệ thành công</div>
                          <div className="mt-1 sm:mt-2 text-lg sm:text-2xl font-extrabold">92.4%</div>
                        </div>
                        <div className="glass-effect rounded-xl p-2 sm:p-4">
                          <div className="text-xs sm:text-sm text-white/70">Hoạt động</div>
                          <div className="mt-1 sm:mt-2 text-lg sm:text-2xl font-extrabold">Ổn định</div>
                        </div>
                      </div>
                      <div className="mt-3 sm:mt-4 grid grid-cols-2 gap-2 sm:gap-3">
                        <button className="glass-effect rounded-lg px-2 sm:px-4 py-1.5 sm:py-2 text-left text-xs sm:text-sm flex items-center gap-1 sm:gap-2">
                          <Play className="w-3 h-3 sm:w-4 sm:h-4" /> Bắt đầu
                        </button>
                        <button className="glass-effect rounded-lg px-2 sm:px-4 py-1.5 sm:py-2 text-left text-xs sm:text-sm flex items-center gap-1 sm:gap-2">
                          <SettingsIcon className="w-3 h-3 sm:w-4 sm:h-4" /> Cấu hình
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="pointer-events-none absolute -z-10 -top-6 sm:-top-10 -right-6 sm:-right-10 w-40 h-40 sm:w-60 sm:h-60 rounded-full blur-3xl bg-indigo-500/30" />
              </div>
            </div>
          </div>
        </section>

        {/* Features (reflect real implemented features) */}
        <section id="features" className="mt-12 sm:mt-20">
          <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8">
            <div className="text-center max-w-2xl mx-auto">
              <h2 className="text-2xl sm:text-3xl font-extrabold">Tính năng nổi bật</h2>
              <p className="mt-2 sm:mt-3 text-white/80 text-sm sm:text-base">Tổng hợp trực tiếp từ hệ thống: automation, proxy, TKQC/BM, 2FA, subscription…</p>
            </div>

            <div className="mt-6 sm:mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {/* Built-from-code features */}
                              {[ 
                { icon: <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-300" />, title: 'Đổi mail tự động', desc: 'Mail1s/Outlook • gửi + đọc mã • xác nhận OAuth GraphQL' },
                { icon: <Key className="w-4 h-4 sm:w-5 sm:h-5 text-purple-300" />, title: 'Đăng nhập Cookie/Password', desc: 'Làm mới EAAG/EAAB • session bền • tự xử lý lỗi' },
                { icon: <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-300" />, title: 'Proxy thông minh', desc: 'NetProxy • tự lấy/đổi IP • gắn vào mọi request' },
                { icon: <Activity className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-300" />, title: 'Quản lý luồng', desc: 'Chạy song song • giới hạn theo gói • log tiến trình' },
                { icon: <Building2 className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300" />, title: 'TKQC & Business Manager', desc: 'Check TKQC/BM • thống kê • phân tích số liệu' },
                { icon: <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-pink-300" />, title: 'Bật 2FA & bảo mật', desc: 'Enable 2FA • check quality via • refresh session' },
                { icon: <Share2 className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-300" />, title: 'Share BM tự động', desc: 'Role tuỳ chọn • hỗ trợ Mail1s tạo email nhận' },
                { icon: <Bell className="w-4 h-4 sm:w-5 sm:h-5 text-purple-300" />, title: 'Thông báo realtime', desc: 'Notification • progress logs • ticker thông tin' },
                { icon: <Database className="w-4 h-4 sm:w-4 sm:h-5 text-cyan-300" />, title: 'Gói & bảng giá', desc: 'Các gói linh hoạt, Phù hợp nhu cầu' },
              ].map((f, idx) => (
                <div key={idx} className="glass-effect rounded-2xl p-4 sm:p-6">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg bg-white/10 flex items-center justify-center border border-white/10">
                    {f.icon}
                  </div>
                  <h3 className="mt-3 sm:mt-4 font-semibold text-base sm:text-lg">{f.title}</h3>
                  <p className="mt-1 text-white/70 text-xs sm:text-sm">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Steps */}
        <section id="steps" className="mt-12 sm:mt-20">
          <div className="max-w-5xl mx-auto px-3 sm:px-4 lg:px-8">
            <div className="glass-effect rounded-2xl p-4 sm:p-6">
              <h3 className="text-lg sm:text-xl font-bold">Quy trình 3 bước</h3>
              <div className="mt-4 sm:mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                <div className="glass-effect rounded-xl p-3 sm:p-5">
                  <div className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm text-white/70">
                    <MousePointerClick className="w-3 h-3 sm:w-4 sm:h-4" /> Bước 1
                  </div>
                  <div className="mt-1 sm:mt-2 font-semibold text-sm sm:text-base">Chọn gói phù hợp</div>
                  <p className="text-xs sm:text-sm text-white/70 mt-1">Xem tính năng, chọn gói theo nhu cầu.</p>
                </div>
                <div className="glass-effect rounded-xl p-3 sm:p-5">
                  <div className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm text-white/70">
                    <Settings2 className="w-3 h-3 sm:w-4 sm:h-4" /> Bước 2
                  </div>
                  <div className="mt-1 sm:mt-2 font-semibold text-sm sm:text-base">Tuỳ chỉnh nhanh</div>
                  <p className="text-xs sm:text-sm text-white/70 mt-1">Thiết lập nội dung, proxy, 2FA, subscription, share BM…</p>
                </div>
                <div className="glass-effect rounded-xl p-3 sm:p-5">
                  <div className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm text-white/70">
                    <Rocket className="w-3 h-3 sm:w-4 sm:h-4" /> Bước 3
                  </div>
                  <div className="mt-1 sm:mt-2 font-semibold text-sm sm:text-base">Triển khai</div>
                  <p className="text-xs sm:text-sm text-white/70 mt-1">Thêm tài khoản và làm mọi thứ bạn muốn</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="mt-12 sm:mt-20">
          <div className="max-w-6xl mx-auto px-3 sm:px-4 lg:px-8">
            <div className="text-center max-w-2xl mx-auto">
              <h2 className="text-2xl sm:text-3xl font-extrabold">Bảng giá minh bạch</h2>
              <p className="mt-2 sm:mt-3 text-white/80 text-sm sm:text-base">Chọn gói phù hợp, có thể nâng cấp bất kỳ lúc nào.</p>
            </div>

            <div className="mt-6 sm:mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {loadingPlans && (
                <div className="col-span-1 sm:col-span-2 lg:col-span-3 text-center text-white/70">Đang tải bảng giá...</div>
              )}
              {!loadingPlans && plans.length === 0 && (
                <div className="col-span-1 sm:col-span-2 lg:col-span-3 text-center text-white/70">Hiện chưa có gói nào khả dụng.</div>
              )}

              {plans.map((p) => (
                <div key={p._id} className="glass-effect rounded-2xl p-4 sm:p-6 flex flex-col">
                  <div className="text-xs sm:text-sm text-white/70">{p.name || p.plan}</div>
                  <div className="mt-2 text-xl sm:text-3xl font-extrabold">
                    {p.price > 0 ? `${formatCurrency(p.price, p.currency)} / ${p.duration} tháng` : 'Miễn phí'}
                  </div>
                  <div className="mt-1 text-xs text-white/60">Tối đa {p.maxThreads === -1 ? 'không giới hạn' : `${p.maxThreads}`} luồng</div>
                  <ul className="mt-3 sm:mt-4 space-y-1 sm:space-y-2 text-xs sm:text-sm text-white/80">
                    {(p.features || []).slice(0, 6).map((f, idx) => (
                      <li key={idx} className="flex items-center gap-1 sm:gap-2"><Check className="w-3 h-3 sm:w-4 sm:h-4 text-emerald-300" /> {f}</li>
                    ))}
                  </ul>
                  <Link href="/auth" className="mt-4 sm:mt-6 w-full text-center px-3 sm:px-4 py-2 rounded-lg bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 text-sm sm:text-base">
                    {p.price > 0 ? 'Mua ngay' : 'Dùng thử'}
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="mt-12 sm:mt-20">
          <div className="max-w-6xl mx-auto px-3 sm:px-4 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              <figure className="glass-effect rounded-2xl p-6">
                <blockquote className="text-white/90">“Thiết kế rất hiện đại, triển khai cực nhanh, tỷ lệ chuyển đổi tăng rõ rệt.”</blockquote>
                <figcaption className="mt-4 text-sm text-white/60 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10" /> An, Marketing Lead
                </figcaption>
              </figure>
              <figure className="glass-effect rounded-2xl p-6">
                <blockquote className="text-white/90">“Phong cách dashboard nhìn rất chuyên nghiệp. Dễ tùy chỉnh.”</blockquote>
                <figcaption className="mt-4 text-sm text-white/60 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10" /> Minh, PM
                </figcaption>
              </figure>
              <figure className="glass-effect rounded-2xl p-6">
                <blockquote className="text-white/90">“Hiệu ứng mượt, tải nhanh, code sạch. Rất phù hợp cho landing.”</blockquote>
                <figcaption className="mt-4 text-sm text-white/60 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-white/10" /> Huy, Dev
                </figcaption>
              </figure>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="mt-12 sm:mt-20">
          <div className="max-w-4xl mx-auto px-3 sm:px-4 lg:px-8">
            <h3 className="text-xl sm:text-2xl font-bold text-center">Câu hỏi thường gặp</h3>
            <div className="mt-6 sm:mt-8 space-y-3">
              <details className="glass-effect rounded-xl p-4">
                <summary className="cursor-pointer font-semibold">Giới hạn luồng theo gói hoạt động thế nào?</summary>
                <div className="mt-2 text-white/80 text-sm">Mỗi gói có <em>maxThreads</em>. Hệ thống tự áp giới hạn khi chạy đa luồng; gói Enterprise có thể không giới hạn (giá trị -1).</div>
              </details>
              <details className="glass-effect rounded-xl p-4">
                <summary className="cursor-pointer font-semibold">Đổi mail tự động hoạt động ra sao?</summary>
                <div className="mt-2 text-white/80 text-sm">Có Mail1s/Outlook: gửi mã, đọc inbox, và xác nhận qua GraphQL (OAuth). Nếu xác nhận thất bại, hệ thống log “Change Mail: không thành công”.</div>
              </details>
              <details className="glass-effect rounded-xl p-4">
                <summary className="cursor-pointer font-semibold">Proxy có được dùng tự động không?</summary>
                <div className="mt-2 text-white/80 text-sm">Có. Tích hợp NetProxy, tự lấy/đổi IP và gắn agent vào các request Facebook (login, change mail, share BM…).</div>
              </details>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section id="cta" className="mt-12 sm:mt-20 mb-16 sm:mb-24">
          <div className="max-w-4xl mx-auto px-3 sm:px-4 lg:px-8 text-center">
            <div className="glass-effect rounded-2xl p-4 sm:p-8">
              <h3 className="text-xl sm:text-2xl font-bold">Sẵn sàng bắt đầu?</h3>
              <p className="mt-2 text-white/80 text-sm sm:text-base">Nhận mẫu này, tuỳ chỉnh nội dung và triển khai trong vài phút.</p>
              <div className="mt-4 sm:mt-6 flex flex-col sm:flex-row gap-2 sm:gap-3 justify-center">
                <Link href="/auth" className="px-4 sm:px-6 py-2 sm:py-3 rounded-xl bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 hover:opacity-90 font-semibold text-sm sm:text-base">Dùng thử miễn phí</Link>
                <a href="https://datpromax.com" className="px-4 sm:px-6 py-2 sm:py-3 rounded-xl glass-effect font-semibold text-sm sm:text-base">Liên hệ tư vấn</a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 py-6 sm:py-10">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 items-center">
          <div className="text-white/70 text-xs sm:text-sm text-center sm:text-left">© {new Date().getFullYear()} Ftool.vn. All rights reserved.</div>
          <nav className="flex justify-center gap-4 sm:gap-6 text-xs sm:text-sm text-white/80">
            <a href="#features" className="hover:text-white">Tính năng</a>
            <a href="#pricing" className="hover:text-white">Bảng giá</a>
            <a href="#faq" className="hover:text-white">FAQ</a>
          </nav>
          <div className="flex justify-center sm:justify-end gap-2 sm:gap-3">
            <a href="#" className="glass-effect p-1.5 sm:p-2 rounded-lg" aria-label="Twitter"><Twitter className="w-3 h-3 sm:w-4 sm:h-4" /></a>
            <a href="#" className="glass-effect p-1.5 sm:p-2 rounded-lg" aria-label="Facebook"><Facebook className="w-3 h-3 sm:w-4 sm:h-4" /></a>
            <a href="#" className="glass-effect p-1.5 sm:p-2 rounded-lg" aria-label="Github"><Github className="w-3 h-3 sm:w-4 sm:h-4" /></a>
          </div>
        </div>
      </footer>
    </div>
  )
}


