import React from 'react'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { ThemeProvider } from '@/contexts/ThemeContext'
import { NotificationProvider } from '@/components/NotificationSystem'
import { StorageProvider } from '@/contexts/StorageContext'
import ConsoleSilencer from '@/components/ConsoleSilencer'
import SecurityCleaner from '@/components/SecurityCleaner'

// Import để khởi tạo cron tự động
import '@/lib/cron'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Facebook Account Manager',
  description: 'Quản lý tài khoản Facebook',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider>
          <NotificationProvider>
            <StorageProvider>
              <SecurityCleaner />
              <ConsoleSilencer />
              {children}
            </StorageProvider>
          </NotificationProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}