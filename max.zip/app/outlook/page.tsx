﻿'use client'

import React, { useState, useEffect, useRef, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { 
  Settings, Plus, Search, Play, Square as StopIcon, ChevronDown, FileText, User, Users, Calendar, Eye, Trash, RefreshCw, Shield, Database, Globe, BarChart3, Activity, Target, Lock, Unlock, Download, Upload, Filter, Star, Crown, Home, Menu, X, EyeOff, AlertCircle, UserCheck, UserX, TrendingUp, Edit, LogOut, Bell, Grid3X3, List, MoreVertical, Trash2, Sun, Moon, Mail, Key, Cookie, Hash, Copy, Minus, Terminal, ChevronUp, Building2, DollarSign, CreditCard, CheckCircle, XCircle, Clock, CheckSquare, RotateCcw, AlertTriangle
} from 'lucide-react'
import Navigation from '../../components/Navigation'
import RealTimeStatusLog, { RealTimeStatusLogRef } from '../../components/RealTimeStatusLog'
import VersionBadge from '@/components/VersionBadge'

interface OutlookAccount {
  _id: string;
  email: string;
  password: string;
  twofa?: string; // Thêm field 2FA
  proxy?: string;
  status: 'active' | 'inactive' | 'error' | 'token_expired' | 'needs_reauth';
  lastLogin?: string;
  lastMailCheck?: string;
  errorMessage?: string;
  lastError?: string;
  tokenExpiresAt?: string;
  isTokenExpired?: boolean;
  createdAt: string;
  updatedAt: string;
  lastUpdated?: string;
}

interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
}

export default function OutlookDashboard() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [accounts, setAccounts] = useState<OutlookAccount[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([])

  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table')
  const [toasts, setToasts] = useState<Toast[]>([])
  


  
  // Bulk Import Modal
  const [showBulkImportModal, setShowBulkImportModal] = useState(false)
  const [bulkAccountsText, setBulkAccountsText] = useState('')
  const [bulkProxy, setBulkProxy] = useState('')
  const [bulkImporting, setBulkImporting] = useState(false)
  const [bulkProgress, setBulkProgress] = useState({ current: 0, total: 0 })
  
  // Interface for bulk import account
  interface BulkAccount {
    email: string
    password: string
    refreshToken?: string
    clientId?: string
  }
  
  // Settings Modal
  const [showSettings, setShowSettings] = useState(false)
  const [mailReadMethod, setMailReadMethod] = useState<'outlook' | 'imap' | 'scraping'>('outlook')
  const [imapSettings, setImapSettings] = useState({
    host: 'outlook.office365.com',
    port: 993,
    secure: true
  })
  const [maxEmailsPerRead, setMaxEmailsPerRead] = useState(10)
  const [timeoutSeconds, setTimeoutSeconds] = useState(30)
  const [imapTimeoutSeconds, setImapTimeoutSeconds] = useState(90)
  const [scrapingSettings, setScrapingSettings] = useState({
    headless: true,
    timeout: 120,
    waitForLoad: 5000,
    debugMode: false
  })
  
  // Thread and Proxy Settings
  const [maxThreads, setMaxThreads] = useState(3)
  const [userMaxThreads, setUserMaxThreads] = useState(2) // Giới hạn theo gói user
  const [userPlan, setUserPlan] = useState('free')
  const [subscriptionDaysLeft, setSubscriptionDaysLeft] = useState(30)
  const [proxySettings, setProxySettings] = useState({
    enabled: false,
    server: '', // IP từ database (chỉ hiển thị, không refresh)
    selectedProxyId: '',
    useForAll: false,
    databaseIP: '', // IP từ database
    lastDatabaseCheck: 0 // Thời gian kiểm tra database cuối cùng
  })
  const [availableProxies, setAvailableProxies] = useState<any[]>([])
  
  // Read Mail Modal
  const [showReadMailModal, setShowReadMailModal] = useState(false)
  const [selectedAccountForMail, setSelectedAccountForMail] = useState<string | null>(null)
  const [filterSender, setFilterSender] = useState('')
  const [filterMinutes, setFilterMinutes] = useState('')
  const [readingMail, setReadingMail] = useState(false)

  // Stored Emails Viewer
  const [showStoredEmailsModal, setShowStoredEmailsModal] = useState(false)
  const [storedEmails, setStoredEmails] = useState<any[]>([])
  const [selectedAccountForStoredEmails, setSelectedAccountForStoredEmails] = useState<string | null>(null)

  // Email Detail Viewer
  const [showEmailDetailModal, setShowEmailDetailModal] = useState(false)
  const [selectedEmailDetail, setSelectedEmailDetail] = useState<any>(null)
  const [mailResults, setMailResults] = useState<any[]>([])
  
  // Progress logs
  const [progressLogs, setProgressLogs] = useState<string[]>([])
  const progressLogsRef = useRef<HTMLDivElement>(null)
  const [isProgressMinimized, setIsProgressMinimized] = useState(false)

  // Run control (Start/Stop)
  const [isRunning, setIsRunning] = useState(false)
  const currentRunIdRef = useRef<string | null>(null)
  const activeControllersRef = useRef<Map<string, AbortController[]>>(new Map())

  const startRun = useCallback(() => {
    const newId = String(Date.now())
    currentRunIdRef.current = newId
    setIsRunning(true)
    return newId
  }, [])

  const registerController = (key: string, controller: AbortController) => {
    const list = activeControllersRef.current.get(key) || []
    list.push(controller)
    activeControllersRef.current.set(key, list)
  }

  const releaseController = (key: string, controller: AbortController) => {
    const list = activeControllersRef.current.get(key)
    if (!list) return
    activeControllersRef.current.set(key, list.filter(c => c !== controller))
  }

  const stopRun = useCallback(() => {
    const cancelId = currentRunIdRef.current
    if (cancelId) {
      try {
        fetch('/api/cancel-run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ runId: cancelId }) })
      } catch {}
    }
    activeControllersRef.current.forEach(list => list.forEach(c => c.abort()))
    activeControllersRef.current.clear()
    setIsRunning(false)
    setReadingMail(false)
  }, [])

  const controlledFetch = useCallback(async (url: string, options: any, key: string) => {
    const controller = new AbortController()
    registerController(key, controller)
    try {
      return await fetch(url, { ...options, signal: controller.signal })
    } finally {
      releaseController(key, controller)
    }
  }, [])

  // Real-time status logs
  const [statusLogRefs, setStatusLogRefs] = useState<Map<string, RealTimeStatusLogRef>>(new Map())
  const [accountStatusLogs, setAccountStatusLogs] = useState<Map<string, any[]>>(new Map())
  
  // Use useRef to avoid infinite loops
  const statusLogRefsRef = useRef<Map<string, RealTimeStatusLogRef>>(new Map())

  // Custom confirmation modal state
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [accountsToDelete, setAccountsToDelete] = useState<Array<{id: string, email: string}>>([])
  
  // Context menu states
  const [contextMenu, setContextMenu] = useState<{
    visible: boolean;
    x: number;
    y: number;
    accountId?: string;
  }>({
    visible: false,
    x: 0,
    y: 0
  })

  // Highlight accounts state
  const [highlightedAccounts, setHighlightedAccounts] = useState<string[]>([])

  // Facebook accounts display settings
  const [showFacebookInfo, setShowFacebookInfo] = useState(false)
  const [facebookAccounts, setFacebookAccounts] = useState<any[]>([])

  // Toast helper functions
  const showToast = (type: 'success' | 'error' | 'info' | 'warning', title: string, message: string) => {
    const id = Date.now().toString();
    const newToast = { id, type, title, message };
    setToasts(prev => [...prev, newToast]);
    
    // Auto remove after 4 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(toast => toast.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  // Function to add logs to progress
  const addProgressLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString('vi-VN', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    })
    const logEntry = `[${timestamp}] ${message}`
    
    setProgressLogs(prev => {
      const newLogs = [...prev, logEntry]
      // Keep only last 100 logs to prevent memory issues
      return newLogs.slice(-100)
    })
    
    // Auto scroll to bottom
    setTimeout(() => {
      if (progressLogsRef.current) {
        progressLogsRef.current.scrollTop = progressLogsRef.current.scrollHeight
      }
    }, 100)
  }

  // Function to add real-time status log
  const addStatusLog = useCallback(async (accountId: string, status: 'running' | 'success' | 'error' | 'waiting' | 'completed', message: string, details?: string, progress?: number) => {
    const statusLogRef = statusLogRefsRef.current.get(accountId)
    if (statusLogRef) {
      statusLogRef.addLog(status, message, details, progress)
      
      // Force refresh logs from database to ensure real-time updates
      try {
        await statusLogRef.forceRefresh()
          } catch (error) {
      // Handle error silently
    }
    }
    
    // Also add to progress logs
    const account = accounts.find(acc => acc._id === accountId)
    if (account) {
      addProgressLog(`[${account.email}] ${message}`)
    }
  }, [accounts])

  // Function to register status log ref
  const registerStatusLogRef = useCallback((accountId: string, ref: RealTimeStatusLogRef) => {
    if (ref && !statusLogRefsRef.current.has(accountId)) {
      statusLogRefsRef.current.set(accountId, ref)
      // Only update state if we need to trigger a re-render
      setStatusLogRefs(prev => new Map(statusLogRefsRef.current))
    }
  }, [])

  // Function to clear status logs for an account
  const clearStatusLogs = (accountId: string) => {
    const statusLogRef = statusLogRefsRef.current.get(accountId)
    if (statusLogRef) {
      statusLogRef.clearLogs()
    }
  }

  // Context menu handlers
  const handleContextMenu = (e: React.MouseEvent, accountId?: string) => {
    e.preventDefault()
    setContextMenu({
      visible: true,
      x: e.clientX,
      y: e.clientY,
      accountId
    })
  }

  const handleContextMenuClose = () => {
    setContextMenu({
      visible: false,
      x: 0,
      y: 0
    })
  }

  const handleCopyAccount = (type: string) => {
    if (!contextMenu.accountId) return
    
    const account = accounts.find(acc => acc._id === contextMenu.accountId)
    if (!account) return

    let textToCopy = ''
    switch (type) {
      case 'email':
        textToCopy = account.email
        break
      case 'password':
        textToCopy = account.password || 'N/A'
        break
      case '2fa':
        textToCopy = account.twofa || 'N/A'
        break
      case 'full':
        textToCopy = `${account.email}|${account.password || 'N/A'}|${account.twofa || 'N/A'}`
        break
      default:
        return
    }

    navigator.clipboard.writeText(textToCopy)
    showToast('success', 'Thành công', `Đã copy ${type.toUpperCase()} vào clipboard`)
    handleContextMenuClose()
  }

  // Copy selected accounts
  const handleCopySelectedAccounts = (type: string) => {
    if (selectedAccounts.length === 0) {
      showToast('warning', 'Cảnh báo', 'Không có tài khoản nào được chọn!')
      return
    }

    const selectedAccountsData = selectedAccounts.map(accountId => {
      const account = accounts.find(acc => acc._id === accountId)
      if (!account) return null
      
      switch (type) {
        case 'email':
          return account.email
        case 'password':
          return account.password || 'N/A'
        case '2fa':
          return account.twofa || 'N/A'
        case 'full':
          return `${account.email}|${account.password || 'N/A'}|${account.twofa || 'N/A'}`
        default:
          return null
      }
    }).filter(Boolean)

    if (selectedAccountsData.length === 0) {
      showToast('error', 'Lỗi', 'Không có dữ liệu để copy!')
      return
    }

    const textToCopy = selectedAccountsData.join('\n')
    navigator.clipboard.writeText(textToCopy)
    showToast('success', 'Thành công', `Đã copy ${type.toUpperCase()} của ${selectedAccountsData.length} tài khoản đã chọn vào clipboard`)
  }

  const handleContextMenuSelect = (accountId: string) => {
    if (selectedAccounts.includes(accountId)) {
      setSelectedAccounts(selectedAccounts.filter(id => id !== accountId))
    } else {
      setSelectedAccounts([...selectedAccounts, accountId])
    }
    handleContextMenuClose()
  }

  const handleContextMenuDelete = async (accountId: string) => {
    try {
      const response = await fetch(`/api/outlook-accounts?id=${accountId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const deletedAccount = accounts.find(acc => acc._id === accountId)
        setAccounts(accounts.filter(account => account._id !== accountId))
        setSelectedAccounts(selectedAccounts.filter(id => id !== accountId))
        showToast('success', 'Thành công', 'Đã xóa tài khoản thành công!')
        addProgressLog(`🗑️ Đã xóa tài khoản ${deletedAccount?.email || 'Unknown'}`)
      } else {
        showToast('error', 'Lỗi', 'Không thể xóa tài khoản. Vui lòng thử lại!')
      }
    } catch (error) {
      showToast('error', 'Lỗi', 'Không thể xóa tài khoản. Vui lòng thử lại!')
    }
    handleContextMenuClose()
  }

  const handleDeselectAll = () => {
    setSelectedAccounts([])
    handleContextMenuClose()
  }

  const handleHighlightAccount = (accountId: string) => {
    if (highlightedAccounts.includes(accountId)) {
      setHighlightedAccounts(prev => prev.filter(id => id !== accountId))
    } else {
      setHighlightedAccounts(prev => [...prev, accountId])
    }
  }

  const handleSelectHighlighted = () => {
    setSelectedAccounts(prev => {
      const uniqueAccounts = [...prev, ...highlightedAccounts].filter((id, index, array) => array.indexOf(id) === index)
      return uniqueAccounts
    })
    handleContextMenuClose()
  }

  // Load Facebook accounts
  const loadFacebookAccounts = async () => {
    try {
      const response = await fetch('/api/facebook-accounts', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const result = await response.json()
        const accountsArray = Array.isArray(result)
          ? result
          : Array.isArray(result?.data)
            ? result.data
            : Array.isArray(result?.accounts)
              ? result.accounts
              : Array.isArray(result?.savedAccounts)
                ? result.savedAccounts
                : []
        setFacebookAccounts(accountsArray)
      }
    } catch (error) {
      // Handle error silently
    }
  }

  // Get Facebook account info for Outlook account
  const getFacebookAccountInfo = (outlookEmail: string) => {
    if (!showFacebookInfo || !facebookAccounts.length) return null
    
    // Tìm tài khoản Facebook có email trùng với Outlook
    const facebookAccount = facebookAccounts.find(fb => 
      fb.mail && fb.mail.toLowerCase() === outlookEmail.toLowerCase()
    )
    
    return facebookAccount
  }

  // Login Outlook using Facebook mail/passmail of the matched account
  const handleLoginWithFacebookCreds = async (accountId: string) => {
    try {
      const account = accounts.find(acc => acc._id === accountId)
      if (!account) {
        showToast('error', 'Lỗi', 'Không tìm thấy tài khoản Outlook')
        return
      }

      const fb = getFacebookAccountInfo(account.email)
      if (!fb || !fb.mail || !fb.passmail) {
        showToast('warning', 'Thiếu thông tin', 'Không tìm thấy email/passmail Facebook tương ứng')
        return
      }

      addProgressLog(`🚀 Đăng nhập bằng thông tin Facebook: ${fb.mail}`)
      addStatusLog(accountId, 'running', 'Đang đăng nhập bằng FB', 'Sử dụng email/passmail từ Facebook')

      const runId = currentRunIdRef.current || startRun()
      const response = await controlledFetch('/api/outlook/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: fb.mail,
          password: fb.passmail,
          proxy: account.proxy,
          runId
        })
      }, `login-${accountId}`)

      const data = await response.json()
      if (data.success) {
        showToast('success', 'Thành công', `Đăng nhập thành công cho ${fb.mail}`)
        addProgressLog(`✅ Đăng nhập bằng FB thành công: ${fb.mail}`)
        addStatusLog(accountId, 'success', 'Đăng nhập thành công', 'Đã nhận tokens từ Outlook')

        // Lưu tokens vào DB cho account hiện tại
        const updateResponse = await fetch('/api/outlook-accounts', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            accountId,
            access_token: data.data?.access_token,
            refresh_token: data.data?.refresh_token,
            expires_in: data.data?.expires_in,
            status: 'active'
          })
        })

        if (updateResponse.ok) {
          addProgressLog('💾 Đã lưu tokens mới vào database')
          addStatusLog(accountId, 'completed', 'Đã lưu tokens', 'Tokens đã được cập nhật')
        }

        loadAccounts()
      } else {
        showToast('error', 'Lỗi', data.message || 'Đăng nhập thất bại')
        addProgressLog(`❌ Đăng nhập bằng FB thất bại: ${data.message || 'Unknown'}`)
        addStatusLog(accountId, 'error', 'Đăng nhập thất bại', data.message || 'Không thể xác thực')
      }
    } catch (error) {
      showToast('error', 'Lỗi', 'Lỗi kết nối server')
      // accountId might not exist if earlier failed; guard it
    }
  }

  // Function to handle bulk delete confirmation
  const handleBulkDeleteConfirm = async () => {
    try {
      // Hiển thị loading state
      showToast('info', 'Đang xử lý', 'Đang xóa tài khoản...')
      
      // Xóa tất cả tài khoản đã chọn từ database TRƯỚC
      const deletePromises = accountsToDelete.map(async ({ id, email }) => {
        try {
          const response = await fetch(`/api/outlook-accounts?id=${id}`, {
            method: 'DELETE',
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          })
          
          if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`)
          }
          
          return { success: true, id, email }
        } catch (error) {
          return { success: false, id, email, error: error.message }
        }
      })
      
      // Đợi tất cả operations hoàn thành
      const results = await Promise.all(deletePromises)
      
      // Phân loại kết quả
      const successfulDeletes = results.filter(r => r.success)
      const failedDeletes = results.filter(r => !r.success)
      
      if (successfulDeletes.length > 0) {
        // Xóa khỏi local state chỉ những tài khoản đã xóa thành công
        setAccounts(prev => prev.filter(acc => 
          !successfulDeletes.some(deleted => deleted.id === acc._id)
        ))
        
        // Hiển thị thông báo thành công
        showToast('success', 'Thành công', `Đã xóa ${successfulDeletes.length} tài khoản`)
        addProgressLog(`🗑️ Đã xóa ${successfulDeletes.length} tài khoản: ${successfulDeletes.map(a => a.email).join(', ')}`)
      }
      
      if (failedDeletes.length > 0) {
        // Hiển thị thông báo lỗi cho những tài khoản xóa thất bại
        failedDeletes.forEach(({ email, error }) => {
          showToast('error', 'Lỗi', `Không thể xóa tài khoản ${email}: ${error}`)
        })
        addProgressLog(`❌ Xóa thất bại ${failedDeletes.length} tài khoản: ${failedDeletes.map(a => a.email).join(', ')}`)
      }
      
      // Clear selection và đóng modal
      setSelectedAccounts([])
      setShowDeleteConfirm(false)
      setAccountsToDelete([])
      
    } catch (error) {
      showToast('error', 'Lỗi', 'Có lỗi xảy ra khi xóa tài khoản')
      addProgressLog(`❌ Lỗi xóa hàng loạt: ${error.message}`)
    }
  }



  // Save settings to localStorage
  const saveSettings = () => {
    try {
      const settings = {
        mailReadMethod,
        imapSettings,
        maxEmailsPerRead,
        timeoutSeconds,
        imapTimeoutSeconds,
        scrapingSettings,
        maxThreads,
        proxySettings: {
          ...proxySettings,
          lastDatabaseCheck: Date.now() // Update timestamp when saving
        }
      }
      localStorage.setItem('outlook_settings', JSON.stringify(settings))
      showToast('success', 'Thành công', 'Đã lưu cài đặt')
      addProgressLog('💾 Đã lưu cài đặt vào localStorage')
    } catch (error) {
      showToast('error', 'Lỗi', 'Không thể lưu cài đặt')
      addProgressLog('❌ Lỗi lưu cài đặt')
    }
  }

  // Load available proxies
  const loadAvailableProxies = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) {
        setAvailableProxies([])
        return
      }

      const response = await fetch('/api/proxy/available', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setAvailableProxies(data.availableProxies || [])
        addProgressLog(`🌐 Tải được ${data.availableProxies?.length || 0} proxy servers`)
      } else {
        setAvailableProxies([])
      }
    } catch (error) {
      setAvailableProxies([])
    }
  }

  // Get specific proxy server
  const getProxyServer = async (proxyId: string) => {
    try {
      const token = localStorage.getItem('token')
      if (!token || !proxyId) {
        return ''
      }

      addProgressLog(`🔍 Đang gọi API lấy proxy server cho ID: ${proxyId}`)

      const response = await fetch('/api/proxy/get-proxy', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ proxyId })
      })

      if (response.ok) {
        const data = await response.json()
        const proxyServer = data.proxy || data.server || ''
        addProgressLog(`📡 API trả về proxy server: ${proxyServer || 'Không có'}`)
        return proxyServer
      } else {
        const errorText = await response.text()
        addProgressLog(`❌ API lỗi (${response.status}): ${errorText}`)
        return ''
      }
    } catch (error) {
      addProgressLog(`❌ Lỗi kết nối API proxy: ${error}`)
      return ''
    }
  }

  // Chỉ lấy IP từ database - không refresh/reset

  // Check proxy IP from database
  const checkProxyIPFromDatabase = async (proxyId: string) => {
    try {
      const token = localStorage.getItem('token')
      if (!token || !proxyId) {
        return null
      }

      addProgressLog(`🔍 Đang kiểm tra IP proxy từ database cho ID: ${proxyId}`)

      const response = await fetch('/api/proxy/get-proxy', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ proxyId, checkDatabase: true })
      })

      if (response.ok) {
        const data = await response.json()
        const databaseIP = data.databaseIP || data.proxy || ''
        addProgressLog(`📊 Database trả về IP: ${databaseIP || 'Không có'}`)
        return databaseIP
      } else {
        const errorText = await response.text()
        addProgressLog(`❌ API database lỗi (${response.status}): ${errorText}`)
        return null
      }
    } catch (error) {
      addProgressLog(`❌ Lỗi kết nối database: ${error}`)
      return null
    }
  }

  // Update proxy IP from database if changed
  const updateProxyIPFromDatabase = async () => {
    if (!proxySettings.selectedProxyId) return

    const now = Date.now()
    const minInterval = 10000 // Minimum 10 seconds between database checks
    
    if (now - proxySettings.lastDatabaseCheck < minInterval) {
      return // Skip if checked too recently
    }

    try {
      const databaseIP = await checkProxyIPFromDatabase(proxySettings.selectedProxyId)
      if (databaseIP && databaseIP !== proxySettings.databaseIP) {
        // IP changed in database, update UI
        setProxySettings(prev => ({ 
          ...prev, 
          databaseIP,
          lastDatabaseCheck: now,
          server: databaseIP // Update current server IP
        }))
        addProgressLog(`🔄 IP proxy đã thay đổi trong database: ${databaseIP}`)
      } else if (databaseIP) {
        // Update last check time even if IP didn't change
        setProxySettings(prev => ({ 
          ...prev, 
          lastDatabaseCheck: now 
        }))
      }
    } catch (error) {
      // Handle error silently
    }
  }

  // Safe Auto Refresh Utilities
    // Chỉ lấy IP từ database - không refresh/reset

  // Load user subscription info
  const loadUserSubscription = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) {
        setUserMaxThreads(2)
        setUserPlan('free')
        return
      }

      const response = await fetch('/api/subscription/user', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setUserMaxThreads(data.maxThreads || 2)
        setUserPlan(data.plan || 'free')
        setSubscriptionDaysLeft(data.daysLeft || 30)
        
        // Điều chỉnh maxThreads nếu vượt quá giới hạn
        if (maxThreads > data.maxThreads) {
          setMaxThreads(data.maxThreads)
        }
        
        addProgressLog(`📋 Gói hiện tại: ${data.plan?.toUpperCase()} - Giới hạn: ${data.maxThreads} luồng - Còn lại: ${data.daysLeft || 30} ngày`)
      } else {
        setUserMaxThreads(2)
        setUserPlan('free')
      }
    } catch (error) {
      setUserMaxThreads(2)
      setUserPlan('free')
    }
  }

  // Load settings from localStorage
  const loadSettings = () => {
    try {
      const stored = localStorage.getItem('outlook_settings')
      if (stored) {
        const settings = JSON.parse(stored)
        setMailReadMethod(settings.mailReadMethod || 'rest')
        setImapSettings(settings.imapSettings || {
          host: 'outlook.office365.com',
          port: 993,
          secure: true
        })
        setMaxEmailsPerRead(settings.maxEmailsPerRead || 10)
        setTimeoutSeconds(settings.timeoutSeconds || 30)
        setImapTimeoutSeconds(settings.imapTimeoutSeconds || 90)
        setScrapingSettings(settings.scrapingSettings || {
          headless: true,
          timeout: 120,
          waitForLoad: 5000,
          debugMode: false
        })
        setMaxThreads(settings.maxThreads || 3)
        setProxySettings(settings.proxySettings || {
          enabled: false,
          server: '',
          selectedProxyId: '',
          useForAll: false,
          databaseIP: '',
          lastDatabaseCheck: 0
        })
        
        // If we have a selected proxy, check database IP
        if (settings.proxySettings?.selectedProxyId) {
          setTimeout(() => {
            updateProxyIPFromDatabase()
          }, 1000) // Delay to ensure component is fully mounted
        }
        addProgressLog('📂 Đã tải cài đặt từ localStorage')
      }
    } catch (error) {
      addProgressLog('❌ Lỗi tải cài đặt, sử dụng mặc định')
    }
  }

  // Reset settings to default
  const resetSettings = () => {
    setMailReadMethod('outlook')
    setImapSettings({
      host: 'outlook.office365.com',
      port: 993,
      secure: true
    })
    setMaxEmailsPerRead(10)
    setTimeoutSeconds(30)
    setImapTimeoutSeconds(90)
    setScrapingSettings({
      headless: true,
      timeout: 120,
      waitForLoad: 5000,
      debugMode: false
    })
    setMaxThreads(3)
    setProxySettings({
      enabled: false,
      server: '',
      selectedProxyId: '',
      useForAll: false,
      databaseIP: '',
      lastDatabaseCheck: 0
    })
    showToast('info', 'Thông báo', 'Đã reset về cài đặt mặc định')
    addProgressLog('🔄 Đã reset cài đặt về mặc định')
  }

  // Check authentication
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('/api/auth/check')
        if (response.ok) {
          const userData = await response.json()
          setUser(userData.user)
        } else {
          router.push('/auth')
          return
        }
      } catch (error) {
        router.push('/auth')
        return
      }
      setLoading(false)
    }

    checkAuth()
  }, [router])

  // Load Facebook accounts when component mounts
  useEffect(() => {
    if (showFacebookInfo) {
      loadFacebookAccounts()
    }
  }, [showFacebookInfo])

  // Load saved account statuses from localStorage
  const loadSavedAccountStatuses = () => {
    try {
      accounts.forEach(account => {
        const storageKey = `outlook_account_status_${account._id}`
        const savedStatus = localStorage.getItem(storageKey)
        if (savedStatus) {
          const statusData = JSON.parse(savedStatus)
          
          // Update account with saved status
          setAccounts(prev => prev.map(acc => 
            acc._id === account._id 
              ? { 
                  ...acc, 
                  status: statusData.status,
                  lastUpdated: statusData.lastUpdated,
                  lastLogin: statusData.lastLogin,
                  lastMailCheck: statusData.lastMailCheck,
                  errorMessage: statusData.errorMessage,
                  lastError: statusData.lastError
                }
              : acc
          ))
        }
      })
    } catch (error) {
      // Handle error silently
    }
  }

  // Clear saved account statuses from localStorage
  const clearSavedAccountStatuses = () => {
    try {
      accounts.forEach(account => {
        const storageKey = `outlook_account_status_${account._id}`
        localStorage.removeItem(storageKey)
      })

      
      // Reload accounts to reset to default statuses
      loadAccounts()
    } catch (error) {
      // Handle error silently
    }
  }

  // Load accounts and restore saved statuses
  const loadAccounts = async () => {
    try {
      addProgressLog('Đang tải danh sách tài khoản Outlook...')
      const response = await fetch('/api/outlook-accounts')
      if (response.ok) {
        const data = await response.json()
        setAccounts(data.data || [])
        addProgressLog(`Đã tải ${data.data?.length || 0} tài khoản Outlook`)
        
        // Clean up old refs that are no longer needed
        const currentAccountIds = new Set(data.data?.map((acc: any) => acc._id) || [])
        statusLogRefsRef.current.forEach((ref, accountId) => {
          if (!currentAccountIds.has(accountId)) {
            statusLogRefsRef.current.delete(accountId)
          }
        })
        
        // Restore saved statuses after loading accounts
        setTimeout(() => {
          loadSavedAccountStatuses()
        }, 100)
      } else {
        throw new Error('Failed to load accounts')
      }
    } catch (error) {
      showToast('error', 'Lỗi', 'Không thể tải danh sách tài khoản')
      addProgressLog('❌ Lỗi tải danh sách tài khoản')
    }
  }

  useEffect(() => {
    if (user) {
      loadAccounts()
    }
  }, [user])

  // Load settings on component mount
  useEffect(() => {
    loadSettings()
    loadUserSubscription()
    loadAvailableProxies()
  }, [])

  // Monitor database IP changes effect
  useEffect(() => {
    if (!proxySettings.selectedProxyId) return

    // Check database IP immediately when proxy is selected
    updateProxyIPFromDatabase()

    // Set up interval to check database IP changes
    const databaseCheckInterval = setInterval(() => {
      updateProxyIPFromDatabase()
    }, 30000) // Check every 30 seconds

    return () => {
      clearInterval(databaseCheckInterval)
    }
  }, [proxySettings.selectedProxyId])

  // Cleanup effect for status log refs
  useEffect(() => {
    return () => {
      // Clean up all refs when component unmounts
      statusLogRefsRef.current.clear()
    }
  }, [])



  // Handle bulk import
  const handleBulkImport = async () => {
    if (!bulkAccountsText.trim()) {
      showToast('warning', 'Cảnh báo', 'Vui lòng nhập danh sách tài khoản')
      return
    }

    // Parse accounts from text (format: email:password or email|password|refresh_token|client_id)
    const lines = bulkAccountsText.trim().split('\n')
    const accountsToAdd: BulkAccount[] = []
    
    for (const line of lines) {
      const trimmedLine = line.trim()
      if (!trimmedLine) continue
      
      const parts = trimmedLine.split(/[:|]/)
      if (parts.length >= 2) {
        const account: BulkAccount = {
          email: parts[0].trim(),
          password: parts[1].trim()
        }
        
        // If refresh_token and client_id are provided
        if (parts.length >= 4) {
          account.refreshToken = parts[2].trim()
          account.clientId = parts[3].trim()
        }
        
        accountsToAdd.push(account)
      }
    }

    if (accountsToAdd.length === 0) {
      showToast('warning', 'Cảnh báo', 'Không tìm thấy tài khoản hợp lệ. Định dạng: email|password hoặc email|password|refresh_token|client_id')
      return
    }

    setBulkImporting(true)
    setBulkProgress({ current: 0, total: accountsToAdd.length })
    addProgressLog(`Bắt đầu import ${accountsToAdd.length} tài khoản...`)

    const importCounters = { success: 0, error: 0 }

    for (let i = 0; i < accountsToAdd.length; i++) {
      const account = accountsToAdd[i]
      setBulkProgress({ current: i + 1, total: accountsToAdd.length })
      const hasTokens = account.refreshToken && account.clientId
      addProgressLog(`[${i + 1}/${accountsToAdd.length}] Đang thêm: ${account.email}${hasTokens ? ' (có refresh token)' : ''}`)

      try {
        const requestBody: any = {
          email: account.email,
          password: account.password,
          proxy: bulkProxy || null,
          skipValidation: true // Skip login validation for bulk import
        }
        
        // Add refresh_token and client_id if provided
        if (account.refreshToken) {
          requestBody.refreshToken = account.refreshToken
        }
        if (account.clientId) {
          requestBody.clientId = account.clientId
        }

        const response = await fetch('/api/outlook-accounts', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        })

        const data = await response.json()

        if (data.success) {
          importCounters.success++
          addProgressLog(`✅ [${i + 1}/${accountsToAdd.length}] Thành công: ${account.email}`)
        } else {
          importCounters.error++
          // Check different error types
          if (data.message && data.message.includes('đã tồn tại')) {
            addProgressLog(`⚠️ [${i + 1}/${accountsToAdd.length}] Đã tồn tại: ${account.email}`)
          } else if (data.message && data.message.includes('server đang bảo trì')) {
            addProgressLog(`🔄 [${i + 1}/${accountsToAdd.length}] Server bảo trì: ${account.email} - Sẽ thử lại sau`)
          } else if (data.message && data.message.includes('server đang gặp sự cố')) {
            addProgressLog(`🛠️ [${i + 1}/${accountsToAdd.length}] Server lỗi: ${account.email} - Tạm thời bỏ qua`)
          } else if (data.message && data.message.includes('không chính xác')) {
            addProgressLog(`🔐 [${i + 1}/${accountsToAdd.length}] Sai thông tin: ${account.email}`)
          } else {
            addProgressLog(`❌ [${i + 1}/${accountsToAdd.length}] Lỗi: ${account.email} - ${data.message}`)
          }
        }
      } catch (error) {
        importCounters.error++
        addProgressLog(`❌ [${i + 1}/${accountsToAdd.length}] Lỗi kết nối: ${account.email}`)
      }

      // Small delay to prevent overwhelming the server
      await new Promise(resolve => setTimeout(resolve, 100))
    }

    setBulkImporting(false)
    setBulkProgress({ current: 0, total: 0 })
    
    showToast('info', 'Hoàn thành', `Import hoàn thành: ${importCounters.success} thành công, ${importCounters.error} lỗi`)
    addProgressLog(`🎉 Import hoàn thành: ${importCounters.success} thành công, ${importCounters.error} lỗi`)
    
    setBulkAccountsText('')
    setBulkProxy('')
    setShowBulkImportModal(false)
    loadAccounts()
  }

  // Handle delete account
  const handleDeleteAccount = async (accountId: string, email: string) => {
    if (!confirm(`Bạn có chắc muốn xóa tài khoản ${email}?`)) {
      return
    }

    addProgressLog(`Đang xóa tài khoản: ${email}`)

    try {
      const response = await fetch(`/api/outlook-accounts?id=${accountId}`, {
        method: 'DELETE',
      })

      const data = await response.json()

      if (data.success) {
        showToast('success', 'Thành công', 'Xóa tài khoản thành công')
        addProgressLog(`✅ Xóa tài khoản thành công: ${email}`)
        loadAccounts()
      } else {
        showToast('error', 'Lỗi', data.message || 'Không thể xóa tài khoản')
        addProgressLog(`❌ Lỗi xóa tài khoản: ${data.message}`)
      }
    } catch (error) {
      showToast('error', 'Lỗi', 'Lỗi kết nối server')
      addProgressLog('❌ Lỗi kết nối server')
    }
  }

  // Handle direct login (skip test steps)
  const handleTestLogin = async (accountId: string, email: string) => {
    addProgressLog(`🚀 Đang đăng nhập trực tiếp : ${email}`)
    
    // Add real-time status log
    addStatusLog(accountId, 'running', 'Đang đăng nhập trực tiếp...', 'Bắt đầu quá trình đăng nhập')

    try {
      // Get account details first
      const account = accounts.find(acc => acc._id === accountId)
      if (!account) {
        addProgressLog(`❌ Không tìm thấy tài khoản: ${email}`)
        addStatusLog(accountId, 'error', 'Không tìm thấy tài khoản', 'Tài khoản không tồn tại trong hệ thống')
        showToast('error', 'Lỗi', 'Không tìm thấy tài khoản')
        return
      }

      // Call direct login API (skip test)
      const response = await fetch('/api/outlook/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: account.email,
          password: account.password,
          proxy: account.proxy
        }),
      })

      const data = await response.json()

      if (data.success) {
        showToast('success', 'Thành công', `Đăng nhập trực tiếp thành công cho ${email}`)
        addProgressLog(`✅ Đăng nhập trực tiếp thành công: ${email}`)
        addStatusLog(accountId, 'success', 'Đăng nhập thành công', 'Đã lấy được access token và refresh token')
        
        // Update account in database with new tokens
        const updateResponse = await fetch('/api/outlook-accounts', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            accountId: accountId,
            access_token: data.data.access_token,
            refresh_token: data.data.refresh_token,
            expires_in: data.data.expires_in,
            status: 'active'
          }),
        })

        if (updateResponse.ok) {
          addProgressLog(`💾 Đã lưu tokens mới vào database`)
          addStatusLog(accountId, 'completed', 'Đã lưu tokens', 'Tokens đã được cập nhật')
        }
        
        loadAccounts()
      } else {
        showToast('error', 'Lỗi', data.message || 'Đăng nhập thất bại')
        addProgressLog(`❌ Đăng nhập trực tiếp thất bại: ${data.message}`)
        addStatusLog(accountId, 'error', 'Đăng nhập thất bại', data.message || 'Không thể xác thực tài khoản')
      }
    } catch (error) {
      showToast('error', 'Lỗi', 'Lỗi kết nối server')
      addProgressLog('❌ Lỗi kết nối server')
      addStatusLog(accountId, 'error', 'Lỗi kết nối', 'Không thể kết nối đến server')
    }
  }

  // Handle refresh token
  const handleRefreshToken = async (accountId: string, email: string) => {
    addProgressLog(`Đang refresh token: ${email}`)

    try {
      const response = await fetch('/api/outlook/refresh-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          accountId: accountId,
        }),
      })

      const data = await response.json()

      if (data.success) {
        showToast('success', 'Thành công', `Refresh token thành công: ${email}`)
        addProgressLog(`✅ Refresh token thành công: ${email}`)
        loadAccounts()
      } else {
        showToast('error', 'Lỗi', `Refresh token thất bại: ${data.message}`)
        addProgressLog(`❌ Refresh token thất bại: ${email} - ${data.message}`)
      }
    } catch (error) {
      showToast('error', 'Lỗi', 'Lỗi kết nối server')
      addProgressLog('❌ Lỗi kết nối server')
    }
  }

  // Handle read mail (direct, no test)
  const handleReadMail = async () => {
    if (!selectedAccountForMail) return

    const account = accounts.find(acc => acc._id === selectedAccountForMail)
    if (!account) return

    const runId = startRun()
    setReadingMail(true)
    addProgressLog(`🚀 Đang đọc mail trực tiếp (bỏ qua test): ${account.email}`)
    addProgressLog(`⚡ Sử dụng stored tokens hoặc auto-refresh...`)

    // Update status to reading
    updateAccountStatusDuringOperation(selectedAccountForMail, 'reading')

    try {
      let mailResponse: Response
      
      // Choose API based on selected method
      if (mailReadMethod === 'outlook') {
        // Use new ftool.vn API
        addProgressLog(`📧 Sử dụng ftool.vn API cho: ${account.email}`)
        mailResponse = await controlledFetch('/api/outlook/emails', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: account.email,
            password: account.password,
            count: 50,
            keyword: filterSender || '',
            runId
          }),
        }, `read-${account._id}`)
      } else {
        // Use old API for IMAP/Scraping
        mailResponse = await controlledFetch('/api/outlook/read-mail', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            accountId: selectedAccountForMail,
            directRead: true, // Skip test, use stored tokens
            filter_sender: filterSender || null,
            minutes: filterMinutes ? parseInt(filterMinutes) : null
          }),
        }, `read-${selectedAccountForMail}`)
      }

      const mailData = await mailResponse.json()

      if (mailData.success) {
        let emails = []
        
        if (mailReadMethod === 'outlook') {
          // ftool.vn API response format - try multiple possible structures
          
          // Try to extract emails from various possible locations
          if (mailData.data?.emails && Array.isArray(mailData.data.emails)) {
            emails = mailData.data.emails
          } else if (mailData.data?.messages && Array.isArray(mailData.data.messages)) {
            emails = mailData.data.messages
          } else if (mailData.data?.data && mailData.data.data.messages && Array.isArray(mailData.data.data.messages)) {
            // ftool.vn API nested structure: data.data.messages
            emails = mailData.data.data.messages
          } else if (mailData.data?.data && mailData.data.data.emails && Array.isArray(mailData.data.data.emails)) {
            // ftool.vn API nested structure: data.data.emails
            emails = mailData.data.data.emails
          } else if (Array.isArray(mailData.data)) {
            emails = mailData.data
          }
        } else {
          // Old API response format
          emails = mailData.data.emails || []
        }
        
        setMailResults(emails)
        
        // Save emails to localStorage
        if (emails.length > 0) {
          saveEmailsToStorage(account.email, emails)
        }
        
        // Update status to success
        updateAccountStatusDuringOperation(selectedAccountForMail, 'success', emails.length)
        
        showToast('success', 'Thành công', `Đọc được ${emails.length} email`)
        addProgressLog(`✅ Đọc mail qua ${mailReadMethod === 'outlook' ? 'ftool.vn API' : 'Outlook API'} thành công: ${emails.length} email`)
      } else if (mailData.error_type === 'token_expired' || mailData.needs_reauth) {
        addProgressLog(`🔑 Token hết hạn, đang thử đăng nhập lại...`)
        
        // Update status to error (needs reauth)
        updateAccountStatusDuringOperation(selectedAccountForMail, 'error')
        
        // Try direct login if token expired
        const loginResponse = await fetch('/api/outlook/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: account.email,
            password: account.password,
            proxy: account.proxy
          }),
        })

        const loginData = await loginResponse.json()
        if (loginData.success) {
          // Update tokens and retry mail read
          await fetch('/api/outlook-accounts', {
            method: 'PUT',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              accountId: selectedAccountForMail,
              access_token: loginData.data.access_token,
              refresh_token: loginData.data.refresh_token,
              expires_in: loginData.data.expires_in,
              status: 'active'
            }),
          })

          addProgressLog(`✅ Đăng nhập lại thành công, đang đọc mail...`)
          
          // Retry mail read with new token
          const retryMailResponse = await fetch('/api/outlook/read-mail', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              access_token: loginData.data.access_token,
              filter_sender: filterSender || null,
              minutes: filterMinutes ? parseInt(filterMinutes) : null
            }),
          })

          const retryMailData = await retryMailResponse.json()
          if (retryMailData.success) {
            const emails = retryMailData.data.emails || []
            setMailResults(emails)
            
            // Save emails to localStorage
            if (emails.length > 0) {
              saveEmailsToStorage(account.email, emails)
            }
            
            // Update status to success after retry
            updateAccountStatusDuringOperation(selectedAccountForMail, 'success', emails.length)
            
            showToast('success', 'Thành công', `Đọc được ${emails.length} email`)
            addProgressLog(`✅ Đọc mail sau đăng nhập lại thành công: ${emails.length} email`)
          } else {
            // Update status to error after retry failure
            updateAccountStatusDuringOperation(selectedAccountForMail, 'error')
            throw new Error(retryMailData.message)
          }
        } else {
          // Update status to error after login failure
          updateAccountStatusDuringOperation(selectedAccountForMail, 'error')
          throw new Error(`Đăng nhập lại thất bại: ${loginData.message}`)
        }
      } else {
        // Update status to error
        updateAccountStatusDuringOperation(selectedAccountForMail, 'error')
        showToast('error', 'Lỗi', mailData.message || 'Không thể đọc mail')
        addProgressLog(`❌ Lỗi đọc mail: ${mailData.message}`)
        setMailResults([])
      }
    } catch (error) {
      // Update status to error
      updateAccountStatusDuringOperation(selectedAccountForMail, 'error')
      showToast('error', 'Lỗi', 'Lỗi kết nối server')
      addProgressLog('❌ Lỗi kết nối server')
      setMailResults([])
    } finally {
      setReadingMail(false)
      // Update status to completed
      updateAccountStatusDuringOperation(selectedAccountForMail, 'completed')
      setIsRunning(false)
    }
  }

  // Handle bulk read mail (no test, direct read)
  const handleReadMailBulk = async () => {
    if (selectedAccounts.length === 0) return

    const selectedAccountsList = accounts.filter(acc => selectedAccounts.includes(acc._id))
    const methodText = mailReadMethod === 'outlook' ? 'ftool.vn API' : 
                      mailReadMethod === 'imap' ? 'IMAP' : 'Web Scraping'
    const timeoutText = mailReadMethod === 'imap' ? ` (timeout: ${imapTimeoutSeconds}s)` : 
                       mailReadMethod === 'scraping' ? ` (timeout: ${scrapingSettings.timeout}s)` : ''
    const proxyText = proxySettings.enabled ? ` | Proxy: ${proxySettings.server}` : ''
    addProgressLog(`🚀 Bắt đầu đọc mail từ ${selectedAccountsList.length} tài khoản qua ${methodText}${timeoutText}${proxyText}`)
    addProgressLog(`⚡ Sử dụng ${Math.min(maxThreads, userMaxThreads)} luồng xử lý đồng thời (Giới hạn gói ${userPlan.toUpperCase()}: ${userMaxThreads})`)

    const counters = { success: 0, error: 0, expired: 0 }

    // Process accounts in batches based on maxThreads
    const processAccount = async (account: any, index: number) => {
      const startTime = Date.now()
      addProgressLog(`[${index + 1}/${selectedAccountsList.length}] Đang đọc mail qua ${methodText}: ${account.email}`)

      // Update status to reading
      updateAccountStatusDuringOperation(account._id, 'reading')
      
      // Add real-time status log
      addStatusLog(account._id, 'running', `Đang đọc mail qua ${methodText}...`, `Bắt đầu đọc mail cho ${account.email}`)

      try {
        // Choose API endpoint based on method
        const apiEndpoint = mailReadMethod === 'outlook' ? '/api/outlook/emails' :
                           mailReadMethod === 'imap' ? '/api/outlook/read-mail-imap' :
                           '/api/outlook/read-mail-scraping'
        
        let requestBody: any = {}

        // Add method-specific settings
        if (mailReadMethod === 'outlook') {
          // Format for ftool.vn API - gửi email và password riêng biệt
          requestBody = {
            email: account.email,
            password: account.password,
            count: 50, // Default count
            keyword: '', // No keyword filter for bulk processing
            proxy: proxySettings.enabled && proxySettings.server ? {
              host: proxySettings.server
            } : null,
            runId: currentRunIdRef.current || undefined
          }
        } else if (mailReadMethod === 'imap') {
          requestBody = {
            accountId: account._id,
            filterSender: null,
            minutes: null,
            directRead: true,
            imapSettings: {
              ...imapSettings,
              timeout: imapTimeoutSeconds * 1000 // Convert to milliseconds
            }
          }
          // Add proxy settings if enabled
          if (proxySettings.enabled && proxySettings.server) {
            requestBody.proxySettings = proxySettings
          }
        } else if (mailReadMethod === 'scraping') {
          requestBody = {
            accountId: account._id,
            filterSender: null,
            minutes: null,
            directRead: true,
            scrapingSettings: scrapingSettings
          }
          // Add proxy settings if enabled
          if (proxySettings.enabled && proxySettings.server) {
            requestBody.proxySettings = proxySettings
          }
        }

        const response = await controlledFetch(apiEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        }, `bulk-${account._id}`)

        const data = await response.json()
        const duration = ((Date.now() - startTime) / 1000).toFixed(1)

        // Handle different response formats
        const isSuccess = mailReadMethod === 'outlook' ? data.success : data.success
        let emails = []
        
        if (mailReadMethod === 'outlook') {
          // ftool.vn API response format - try multiple possible structures
          if (data.data?.emails && Array.isArray(data.data.emails)) {
            emails = data.data.emails
          } else if (data.data?.messages && Array.isArray(data.data.messages)) {
            emails = data.data.messages
          } else if (data.data?.data && data.data.data.messages && Array.isArray(data.data.data.messages)) {
            // ftool.vn API nested structure: data.data.messages
            emails = data.data.data.messages
          } else if (data.data?.data && data.data.data.emails && Array.isArray(data.data.data.emails)) {
            // ftool.vn API nested structure: data.data.emails
            emails = data.data.data.emails
          } else if (Array.isArray(data.data)) {
            emails = data.data
          }
        } else {
          emails = data.emails || []
        }
        
        const errorMessage = mailReadMethod === 'outlook' ? data.error : data.error

        if (isSuccess) {
          counters.success++
          addProgressLog(`✅ [${index + 1}/${selectedAccountsList.length}] Thành công (${methodText}): ${account.email} - ${emails.length} emails (${duration}s)`)
          
          // Update status to success with email count
          updateAccountStatusDuringOperation(account._id, 'success', emails.length)
          
          // Add real-time status log for success
          addStatusLog(account._id, 'success', `Đọc được ${emails.length} email`, `Hoàn thành đọc mail qua ${methodText} trong ${duration}s`)
          
          // Save emails to localStorage
          if (emails.length > 0) {
            saveEmailsToStorage(account.email, emails)
            
            emails.slice(0, 3).forEach((email: any, index: number) => {
              const subject = email.subject || 'No subject'
              const sender = email.from || email.sender || 'Unknown sender'
              addProgressLog(`  📧 ${subject} - ${sender}`)
            })
            if (emails.length > 3) {
              addProgressLog(`  📧 ... và ${emails.length - 3} email khác`)
            }
          }
        } else {
          // Update status to error
          updateAccountStatusDuringOperation(account._id, 'error')
          
          // Add real-time status log for error
          addStatusLog(account._id, 'error', 'Đọc mail thất bại', `Lỗi khi đọc mail qua ${methodText}: ${data.message}`)
          
          // Check if IMAP failed
          const isImapAuthError = mailReadMethod === 'imap' && (
            data.message?.includes('Timed out while authenticating') ||
            data.message?.includes('Authentication failed') ||
            data.message?.includes('IMAP not enabled') ||
            data.message?.includes('IMAP4 disabled') ||
            data.error_type === 'imap_error'
          )

          if (isImapAuthError) {
            counters.error++
            addProgressLog(`❌ [${index + 1}/${selectedAccountsList.length}] IMAP authentication failed: ${account.email}`)
          } else {
            // Categorize different error types
            if (mailReadMethod === 'outlook' && errorMessage && (errorMessage.includes('Token') || errorMessage.includes('token') || errorMessage.includes('authentication'))) {
              counters.expired++
              addProgressLog(`🔑 [${index + 1}/${selectedAccountsList.length}] Token hết hạn: ${account.email} - Cần đăng nhập lại`)
            } else {
              counters.error++
              if (data.message && data.message.includes('IMAP not enabled')) {
                addProgressLog(`📧 [${index + 1}/${selectedAccountsList.length}] IMAP chưa bật: ${account.email}`)
              } else if (data.message && data.message.includes('Authentication failed')) {
                addProgressLog(`🔐 [${index + 1}/${selectedAccountsList.length}] Sai mật khẩu: ${account.email}`)
              } else if (data.message && data.message.includes('Puppeteer not installed')) {
                addProgressLog(`🤖 [${index + 1}/${selectedAccountsList.length}] Chưa cài Puppeteer: ${account.email}`)
              } else if (data.message && data.message.includes('Timeout after')) {
                addProgressLog(`⏱️ [${index + 1}/${selectedAccountsList.length}] Scraping timeout: ${account.email} - Tăng timeout trong settings`)
              } else if (data.message && data.message.includes('Failed to load Outlook page')) {
                addProgressLog(`🌐 [${index + 1}/${selectedAccountsList.length}] Không load được trang: ${account.email}`)
              } else if (data.message && data.message.includes('Microsoft có thể đã thay đổi format')) {
                addProgressLog(`🔧 [${index + 1}/${selectedAccountsList.length}] Lỗi format: ${account.email} - Microsoft đã thay đổi API`)
              } else if (data.message && data.message.includes('bị khóa')) {
                addProgressLog(`🔒 [${index + 1}/${selectedAccountsList.length}] Tài khoản bị khóa: ${account.email}`)
              } else if (data.message && data.message.includes('không tồn tại')) {
                addProgressLog(`👤 [${index + 1}/${selectedAccountsList.length}] Tài khoản không tồn tại: ${account.email}`)
              } else {
                let errorMsg = `❌ [${index + 1}/${selectedAccountsList.length}] Lỗi (${methodText}): ${account.email} - ${data.message}`
                
                // Add suggestions if available
                if (data.suggestions && data.suggestions.length > 0) {
                  errorMsg += ` | Gợi ý: ${data.suggestions.join(', ')}`
                }
                
                // Add specific error type info
                if (data.error_type) {
                  switch (data.error_type) {
                    case 'LOGIN_PAGE_CHANGED':
                      errorMsg += ' | 💡 Thử IMAP thay thế'
                      break
                    case 'TIMEOUT_ERROR':
                      errorMsg += ' | ⏱️ Tăng timeout trong Settings'
                      break
                    case 'NO_INTERNET':
                      errorMsg += ' | 🌐 Kiểm tra kết nối mạng'
                      break
                    case 'PUPPETEER_ERROR':
                      errorMsg += ' | 🤖 Khởi động lại ứng dụng'
                      break
                  }
                }
                
                addProgressLog(errorMsg)
              }
            }
          }
        }
      } catch (error) {
        counters.error++
        addProgressLog(`❌ [${index + 1}/${selectedAccountsList.length}] Lỗi kết nối (${methodText}): ${account.email}`)
        addStatusLog(account._id, 'error', 'Lỗi kết nối', `Không thể kết nối đến server: ${error}`)
      }
    }

    // Process accounts in batches using actual thread limit
    const actualMaxThreads = Math.min(maxThreads, userMaxThreads)
    for (let i = 0; i < selectedAccountsList.length; i += actualMaxThreads) {
      const batch = selectedAccountsList.slice(i, i + actualMaxThreads)
      const batchPromises = batch.map((account, batchIndex) => 
        processAccount(account, i + batchIndex)
      )
      
      // Wait for current batch to complete before starting next batch
      await Promise.all(batchPromises)
      
      // Small delay between batches
      if (i + actualMaxThreads < selectedAccountsList.length) {
        await new Promise(resolve => setTimeout(resolve, 1000))
      }
    }

    // Summary message
    let summaryParts: string[] = []
    if (counters.success > 0) summaryParts.push(`${counters.success} thành công`)
    if (counters.error > 0) summaryParts.push(`${counters.error} lỗi`)
    if (counters.expired > 0) summaryParts.push(`${counters.expired} token hết hạn`)
    
    // Update status for all processed accounts
    selectedAccounts.forEach(accountId => {
      const account = accounts.find(acc => acc._id === accountId)
      if (account) {
        updateAccountStatusDuringOperation(accountId, 'completed')
      }
    })
    
    const summaryMessage = summaryParts.join(', ')
    showToast('info', 'Hoàn thành', `Đọc mail qua ${methodText} hoàn thành: ${summaryMessage}`)
    addProgressLog(`🎉 Hoàn thành đọc mail qua ${methodText}: ${summaryMessage}`)
    
    if (mailReadMethod === 'outlook') {
      if (counters.error > 0) {
        addProgressLog(`💡 Gợi ý: ${counters.error} tài khoản Outlook API thất bại. Kiểm tra refresh token hoặc thử IMAP/Scraping.`)
      }
      addProgressLog(`🔧 Lưu ý: Outlook API cần refresh token hợp lệ. Nếu không có, hãy thử IMAP hoặc Web Scraping.`)
    } else if (mailReadMethod === 'imap') {
      if (counters.error > 0) {
        addProgressLog(`💡 Gợi ý: ${counters.error} tài khoản IMAP thất bại. Hãy thử Outlook API hoặc Web Scraping method.`)
      }
      addProgressLog(`🔧 Lưu ý: IMAP có thể không hoạt động với tài khoản Outlook mới. Outlook API hoặc Web Scraping có thể ổn định hơn.`)
    } else if (mailReadMethod === 'scraping') {
      if (counters.error > 0) {
        addProgressLog(`💡 Gợi ý: ${counters.error} tài khoản scraping thất bại. Thử tăng timeout hoặc tắt headless mode.`)
      }
      addProgressLog(`🤖 Lưu ý: Web scraping chậm hơn nhưng hoạt động khi API bị chặn.`)
    }
    
    setIsRunning(false)
    loadAccounts()
  }

  // Handle logout
  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' })
      router.push('/auth')
    } catch (error) {
      // Handle error silently
    }
  }

  // Save emails to localStorage
  const saveEmailsToStorage = (accountEmail: string, emails: any[]) => {
    try {
      const storageKey = `outlook_emails_${accountEmail}`
      const emailData = {
        accountEmail,
        emails,
        timestamp: new Date().toISOString(),
        count: emails.length
      }
      localStorage.setItem(storageKey, JSON.stringify(emailData))
      addProgressLog(`💾 Đã lưu ${emails.length} email vào localStorage cho ${accountEmail}`)
    } catch (error) {
      addProgressLog(`❌ Lỗi lưu email vào localStorage: ${error}`)
    }
  }

  // Load emails from localStorage for specific account
  const loadEmailsFromStorage = (accountEmail: string) => {
    try {
      const storageKey = `outlook_emails_${accountEmail}`
      const stored = localStorage.getItem(storageKey)
      if (stored) {
        const emailData = JSON.parse(stored)
        return emailData.emails || []
      }
      return []
    } catch (error) {
      return []
    }
  }

  // Delete emails from localStorage for specific account
  const deleteEmailsFromStorage = (accountEmail: string) => {
    try {
      const storageKey = `outlook_emails_${accountEmail}`
      localStorage.removeItem(storageKey)
      addProgressLog(`🗑️ Đã xóa email đã lưu cho ${accountEmail}`)
      return true
    } catch (error) {
      addProgressLog(`❌ Lỗi xóa email: ${error}`)
      return false
    }
  }

  // Handle delete stored emails with confirmation
  const handleDeleteStoredEmails = (accountEmail: string) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa tất cả email đã lưu cho ${accountEmail}?`)) {
      const success = deleteEmailsFromStorage(accountEmail)
      if (success) {
        setStoredEmails([])
        showToast('success', 'Thành công', 'Đã xóa email đã lưu')
      } else {
        showToast('error', 'Lỗi', 'Không thể xóa email')
      }
    }
  }

  // Delete specific email from localStorage
  const deleteSpecificEmailFromStorage = (accountEmail: string, emailIndex: number) => {
    try {
      const storageKey = `outlook_emails_${accountEmail}`
      const stored = localStorage.getItem(storageKey)
      if (stored) {
        const emailData = JSON.parse(stored)
        const emails = emailData.emails || []
        
        if (emailIndex >= 0 && emailIndex < emails.length) {
          emails.splice(emailIndex, 1)
          
          if (emails.length > 0) {
            emailData.emails = emails
            emailData.count = emails.length
            localStorage.setItem(storageKey, JSON.stringify(emailData))
          } else {
            localStorage.removeItem(storageKey)
          }
          
          addProgressLog(`🗑️ Đã xóa 1 email cho ${accountEmail}`)
          return true
        }
      }
      return false
    } catch (error) {
      addProgressLog(`❌ Lỗi xóa email: ${error}`)
      return false
    }
  }

  // Handle delete specific email with confirmation
  const handleDeleteSpecificEmail = (emailIndex: number, emailSubject: string) => {
    if (window.confirm(`Bạn có chắc chắn muốn xóa email "${emailSubject}"?`)) {
      const success = deleteSpecificEmailFromStorage(selectedAccountForStoredEmails, emailIndex)
      if (success) {
        const updatedEmails = [...storedEmails]
        updatedEmails.splice(emailIndex, 1)
        setStoredEmails(updatedEmails)
        showToast('success', 'Thành công', 'Đã xóa email')
      } else {
        showToast('error', 'Lỗi', 'Không thể xóa email')
      }
    }
  }

  // Handle view stored emails for specific account
  const handleViewStoredEmails = (accountEmail: string) => {
    const emails = loadEmailsFromStorage(accountEmail)
    setStoredEmails(emails)
    setSelectedAccountForStoredEmails(accountEmail)
    setShowStoredEmailsModal(true)
    addProgressLog(`📧 Hiển thị ${emails.length} email đã lưu cho ${accountEmail}`)
  }

  // Handle view email detail
  const handleViewEmailDetail = (email: any) => {
    // Remove DEBUG console.log statements to reduce console spam
    setSelectedEmailDetail(email)
    setShowEmailDetailModal(true)
  }

  // Clean and format email content
  const formatEmailContent = (content: string, contentType: string) => {
    if (!content) return 'Không có nội dung'
    
    if (contentType === 'html' || content.includes('<html') || content.includes('<!DOCTYPE')) {
      // Remove HTML tags for preview but keep structure
      const cleanContent = content
        .replace(/<script[^>]*>.*?<\/script>/gi, '') // Remove scripts
        .replace(/<style[^>]*>.*?<\/style>/gi, '') // Remove styles
        .replace(/<[^>]*>/g, ' ') // Remove HTML tags
        .replace(/\s+/g, ' ') // Normalize whitespace
        .trim()
      
      return cleanContent || 'Nội dung HTML'
    }
    
    return content
  }

  // Get safe HTML content for display
  const getSafeHtmlContent = (content: string, contentType: string) => {
    if (!content) return 'Không có nội dung'
    
    if (contentType === 'html' || content.includes('<html') || content.includes('<!DOCTYPE')) {
      // Basic HTML sanitization - remove dangerous elements
      const safeContent = content
        .replace(/<script[^>]*>.*?<\/script>/gi, '') // Remove scripts
        .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '') // Remove iframes
        .replace(/on\w+="[^"]*"/gi, '') // Remove event handlers
        .replace(/javascript:/gi, '') // Remove javascript: links
      
      return safeContent
    }
    
    // For plain text, convert line breaks to <br>
    return content.replace(/\n/g, '<br>')
  }

  // Filter accounts based on search term and status
  const filteredAccounts = accounts.filter(account => {
    const matchesSearch = account.email.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesSearch
  })

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100'
      case 'inactive': return 'text-gray-600 bg-gray-100'
      case 'error': return 'text-red-600 bg-red-100'
      case 'token_expired': return 'text-yellow-600 bg-yellow-100'
      case 'needs_reauth': return 'text-orange-600 bg-orange-100'
      default: return 'text-gray-600 bg-gray-100'
    }
  }

  // Get status icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4" />
      case 'inactive': return <XCircle className="h-4 w-4" />
      case 'error': return <AlertCircle className="h-4 w-4" />
      case 'token_expired': return <Clock className="h-4 w-4" />
      case 'needs_reauth': return <Key className="h-4 w-4" />
      default: return <XCircle className="h-4 w-4" />
    }
  }

  // Update account status in real-time
  const updateAccountStatus = (accountId: string, status: OutlookAccount['status'], additionalData?: any) => {
    const timestamp = new Date().toLocaleTimeString('vi-VN', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    })
    
    setAccounts(prev => prev.map(acc => 
      acc._id === accountId 
        ? { 
            ...acc, 
            status, 
            lastUpdated: new Date().toISOString(),
            ...additionalData
          }
        : acc
    ))

    // Save updated account status to localStorage
    const updatedAccount = accounts.find(acc => acc._id === accountId)
    if (updatedAccount) {
      try {
        const storageKey = `outlook_account_status_${accountId}`
        const statusData = {
          accountId,
          status,
          lastUpdated: new Date().toISOString(),
          ...additionalData
        }
        localStorage.setItem(storageKey, JSON.stringify(statusData))
          } catch (error) {
      // Handle error silently
    }
    }
  }

  // Real-time status update timer
  useEffect(() => {
    const statusUpdateInterval = setInterval(async () => {
      // Update status for accounts that are currently being processed
      if (readingMail || selectedAccounts.length > 0) {
        // Update status for accounts being processed
        selectedAccounts.forEach(accountId => {
          const account = accounts.find(acc => acc._id === accountId)
          if (account) {
            // Check if account is currently being processed
            if (account.status === 'active' && account.lastMailCheck) {
              const lastCheck = new Date(account.lastMailCheck)
              const now = new Date()
              const timeDiff = now.getTime() - lastCheck.getTime()
              
              // If last mail check was more than 5 minutes ago, mark as inactive
              if (timeDiff > 5 * 60 * 1000) {
                updateAccountStatus(accountId, 'inactive')
              }
            }
          }
        })
      }
    }, 5000) // Update every 5 seconds

    return () => clearInterval(statusUpdateInterval)
  }, [readingMail, selectedAccounts, accounts])

  // Handle context menu outside clicks
  useEffect(() => {
    if (contextMenu.visible) {
      const handleClickOutside = () => {
        handleContextMenuClose()
      }
      
      document.addEventListener('click', handleClickOutside)
      document.addEventListener('contextmenu', handleClickOutside)
      
      return () => {
        document.removeEventListener('click', handleClickOutside)
        document.removeEventListener('contextmenu', handleClickOutside)
      }
    }
  }, [contextMenu.visible])

  // Update account status during mail reading operations
  const updateAccountStatusDuringOperation = (accountId: string, operation: 'reading' | 'success' | 'error' | 'completed', emailCount?: number) => {
    const account = accounts.find(acc => acc._id === accountId)
    if (!account) return

    switch (operation) {
      case 'reading':
        updateAccountStatus(accountId, 'active', {
          lastMailCheck: new Date().toISOString(),
          status: 'Đang đọc mail...'
        })
        addStatusLog(accountId, 'running', 'Đang đọc mail...', 'Bắt đầu quá trình đọc mail')
        break
      case 'success':
        updateAccountStatus(accountId, 'active', {
          lastMailCheck: new Date().toISOString(),
          lastLogin: new Date().toISOString(),
          errorMessage: undefined,
          lastError: undefined,
          status: `Đăng nhập thành công - ${emailCount || 0} email`
        })
        addStatusLog(accountId, 'success', `Đọc mail thành công - ${emailCount || 0} email`, `Hoàn thành đọc mail cho ${account.email}`)
        break
      case 'error':
        updateAccountStatus(accountId, 'error', {
          lastMailCheck: new Date().toISOString(),
          lastError: new Date().toISOString(),
          status: 'Đăng nhập thất bại'
        })
        addStatusLog(accountId, 'error', 'Đọc mail thất bại', `Có lỗi xảy ra khi đọc mail cho ${account.email}`)
        break
      case 'completed':
        updateAccountStatus(accountId, 'active', {
          lastMailCheck: new Date().toISOString(),
          status: emailCount ? `Đăng nhập thành công - ${emailCount} email` : 'Đăng nhập thành công'
        })
        addStatusLog(accountId, 'completed', 'Hoàn thành quá trình xử lý', `Đã hoàn thành tất cả thao tác cho ${account.email}`)
        break
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Đang tải...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <Navigation currentPage="outlook" />
      
      {/* Page Title */}
      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 lg:pt-8 lg:ml-64">
        <div className="flex items-center space-x-3 mb-6">
          <div className="flex items-center bg-gradient-to-r from-blue-600 to-indigo-600 p-2.5 rounded-xl shadow-lg">
            <Mail className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Outlook Dashboard
            </h1>
            <div className="flex items-center space-x-2 mt-2">
              <span className="inline-flex items-center px-2.5 py-1 text-xs font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300 rounded-full border border-emerald-200 dark:border-emerald-700/50 shadow-sm">
                <Activity className="w-3 h-3 mr-1" />
                Direct Mode
              </span>
              <span className={`inline-flex items-center px-2.5 py-1 text-xs font-semibold rounded-full border shadow-sm ${
                mailReadMethod === 'outlook'
                  ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 border-blue-200 dark:border-blue-700/50'
                  : mailReadMethod === 'imap'
                  ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300 border-purple-200 dark:border-purple-700/50'
                  : 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300 border-orange-200 dark:border-orange-700/50'
              }`}>
                {mailReadMethod === 'outlook' ? (
                  <>
                    <Globe className="w-3 h-3 mr-1" />
                    Outlook
                  </>
                ) : mailReadMethod === 'imap' ? (
                  <>
                    <Database className="w-3 h-3 mr-1" />
                    IMAP
                  </>
                ) : (
                  <>
                    <Target className="w-3 h-3 mr-1" />
                    Scraping
                  </>
                )}
              </span>
            </div>
          </div>
        </div>
        
        {/* Settings Button */}
        <div className="flex justify-end mb-6">
          <button
            onClick={() => setShowSettings(true)}
            className="p-2.5 rounded-xl bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-600 hover:from-gray-200 hover:to-gray-300 dark:hover:from-gray-600 dark:hover:to-gray-500 transition-all duration-200 shadow-md hover:shadow-lg text-gray-700 dark:text-gray-300"
            title="Cài đặt"
          >
            <Settings className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 pb-8 lg:ml-64">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 dark:border-gray-700/50 p-6 hover:shadow-xl transition-all duration-300 group">
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl shadow-lg group-hover:shadow-blue-500/25 transition-all duration-300">
                <Mail className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Tổng tài khoản</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">{accounts.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 dark:border-gray-700/50 p-6 hover:shadow-xl transition-all duration-300 group">
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-xl shadow-lg group-hover:shadow-emerald-500/25 transition-all duration-300">
                <CheckCircle className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Hoạt động</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {accounts.filter(acc => acc.status === 'active').length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 dark:border-gray-700/50 p-6 hover:shadow-xl transition-all duration-300 group">
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-red-500 to-red-600 rounded-xl shadow-lg group-hover:shadow-red-500/25 transition-all duration-300">
                <XCircle className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Lỗi</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {accounts.filter(acc => acc.status === 'error').length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 dark:border-gray-700/50 p-6 hover:shadow-xl transition-all duration-300 group">
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-amber-500 to-amber-600 rounded-xl shadow-lg group-hover:shadow-amber-500/25 transition-all duration-300">
                <Clock className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-1">Token hết hạn</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {accounts.filter(acc => acc.status === 'token_expired' || acc.isTokenExpired).length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Bar */}
        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 dark:border-gray-700/50 mb-6">
          <div className="p-6">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                <button
                  onClick={() => setShowBulkImportModal(true)}
                  className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-medium rounded-lg transition-all duration-200 shadow-md hover:shadow-lg hover:shadow-purple-500/25 text-sm"
                >
                  <Upload className="h-3.5 w-3.5 mr-1.5" />
                  Import hàng loạt
                </button>
                
                
                <button
                  onClick={() => {
                    if (selectedAccounts.length === 0) {
                      showToast('warning', 'Cảnh báo', 'Vui lòng chọn ít nhất một tài khoản')
                      return
                    }
                    startRun()
                    handleReadMailBulk()
                  }}
                  disabled={selectedAccounts.length === 0 || isRunning}
                  className={`inline-flex items-center px-4 py-2 font-medium rounded-lg transition-all duration-200 shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed text-sm ${
                    mailReadMethod === 'outlook'
                      ? 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white hover:shadow-blue-500/25'
                      : mailReadMethod === 'imap'
                      ? 'bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white hover:shadow-purple-500/25'
                      : 'bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white hover:shadow-orange-500/25'
                  }`}
                  title={`Đọc mail qua ${mailReadMethod === 'outlook' ? 'Outlook API' : mailReadMethod === 'imap' ? 'IMAP' : 'Web Scraping'}`}
                >
                  {mailReadMethod === 'outlook' ? (
                    <Globe className="h-3.5 w-3.5 mr-1.5" />
                  ) : mailReadMethod === 'imap' ? (
                    <Database className="h-3.5 w-3.5 mr-1.5" />
                  ) : (
                    <Target className="h-3.5 w-3.5 mr-1.5" />
                  )}
                  {mailReadMethod === 'outlook' ? 'Outlook' : mailReadMethod === 'imap' ? 'IMAP' : 'Scraping'} ({selectedAccounts.length})
                </button>

                <button
                  onClick={stopRun}
                  disabled={!isRunning}
                  className={`inline-flex items-center px-4 py-2 font-medium rounded-lg transition-all duration-200 shadow-md disabled:opacity-50 disabled:cursor-not-allowed text-sm ${!isRunning ? 'bg-gray-200 text-gray-500' : 'bg-red-600 text-white hover:bg-red-700'}`}
                >
                  <StopIcon className="h-3.5 w-3.5 mr-1.5" />
                  Dừng
                </button>
                
                <button
                  onClick={() => {
                    if (selectedAccounts.length === accounts.length) {
                      setSelectedAccounts([])
                      showToast('info', 'Thông báo', 'Đã bỏ chọn tất cả tài khoản')
                    } else {
                      setSelectedAccounts(accounts.map(acc => acc._id))
                      showToast('info', 'Thông báo', `Đã chọn tất cả ${accounts.length} tài khoản`)
                    }
                  }}
                  className="inline-flex items-center px-3 py-2 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white font-medium rounded-lg transition-all duration-200 shadow-md hover:shadow-lg hover:shadow-indigo-500/25 text-sm"
                >
                  <CheckSquare className="h-3.5 w-3.5 mr-1.5" />
                  {selectedAccounts.length === accounts.length ? 'Bỏ chọn tất cả' : 'Chọn tất cả'}
                </button>
                
                <button
                  onClick={() => {
                    if (selectedAccounts.length === 0) {
                      showToast('warning', 'Cảnh báo', 'Vui lòng chọn ít nhất một tài khoản để xóa')
                      return
                    }
                    
                    // Chuẩn bị danh sách tài khoản sẽ xóa
                    const accountsToDelete = selectedAccounts.map(accountId => {
                      const account = accounts.find(acc => acc._id === accountId)
                      return { id: accountId, email: account?.email || 'Unknown' }
                    })
                    
                    // Hiển thị custom confirmation modal
                    setAccountsToDelete(accountsToDelete)
                    setShowDeleteConfirm(true)
                  }}
                  disabled={selectedAccounts.length === 0}
                  className={`inline-flex items-center px-3 py-2 font-medium rounded-lg transition-all duration-200 shadow-md hover:shadow-lg text-sm ${
                    selectedAccounts.length === 0
                      ? 'bg-gray-400 text-gray-200 cursor-not-allowed'
                      : 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white hover:shadow-red-500/25'
                  }`}
                  title={selectedAccounts.length === 0 ? 'Chọn tài khoản để xóa' : `Xóa ${selectedAccounts.length} tài khoản đã chọn`}
                >
                  <Trash2 className="h-3.5 w-3.5 mr-1.5" />
                  Xóa tài khoản đã chọn
                  {selectedAccounts.length > 0 && (
                    <span className="ml-2 px-2 py-0.5 bg-white/20 rounded-full text-xs">
                      {selectedAccounts.length}
                    </span>
                  )}
                </button>

                

              </div>
              
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Search className="h-3.5 w-3.5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Tìm kiếm email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 pr-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white/80 dark:bg-gray-700/80 backdrop-blur-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 shadow-sm focus:shadow-md text-sm"
                  />
                </div>
                

                
                <div className="flex bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-600 rounded-xl p-1 shadow-sm">
                  <button
                    onClick={() => setViewMode('table')}
                    className={`p-2 rounded-lg transition-all duration-200 ${
                      viewMode === 'table' 
                        ? 'bg-white dark:bg-gray-600 shadow-md text-blue-600 dark:text-blue-400' 
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
                    }`}
                    title="Xem dạng bảng"
                  >
                    <List className="h-3.5 w-3.5" />
                  </button>
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded-lg transition-all duration-200 ${
                      viewMode === 'grid' 
                        ? 'bg-white dark:bg-gray-600 shadow-md text-blue-600 dark:text-blue-400' 
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
                    }`}
                    title="Xem dạng lưới"
                  >
                    <Grid3X3 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Accounts Table/Grid */}
        <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl shadow-lg border border-gray-200/50 dark:border-gray-700/50">
          {/* Table Info Header */}
          <div className="px-6 py-3 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  📊 Tổng cộng: <span className="font-bold text-blue-600 dark:text-blue-400">{filteredAccounts.length}</span> tài khoản
                </span>
                {selectedAccounts.length > 0 && (
                  <span className="text-xs text-gray-500 dark:text-gray-400 bg-green-100 dark:bg-green-900/20 px-2 py-1 rounded-full">
                    ✅ Đã chọn: {selectedAccounts.length}
                  </span>
                )}
                {highlightedAccounts.length > 0 && (
                  <span className="text-xs text-gray-500 dark:text-gray-400 bg-blue-100 dark:bg-blue-900/20 px-2 py-1 rounded-full">
                    🔵 Bôi đen: {highlightedAccounts.length}
                  </span>
                )}
                {showFacebookInfo && (
                  <span className="text-xs text-gray-500 dark:text-gray-400 bg-green-100 dark:bg-green-900/20 px-2 py-1 rounded-full">
                    📘 Facebook: {facebookAccounts.length} tài khoản
                  </span>
                )}
                {filteredAccounts.length > 10 && (
                  <span className="text-xs text-gray-500 dark:text-gray-400 bg-blue-100 dark:bg-blue-900/20 px-2 py-1 rounded-full">
                    💡 Cuộn xuống để xem thêm
                  </span>
                )}
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400">
                {viewMode === 'table' ? 'Dạng bảng' : 'Dạng lưới'}
              </div>
            </div>
          </div>
          
          {viewMode === 'table' ? (
            <div className="overflow-x-auto max-h-[60vh] sm:max-h-[65vh] lg:max-h-[70vh] overflow-y-auto accounts-table-scroll">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700 sticky top-0 z-10 shadow-sm">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      <input
                        type="checkbox"
                        checked={selectedAccounts.length === filteredAccounts.length && filteredAccounts.length > 0}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedAccounts(filteredAccounts.map(acc => acc._id))
                          } else {
                            setSelectedAccounts([])
                          }
                        }}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Trạng thái
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Đăng nhập cuối
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Đọc mail cuối
                    </th>
                    {showFacebookInfo && (
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                        <div className="flex items-center space-x-2">
                          <Users className="w-4 h-4 text-blue-600" />
                          <span>FACEBOOK</span>
                        </div>
                      </th>
                    )}
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Hành động
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {filteredAccounts.map((account) => (
                    <tr 
                      key={account._id} 
                      onClick={() => handleHighlightAccount(account._id)}
                      onContextMenu={(e) => handleContextMenu(e, account._id)}
                      className={`hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer ${
                        highlightedAccounts.includes(account._id)
                          ? 'bg-blue-100 dark:bg-blue-900/30 border-l-4 border-blue-400'
                          : account.status === 'needs_reauth' 
                            ? 'bg-orange-50 dark:bg-orange-900/20 border-l-4 border-orange-400' 
                            : ''
                      }`}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <input
                          type="checkbox"
                          checked={selectedAccounts.includes(account._id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedAccounts(prev => [...prev, account._id])
                            } else {
                              setSelectedAccounts(prev => prev.filter(id => id !== account._id))
                            }
                          }}
                          className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {account.email}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <RealTimeStatusLog
                          key={account._id}
                          ref={(ref) => {
                            if (ref) {
                              registerStatusLogRef(account._id, ref)
                            }
                          }}
                          accountId={account._id}
                          email={account.email}
                          currentStatus={account.status}
                          onStatusUpdate={(accountId, status, message) => {
                            // Don't update account status here to avoid infinite loop
                            // The status will be updated by the actual operations
                          }}
                        />
                        {account.lastUpdated && (
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            Cập nhật: {new Date(account.lastUpdated).toLocaleTimeString('vi-VN', { 
                              hour12: false, 
                              hour: '2-digit', 
                              minute: '2-digit', 
                              second: '2-digit' 
                            })}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {account.lastLogin ? new Date(account.lastLogin).toLocaleString('vi-VN') : 'Chưa có'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                        {account.lastMailCheck ? new Date(account.lastMailCheck).toLocaleString('vi-VN') : 'Chưa có'}
                      </td>
                      {showFacebookInfo && (
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          {(() => {
                            const fbAccount = getFacebookAccountInfo(account.email)
                            if (!fbAccount) {
                              return (
                                <div className="text-xs text-gray-400 dark:text-gray-500">
                                  Không tìm thấy
                                </div>
                              )
                            }
                            return (
                              <div className="space-y-1">
                                <div className="flex items-center space-x-2">
                                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                  <span className="text-xs text-green-600 dark:text-green-400 font-medium">
                                    {fbAccount.uid}
                                  </span>
                                </div>
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                  {(fbAccount.mail || 'N/A') + '|' + (fbAccount.passmail || 'N/A')}
                                </div>
                                <div className="flex items-center gap-2 pt-1">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      navigator.clipboard.writeText(`${fbAccount.mail || ''}|${fbAccount.passmail || ''}`)
                                      showToast('success', 'Đã copy', 'Đã copy mail|passmail từ Facebook')
                                    }}
                                    className="px-2 py-0.5 text-[11px] bg-gray-100 dark:bg-gray-700 rounded hover:bg-gray-200 dark:hover:bg-gray-600"
                                  >
                                    Copy
                                  </button>
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      handleLoginWithFacebookCreds(account._id)
                                    }}
                                    className="px-2 py-0.5 text-[11px] bg-blue-500 text-white rounded hover:bg-blue-600"
                                  >
                                    Login FB
                                  </button>
                                </div>
                              </div>
                            )
                          })()}
                        </td>
                      )}
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">


                          <button
                            onClick={() => handleViewStoredEmails(account.email)}
                            className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                            title="Xem email đã lưu"
                          >
                            <Database className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteAccount(account._id, account.email)}
                            className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                            title="Xóa"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6 max-h-[60vh] sm:max-h-[65vh] lg:max-h-[70vh] overflow-y-auto accounts-table-scroll">
              {filteredAccounts.map((account) => (
                <div 
                  key={account._id} 
                  onClick={() => handleHighlightAccount(account._id)}
                  onContextMenu={(e) => handleContextMenu(e, account._id)}
                  className={`border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer ${
                    highlightedAccounts.includes(account._id)
                      ? 'border-blue-400 bg-blue-100 dark:bg-blue-900/30'
                      : account.status === 'needs_reauth'
                        ? 'border-orange-400 bg-orange-50 dark:bg-orange-900/20'
                        : 'border-gray-200 dark:border-gray-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <input
                      type="checkbox"
                      checked={selectedAccounts.includes(account._id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedAccounts(prev => [...prev, account._id])
                        } else {
                          setSelectedAccounts(prev => prev.filter(id => id !== account._id))
                        }
                      }}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span 
                      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(account.status)}`}
                      title={account.lastError || account.errorMessage || ''}
                    >
                      {getStatusIcon(account.status)}
                      <span className="ml-1">
                        {account.status === 'active' ? 'Hoạt động' :
                         account.status === 'inactive' ? 'Không hoạt động' :
                         account.status === 'error' ? 'Lỗi' :
                         account.status === 'token_expired' ? 'Token hết hạn' :
                         account.status === 'needs_reauth' ? 'Cần đăng nhập lại' : account.status}
                      </span>
                    </span>
                  </div>
                  
                  <div className="mb-3">
                    <h3 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                      {account.email}
                    </h3>
                  </div>
                  
                  {/* Real-time Status Log */}
                  <div className="mb-3">
                    <RealTimeStatusLog
                      key={account._id}
                      ref={(ref) => {
                        if (ref) {
                          registerStatusLogRef(account._id, ref)
                        }
                      }}
                      accountId={account._id}
                      email={account.email}
                      currentStatus={account.status}
                      onStatusUpdate={(accountId, status, message) => {
                        // Don't update account status here to avoid infinite loop
                        // The status will be updated by the actual operations
                      }}
                    />
                  </div>
                  
                  <div className="text-xs text-gray-500 dark:text-gray-400 mb-3">
                    <p>Đăng nhập cuối: {account.lastLogin ? new Date(account.lastLogin).toLocaleString('vi-VN') : 'Chưa có'}</p>
                    <p>Đọc mail cuối: {account.lastMailCheck ? new Date(account.lastMailCheck).toLocaleString('vi-VN') : 'Chưa có'}</p>
                  </div>
                  
                  {showFacebookInfo && (
                    <div className="text-xs text-gray-500 dark:text-gray-400 mb-3 border-t border-gray-100 dark:border-gray-700 pt-2">
                      {(() => {
                        const fbAccount = getFacebookAccountInfo(account.email)
                        if (!fbAccount) {
                          return (
                            <p className="text-gray-400 dark:text-gray-500">
                              Facebook: Không tìm thấy
                            </p>
                          )
                        }
                        return (
                          <div className="space-y-1">
                            <p className="text-green-600 dark:text-green-400 font-medium">
                              Facebook: {fbAccount.uid}
                            </p>
                            <p className="text-gray-600 dark:text-gray-400">
                              {(fbAccount.mail || 'N/A') + '|' + (fbAccount.passmail || 'N/A')}
                            </p>
                            <div className="flex items-center gap-2 pt-1">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  navigator.clipboard.writeText(`${fbAccount.mail || ''}|${fbAccount.passmail || ''}`)
                                  showToast('success', 'Đã copy', 'Đã copy mail|passmail từ Facebook')
                                }}
                                className="px-2 py-0.5 text-[11px] bg-gray-100 dark:bg-gray-700 rounded hover:bg-gray-200 dark:hover:bg-gray-600"
                              >
                                Copy
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  handleLoginWithFacebookCreds(account._id)
                                }}
                                className="px-2 py-0.5 text-[11px] bg-blue-500 text-white rounded hover:bg-blue-600"
                              >
                                Login FB
                              </button>
                            </div>
                          </div>
                        )
                      })()}
                    </div>
                  )}
                  
                  <div className="flex justify-between">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleTestLogin(account._id, account.email)}
                        className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                        title="Đăng nhập trực tiếp (bỏ qua test)"
                      >
                        <Play className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleRefreshToken(account._id, account.email)}
                        className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300"
                        title="Refresh token"
                      >
                        <RefreshCw className="h-4 w-4" />
                      </button>
                    </div>

                    <button
                      onClick={() => handleViewStoredEmails(account.email)}
                      className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                      title="Xem email đã lưu"
                    >
                      <Database className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteAccount(account._id, account.email)}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                      title="Xóa"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {filteredAccounts.length === 0 && (
            <div className="text-center py-12">
              <Mail className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 dark:text-gray-400">
                {searchTerm ? 'Không tìm thấy tài khoản nào' : 'Chưa có tài khoản Outlook nào'}
              </p>
            </div>
          )}
        </div>

        {/* Progress Logs */}
        <div className="mt-6 bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">Nhật ký hoạt động</h3>
            <button
              onClick={() => setIsProgressMinimized(!isProgressMinimized)}
              className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              {isProgressMinimized ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </button>
          </div>
          
          {!isProgressMinimized && (
            <div 
              ref={progressLogsRef}
              className="p-4 max-h-64 overflow-y-auto bg-gray-50 dark:bg-gray-900 font-mono text-sm"
            >
              {progressLogs.length === 0 ? (
                <p className="text-gray-500 dark:text-gray-400">Chưa có hoạt động nào...</p>
              ) : (
                progressLogs.map((log, index) => (
                  <div key={index} className="text-gray-700 dark:text-gray-300 mb-1">
                    {log}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>



      {/* Bulk Import Modal */}
      {showBulkImportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-2xl mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Import tài khoản hàng loạt</h3>
              <button
                onClick={() => setShowBulkImportModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Danh sách tài khoản
                </label>
                <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                  <div>Định dạng hỗ trợ:</div>
                  <div>• <code className="bg-gray-100 dark:bg-gray-700 px-1 rounded">email|password</code></div>
                  <div>• <code className="bg-gray-100 dark:bg-gray-700 px-1 rounded">email|password|refresh_token|client_id</code></div>
                  {bulkAccountsText.trim() && (
                    <span className="ml-2 text-blue-600 dark:text-blue-400 font-medium">
                      ({bulkAccountsText.trim().split('\n').filter(line => line.trim() && (line.includes(':') || line.includes('|'))).length} tài khoản)
                    </span>
                  )}
                </div>
                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3 mb-3">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600 dark:text-yellow-400 mt-0.5 flex-shrink-0" />
                    <div className="text-xs text-yellow-800 dark:text-yellow-200">
                      <strong>Lưu ý:</strong> Import hàng loạt sẽ không kiểm tra đăng nhập ngay lập tức để tăng tốc độ. 
                      Sau khi import, bạn có thể:
                      <br />• <Play className="h-3 w-3 inline mx-1" /> Test login để xác thực
                      <br />• <RefreshCw className="h-3 w-3 inline mx-1" /> Refresh token nếu token hết hạn
                    </div>
                  </div>
                </div>
                <textarea
                  value={bulkAccountsText}
                  onChange={(e) => setBulkAccountsText(e.target.value)}
                  rows={10}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                  placeholder={`example1@outlook.com|password1
example2@hotmail.com|password2|refresh_token2|client_id2
example3@live.com|password3`}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Proxy chung (tùy chọn)
                </label>
                <input
                  type="text"
                  value={bulkProxy}
                  onChange={(e) => setBulkProxy(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="http://proxy:port"
                />
              </div>
              
              {bulkImporting && (
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
                      Đang import...
                    </span>
                    <span className="text-sm text-blue-700 dark:text-blue-300">
                      {bulkProgress.current}/{bulkProgress.total}
                    </span>
                  </div>
                  <div className="w-full bg-blue-200 dark:bg-blue-800 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(bulkProgress.current / bulkProgress.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setShowBulkImportModal(false)}
                disabled={bulkImporting}
                className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50 rounded-lg transition-colors"
              >
                Hủy
              </button>
              <button
                onClick={handleBulkImport}
                disabled={bulkImporting || !bulkAccountsText.trim()}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 disabled:bg-gray-400 text-white rounded-lg transition-colors"
              >
                {bulkImporting ? 'Đang import...' : 'Import'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Read Mail Modal */}
      {showReadMailModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">Đọc mail Outlook</h3>
              <button
                onClick={() => {
                  setShowReadMailModal(false)
                  setSelectedAccountForMail(null)
                  setFilterSender('')
                  setFilterMinutes('')
                  setMailResults([])
                }}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Tài khoản
                </label>
                <select
                  value={selectedAccountForMail || ''}
                  onChange={(e) => setSelectedAccountForMail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Chọn tài khoản</option>
                  {accounts.map((account) => (
                    <option key={account._id} value={account._id}>
                      {account.email}
                    </option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Lọc theo người gửi
                </label>
                <input
                  type="email"
                  value={filterSender}
                  onChange={(e) => setFilterSender(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="sender@example.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Thời gian (phút)
                </label>
                <input
                  type="number"
                  value={filterMinutes}
                  onChange={(e) => setFilterMinutes(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="60"
                />
              </div>
            </div>
            
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleReadMail}
                  disabled={readingMail || !selectedAccountForMail || isRunning}
                  className={`px-4 py-2 rounded-lg text-white ${readingMail || isRunning ? 'bg-gray-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700'} transition-colors`}
                >
                  {readingMail ? 'Đang đọc...' : 'Đọc mail'}
                </button>
                <button
                  onClick={stopRun}
                  disabled={!isRunning}
                  className={`px-4 py-2 rounded-lg ${!isRunning ? 'bg-gray-200 text-gray-500 cursor-not-allowed' : 'bg-red-600 text-white hover:bg-red-700'} transition-colors`}
                >
                  Dừng
                </button>
              </div>
              <span className="text-sm text-gray-500 dark:text-gray-400">Tìm thấy {mailResults.length} email</span>
            </div>
            
            {/* Mail Results */}
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {mailResults.map((email, index) => (
                <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-medium text-gray-900 dark:text-white">
                      {email.subject}
                    </h4>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      {email.folder}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <p>Từ: {email.sender}</p>
                    <p>Thời gian: {email.received_time}</p>
                  </div>
                  <div className="text-sm text-gray-700 dark:text-gray-300 max-h-32 overflow-y-auto">
                    {email.body_type === 'html' ? (
                      <div dangerouslySetInnerHTML={{ __html: email.body.substring(0, 500) + '...' }} />
                    ) : (
                      <p>{email.body.substring(0, 500)}...</p>
                    )}
                  </div>
                </div>
              ))}
              
              {mailResults.length === 0 && !readingMail && (
                <div className="text-center py-8">
                  <Mail className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">Chưa có email nào</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      <div className="fixed top-6 right-6 z-50 space-y-4 max-w-sm">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`w-full backdrop-blur-sm bg-white/95 shadow-2xl rounded-2xl pointer-events-auto border overflow-hidden transform transition-all duration-700 ease-out animate-in hover:scale-105 hover:shadow-3xl ${
              toast.type === 'success' ? 'border-green-200 shadow-green-500/20 hover:shadow-green-500/30' :
              toast.type === 'error' ? 'border-red-200 shadow-red-500/20 hover:shadow-red-500/30' :
              toast.type === 'warning' ? 'border-yellow-200 shadow-yellow-500/20 hover:shadow-yellow-500/30' :
              'border-blue-200 shadow-blue-500/20 hover:shadow-blue-500/30'
            }`}
          >
            <div className="p-5">
              <div className="flex items-center">
                <div className={`flex-shrink-0 p-3 rounded-full animate-pulse ${
                  toast.type === 'success' ? 'bg-gradient-to-r from-green-400 to-green-500 shadow-lg shadow-green-500/50' :
                  toast.type === 'error' ? 'bg-gradient-to-r from-red-400 to-red-500 shadow-lg shadow-red-500/50' :
                  toast.type === 'warning' ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 shadow-lg shadow-yellow-500/50' :
                  'bg-gradient-to-r from-blue-400 to-blue-500 shadow-lg shadow-blue-500/50'
                }`}>
                  {toast.type === 'success' && (
                    <CheckCircle className="h-6 w-6 text-white" />
                  )}
                  {toast.type === 'error' && (
                    <XCircle className="h-6 w-6 text-white" />
                  )}
                  {toast.type === 'warning' && (
                    <Clock className="h-6 w-6 text-white" />
                  )}
                  {toast.type === 'info' && (
                    <Eye className="h-6 w-6 text-white" />
                  )}
                </div>
                <div className="ml-4 flex-1">
                  <p className="text-base font-bold text-gray-900 mb-1">
                    {toast.title}
                  </p>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {toast.message}
                  </p>
                </div>
                <div className="ml-3 flex-shrink-0">
                  <button
                    className="inline-flex text-gray-400 hover:text-gray-700 transition-all duration-200 p-2 rounded-full hover:bg-gray-100/80 hover:scale-110 active:scale-95"
                    onClick={() => removeToast(toast.id)}
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
            
            {/* Animated progress bar */}
            <div className="h-1 bg-gray-100 relative overflow-hidden">
              <div 
                className={`absolute top-0 left-0 h-full w-full ${
                  toast.type === 'success' ? 'bg-gradient-to-r from-green-400 to-green-600' :
                  toast.type === 'error' ? 'bg-gradient-to-r from-red-400 to-red-600' :
                  toast.type === 'warning' ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' :
                  'bg-gradient-to-r from-blue-400 to-blue-600'
                }`}
                style={{
                  animation: 'toast-progress 4s linear forwards'
                }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white">Cài đặt Outlook</h3>
              <button
                onClick={() => setShowSettings(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="space-y-6">
              {/* General Settings */}
              <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Cài đặt chung
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div>
                      <label className="text-sm font-medium text-gray-900 dark:text-white">
                        Auto refresh
                      </label>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Tự động làm mới danh sách
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div>
                      <label className="text-sm font-medium text-gray-900 dark:text-white">
                        Notifications
                      </label>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Hiển thị thông báo
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Thread & Proxy Settings */}
              <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Cài đặt hiệu suất
                </h4>
                
                <div className="space-y-4">
                  {/* Max Threads */}
                  <div className="bg-cyan-50 dark:bg-cyan-900/20 rounded-lg p-4 border border-cyan-200 dark:border-cyan-800">
                    <div className="flex items-center mb-3">
                      <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center mr-3">
                        <Shield className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <h5 className="text-sm font-medium text-cyan-900 dark:text-cyan-100">
                          Cài đặt đa luồng
                        </h5>
                        <p className="text-xs text-cyan-700 dark:text-cyan-300">
                          Cấu hình số luồng tối đa cho hệ thống
                        </p>
                      </div>
                    </div>
                    
                    {/* User Plan Notice */}
                    <div className={`rounded-lg p-3 mb-4 border ${
                      userPlan === 'free' 
                        ? 'bg-gray-50 dark:bg-gray-900/20 border-gray-200 dark:border-gray-800'
                        : userPlan === 'premium'
                        ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
                        : 'bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-800'
                    }`}>
                      <div className="flex items-center">
                        {userPlan === 'free' ? (
                          <Shield className="h-4 w-4 text-gray-500 mr-2" />
                        ) : (
                          <Crown className="h-4 w-4 text-blue-500 mr-2" />
                        )}
                        <span className={`text-sm ${
                          userPlan === 'free' 
                            ? 'text-gray-700 dark:text-gray-300'
                            : 'text-blue-700 dark:text-blue-300'
                        }`}>
                          Gói hiện tại: {userPlan.toUpperCase()}
                        </span>
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <p className={`text-xs ${
                          userPlan === 'free' 
                            ? 'text-gray-600 dark:text-gray-400'
                            : 'text-blue-600 dark:text-blue-400'
                        }`}>
                          Giới hạn tối đa {userMaxThreads} luồng
                        </p>
                        {userPlan === 'free' && (
                          <button
                            onClick={() => window.open('/pricing', '_blank')}
                            className="text-xs bg-gradient-to-r from-blue-500 to-purple-600 text-white px-2 py-1 rounded-md hover:from-blue-600 hover:to-purple-700 transition-all duration-200 flex items-center space-x-1"
                          >
                            <Crown className="h-3 w-3" />
                            <span>Nâng cấp</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Thread Slider */}
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          Số luồng tối đa
                        </label>
                        <div className="flex items-center space-x-2">
                          <span className="text-lg font-bold text-cyan-600 dark:text-cyan-400">
                            {Math.min(maxThreads, userMaxThreads)}
                          </span>
                        </div>
                      </div>
                      
                      <div className="relative">
                        <input
                          type="range"
                          min="1"
                          max={userMaxThreads}
                          value={Math.min(maxThreads, userMaxThreads)}
                          onChange={(e) => {
                            const value = parseInt(e.target.value)
                            if (value <= userMaxThreads) {
                              setMaxThreads(value)
                            }
                          }}
                          className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-opacity-50 slider-thumb"
                          style={{
                            background: `linear-gradient(to right, #06b6d4 0%, #06b6d4 ${(Math.min(maxThreads, userMaxThreads) / userMaxThreads) * 100}%, #e5e7eb ${(Math.min(maxThreads, userMaxThreads) / userMaxThreads) * 100}%, #e5e7eb 100%)`
                          }}
                        />
                      </div>
                      
                      <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                        <span>Hiện tại: {Math.min(maxThreads, userMaxThreads)} - Giới hạn gói {userPlan.toUpperCase()}: {userMaxThreads} luồng</span>
                      </div>
                    </div>
                  </div>

                  {/* Proxy Settings */}
                  <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h5 className="text-sm font-medium text-gray-900 dark:text-white">
                          Cài đặt Proxy
                        </h5>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Sử dụng proxy server cho kết nối
                        </p>
                      </div>
                      <input
                        type="checkbox"
                        checked={proxySettings.enabled}
                        onChange={(e) => setProxySettings(prev => ({ ...prev, enabled: e.target.checked }))}
                        className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                      />
                    </div>
                    
                    {proxySettings.enabled && (
                      <div className="space-y-3">
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-xs font-medium text-gray-700 dark:text-gray-300">
                              Chọn Proxy Server
                            </label>
                            <button
                              onClick={loadAvailableProxies}
                              className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200 flex items-center space-x-1"
                            >
                              <RefreshCw className="h-3 w-3" />
                              <span>Làm mới</span>
                            </button>
                          </div>
                          <select
                            value={proxySettings.selectedProxyId}
                            onChange={async (e) => {
                              const selectedProxyId = e.target.value
                              const selectedProxy = availableProxies.find(p => p._id === selectedProxyId)
                              
                              if (!selectedProxyId) {
                                setProxySettings(prev => ({ 
                                  ...prev, 
                                  selectedProxyId: '',
                                  server: ''
                                }))
                                return
                              }
                              
                              // Set loading state first
                              setProxySettings(prev => ({ 
                                ...prev, 
                                selectedProxyId: selectedProxyId,
                                server: 'Đang tải...'
                              }))
                              
                              addProgressLog(`🔄 Đang lấy thông tin proxy: ${selectedProxy?.name || selectedProxyId}`)
                              
                              try {
                                // Try to get server from currentProxy first, then from API
                                let actualServer = selectedProxy?.currentProxy || ''
                                
                                if (!actualServer) {
                                  actualServer = await getProxyServer(selectedProxyId)
                                }
                                
                                if (actualServer) {
                                  setProxySettings(prev => ({ 
                                    ...prev, 
                                    server: actualServer
                                  }))
                                  addProgressLog(`✅ Đã chọn proxy: ${selectedProxy?.name || 'Unknown'} - ${actualServer}`)
                                } else {
                                  setProxySettings(prev => ({ 
                                    ...prev, 
                                    server: 'Không thể lấy IP proxy'
                                  }))
                                  addProgressLog(`❌ Không thể lấy IP cho proxy: ${selectedProxy?.name || selectedProxyId}`)
                                }
                              } catch (error) {
                                setProxySettings(prev => ({ 
                                  ...prev, 
                                  server: 'Lỗi khi lấy IP proxy'
                                }))
                                addProgressLog(`❌ Lỗi khi lấy proxy: ${error}`)
                              }
                            }}
                            className="w-full px-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          >
                            <option value="">-- Chọn proxy server --</option>
                            {availableProxies.map((proxy) => (
                              <option key={proxy._id} value={proxy._id}>
                                {proxy.name} {proxy.isResidential ? '(Residential)' : '(Datacenter)'} - {proxy.currentUsers}/{proxy.maxUsers} users
                              </option>
                            ))}
                          </select>
                          {proxySettings.selectedProxyId && (
                            <div className="mt-1 space-y-2">
                              <div className="text-xs text-gray-500 dark:text-gray-400">
                                Server: {proxySettings.server || 'Đang tải...'}
                              </div>
                              {proxySettings.databaseIP && (
                                <div className="text-xs text-green-600 dark:text-green-400">
                                  📊 Database IP: {proxySettings.databaseIP}
                                  {proxySettings.databaseIP !== proxySettings.server && (
                                    <span className="ml-2 text-orange-600 dark:text-orange-400">
                                      ⚠️ Khác với IP hiện tại
                                    </span>
                                  )}
                                </div>
                              )}
                              <div className="flex gap-2 flex-wrap">
                                <button
                                  onClick={() => updateProxyIPFromDatabase()}
                                  className="flex items-center px-2 py-1 bg-green-100 hover:bg-green-200 dark:bg-green-900 dark:hover:bg-green-800 text-green-700 dark:text-green-300 rounded text-xs transition-colors"
                                  title="Kiểm tra IP từ database"
                                >
                                  <Database className="h-3 w-3 mr-1" />
                                  Check DB
                                </button>
                                {proxySettings.server && proxySettings.server !== 'Đang tải...' && !proxySettings.server.includes('Lỗi') && !proxySettings.server.includes('Không thể') && (
                                  <button
                                    onClick={async () => {
                                      addProgressLog(`🧪 Đang test proxy: ${proxySettings.server}`)
                                      try {
                                        const response = await fetch('/api/proxy/test-proxy', {
                                          method: 'POST',
                                          headers: {
                                            'Authorization': `Bearer ${localStorage.getItem('token')}`,
                                            'Content-Type': 'application/json'
                                          },
                                          body: JSON.stringify({ 
                                            proxyId: proxySettings.selectedProxyId,
                                            proxyServer: proxySettings.server 
                                          })
                                        })
                                        
                                        if (response.ok) {
                                          const result = await response.json()
                                          if (result.success) {
                                            addProgressLog(`✅ Proxy hoạt động tốt: ${result.ip || 'Unknown IP'}`)
                                            showToast('success', 'Thành công', 'Proxy hoạt động tốt')
                                          } else {
                                            addProgressLog(`❌ Proxy không hoạt động: ${result.error || 'Unknown error'}`)
                                            showToast('error', 'Lỗi', 'Proxy không hoạt động')
                                          }
                                        } else {
                                          addProgressLog(`❌ Không thể test proxy: ${response.status}`)
                                          showToast('error', 'Lỗi', 'Không thể test proxy')
                                        }
                                      } catch (error) {
                                        addProgressLog(`❌ Lỗi test proxy: ${error}`)
                                        showToast('error', 'Lỗi', 'Lỗi khi test proxy')
                                      }
                                    }}
                                    className="flex items-center px-2 py-1 bg-green-100 hover:bg-green-200 dark:bg-green-900 dark:hover:bg-green-800 text-green-700 dark:text-green-300 rounded text-xs transition-colors"
                                  >
                                    <Activity className="h-3 w-3 mr-1" />
                                    Test Proxy
                                  </button>
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <div className="space-y-3">
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              id="useProxyForAll"
                              checked={proxySettings.useForAll}
                              onChange={(e) => setProxySettings(prev => ({ ...prev, useForAll: e.target.checked }))}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 mr-2"
                            />
                            <label htmlFor="useProxyForAll" className="text-xs text-gray-700 dark:text-gray-300">
                              Sử dụng proxy cho tất cả tài khoản
                            </label>
                          </div>
                          
                          <div className="ml-6 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded">
                            <div className="text-xs text-blue-700 dark:text-blue-300 font-medium">
                              📊 CHỈ HIỂN THỊ IP TỪ DATABASE
                            </div>
                            <div className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                              IP proxy được lấy trực tiếp từ database, không refresh/reset.
                              Tự động cập nhật khi IP thay đổi trong database.
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-blue-600 dark:text-blue-400">
                            💡 Áp dụng proxy cho tất cả tài khoản
                          </span>
                          <span className="text-gray-500 dark:text-gray-400">
                            {availableProxies.length} proxy có sẵn
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Mail Settings */}
              <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Mail className="h-5 w-5 mr-2" />
                  Cài đặt Mail
                </h4>
                
                <div className="space-y-4">
                  {/* Mail Read Method */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      Phương thức đọc mail
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div 
                        className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          mailReadMethod === 'outlook' 
                            ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                            : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                        }`}
                        onClick={() => setMailReadMethod('outlook')}
                      >
                        <div className="flex items-center mb-2">
                          <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                            mailReadMethod === 'outlook' 
                              ? 'border-blue-500 bg-blue-500' 
                              : 'border-gray-300 dark:border-gray-600'
                          }`}>
                            {mailReadMethod === 'outlook' && (
                              <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                            )}
                          </div>
                          <Globe className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-2" />
                          <span className="font-medium text-gray-900 dark:text-white">Outlook API</span>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-400 ml-7">
                          Sử dụng Microsoft Graph API với OAuth2
                        </p>
                        <div className="mt-2 ml-7">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                            ✅ Ổn định
                          </span>
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 ml-1">
                            🚀 Nhanh
                          </span>
                        </div>
                      </div>
                      
                      <div 
                        className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          mailReadMethod === 'imap' 
                            ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20' 
                            : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                        }`}
                        onClick={() => setMailReadMethod('imap')}
                      >
                        <div className="flex items-center mb-2">
                          <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                            mailReadMethod === 'imap' 
                              ? 'border-purple-500 bg-purple-500' 
                              : 'border-gray-300 dark:border-gray-600'
                          }`}>
                            {mailReadMethod === 'imap' && (
                              <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                            )}
                          </div>
                          <Mail className="h-5 w-5 text-purple-600 dark:text-purple-400 mr-2" />
                          <span className="font-medium text-gray-900 dark:text-white">IMAP</span>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-400 ml-7">
                          Sử dụng IMAP protocol (chỉ cần email/password)
                        </p>
                        <div className="mt-2 ml-7">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
                            ⚠️ Có thể bị tắt
                          </span>
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200 ml-1">
                            🔐 Đơn giản
                          </span>
                        </div>
                      </div>
                      
                      <div 
                        className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          mailReadMethod === 'scraping' 
                            ? 'border-orange-500 bg-orange-50 dark:bg-orange-900/20' 
                            : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                        }`}
                        onClick={() => setMailReadMethod('scraping')}
                      >
                        <div className="flex items-center mb-2">
                          <div className={`w-4 h-4 rounded-full border-2 mr-3 ${
                            mailReadMethod === 'scraping' 
                              ? 'border-orange-500 bg-orange-500' 
                              : 'border-gray-300 dark:border-gray-600'
                          }`}>
                            {mailReadMethod === 'scraping' && (
                              <div className="w-2 h-2 bg-white rounded-full mx-auto mt-0.5"></div>
                            )}
                          </div>
                          <Globe className="h-5 w-5 text-orange-600 dark:text-orange-400 mr-2" />
                          <span className="font-medium text-gray-900 dark:text-white">Web Scraping</span>
                        </div>
                        <p className="text-xs text-gray-600 dark:text-gray-400 ml-7">
                          Tự động đăng nhập web Outlook (không cần token)
                        </p>
                        <div className="mt-2 ml-7">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200">
                            🤖 Tự động
                          </span>
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 ml-1">
                            🔓 Không cần API
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* IMAP Settings (only show when IMAP is selected) */}
                  {mailReadMethod === 'imap' && (
                    <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
                      <h5 className="text-sm font-medium text-purple-900 dark:text-purple-100 mb-3 flex items-center">
                        <Settings className="h-4 w-4 mr-2" />
                        Cài đặt IMAP Server
                      </h5>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-purple-700 dark:text-purple-300 mb-1">
                            IMAP Host
                          </label>
                          <input
                            type="text"
                            value={imapSettings.host}
                            onChange={(e) => setImapSettings(prev => ({ ...prev, host: e.target.value }))}
                            className="w-full px-2 py-1 text-sm border border-purple-300 dark:border-purple-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                            placeholder="outlook.office365.com"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-xs font-medium text-purple-700 dark:text-purple-300 mb-1">
                            Port
                          </label>
                          <input
                            type="number"
                            value={imapSettings.port}
                            onChange={(e) => setImapSettings(prev => ({ ...prev, port: parseInt(e.target.value) }))}
                            className="w-full px-2 py-1 text-sm border border-purple-300 dark:border-purple-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                            placeholder="993"
                          />
                        </div>
                        
                        <div className="flex items-center">
                          <input
                            type="checkbox"
                            id="imap-secure"
                            checked={imapSettings.secure}
                            onChange={(e) => setImapSettings(prev => ({ ...prev, secure: e.target.checked }))}
                            className="rounded border-purple-300 text-purple-600 focus:ring-purple-500 mr-2"
                          />
                          <label htmlFor="imap-secure" className="text-xs font-medium text-purple-700 dark:text-purple-300">
                            SSL/TLS
                          </label>
                        </div>
                      </div>
                      
                      <div className="mt-3">
                        <label className="block text-xs font-medium text-purple-700 dark:text-purple-300 mb-1">
                          IMAP Timeout (giây)
                        </label>
                        <input
                          type="number"
                          value={imapTimeoutSeconds}
                          onChange={(e) => setImapTimeoutSeconds(parseInt(e.target.value) || 90)}
                          min={30}
                          max={300}
                          className="w-full px-2 py-1 text-sm border border-purple-300 dark:border-purple-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                          placeholder="90"
                        />
                        <p className="text-xs text-purple-600 dark:text-purple-400 mt-1">
                          Thời gian chờ kết nối IMAP (30-300 giây). Tăng lên nếu kết nối chậm.
                        </p>
                      </div>
                      
                      <div className="mt-3 space-y-2">
                        <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded">
                          <div className="flex items-start space-x-2">
                            <AlertCircle className="h-4 w-4 text-yellow-600 dark:text-yellow-400 mt-0.5 flex-shrink-0" />
                            <div className="text-xs text-yellow-800 dark:text-yellow-200">
                              <strong>Lưu ý:</strong> IMAP có thể bị Microsoft tắt cho tài khoản mới. 
                              Nếu IMAP không hoạt động, hãy thử sử dụng Web Scraping method.
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Web Scraping Settings (only show when Scraping is selected) */}
                  {mailReadMethod === 'scraping' && (
                    <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
                      <h5 className="text-sm font-medium text-orange-900 dark:text-orange-100 mb-3 flex items-center">
                        <Settings className="h-4 w-4 mr-2" />
                        Cài đặt Web Scraping
                      </h5>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-xs font-medium text-orange-700 dark:text-orange-300 mb-1">
                            Timeout (giây)
                          </label>
                          <input
                            type="number"
                            value={scrapingSettings.timeout}
                            onChange={(e) => setScrapingSettings(prev => ({ ...prev, timeout: parseInt(e.target.value) || 120 }))}
                            min={60}
                            max={300}
                            className="w-full px-2 py-1 text-sm border border-orange-300 dark:border-orange-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                            placeholder="120"
                          />
                        </div>
                        
                        <div>
                          <label className="block text-xs font-medium text-orange-700 dark:text-orange-300 mb-1">
                            Wait Load (ms)
                          </label>
                          <input
                            type="number"
                            value={scrapingSettings.waitForLoad}
                            onChange={(e) => setScrapingSettings(prev => ({ ...prev, waitForLoad: parseInt(e.target.value) || 5000 }))}
                            min={1000}
                            max={15000}
                            className="w-full px-2 py-1 text-sm border border-orange-300 dark:border-orange-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                            placeholder="5000"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              id="scraping-headless"
                              checked={scrapingSettings.headless}
                              onChange={(e) => setScrapingSettings(prev => ({ ...prev, headless: e.target.checked }))}
                              className="rounded border-orange-300 text-orange-600 focus:ring-orange-500 mr-2"
                            />
                            <label htmlFor="scraping-headless" className="text-xs font-medium text-orange-700 dark:text-orange-300">
                              Headless Mode
                            </label>
                          </div>
                          
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              id="scraping-debug"
                              checked={scrapingSettings.debugMode}
                              onChange={(e) => setScrapingSettings(prev => ({ ...prev, debugMode: e.target.checked }))}
                              className="rounded border-orange-300 text-orange-600 focus:ring-orange-500 mr-2"
                            />
                            <label htmlFor="scraping-debug" className="text-xs font-medium text-orange-700 dark:text-orange-300">
                              Debug Mode
                            </label>
                          </div>
                          
                          <button
                            onClick={async () => {
                              addProgressLog('🧪 Testing Puppeteer...')
                              try {
                                const response = await fetch('/api/outlook/test-puppeteer', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ debugMode: scrapingSettings.debugMode })
                                })
                                const data = await response.json()
                                if (data.success) {
                                  addProgressLog('✅ Puppeteer test successful!')
                                } else {
                                  addProgressLog(`❌ Puppeteer test failed: ${data.message}`)
                                }
                              } catch (error) {
                                addProgressLog(`❌ Puppeteer test error: ${error}`)
                              }
                            }}
                            className="px-3 py-1 text-xs bg-orange-100 dark:bg-orange-900 text-orange-700 dark:text-orange-300 border border-orange-300 dark:border-orange-600 rounded hover:bg-orange-200 dark:hover:bg-orange-800 transition-colors"
                          >
                            Test Puppeteer
                          </button>
                        </div>
                      </div>
                      
                      <div className="mt-3 space-y-2">
                        <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded">
                          <div className="flex items-start space-x-2">
                            <Globe className="h-4 w-4 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                            <div className="text-xs text-blue-800 dark:text-blue-200">
                              <strong>Web Scraping:</strong> Tự động mở trình duyệt, đăng nhập Outlook và đọc email. 
                              Chậm hơn nhưng hoạt động khi API bị chặn.
                            </div>
                          </div>
                        </div>
                        
                        <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded">
                          <div className="flex items-start space-x-2">
                            <AlertCircle className="h-4 w-4 text-yellow-600 dark:text-yellow-400 mt-0.5 flex-shrink-0" />
                            <div className="text-xs text-yellow-800 dark:text-yellow-200">
                              <strong>Lưu ý:</strong> Cần cài đặt Puppeteer. Có thể bị phát hiện bởi anti-bot. 
                              Tắt Headless để debug.
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Số email tối đa mỗi lần đọc
                    </label>
                    <input
                      type="number"
                      value={maxEmailsPerRead}
                      onChange={(e) => setMaxEmailsPerRead(parseInt(e.target.value) || 10)}
                      min={1}
                      max={50}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Timeout (giây)
                    </label>
                    <input
                      type="number"
                      value={timeoutSeconds}
                      onChange={(e) => setTimeoutSeconds(parseInt(e.target.value) || 30)}
                      min={10}
                      max={120}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Proxy Settings */}
              <div className="border-b border-gray-200 dark:border-gray-700 pb-6">
                <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Globe className="h-5 w-5 mr-2" />
                  Cài đặt Proxy
                </h4>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Proxy mặc định
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="http://proxy:port"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div>
                      <label className="text-sm font-medium text-gray-900 dark:text-white">
                        Sử dụng proxy cho tất cả
                      </label>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Áp dụng proxy cho tất cả tài khoản
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Security Settings */}
              <div>
                <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                  <Shield className="h-5 w-5 mr-2" />
                  Cài đặt bảo mật
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div>
                      <label className="text-sm font-medium text-gray-900 dark:text-white">
                        Lưu mật khẩu
                      </label>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Lưu mật khẩu trong database
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div>
                      <label className="text-sm font-medium text-gray-900 dark:text-white">
                        Auto login test
                      </label>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Tự động test login khi thêm
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center mt-8">
              <button
                onClick={resetSettings}
                className="px-4 py-2 text-orange-600 hover:text-orange-700 bg-orange-50 hover:bg-orange-100 dark:bg-orange-900 dark:hover:bg-orange-800 dark:text-orange-400 rounded-lg transition-colors flex items-center"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Reset mặc định
              </button>
              
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowSettings(false)}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                >
                  Hủy
                </button>
                <button
                  onClick={() => {
                    saveSettings()
                    setShowSettings(false)
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center"
                >
                  <Database className="h-4 w-4 mr-2" />
                  Lưu cài đặt
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <style jsx>{`
        @keyframes toast-progress {
          from { 
            transform: translateX(0%);
          }
          to { 
            transform: translateX(-100%);
          }
        }
        
        .animate-in {
          animation: slide-in-from-right 0.7s ease-out;
        }
        
        @keyframes slide-in-from-right {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0%);
            opacity: 1;
          }
        }
      `}</style>

      {/* Stored Emails Modal */}
      {showStoredEmailsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-4xl mx-4 max-h-[80vh] overflow-hidden">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                📧 Email đã lưu - {selectedAccountForStoredEmails}
              </h3>
              <button
                onClick={() => setShowStoredEmailsModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Database className="h-5 w-5 text-blue-600 dark:text-blue-400 mr-2" />
                  <span className="text-sm text-blue-800 dark:text-blue-200">
                    Hiển thị {storedEmails.length} email đã lưu trong localStorage
                  </span>
                </div>
                {storedEmails.length > 0 && (
                  <button
                    onClick={() => handleDeleteStoredEmails(selectedAccountForStoredEmails)}
                    className="flex items-center px-3 py-1 bg-red-100 hover:bg-red-200 dark:bg-red-900 dark:hover:bg-red-800 text-red-700 dark:text-red-300 rounded-lg text-sm transition-colors"
                    title="Xóa tất cả email đã lưu"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Xóa tất cả
                  </button>
                )}
              </div>
            </div>
            
            <div className="overflow-y-auto max-h-96">
              {storedEmails.length > 0 ? (
                <div className="space-y-3">
                  {storedEmails.map((email, index) => (
                    <div 
                      key={index} 
                      className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors relative group"
                    >
                      <div 
                        className="cursor-pointer"
                        onClick={() => handleViewEmailDetail(email)}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-medium text-gray-900 dark:text-white text-sm pr-8">
                            {email.subject}
                          </h4>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {email.received_time}
                          </span>
                        </div>
                        
                        <div className="flex justify-between items-center text-sm">
                          <span className="text-gray-600 dark:text-gray-300">
                            📧 Từ: {email.sender}
                          </span>
                          <span className="px-2 py-1 bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300 rounded text-xs">
                            📁 {email.folder}
                          </span>
                        </div>
                        
                        {email.body && (
                          <div className="mt-2 p-2 bg-gray-50 dark:bg-gray-600 rounded text-xs text-gray-600 dark:text-gray-300 max-h-20 overflow-y-auto">
                            {formatEmailContent(email.body, email.body_type).substring(0, 200)}...
                          </div>
                        )}
                        
                        <div className="mt-2 text-xs text-blue-600 dark:text-blue-400">
                          👆 Click để xem toàn bộ nội dung
                        </div>
                      </div>
                      
                      {/* Delete button for individual email */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDeleteSpecificEmail(index, email.subject || 'Email không có tiêu đề')
                        }}
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-red-100 hover:bg-red-200 dark:bg-red-900 dark:hover:bg-red-800 text-red-600 dark:text-red-400 p-1 rounded-full"
                        title="Xóa email này"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Mail className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">
                    Chưa có email nào được lưu cho tài khoản này
                  </p>
                  <p className="text-xs text-gray-400 dark:text-gray-500 mt-2">
                    Hãy đọc mail trước để lưu vào localStorage
                  </p>
                </div>
              )}
            </div>
            
            <div className="flex justify-end items-center mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
              <button
                onClick={() => setShowStoredEmailsModal(false)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg transition-colors"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Email Detail Modal */}
      {showEmailDetailModal && selectedEmailDetail && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-5xl mx-4 max-h-[90vh] overflow-hidden">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                📧 Chi tiết email
              </h3>
              <button
                onClick={() => setShowEmailDetailModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            {/* Email Header */}
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                    Tiêu đề
                  </label>
                  <p className="text-sm font-medium text-gray-900 dark:text-white mt-1">
                    {selectedEmailDetail.subject || selectedEmailDetail.title || 'Không có tiêu đề'}
                  </p>
                </div>
                
                <div>
                  <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                    Thời gian nhận
                  </label>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                    {selectedEmailDetail.received_time || selectedEmailDetail.time || selectedEmailDetail.date || 'Không có thời gian'}
                  </p>
                </div>
                
                <div>
                  <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                    Người gửi
                  </label>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                    {selectedEmailDetail.sender || selectedEmailDetail.from || selectedEmailDetail.author || 'Không có người gửi'}
                  </p>
                </div>
                
                <div>
                  <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wide">
                    Thư mục
                  </label>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                    📁 {selectedEmailDetail.folder || selectedEmailDetail.mailbox || 'Inbox'}
                  </p>
                </div>
              </div>
            </div>
            
            {/* Email Content */}
            <div className="border border-gray-200 dark:border-gray-600 rounded-lg">
              <div className="bg-gray-50 dark:bg-gray-700 px-4 py-2 border-b border-gray-200 dark:border-gray-600">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    Nội dung email
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {(() => {
                      const content = selectedEmailDetail.htmlContent || selectedEmailDetail.body || selectedEmailDetail.content || selectedEmailDetail.text || selectedEmailDetail.message || ''
                      return content.includes('<html') || content.includes('<!DOCTYPE') || content.includes('<') ? '🌐 HTML' : '📝 Text'
                    })()}
                  </span>
                </div>
              </div>
              
              <div className="p-4 max-h-96 overflow-y-auto">
                {(() => {
                  // Try to get content from various possible fields
                  const content = selectedEmailDetail.htmlContent || selectedEmailDetail.body || selectedEmailDetail.content || selectedEmailDetail.text || selectedEmailDetail.message || 'Không có nội dung'
                  const isHtml = content.includes('<html') || content.includes('<!DOCTYPE') || content.includes('<')
                  
                  if (isHtml) {
                    return (
                      <div 
                        className="prose prose-sm max-w-none dark:prose-invert"
                        dangerouslySetInnerHTML={{ 
                          __html: getSafeHtmlContent(content, 'html') 
                        }}
                      />
                    )
                  } else {
                    return (
                      <div className="whitespace-pre-wrap text-sm text-gray-700 dark:text-gray-300">
                        {content}
                      </div>
                    )
                  }
                })()}
              </div>
            </div>
            
            {/* Actions */}
            <div className="flex justify-between items-center mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
              <div className="flex space-x-2">
                <button
                  onClick={() => {
                    const content = selectedEmailDetail.htmlContent || selectedEmailDetail.body || selectedEmailDetail.content || selectedEmailDetail.text || selectedEmailDetail.message || ''
                    navigator.clipboard.writeText(content)
                    showToast('success', 'Thành công', 'Đã copy nội dung email')
                  }}
                  className="px-3 py-2 text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 dark:bg-blue-900 dark:hover:bg-blue-800 dark:text-blue-400 rounded-lg transition-colors text-sm"
                >
                  <Copy className="h-4 w-4 mr-1" />
                  Copy nội dung
                </button>
                
                <button
                  onClick={() => {
                    const content = selectedEmailDetail.htmlContent || selectedEmailDetail.body || selectedEmailDetail.content || selectedEmailDetail.text || selectedEmailDetail.message || ''
                    const emailInfo = `Subject: ${selectedEmailDetail.subject}\nFrom: ${selectedEmailDetail.sender}\nTime: ${selectedEmailDetail.received_time || selectedEmailDetail.time}\nFolder: ${selectedEmailDetail.folder || 'Inbox'}\n\nContent:\n${content}`
                    navigator.clipboard.writeText(emailInfo)
                    showToast('success', 'Thành công', 'Đã copy toàn bộ thông tin email')
                  }}
                  className="px-3 py-2 text-green-600 hover:text-green-700 bg-green-50 hover:bg-green-100 dark:bg-green-900 dark:hover:bg-green-800 dark:text-green-400 rounded-lg transition-colors text-sm"
                >
                  <FileText className="h-4 w-4 mr-1" />
                  Copy tất cả
                </button>
              </div>
              
              <button
                onClick={() => setShowEmailDetailModal(false)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 rounded-lg transition-colors"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Status Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-blue-600 text-white px-4 py-2 z-40">
        <div className="max-w-screen-2xl mx-auto flex items-center justify-between text-sm lg:ml-64">
          <div className="flex items-center space-x-6">
            <span>Bôi đen: <strong>0</strong></span>
            <span>Đã chọn: <strong>{selectedAccounts.length}</strong></span>
            <span>Tất cả: <strong>{accounts.length}</strong></span>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <span>Gói:</span>
              <span className={`px-2 py-1 rounded text-xs font-bold ${
                userPlan === 'premium' ? 'bg-purple-500 text-white' :
                userPlan === 'enterprise' ? 'bg-gold-500 text-white' :
                'bg-gray-500 text-white'
              }`}>
                {userPlan.toUpperCase()}
              </span>
            </div>
            <span>Còn lại: <strong>{subscriptionDaysLeft} ngày</strong></span>
            <button
              onClick={() => window.location.reload()}
              className="text-white hover:text-blue-200 transition-colors"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
            <span className="text-gray-200 dark:text-gray-300 font-medium text-xs"><VersionBadge prefix="FTool - Outlook" /></span>
          </div>
        </div>
      </div>

      {/* Context Menu */}
      {contextMenu.visible && (
        <div 
          className="fixed z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border border-gray-200/50 dark:border-gray-700/50 rounded-xl shadow-2xl py-2 min-w-[200px] animate-in fade-in-0 zoom-in-95 duration-200"
          style={{ 
            left: contextMenu.x, 
            top: contextMenu.y,
            transform: 'translate(-50%, -100%)'
          }}
        >
          {/* Header */}
          <div className="px-3 py-2 border-b border-gray-100 dark:border-gray-800">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-md flex items-center justify-center">
                <Mail className="w-3 h-3 text-white" />
              </div>
              <div>
                <span className="text-sm font-semibold text-gray-900 dark:text-white">Tài khoản Outlook</span>
              </div>
            </div>
          </div>
          
          {/* Selection Actions */}
          <div className="px-2 py-1">
            <button
              onClick={() => handleContextMenuSelect(contextMenu.accountId!)}
              className="w-full px-3 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-green-50 hover:to-emerald-50 dark:hover:from-green-900/20 dark:hover:to-emerald-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
            >
              <div className="w-6 h-6 bg-green-100 dark:bg-green-900/30 rounded-md flex items-center justify-center group-hover:bg-green-200 dark:group-hover:bg-green-800/40 transition-colors">
                <UserCheck className="w-3 h-3 text-green-600 dark:text-green-400" />
              </div>
              <span className="font-medium">
                {selectedAccounts.includes(contextMenu.accountId!) ? 'Bỏ chọn' : 'Chọn'}
              </span>
            </button>
            
            <button
              onClick={handleSelectHighlighted}
              disabled={highlightedAccounts.length === 0}
              className={`w-full px-3 py-2 text-left text-sm transition-all duration-200 rounded-lg flex items-center space-x-2 group ${
                highlightedAccounts.length === 0
                  ? 'text-gray-400 dark:text-gray-500 cursor-not-allowed'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-orange-50 hover:to-amber-50 dark:hover:from-orange-900/20 dark:hover:to-amber-900/20'
              }`}
            >
              <div className={`w-6 h-6 rounded-md flex items-center justify-center transition-colors ${
                highlightedAccounts.length === 0
                  ? 'bg-gray-100 dark:bg-gray-800'
                  : 'bg-orange-100 dark:bg-orange-900/30 group-hover:bg-orange-200 dark:group-hover:bg-orange-800/40'
              }`}>
                <Users className="w-3 h-3 text-orange-600 dark:text-orange-400" />
              </div>
              <span className="font-medium">
                Chọn bôi đen ({highlightedAccounts.length})
              </span>
            </button>
            
            <button
              onClick={handleDeselectAll}
              className="w-full px-3 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-blue-50 hover:to-indigo-50 dark:hover:from-blue-900/20 dark:hover:to-indigo-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
            >
              <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900/30 rounded-md flex items-center justify-center group-hover:bg-blue-200 dark:group-hover:bg-blue-800/40 transition-colors">
                <X className="w-3 h-3 text-blue-600 dark:text-blue-400" />
              </div>
              <span className="font-medium">Bỏ chọn tất cả</span>
            </button>
            
            <button
              onClick={() => setHighlightedAccounts([])}
              disabled={highlightedAccounts.length === 0}
              className={`w-full px-3 py-2 text-left text-sm transition-all duration-200 rounded-lg flex items-center space-x-2 group ${
                highlightedAccounts.length === 0
                  ? 'text-gray-400 dark:text-gray-500 cursor-not-allowed'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gradient-to-r hover:from-red-50 hover:to-pink-50 dark:hover:from-red-900/20 dark:hover:to-pink-900/20'
              }`}
            >
              <div className={`w-6 h-6 rounded-md flex items-center justify-center transition-colors ${
                highlightedAccounts.length === 0
                  ? 'bg-gray-100 dark:bg-gray-800'
                  : 'bg-red-100 dark:bg-red-900/30 group-hover:bg-red-200 dark:group-hover:bg-red-800/40'
              }`}>
                <X className="w-3 h-3 text-red-600 dark:text-red-400" />
              </div>
              <span className="font-medium">
                Xóa bôi đen ({highlightedAccounts.length})
              </span>
            </button>

                  

                  {/* Copy Selected Accounts Section */}
                  {selectedAccounts.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-100 dark:border-gray-800">
                      <div className="flex items-center space-x-2 mb-2">
                        <Users className="w-3 h-3 text-green-600 dark:text-green-400" />
                        <span className="text-xs font-semibold text-green-700 dark:text-green-300">
                          Copy {selectedAccounts.length} tài khoản đã chọn
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-1">
                        <button
                          onClick={() => handleCopySelectedAccounts('email')}
                          className="px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20 rounded transition-colors font-medium"
                        >
                          Email
                        </button>
                        <button
                          onClick={() => handleCopySelectedAccounts('password')}
                          className="px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20 rounded transition-colors font-medium"
                        >
                          Password
                        </button>
                        <button
                          onClick={() => handleCopySelectedAccounts('2fa')}
                          className="px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/20 rounded transition-colors font-medium"
                        >
                          2FA
                        </button>
                      </div>
                      
                      <button
                        onClick={() => handleCopySelectedAccounts('full')}
                        className="w-full mt-1 px-2 py-1 text-xs text-green-700 dark:text-green-300 hover:bg-gradient-to-r hover:from-green-50 hover:to-emerald-50 dark:hover:from-green-900/20 dark:hover:to-emerald-900/20 rounded transition-all duration-200 font-medium"
                      >
                        Email + Password
                      </button>
                    </div>
                  )}
                </div>
                
                {/* Facebook Info Section */}
                {showFacebookInfo && (
                  <div className="px-3 py-2 border-t border-gray-100 dark:border-gray-800">
                    <div className="flex items-center space-x-2 mb-2">
                      <Users className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                      <span className="text-xs font-semibold text-gray-900 dark:text-white">Facebook</span>
                    </div>
                    
                    {(() => {
                      const fbAccount = getFacebookAccountInfo(contextMenu.accountId ? accounts.find(acc => acc._id === contextMenu.accountId)?.email : '')
                      if (!fbAccount) {
                        return (
                          <div className="text-xs text-gray-400 dark:text-gray-500 px-2 py-1">
                            Không tìm thấy tài khoản FB
                          </div>
                        )
                      }
                      return (
                        <div className="space-y-2">
                          <div className="text-xs text-gray-600 dark:text-gray-400 px-2 py-1 bg-gray-50 dark:bg-gray-800 rounded">
                            <div className="font-medium text-green-600 dark:text-green-400">
                              UID: {fbAccount.uid}
                            </div>
                            <div>Tên: {fbAccount.name || 'N/A'}</div>
                            <div>Trạng thái: {fbAccount.status || 'N/A'}</div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-1">
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(fbAccount.uid)
                                showToast('success', 'Thành công', 'Đã copy UID Facebook')
                                handleContextMenuClose()
                              }}
                              className="px-2 py-1 text-xs text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded transition-colors font-medium"
                            >
                              Copy UID
                            </button>
                            <button
                              onClick={() => {
                                navigator.clipboard.writeText(fbAccount.mail || '')
                                showToast('success', 'Thành công', 'Đã copy email Facebook')
                                handleContextMenuClose()
                              }}
                              className="px-2 py-1 text-xs text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded transition-colors font-medium"
                            >
                              Copy Email
                            </button>
                          </div>
                          
                          <button
                            onClick={() => {
                              if (contextMenu.accountId) {
                                handleLoginWithFacebookCreds(contextMenu.accountId)
                                handleContextMenuClose()
                              }
                            }}
                            className="w-full mt-2 px-2 py-1 text-xs text-white bg-green-600 hover:bg-green-700 rounded transition-colors font-medium"
                          >
                            Login with FB Mail/Pass
                          </button>
                        </div>
                      )
                    })()}
                  </div>
                )}
          
          {/* Actions Section */}
          <div className="px-2 py-1 border-t border-gray-100 dark:border-gray-800">
            <button
              onClick={() => handleContextMenuDelete(contextMenu.accountId!)}
              className="w-full px-3 py-2 text-left text-sm text-red-600 dark:text-red-400 hover:bg-gradient-to-r hover:from-red-50 hover:to-pink-50 dark:hover:from-red-900/20 dark:hover:to-pink-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
            >
              <div className="w-6 h-6 bg-red-100 dark:bg-red-900/30 rounded-md flex items-center justify-center group-hover:bg-red-200 dark:group-hover:bg-red-800/40 transition-colors">
                <Trash2 className="w-3 h-3 text-red-600 dark:text-red-400" />
              </div>
              <span className="font-medium">Xóa tài khoản</span>
            </button>
            
            {selectedAccounts.length > 0 && (
              <button
                onClick={() => {
                  if (selectedAccounts.length === 0) {
                    showToast('warning', 'Cảnh báo', 'Vui lòng chọn ít nhất một tài khoản để xóa')
                    return
                  }
                  
                  const accountsToDelete = selectedAccounts.map(accountId => {
                    const account = accounts.find(acc => acc._id === accountId)
                    return { id: accountId, email: account?.email || 'Unknown' }
                  })
                  
                  setAccountsToDelete(accountsToDelete)
                  setShowDeleteConfirm(true)
                  handleContextMenuClose()
                }}
                className="w-full px-3 py-2 text-left text-sm text-red-600 dark:text-red-400 hover:bg-gradient-to-r hover:from-red-50 hover:to-pink-50 dark:hover:from-red-900/20 dark:hover:to-pink-900/20 transition-all duration-200 rounded-lg flex items-center space-x-2 group"
              >
                <div className="w-6 h-6 bg-red-100 dark:bg-red-900/30 rounded-md flex items-center justify-center group-hover:bg-red-200 dark:group-hover:bg-red-800/40 transition-colors">
                  <Trash2 className="w-3 h-3 text-red-600 dark:text-red-400" />
                </div>
                <span className="font-medium">Xóa {selectedAccounts.length} tài khoản đã chọn</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Custom Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full mx-4 transform transition-all">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center">
                  <Trash2 className="w-5 h-5 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                    Xác nhận xóa
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Hành động quan trọng
                  </p>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="mb-4">
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  Bạn có chắc chắn muốn xóa <span className="font-semibold text-red-600 dark:text-red-400">{accountsToDelete.length}</span> tài khoản đã chọn?
                </p>
                
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 mb-4">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400" />
                    <span className="text-sm font-medium text-red-800 dark:text-red-200">
                      Hành động này không thể hoàn tác!
                    </span>
                  </div>
                </div>

                {/* List of accounts to delete */}
                <div className="max-h-32 overflow-y-auto">
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Tài khoản sẽ bị xóa:
                  </p>
                  <div className="space-y-1">
                    {accountsToDelete.map((account, index) => (
                      <div key={account.id} className="flex items-center space-x-2 text-sm">
                        <span className="w-5 h-5 bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center text-xs font-medium">
                          {index + 1}
                        </span>
                        <span className="text-gray-600 dark:text-gray-400 font-mono">
                          {account.email}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-end space-x-3 p-6 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false)
                  setAccountsToDelete([])
                }}
                className="px-4 py-2.5 text-gray-700 dark:text-gray-300 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 rounded-xl font-medium transition-colors"
              >
                Hủy
              </button>
              
              <button
                onClick={handleBulkDeleteConfirm}
                className="px-6 py-2.5 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-medium rounded-xl transition-all duration-200 shadow-md hover:shadow-lg hover:shadow-red-500/25 flex items-center space-x-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>Xóa {accountsToDelete.length} tài khoản</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add bottom padding to prevent content overlap */}
      <div className="h-12"></div>
    </div>
  )
}