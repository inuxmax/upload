'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Check, Crown, Star, Zap, Shield, Users, Clock, ArrowRight, 
  Home, BarChart3, Settings, User, LogOut, Sun, Moon, CreditCard,
  Sparkles, Target, Gift, Rocket, Globe, RefreshCw, Wallet, X
} from 'lucide-react';
import Navigation from '../../components/Navigation';
import { useNotification } from '../../components/NotificationSystem';

interface SubscriptionPlan {
  _id: string;
  name: string;
  plan: string;
  duration: number;
  price: number;
  currency: string;
  maxThreads: number;
  features: string[];
  description: string;
  isActive: boolean;
}

interface UserSubscription {
  _id: string;
  plan: string;
  status: 'active' | 'expired' | 'cancelled' | 'pending';
  startDate: string;
  endDate: string;
  amount: number;
  autoRenew: boolean;
}

interface PaymentInfo {
  bankName: string;
  accountNumber: string;
  accountHolder: string;
  transferContent: string;
}

export default function PricingPage() {
  const router = useRouter();
  const { addNotification } = useNotification();
  const [user, setUser] = useState<any>(null);
  const [balance, setBalance] = useState<number>(0);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [userSubscription, setUserSubscription] = useState<UserSubscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [selectedPlanData, setSelectedPlanData] = useState<SubscriptionPlan | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'failed'>('idle');

  useEffect(() => {
    checkAuth();
    loadPlans();
    loadUserSubscription();
  }, []);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        router.push('/auth/login');
        return;
      }

      const response = await fetch('/api/auth/verify', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        setBalance(userData.balance || 0);
      } else {
        localStorage.removeItem('token');
        router.push('/auth/login');
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      router.push('/auth/login');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    router.push('/auth/login');
  };



  const loadPlans = async () => {
    try {
      const response = await fetch('/api/subscription/plans');
      if (response.ok) {
        const data = await response.json();
        setPlans(data.filter((plan: SubscriptionPlan) => plan.isActive));
      }
    } catch (error) {
      console.error('Error loading plans:', error);
    }
  };

  const loadUserSubscription = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      const response = await fetch('/api/subscription/user', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setUserSubscription(data);
      }
    } catch (error) {
      console.error('Error loading user subscription:', error);
    } finally {
      setLoading(false);
    }
  };





  const handleSelectPlan = (plan: SubscriptionPlan) => {
    if (plan.price === 0) {
      // Free plan - activate immediately
      activateFreePlan(plan);
    } else {
      // Paid plan - show balance payment modal
      setSelectedPlan(plan._id);
      setSelectedPlanData(plan);
      setShowPaymentModal(true);
    }
  };

  const activateFreePlan = async (plan: SubscriptionPlan) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/wallet/pay-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          planId: plan._id
        })
      });

      if (response.ok) {
        addNotification({
          type: 'success',
          title: 'Thành công!',
          message: `Gói ${plan.name} đã được kích hoạt.`
        });
        checkAuth(); // Reload user data
        loadUserSubscription();
      }
    } catch (error) {
      console.error('Error activating free plan:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể kích hoạt gói miễn phí.'
      });
    }
  };

  const payWithBalance = async () => {
    if (!selectedPlanData) return;

    setPaymentStatus('processing');

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/wallet/pay-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          planId: selectedPlanData._id
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setPaymentStatus('success');
        
        addNotification({
          type: 'success',
          title: 'Thanh toán thành công!',
          message: `Gói ${selectedPlanData.name} đã được kích hoạt.`
        });

        setTimeout(() => {
          setShowPaymentModal(false);
          setPaymentStatus('idle');
          checkAuth(); // Reload user data to update balance
          loadUserSubscription();
        }, 2000);
      } else {
        setPaymentStatus('failed');
        
        if (data.error === 'Insufficient balance') {
          addNotification({
            type: 'error',
            title: 'Số dư không đủ',
            message: `Bạn cần thêm ${formatPrice(data.shortfall)} để mua gói này.`
          });
        } else {
          addNotification({
            type: 'error',
            title: 'Lỗi thanh toán',
            message: data.error || 'Không thể thanh toán. Vui lòng thử lại.'
          });
        }
        
        setTimeout(() => setPaymentStatus('idle'), 3000);
      }
    } catch (error) {
      console.error('Error processing payment:', error);
      setPaymentStatus('failed');
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Có lỗi xảy ra khi thanh toán.'
      });
      setTimeout(() => setPaymentStatus('idle'), 3000);
    }
  };

  const getPlanIcon = (planType: string) => {
    const type = planType.toLowerCase();
    if (type.includes('free') || type.includes('miễn phí')) return <Users className="w-8 h-8" />;
    if (type.includes('basic') || type.includes('cơ bản')) return <Zap className="w-8 h-8" />;
    if (type.includes('premium') || type.includes('cao cấp')) return <Star className="w-8 h-8" />;
    if (type.includes('enterprise') || type.includes('doanh nghiệp')) return <Crown className="w-8 h-8" />;
    return <Star className="w-8 h-8" />;
  };

  const getPlanGradient = (planType: string) => {
    const type = planType.toLowerCase();
    if (type.includes('free') || type.includes('miễn phí')) return 'from-gray-500 to-gray-600';
    if (type.includes('basic') || type.includes('cơ bản')) return 'from-blue-500 to-blue-600';
    if (type.includes('premium') || type.includes('cao cấp')) return 'from-purple-500 to-purple-600';
    if (type.includes('enterprise') || type.includes('doanh nghiệp')) return 'from-yellow-500 to-orange-500';
    return 'from-indigo-500 to-indigo-600';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('vi-VN');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400 text-lg">Đang tải...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 md:ml-64">
      {/* Header */}
      <Navigation currentPage="pricing" />
      
      {/* Page Title */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-lg shadow-lg">
            <CreditCard className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">MAX Tool</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400">Nâng cấp tài khoản</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-100 to-indigo-100 dark:from-blue-900/20 dark:to-indigo-900/20 px-4 py-2 rounded-full text-blue-700 dark:text-blue-300 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            <span>Nâng cấp tài khoản của bạn</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
            Chọn gói phù hợp với 
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent"> nhu cầu của bạn</span>
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Mở khóa toàn bộ tính năng và tăng hiệu suất làm việc với các gói nâng cấp của chúng tôi
          </p>
        </div>

        {/* Current Subscription */}
        {userSubscription && (
          <div className="mb-12">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-200 dark:border-green-800 rounded-2xl p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-green-500 rounded-xl">
                    <Shield className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-green-900 dark:text-green-100">Gói hiện tại</h3>
                    <p className="text-green-700 dark:text-green-300">
                      <span className="font-medium">{userSubscription.plan.toUpperCase()}</span>
                      {userSubscription.status === 'active' && (
                        <span className="ml-2">• Hết hạn: {formatDate(userSubscription.endDate)}</span>
                      )}
                    </p>
                  </div>
                </div>
                <div className={`px-4 py-2 rounded-full text-sm font-medium ${
                  userSubscription.status === 'active' 
                    ? 'bg-green-100 dark:bg-green-900/40 text-green-800 dark:text-green-200'
                    : 'bg-red-100 dark:bg-red-900/40 text-red-800 dark:text-red-200'
                }`}>
                  {userSubscription.status === 'active' ? 'Đang hoạt động' : 'Đã hết hạn'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => {
            const isPopular = plan.plan.toLowerCase().includes('premium') || plan.plan.toLowerCase().includes('cao cấp');
            const isCurrentPlan = userSubscription?.plan === plan.plan;
            
            return (
              <div
                key={plan._id}
                className={`relative bg-white dark:bg-gray-800 rounded-2xl shadow-xl border-2 transition-all duration-300 hover:shadow-2xl hover:scale-105 ${
                  isPopular 
                    ? 'border-purple-500 dark:border-purple-400' 
                    : 'border-gray-200 dark:border-gray-700'
                } ${
                  isCurrentPlan ? 'ring-4 ring-green-500/20' : ''
                }`}
              >
                {/* Popular Badge */}
                {isPopular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1 rounded-full text-sm font-medium shadow-lg">
                      <span className="flex items-center space-x-1">
                        <Star className="w-4 h-4" />
                        <span>Phổ biến nhất</span>
                      </span>
                    </div>
                  </div>
                )}

                {/* Current Plan Badge */}
                {isCurrentPlan && (
                  <div className="absolute -top-4 right-4">
                    <div className="bg-green-500 text-white px-3 py-1 rounded-full text-xs font-medium shadow-lg">
                      Gói hiện tại
                    </div>
                  </div>
                )}

                <div className="p-8">
                  {/* Plan Header */}
                  <div className="text-center mb-8">
                    <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-r ${getPlanGradient(plan.plan)} text-white mb-4`}>
                      {getPlanIcon(plan.plan)}
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{plan.name}</h3>
                    <p className="text-gray-600 dark:text-gray-400">{plan.description}</p>
                  </div>

                  {/* Price */}
                  <div className="text-center mb-8">
                    <div className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                      {plan.price === 0 ? (
                        <span className="text-green-600">Miễn phí</span>
                      ) : (
                        <span>{formatPrice(plan.price)}</span>
                      )}
                    </div>
                    <p className="text-gray-600 dark:text-gray-400">
                      {plan.duration} tháng
                    </p>
                  </div>

                  {/* Features */}
                  <div className="space-y-4 mb-8">
                    <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                      <span className="text-gray-700 dark:text-gray-300">Luồng tối đa</span>
                      <span className="font-semibold text-gray-900 dark:text-white">
                        {plan.maxThreads === -1 ? 'Không giới hạn' : plan.maxThreads}
                      </span>
                    </div>
                    
                    {plan.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <Check className="w-5 h-5 text-green-500" />
                        </div>
                        <span className="text-gray-700 dark:text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* CTA Button */}
                  <button
                    onClick={() => handleSelectPlan(plan)}
                    disabled={isCurrentPlan && userSubscription?.status === 'active'}
                    className={`w-full py-4 px-6 rounded-xl font-semibold text-lg transition-all duration-300 ${
                      isCurrentPlan && userSubscription?.status === 'active'
                        ? 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                        : isPopular
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg hover:shadow-xl'
                        : `bg-gradient-to-r ${getPlanGradient(plan.plan)} hover:shadow-lg text-white`
                    }`}
                  >
                    {isCurrentPlan && userSubscription?.status === 'active' ? (
                      'Đang sử dụng'
                    ) : plan.price === 0 ? (
                      'Sử dụng miễn phí'
                    ) : (
                      <span className="flex items-center justify-center space-x-2">
                        <span>Nâng cấp ngay</span>
                        <ArrowRight className="w-5 h-5" />
                      </span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Features Comparison */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">So sánh tính năng</h2>
            <p className="text-gray-600 dark:text-gray-400">Xem chi tiết các tính năng của từng gói</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="text-left py-4 px-6 text-gray-900 dark:text-white font-semibold">Tính năng</th>
                  {plans.map((plan) => (
                    <th key={plan._id} className="text-center py-4 px-6 text-gray-900 dark:text-white font-semibold">
                      {plan.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-100 dark:border-gray-700">
                  <td className="py-4 px-6 text-gray-700 dark:text-gray-300">Luồng tối đa</td>
                  {plans.map((plan) => (
                    <td key={plan._id} className="text-center py-4 px-6 text-gray-900 dark:text-white font-medium">
                      {plan.maxThreads === -1 ? 'Không giới hạn' : plan.maxThreads}
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-gray-100 dark:border-gray-700">
                  <td className="py-4 px-6 text-gray-700 dark:text-gray-300">Thời hạn</td>
                  {plans.map((plan) => (
                    <td key={plan._id} className="text-center py-4 px-6 text-gray-900 dark:text-white font-medium">
                      {plan.duration} tháng
                    </td>
                  ))}
                </tr>
                <tr className="border-b border-gray-100 dark:border-gray-700">
                  <td className="py-4 px-6 text-gray-700 dark:text-gray-300">Hỗ trợ 24/7</td>
                  {plans.map((plan) => (
                    <td key={plan._id} className="text-center py-4 px-6">
                      <Check className="w-5 h-5 text-green-500 mx-auto" />
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Câu hỏi thường gặp</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-8">Có thắc mắc? Chúng tôi có câu trả lời</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Làm thế nào để nâng cấp?</h3>
              <p className="text-gray-600 dark:text-gray-400">Chọn gói phù hợp và thanh toán qua chuyển khoản ngân hàng. Hệ thống sẽ tự động kích hoạt sau khi xác nhận thanh toán.</p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Có thể hủy gói bất cứ lúc nào?</h3>
              <p className="text-gray-600 dark:text-gray-400">Bạn có thể hủy gói bất cứ lúc nào. Tuy nhiên, chúng tôi không hoàn tiền cho thời gian chưa sử dụng.</p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Thanh toán có an toàn không?</h3>
              <p className="text-gray-600 dark:text-gray-400">Chúng tôi sử dụng hệ thống thanh toán qua ngân hàng với mã giao dịch duy nhất để đảm bảo an toàn tuyệt đối.</p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Có hỗ trợ kỹ thuật không?</h3>
              <p className="text-gray-600 dark:text-gray-400">Tất cả gói đều được hỗ trợ kỹ thuật 24/7 qua email và chat trực tuyến.</p>
            </div>
          </div>
        </div>
      </main>

      {/* Payment Modal */}
      {showPaymentModal && selectedPlanData && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {/* Header */}
              <div className="text-center mb-6">
                <div className={`inline-flex p-3 rounded-xl bg-gradient-to-r ${getPlanGradient(selectedPlanData.plan)} text-white mb-4`}>
                  {getPlanIcon(selectedPlanData.plan)}
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  Thanh toán gói {selectedPlanData.name}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {formatPrice(selectedPlanData.price)} / {selectedPlanData.duration} tháng
                </p>
              </div>

              {/* Balance Info */}
              <div className="space-y-4 mb-6">
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-gray-600 dark:text-gray-400">Số dư hiện tại:</span>
                    <span className="font-bold text-green-600 dark:text-green-400">{formatPrice(balance)}</span>
                  </div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-gray-600 dark:text-gray-400">Giá gói:</span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">{formatPrice(selectedPlanData.price)}</span>
                  </div>
                  <hr className="border-gray-300 dark:border-gray-600 my-3" />
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Số dư sau thanh toán:</span>
                    <span className={`font-bold ${balance >= selectedPlanData.price ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                      {formatPrice(balance - selectedPlanData.price)}
                    </span>
                  </div>
                </div>

                {balance < selectedPlanData.price && (
                  <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <X className="w-5 h-5 text-red-600 dark:text-red-400 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-red-800 dark:text-red-200 mb-1">
                          Số dư không đủ
                        </p>
                        <p className="text-sm text-red-700 dark:text-red-300">
                          Bạn cần nạp thêm {formatPrice(selectedPlanData.price - balance)} để mua gói này.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Status */}
              <div className="text-center mb-6">
                {paymentStatus === 'processing' && (
                  <div className="flex items-center justify-center space-x-3 text-blue-600 dark:text-blue-400">
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Đang xử lý thanh toán...</span>
                  </div>
                )}
                
                {paymentStatus === 'success' && (
                  <div className="flex items-center justify-center space-x-3 text-green-600 dark:text-green-400">
                    <Check className="w-5 h-5" />
                    <span>Thanh toán thành công!</span>
                  </div>
                )}
                
                {paymentStatus === 'failed' && (
                  <div className="text-red-600 dark:text-red-400">
                    <span>Thanh toán thất bại. Vui lòng thử lại.</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="flex-1 py-3 px-4 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-medium"
                >
                  Hủy
                </button>
                
                {balance < selectedPlanData.price ? (
                  <button
                    onClick={() => router.push('/wallet')}
                    className="flex-1 py-3 px-4 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors font-medium flex items-center justify-center space-x-2"
                  >
                    <Wallet className="w-4 h-4" />
                    <span>Nạp tiền</span>
                  </button>
                ) : (
                  <button
                    onClick={payWithBalance}
                    disabled={paymentStatus === 'processing'}
                    className="flex-1 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                  >
                    <Wallet className="w-4 h-4" />
                    <span>{paymentStatus === 'processing' ? 'Đang xử lý...' : 'Thanh toán'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}