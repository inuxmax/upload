'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Navigation from '@/components/Navigation';
import { 
  User, 
  Shield, 
  RefreshCw, 
  Wallet, 
  Key, 
  LogOut,
  Edit,
  Save,
  X,
  Eye,
  EyeOff,
  Calendar,
  Package,
  CreditCard,
  Download,
  Copy,
  CheckSquare,
  Square,
  ChevronLeft,
  ChevronRight,
  History,
  DollarSign,
  CheckCircle,
  Clock,
  XCircle,
  AlertCircle,
  Search,
  Filter
} from 'lucide-react';

interface UserData {
  _id: string;
  username: string;
  email: string;
  phone?: string;
  fullName?: string;
  telegramChatId?: string;
  device?: string;
  createdAt: string;
  lastLogin?: string;
  balance?: number;
}

interface Order {
  _id: string;
  transId: string;
  productId?: string;
  productName: string;
  amount: number;
  price: number;
  status: string;
  accounts: string[];
  createdAt: string;
}

interface Product {
  id: string;
  name: string;
  category_id?: string;
  category?: string;
}

interface Transaction {
  _id: string;
  transactionId: string;
  amount: number;
  currency: string;
  description: string;
  type: 'IN' | 'OUT';
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  plan: 'free' | 'basic' | 'premium' | 'enterprise';
  transferContent: string;
  bankName: string;
  accountNumber: string;
  processedAt: string;
  createdAt: string;
  userId: {
    username: string;
    email: string;
  };
}

interface Pagination {
  page: number;
  limit: number;
  total: number;
  pages: number;
}

export default function ProfilePage() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('profile');
  const [user, setUser] = useState<UserData | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAccounts, setShowAccounts] = useState<{[key: string]: boolean}>({});
  const [selectedAccounts, setSelectedAccounts] = useState<{[key: string]: string[]}>({});
  const [currentPage, setCurrentPage] = useState<{[key: string]: number}>({});
  const [accountsPerPage] = useState(10);
  
  // Transaction states
  const [transactionPagination, setTransactionPagination] = useState<Pagination>({
    page: 1,
    limit: 10,
    total: 0,
    pages: 0
  });
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [typeFilter, setTypeFilter] = useState<string>('');

  // Profile edit states
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    fullName: '',
    phone: '',
    telegramChatId: ''
  });

  // Password change states
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/auth/login');
      return;
    }
    
    loadUserData();
    loadProducts();
    loadOrders();
    loadTransactions();
  }, [router]);

  const loadUserData = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
        setEditForm({
          fullName: data.user.fullName || '',
          phone: data.user.phone || '',
          telegramChatId: data.user.telegramChatId || ''
        });
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadOrders = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/shop-external/orders', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setOrders(data.orders || data.data || []);
      }
    } catch (error) {
      console.error('Error loading orders:', error);
    }
  };

  const loadProducts = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/shop-external/products', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (data.success && Array.isArray(data.products)) {
        setProducts(data.products);
      }
    } catch (error) {
      // silent
    }
  };

  const getOrderProductName = (order: Order) => {
    const found = (products || []).find(p => String(p.id) === String(order.productId))?.name;
    return found || order.productName || 'Sản phẩm';
  };

  const loadTransactions = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      const params = new URLSearchParams({
        page: transactionPagination.page.toString(),
        limit: transactionPagination.limit.toString()
      });
      if (statusFilter) params.append('status', statusFilter);
      if (typeFilter) params.append('type', typeFilter);

      const response = await fetch(`/api/transactions/user?${params}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setTransactions(data.transactions);
        setTransactionPagination(data.pagination);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
  };

  const handleSaveProfile = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/user/update-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(editForm)
      });

      if (response.ok) {
        alert('Cập nhật thông tin thành công!');
        setIsEditing(false);
        loadUserData();
      } else {
        alert('Có lỗi xảy ra khi cập nhật thông tin');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      alert('Có lỗi xảy ra khi cập nhật thông tin');
    }
  };

  const handleChangePassword = async () => {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      alert('Mật khẩu mới không khớp!');
      return;
    }

    if (passwordForm.newPassword.length < 6) {
      alert('Mật khẩu mới phải có ít nhất 6 ký tự!');
      return;
    }

    if (passwordForm.currentPassword === passwordForm.newPassword) {
      alert('Mật khẩu mới phải khác với mật khẩu hiện tại!');
      return;
    }

    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      alert('Vui lòng điền đầy đủ thông tin!');
      return;
    }

    setIsChangingPassword(true);

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('Vui lòng đăng nhập lại!');
        router.push('/auth/login');
        return;
      }

      const response = await fetch('/api/user/change-password', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          currentPassword: passwordForm.currentPassword,
          newPassword: passwordForm.newPassword
        })
      });

      const data = await response.json();

      if (response.ok) {
        alert('Đổi mật khẩu thành công!');
        setPasswordForm({
          currentPassword: '',
          newPassword: '',
          confirmPassword: ''
        });
        setShowPasswords({
          current: false,
          new: false,
          confirm: false
        });
      } else {
        alert(data.error || 'Có lỗi xảy ra khi đổi mật khẩu');
      }
    } catch (error) {
      console.error('Error changing password:', error);
      alert('Có lỗi xảy ra khi đổi mật khẩu. Vui lòng thử lại!');
    } finally {
      setIsChangingPassword(false);
    }
  };



  const toggleAccounts = (orderId: string) => {
    setShowAccounts(prev => ({
      ...prev,
      [orderId]: !prev[orderId]
    }));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Đã copy vào clipboard!');
  };

  const downloadOrder = (order: Order) => {
    const content = (order.accounts || []).join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `accounts-order-${order.transId || order._id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const toggleAccountSelection = (orderId: string, account: string) => {
    setSelectedAccounts(prev => {
      const current = prev[orderId] || [];
      const isSelected = current.includes(account);
      
      if (isSelected) {
        return {
          ...prev,
          [orderId]: current.filter(acc => acc !== account)
        };
      } else {
        return {
          ...prev,
          [orderId]: [...current, account]
        };
      }
    });
  };

  const copySelectedAccounts = (orderId: string) => {
    const selected = selectedAccounts[orderId] || [];
    if (selected.length === 0) {
      alert('Vui lòng chọn ít nhất một tài khoản để copy!');
      return;
    }
    
    navigator.clipboard.writeText(selected.join('\n'));
    alert(`Đã copy ${selected.length} tài khoản đã chọn vào clipboard!`);
  };

  const selectAllAccounts = (orderId: string, accounts: string[]) => {
    setSelectedAccounts(prev => ({
      ...prev,
      [orderId]: accounts
    }));
  };

  const clearSelection = (orderId: string) => {
    setSelectedAccounts(prev => ({
      ...prev,
      [orderId]: []
    }));
  };

  const getPaginatedAccounts = (accounts: string[], orderId: string) => {
    const page = currentPage[orderId] || 1;
    const startIndex = (page - 1) * accountsPerPage;
    const endIndex = startIndex + accountsPerPage;
    return accounts.slice(startIndex, endIndex);
  };

  const getTotalPages = (accounts: string[]) => {
    return Math.ceil(accounts.length / accountsPerPage);
  };

  const changePage = (orderId: string, page: number) => {
    setCurrentPage(prev => ({
      ...prev,
      [orderId]: page
    }));
  };

  // Transaction helper functions
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('vi-VN');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800';
      case 'pending':
        return 'text-amber-600 bg-amber-50 dark:bg-amber-900/20 dark:text-amber-400 border-amber-200 dark:border-amber-800';
      case 'failed':
        return 'text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400 border-red-200 dark:border-red-800';
      case 'cancelled':
        return 'text-slate-600 bg-slate-50 dark:bg-slate-900/20 dark:text-slate-400 border-slate-200 dark:border-slate-800';
      default:
        return 'text-slate-600 bg-slate-50 dark:bg-slate-900/20 dark:text-slate-400 border-slate-200 dark:border-slate-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      case 'pending':
        return <Clock className="w-4 h-4" />;
      case 'failed':
        return <XCircle className="w-4 h-4" />;
      case 'cancelled':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Hoàn thành';
      case 'pending':
        return 'Đang xử lý';
      case 'failed':
        return 'Thất bại';
      case 'cancelled':
        return 'Đã hủy';
      default:
        return 'Không xác định';
    }
  };

  const getTypeText = (type: string) => {
    return type === 'IN' ? 'Nhận tiền' : 'Chuyển tiền';
  };

  const getPlanText = (plan: string) => {
    switch (plan) {
      case 'free':
        return 'Miễn phí';
      case 'basic':
        return 'Cơ bản';
      case 'premium':
        return 'Cao cấp';
      case 'enterprise':
        return 'Doanh nghiệp';
      default:
        return plan;
    }
  };

  const handleTransactionPageChange = (page: number) => {
    setTransactionPagination(prev => ({ ...prev, page }));
  };

  const handleExportTransactions = () => {
    const csvContent = [
      ['ID', 'Số tiền', 'Loại', 'Trạng thái', 'Gói', 'Nội dung', 'Ngân hàng', 'Ngày tạo'],
      ...transactions.map(t => [
        t.transactionId,
        formatPrice(t.amount),
        getTypeText(t.type),
        getStatusText(t.status),
        getPlanText(t.plan),
        t.transferContent,
        t.bankName,
        formatDate(t.createdAt)
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `transactions-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredTransactions = transactions.filter(t => {
    if (searchTerm) {
      return (
        t.transactionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.transferContent.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    return true;
  });

  const getNavItemClass = (tab: string) => {
    const baseClass = "flex items-center space-x-3 px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors rounded-lg";
    const activeClass = "bg-blue-100 text-blue-600 border-r-2 border-blue-600";
    
    return activeTab === tab 
      ? `${baseClass} ${activeClass}`
      : baseClass;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navigation currentPage="profile" />
        <div className="flex justify-center items-center py-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation currentPage="profile" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-6">Tài khoản</h2>
              
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab('profile')}
                  className={getNavItemClass('profile')}
                >
                  <User className="w-5 h-5" />
                  <span>Thông tin cá nhân</span>
                </button>
                
                                 <button
                   onClick={() => setActiveTab('orders')}
                   className={getNavItemClass('orders')}
                 >
                   <Package className="w-5 h-5" />
                   <span>Lịch sử mua hàng</span>
                 </button>
                 
                 <button
                   onClick={() => setActiveTab('transactions')}
                   className={getNavItemClass('transactions')}
                 >
                   <History className="w-5 h-5" />
                   <span>Lịch sử giao dịch</span>
                 </button>
                 
                 <button
                   onClick={() => setActiveTab('password')}
                   className={getNavItemClass('password')}
                 >
                   <Key className="w-5 h-5" />
                   <span>Thay đổi mật khẩu</span>
                 </button>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Profile Information */}
            {activeTab === 'profile' && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Thông tin cá nhân</h2>
                  {!isEditing ? (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Edit className="w-4 h-4" />
                      <span>Chỉnh sửa thông tin</span>
                    </button>
                  ) : (
                    <div className="flex space-x-2">
                      <button
                        onClick={handleSaveProfile}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <Save className="w-4 h-4" />
                        <span>Lưu</span>
                      </button>
                      <button
                        onClick={() => setIsEditing(false)}
                        className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                      >
                        <X className="w-4 h-4" />
                        <span>Hủy</span>
                      </button>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tên đăng nhập</label>
                    <input
                      type="text"
                      value={user?.username || ''}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Địa chỉ Email</label>
                    <input
                      type="email"
                      value={user?.email || ''}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Họ và Tên</label>
                    {isEditing ? (
                                              <input
                          type="text"
                          value={editForm.fullName}
                          onChange={(e) => setEditForm({...editForm, fullName: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500"
                        />
                    ) : (
                      <input
                        type="text"
                        value={user?.fullName || ''}
                        disabled
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                      />
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Số điện thoại</label>
                    {isEditing ? (
                                              <input
                          type="tel"
                          value={editForm.phone}
                          onChange={(e) => setEditForm({...editForm, phone: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500"
                        />
                    ) : (
                      <input
                        type="tel"
                        value={user?.phone || ''}
                        disabled
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                      />
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Telegram Chat ID</label>
                    {isEditing ? (
                                              <input
                          type="text"
                          value={editForm.telegramChatId}
                          onChange={(e) => setEditForm({...editForm, telegramChatId: e.target.value})}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500"
                        />
                    ) : (
                      <input
                        type="text"
                        value={user?.telegramChatId || ''}
                        disabled
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                      />
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Thiết bị</label>
                    <input
                      type="text"
                      value={user?.device || ''}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Đăng ký vào lúc</label>
                    <input
                      type="text"
                      value={user?.createdAt ? new Date(user.createdAt).toLocaleString('vi-VN') : ''}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Đăng nhập gần nhất</label>
                    <input
                      type="text"
                      value={user?.lastLogin ? new Date(user.lastLogin).toLocaleString('vi-VN') : ''}
                      disabled
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-gray-700"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Order History */}
            {activeTab === 'orders' && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Lịch sử mua hàng</h2>
                
                {orders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500 text-lg">Chưa có đơn hàng nào</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {orders.map(order => (
                      <div key={order._id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h3 className="font-semibold text-gray-900">{getOrderProductName(order)}</h3>
                            <p className="text-sm text-gray-500">
                              Mã đơn hàng: {order.transId}
                            </p>
                            <p className="text-sm text-gray-500">
                              {new Date(order.createdAt).toLocaleString('vi-VN')}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-green-600">
                              {order.price.toLocaleString('vi-VN')} VNĐ
                            </p>
                            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                              order.status === 'completed' 
                                ? 'bg-green-100 text-green-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {order.status === 'completed' ? 'Hoàn thành' : 'Đang xử lý'}
                            </span>
                          </div>
                        </div>
                        
                                                 <div className="flex items-center justify-between">
                           <div className="flex items-center space-x-4">
                             <span className="text-sm text-gray-600">
                               Số lượng: {order.amount}
                             </span>
                             <span className="text-sm text-gray-600">
                               Tài khoản: {order.accounts.length}
                             </span>
                           </div>
                           
                           <div className="flex items-center space-x-2">
                             <button
                               onClick={() => downloadOrder(order)}
                               className="flex items-center space-x-1 text-green-600 hover:text-green-700 text-sm transition-colors"
                               title="Tải xuống đơn hàng"
                             >
                               <Download className="w-4 h-4" />
                               <span>Tải xuống</span>
                             </button>
                             
                             <button
                               onClick={() => toggleAccounts(order._id)}
                               className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm transition-colors"
                             >
                               {showAccounts[order._id] ? (
                                 <>
                                   <EyeOff className="w-4 h-4" />
                                   <span>Ẩn tài khoản</span>
                                 </>
                               ) : (
                                 <>
                                   <Eye className="w-4 h-4" />
                                   <span>Xem tài khoản</span>
                                 </>
                               )}
                             </button>
                           </div>
                         </div>
                        
                                                 {showAccounts[order._id] && (
                           <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                             <div className="flex justify-between items-center mb-3">
                               <span className="text-sm font-medium text-gray-700">Danh sách tài khoản:</span>
                               <div className="flex items-center space-x-2">
                                 <button
                                   onClick={() => selectAllAccounts(order._id, order.accounts)}
                                   className="flex items-center space-x-1 text-purple-600 hover:text-purple-700 text-sm transition-colors"
                                 >
                                   <CheckSquare className="w-4 h-4" />
                                   <span>Chọn tất cả</span>
                                 </button>
                                 <button
                                   onClick={() => clearSelection(order._id)}
                                   className="flex items-center space-x-1 text-gray-600 hover:text-gray-700 text-sm transition-colors"
                                 >
                                   <Square className="w-4 h-4" />
                                   <span>Bỏ chọn</span>
                                 </button>
                                 <button
                                   onClick={() => copySelectedAccounts(order._id)}
                                   className="flex items-center space-x-1 text-orange-600 hover:text-orange-700 text-sm transition-colors"
                                 >
                                   <Copy className="w-4 h-4" />
                                   <span>Copy đã chọn</span>
                                 </button>
                                 <button
                                   onClick={() => copyToClipboard(order.accounts.join('\n'))}
                                   className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-sm transition-colors"
                                 >
                                   <Copy className="w-4 h-4" />
                                   <span>Copy tất cả</span>
                                 </button>
                               </div>
                             </div>
                             
                             <div className="space-y-2 max-h-40 overflow-y-auto">
                               {getPaginatedAccounts(order.accounts, order._id).map((account, index) => {
                                 const globalIndex = (currentPage[order._id] || 1) * accountsPerPage - accountsPerPage + index;
                                 const isSelected = (selectedAccounts[order._id] || []).includes(account);
                                 
                                 return (
                                   <div key={globalIndex} className="flex items-center space-x-2 text-sm p-2 bg-white rounded border">
                                     <button
                                       onClick={() => toggleAccountSelection(order._id, account)}
                                       className="text-blue-600 hover:text-blue-700 transition-colors"
                                     >
                                       {isSelected ? (
                                         <CheckSquare className="w-4 h-4" />
                                       ) : (
                                         <Square className="w-4 h-4" />
                                       )}
                                     </button>
                                     <span className="font-mono text-gray-700 flex-1">{account}</span>
                                     <button
                                       onClick={() => copyToClipboard(account)}
                                       className="text-blue-600 hover:text-blue-700 transition-colors"
                                     >
                                       <Copy className="w-4 h-4" />
                                     </button>
                                   </div>
                                 );
                               })}
                             </div>
                             
                             {/* Pagination */}
                             {getTotalPages(order.accounts) > 1 && (
                               <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
                                 <div className="text-sm text-gray-600">
                                   Trang {currentPage[order._id] || 1} / {getTotalPages(order.accounts)}
                                 </div>
                                 <div className="flex items-center space-x-2">
                                   <button
                                     onClick={() => changePage(order._id, (currentPage[order._id] || 1) - 1)}
                                     disabled={(currentPage[order._id] || 1) <= 1}
                                     className="p-1 rounded border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                                   >
                                     <ChevronLeft className="w-4 h-4" />
                                   </button>
                                   <button
                                     onClick={() => changePage(order._id, (currentPage[order._id] || 1) + 1)}
                                     disabled={(currentPage[order._id] || 1) >= getTotalPages(order.accounts)}
                                     className="p-1 rounded border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                                   >
                                     <ChevronRight className="w-4 h-4" />
                                   </button>
                                 </div>
                               </div>
                             )}
                           </div>
                         )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

                         {/* Transaction History */}
             {activeTab === 'transactions' && (
               <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                 <h2 className="text-xl font-semibold text-gray-900 mb-6">Lịch sử giao dịch</h2>
                 
                 {/* Filters */}
                 <div className="bg-gray-50 rounded-lg p-4 mb-6">
                   <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
                     <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
                       <div className="relative">
                         <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                         <input
                           type="text"
                           placeholder="Tìm kiếm giao dịch..."
                           value={searchTerm}
                           onChange={(e) => setSearchTerm(e.target.value)}
                           className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500"
                         />
                       </div>
                       <select
                         value={statusFilter}
                         onChange={(e) => setStatusFilter(e.target.value)}
                         className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                       >
                         <option value="">Tất cả trạng thái</option>
                         <option value="completed">Hoàn thành</option>
                         <option value="pending">Đang xử lý</option>
                         <option value="failed">Thất bại</option>
                         <option value="cancelled">Đã hủy</option>
                       </select>
                       <select
                         value={typeFilter}
                         onChange={(e) => setTypeFilter(e.target.value)}
                         className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900"
                       >
                         <option value="">Tất cả loại</option>
                         <option value="IN">Nhận tiền</option>
                         <option value="OUT">Chuyển tiền</option>
                       </select>
                     </div>
                     <div className="flex items-center space-x-3">
                       <button
                         onClick={loadTransactions}
                         className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                       >
                         <RefreshCw className="w-4 h-4" />
                         <span>Làm mới</span>
                       </button>
                       <button
                         onClick={handleExportTransactions}
                         className="flex items-center space-x-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                       >
                         <Download className="w-4 h-4" />
                         <span>Xuất CSV</span>
                       </button>
                     </div>
                   </div>
                 </div>

                 {/* Transactions List */}
                 <div className="overflow-hidden">
                   {filteredTransactions.length === 0 ? (
                     <div className="text-center py-12">
                       <History className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                       <h3 className="text-xl font-semibold text-gray-900 mb-2">
                         Không có giao dịch nào
                       </h3>
                       <p className="text-gray-500">
                         Bạn chưa có giao dịch nào trong lịch sử.
                       </p>
                     </div>
                   ) : (
                     <>
                       <div className="overflow-x-auto">
                         <table className="min-w-full divide-y divide-gray-200">
                           <thead className="bg-gray-50">
                             <tr>
                               <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                 Giao dịch
                               </th>
                               <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                 Số tiền
                               </th>
                               <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                 Loại
                               </th>
                               <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                 Trạng thái
                               </th>
                               <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                 Gói
                               </th>
                               <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                 Ngày tạo
                               </th>
                             </tr>
                           </thead>
                           <tbody className="bg-white divide-y divide-gray-200">
                             {filteredTransactions.map((transaction) => (
                               <tr key={transaction._id} className="hover:bg-gray-50 transition-colors">
                                 <td className="px-6 py-4 whitespace-nowrap">
                                   <div>
                                     <div className="text-sm font-medium text-gray-900">
                                       {transaction.transactionId}
                                     </div>
                                     <div className="text-sm text-gray-500">
                                       {transaction.description}
                                     </div>
                                   </div>
                                 </td>
                                 <td className="px-6 py-4 whitespace-nowrap">
                                   <div className="text-sm font-medium text-gray-900">
                                     {formatPrice(transaction.amount)}
                                   </div>
                                 </td>
                                 <td className="px-6 py-4 whitespace-nowrap">
                                   <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                     transaction.type === 'IN' 
                                       ? 'bg-green-100 text-green-800'
                                       : 'bg-blue-100 text-blue-800'
                                   }`}>
                                     {getTypeText(transaction.type)}
                                   </span>
                                 </td>
                                 <td className="px-6 py-4 whitespace-nowrap">
                                   <div className="flex items-center">
                                     {getStatusIcon(transaction.status)}
                                     <span className={`ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(transaction.status)}`}>
                                       {getStatusText(transaction.status)}
                                     </span>
                                   </div>
                                 </td>
                                 <td className="px-6 py-4 whitespace-nowrap">
                                   <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 border border-purple-200">
                                     {getPlanText(transaction.plan)}
                                   </span>
                                 </td>
                                 <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                   {formatDate(transaction.createdAt)}
                                 </td>
                               </tr>
                             ))}
                           </tbody>
                         </table>
                       </div>

                       {/* Pagination */}
                       {transactionPagination.pages > 1 && (
                         <div className="bg-white px-6 py-3 flex items-center justify-between border-t border-gray-200">
                           <div className="flex-1 flex justify-between sm:hidden">
                             <button
                               onClick={() => handleTransactionPageChange(transactionPagination.page - 1)}
                               disabled={transactionPagination.page === 1}
                               className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                             >
                               Trước
                             </button>
                             <button
                               onClick={() => handleTransactionPageChange(transactionPagination.page + 1)}
                               disabled={transactionPagination.page === transactionPagination.pages}
                               className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                             >
                               Sau
                             </button>
                           </div>
                           <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                             <div>
                               <p className="text-sm text-gray-700">
                                 Hiển thị <span className="font-medium">{(transactionPagination.page - 1) * transactionPagination.limit + 1}</span> đến{' '}
                                 <span className="font-medium">
                                   {Math.min(transactionPagination.page * transactionPagination.limit, transactionPagination.total)}
                                 </span>{' '}
                                 trong tổng số <span className="font-medium">{transactionPagination.total}</span> giao dịch
                               </p>
                             </div>
                             <div>
                               <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px">
                                 <button
                                   onClick={() => handleTransactionPageChange(transactionPagination.page - 1)}
                                   disabled={transactionPagination.page === 1}
                                   className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                                 >
                                   <ChevronLeft className="h-5 w-5" />
                                 </button>
                                 {Array.from({ length: Math.min(5, transactionPagination.pages) }, (_, i) => {
                                   const page = i + 1;
                                   return (
                                     <button
                                       key={page}
                                       onClick={() => handleTransactionPageChange(page)}
                                       className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                                         page === transactionPagination.page
                                           ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                                           : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                                       }`}
                                     >
                                       {page}
                                     </button>
                                   );
                                 })}
                                 <button
                                   onClick={() => handleTransactionPageChange(transactionPagination.page + 1)}
                                   disabled={transactionPagination.page === transactionPagination.pages}
                                   className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                                 >
                                   <ChevronRight className="h-5 w-5" />
                                 </button>
                               </nav>
                             </div>
                           </div>
                         </div>
                       )}
                     </>
                   )}
                 </div>
               </div>
             )}

             {/* Change Password */}
             {activeTab === 'password' && (
               <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                 <h2 className="text-xl font-semibold text-gray-900 mb-6">Thay đổi mật khẩu</h2>
                 
                 <div className="max-w-md space-y-4">
                   <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                     <p className="text-sm text-blue-800">
                       <strong>Lưu ý:</strong> Mật khẩu mới phải có ít nhất 6 ký tự và khác với mật khẩu hiện tại.
                     </p>
                   </div>
                   <div>
                     <label className="block text-sm font-medium text-gray-700 mb-2">Mật khẩu hiện tại</label>
                     <div className="relative">
                       <input
                         type={showPasswords.current ? 'text' : 'password'}
                         value={passwordForm.currentPassword}
                         onChange={(e) => setPasswordForm({...passwordForm, currentPassword: e.target.value})}
                         className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-10 text-gray-900 placeholder-gray-500 ${
                           passwordForm.currentPassword ? 'border-gray-300' : 'border-red-300 focus:ring-red-500'
                         }`}
                         placeholder="Nhập mật khẩu hiện tại"
                         disabled={isChangingPassword}
                       />
                       <button
                         type="button"
                         onClick={() => setShowPasswords({...showPasswords, current: !showPasswords.current})}
                         className="absolute inset-y-0 right-0 pr-3 flex items-center"
                         disabled={isChangingPassword}
                       >
                         {showPasswords.current ? (
                           <EyeOff className="w-5 h-5 text-gray-400" />
                         ) : (
                           <Eye className="w-5 h-5 text-gray-400" />
                         )}
                       </button>
                     </div>
                     {!passwordForm.currentPassword && (
                       <p className="mt-1 text-sm text-red-600">Vui lòng nhập mật khẩu hiện tại</p>
                     )}
                   </div>

                   <div>
                     <label className="block text-sm font-medium text-gray-700 mb-2">Mật khẩu mới</label>
                     <div className="relative">
                       <input
                         type={showPasswords.new ? 'text' : 'password'}
                         value={passwordForm.newPassword}
                         onChange={(e) => setPasswordForm({...passwordForm, newPassword: e.target.value})}
                         className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-10 text-gray-900 placeholder-gray-500 ${
                           passwordForm.newPassword ? 
                             (passwordForm.newPassword.length >= 6 ? 'border-green-300 focus:ring-green-500' : 'border-yellow-300 focus:ring-yellow-500') 
                             : 'border-gray-300'
                         }`}
                         placeholder="Nhập mật khẩu mới (ít nhất 6 ký tự)"
                         disabled={isChangingPassword}
                       />
                       <button
                         type="button"
                         onClick={() => setShowPasswords({...showPasswords, new: !showPasswords.new})}
                         className="absolute inset-y-0 right-0 pr-3 flex items-center"
                         disabled={isChangingPassword}
                       >
                         {showPasswords.new ? (
                           <EyeOff className="w-5 h-5 text-gray-400" />
                         ) : (
                           <Eye className="w-5 h-5 text-gray-400" />
                         )}
                       </button>
                     </div>
                     {passwordForm.newPassword && passwordForm.newPassword.length < 6 && (
                       <p className="mt-1 text-sm text-yellow-600">Mật khẩu phải có ít nhất 6 ký tự</p>
                     )}
                     {passwordForm.newPassword && passwordForm.newPassword.length >= 6 && (
                       <p className="mt-1 text-sm text-green-600">✓ Mật khẩu hợp lệ</p>
                     )}
                   </div>

                   <div>
                     <label className="block text-sm font-medium text-gray-700 mb-2">Xác nhận mật khẩu mới</label>
                     <div className="relative">
                       <input
                         type={showPasswords.confirm ? 'text' : 'password'}
                         value={passwordForm.confirmPassword}
                         onChange={(e) => setPasswordForm({...passwordForm, confirmPassword: e.target.value})}
                         className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-10 text-gray-900 placeholder-gray-500 ${
                           passwordForm.confirmPassword ? 
                             (passwordForm.newPassword === passwordForm.confirmPassword ? 'border-green-300 focus:ring-green-500' : 'border-red-300 focus:ring-red-500') 
                             : 'border-gray-300'
                         }`}
                         placeholder="Nhập lại mật khẩu mới"
                         disabled={isChangingPassword}
                       />
                       <button
                         type="button"
                         onClick={() => setShowPasswords({...showPasswords, confirm: !showPasswords.confirm})}
                         className="absolute inset-y-0 right-0 pr-3 flex items-center"
                         disabled={isChangingPassword}
                       >
                         {showPasswords.confirm ? (
                           <EyeOff className="w-5 h-5 text-gray-400" />
                         ) : (
                           <Eye className="w-5 h-5 text-gray-400" />
                         )}
                       </button>
                     </div>
                     {passwordForm.confirmPassword && passwordForm.newPassword !== passwordForm.confirmPassword && (
                       <p className="mt-1 text-sm text-red-600">Mật khẩu xác nhận không khớp</p>
                     )}
                     {passwordForm.confirmPassword && passwordForm.newPassword === passwordForm.confirmPassword && passwordForm.newPassword.length >= 6 && (
                       <p className="mt-1 text-sm text-green-600">✓ Mật khẩu xác nhận khớp</p>
                     )}
                   </div>

                   <button
                     onClick={handleChangePassword}
                     disabled={isChangingPassword}
                     className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                   >
                     {isChangingPassword ? (
                       <>
                         <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                         <span>Đang xử lý...</span>
                       </>
                     ) : (
                       <>
                         <Key className="w-4 h-4" />
                         <span>Đổi mật khẩu</span>
                       </>
                     )}
                   </button>


                 </div>
               </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
}
