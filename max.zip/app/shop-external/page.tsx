'use client'

import React, { useState, useEffect } from 'react'
import { 
  Search, 
  ShoppingCart, 
  Package, 
  DollarSign, 
  Download, 
  Copy, 
  X, 
  Plus, 
  Minus, 
  CheckCircle, 
  AlertCircle,
  TrendingUp,
  Clock,
  RefreshCw,
  Grid3X3,
  List,
  History
} from 'lucide-react'
import Navigation from '../../components/Navigation'

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category_id: string;
  category: string;
  stock: number;
  image?: string;
  discount?: number;
  content?: string;
  sold?: number;
  purchased?: number;
  features?: string[];
}

interface Order {
  _id: string;
  productId: string;
  productName: string;
  amount: number;
  price: number;
  accounts: string[];
  status: 'pending' | 'completed' | 'failed';
  createdAt: string;
}

interface NotificationModal {
  show: boolean;
  type: 'success' | 'error' | 'info';
  title: string;
  message: string;
  details?: any;
  accounts?: string[]; // Danh sách tài khoản vừa mua
}

export default function ShopExternal() {
  const [products, setProducts] = useState<Product[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [userBalance, setUserBalance] = useState(0)
  const [showPurchaseModal, setShowPurchaseModal] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [purchaseAmount, setPurchaseAmount] = useState(1)
  const [purchasing, setPurchasing] = useState(false)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [showOrderHistory, setShowOrderHistory] = useState(false)
  const [currentOrderPage, setCurrentOrderPage] = useState(1)
  const [orderPageSize] = useState(5)
  const [notification, setNotification] = useState<NotificationModal>({
    show: false,
    type: 'info',
    title: '',
    message: ''
  })
  const [showAnnouncement, setShowAnnouncement] = useState(true)

  const showNotification = (type: 'success' | 'error' | 'info', title: string, message: string, details?: any, accounts?: string[]) => {
    setNotification({
      show: true,
      type,
      title,
      message,
      details,
      accounts
    })
  }

  const hideNotification = () => {
    setNotification(prev => ({ ...prev, show: false }))
  }

  const parseContentToFeatures = (content: string): string[] => {
    if (!content) return [];
    const features = content
      .split(/[•\-\*]/)
      .map(feature => feature.trim())
      .filter(feature => feature.length > 0)
      .slice(0, 10);
    return features;
  };

  const loadUserBalance = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (data.success) {
        setUserBalance(data.user.balance || 0);
      }
    } catch (error) {
      // Handle error silently
    }
  };

  const loadProducts = async () => {
    try {
      const token = localStorage.getItem('token');
      
      const response = await fetch(`/api/shop-external/products?_=${Date.now()}`, {
        cache: 'no-store',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Cache-Control': 'no-cache'
        }
      });
      
      const data = await response.json();
      
      if (data.success) {
        if (data.products && data.products.length > 0) {
          setProducts(data.products);
        } else {
          // Fallback to sample products if API returns empty
          setProducts([
            {
              id: '1',
              name: 'Tài khoản Netflix Premium',
              description: 'Tài khoản Netflix Premium 4K chất lượng cao',
              price: 50000,
              category_id: '1',
              category: 'Streaming',
              stock: 10,
              content: '• Netflix Premium 4K\n• Không giới hạn thiết bị\n• Hỗ trợ 24/7\n• Bảo hành 30 ngày',
              sold: 25
            },
            {
              id: '2',
              name: 'Tài khoản Spotify Premium',
              description: 'Tài khoản Spotify Premium không quảng cáo',
              price: 30000,
              category_id: '2',
              category: 'Music',
              stock: 15,
              content: '• Spotify Premium\n• Không quảng cáo\n• Chất lượng cao\n• Bảo hành 30 ngày',
              sold: 18
            }
          ]);
        }
      } else {
        // Use fallback products for API errors too
        setProducts([
          {
            id: '1',
            name: 'Tài khoản Netflix Premium',
            description: 'Tài khoản Netflix Premium 4K chất lượng cao',
            price: 50000,
            category_id: '1',
            category: 'Streaming',
            stock: 10,
            content: '• Netflix Premium 4K\n• Không giới hạn thiết bị\n• Hỗ trợ 24/7\n• Bảo hành 30 ngày',
            sold: 25
          },
          {
            id: '2',
            name: 'Tài khoản Spotify Premium',
            description: 'Tài khoản Spotify Premium không quảng cáo',
            price: 30000,
            category_id: '2',
            category: 'Music',
            stock: 15,
            content: '• Spotify Premium\n• Không quảng cáo\n• Chất lượng cao\n• Bảo hành 30 ngày',
            sold: 18
          },
          {
            id: '3',
            name: 'Tài khoản Disney+ Premium',
            description: 'Tài khoản Disney+ Premium với tất cả nội dung',
            price: 45000,
            category_id: '1',
            category: 'Streaming',
            stock: 8,
            content: '• Disney+ Premium\n• 4K Ultra HD\n• HDR Support\n• Bảo hành 30 ngày',
            sold: 12
          },
          {
            id: '4',
            name: 'Tài khoản YouTube Premium',
            description: 'Tài khoản YouTube Premium Family',
            price: 35000,
            category_id: '3',
            category: 'Video',
            stock: 12,
            content: '• YouTube Premium\n• YouTube Music\n• Không quảng cáo\n• Bảo hành 30 ngày',
            sold: 20
          },
          {
            id: '5',
            name: 'Tài khoản Crunchyroll',
            description: 'Tài khoản Crunchyroll Premium Anime',
            price: 25000,
            category_id: '3',
            category: 'Video',
            stock: 20,
            content: '• Crunchyroll Premium\n• Anime không giới hạn\n• Simulcast\n• Bảo hành 30 ngày',
            sold: 15
          }
        ]);
      }
    } catch (error) {
      // Use fallback products for network errors too
      setProducts([
        {
          id: '1',
          name: 'Tài khoản Netflix Premium',
          description: 'Tài khoản Netflix Premium 4K chất lượng cao',
          price: 50000,
          category_id: '1',
          category: 'Streaming',
          stock: 10,
          content: '• Netflix Premium 4K\n• Không giới hạn thiết bị\n• Hỗ trợ 24/7\n• Bảo hành 30 ngày',
          sold: 25
        },
        {
          id: '2',
          name: 'Tài khoản Spotify Premium',
          description: 'Tài khoản Spotify Premium không quảng cáo',
          price: 30000,
          category_id: '2',
          category: 'Music',
          stock: 15,
          content: '• Spotify Premium\n• Không quảng cáo\n• Chất lượng cao\n• Bảo hành 30 ngày',
          sold: 18
        },
        {
          id: '3',
          name: 'Tài khoản Disney+ Premium',
          description: 'Tài khoản Disney+ Premium với tất cả nội dung',
          price: 45000,
          category_id: '1',
          category: 'Streaming',
          stock: 8,
          content: '• Disney+ Premium\n• 4K Ultra HD\n• HDR Support\n• Bảo hành 30 ngày',
          sold: 12
        },
        {
          id: '4',
          name: 'Tài khoản YouTube Premium',
          description: 'Tài khoản YouTube Premium Family',
          price: 35000,
          category_id: '3',
          category: 'Video',
          stock: 12,
          content: '• YouTube Premium\n• YouTube Music\n• Không quảng cáo\n• Bảo hành 30 ngày',
          sold: 20
        },
        {
          id: '5',
          name: 'Tài khoản Crunchyroll',
          description: 'Tài khoản Crunchyroll Premium Anime',
          price: 25000,
          category_id: '3',
          category: 'Video',
          stock: 20,
          content: '• Crunchyroll Premium\n• Anime không giới hạn\n• Simulcast\n• Bảo hành 30 ngày',
          sold: 15
        }
      ]);
    }
  };

  const loadOrders = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/shop-external/orders', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (data.success) {
        setOrders((data as any).orders || (data as any).data || []);
      }
    } catch (error) {
      // Handle error silently
    }
  };

  useEffect(() => {
    loadProducts();
    loadOrders();
    loadUserBalance();
    setLoading(false);
  }, []);

  const openPurchaseModal = (product: Product) => {
    setSelectedProduct(product);
    setPurchaseAmount(1);
    setShowPurchaseModal(true);
  };

  const closePurchaseModal = () => {
    setShowPurchaseModal(false);
    setSelectedProduct(null);
    setPurchaseAmount(1);
  };

  const handlePurchase = async () => {
    if (!selectedProduct) return;
    
    setPurchasing(true);
    try {
      const token = localStorage.getItem('token');


      
      const response = await fetch('/api/shop-external/buy', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          productId: selectedProduct.id,
          quantity: purchaseAmount,
          productPrice: selectedProduct.price,
          productName: selectedProduct.name
        })
      });

      const data = await response.json();
      
      if (data.success) {
        // Lấy danh sách tài khoản từ response
        const purchasedAccounts = data.accounts || [];
        showNotification('success', 'Mua hàng thành công!', 'Tài khoản đã được gửi vào lịch sử mua hàng.', undefined, purchasedAccounts);
        closePurchaseModal();
        loadOrders();
        loadUserBalance();
      } else {
        showNotification('error', 'Lỗi:', data.error || data.message || 'Không xác định', data);
      }
    } catch (error) {
      showNotification('error', 'Có lỗi xảy ra khi mua hàng', 'Vui lòng thử lại sau.');
    } finally {
      setPurchasing(false);
    }
  };

  const filteredProducts = (products || []).filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = ['all', ...Array.from(new Set((products || []).map(p => p.category)))];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-400 dark:border-red-800';
      default: return 'bg-gray-100 text-gray-800 border-gray-200 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-3 h-3" />;
      case 'pending': return <Clock className="w-3 h-3" />;
      case 'failed': return <AlertCircle className="w-3 h-3" />;
      default: return <Clock className="w-3 h-3" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Hoàn thành';
      case 'pending': return 'Đang xử lý';
      case 'failed': return 'Thất bại';
      default: return 'Không xác định';
    }
  };

  const getOrderProductName = (order: Order) => {
    const fromProducts = (products || []).find(p => String(p.id) === String(order.productId))?.name
    return fromProducts || order.productName || 'Sản phẩm';
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('vi-VN').format(price) + ' VNĐ';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('vi-VN');
  };

  const handleCopyAccounts = (accounts: string[]) => {
    const text = accounts.join('\n');
    navigator.clipboard.writeText(text);
    showNotification('success', 'Đã copy tài khoản!', 'Tài khoản đã được copy vào clipboard.');
  };

  const handleDownloadOrder = (order: Order) => {
    const content = order.accounts.join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `accounts-order-${order._id}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const paginatedOrders = (orders || []).slice((currentOrderPage - 1) * orderPageSize, currentOrderPage * orderPageSize);
  const totalOrderPages = Math.ceil((orders || []).length / orderPageSize);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <Navigation />
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 md:ml-64">
      <Navigation />
      
      

      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <ShoppingCart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Cửa hàng</h1>
                <p className="text-sm text-gray-600 dark:text-gray-400">Mua tài khoản chất lượng cao</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-white dark:bg-gray-700 rounded-lg px-4 py-2 border border-gray-200 dark:border-gray-600">
                <DollarSign className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium text-gray-900 dark:text-white">
                  {formatPrice(userBalance)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* PXVIET THÔNG BÁO - Nhỏ gọn */}
      {showAnnouncement && (
        <div className="bg-white dark:bg-gray-800 border border-blue-200 dark:border-blue-700 rounded-lg max-w-7xl mx-auto mb-6">
          <div className="bg-blue-50 dark:bg-blue-900/20 border-b border-blue-200 dark:border-blue-700 px-4 py-3 rounded-t-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">i</span>
                </div>
                <h3 className="text-sm font-semibold text-blue-900 dark:text-blue-100">Ftool Shop THÔNG BÁO</h3>
              </div>
              <button 
                onClick={() => setShowAnnouncement(false)}
                className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-dashed border-yellow-300 dark:border-yellow-600 m-3 p-3 rounded-lg">
            <div className="space-y-1 text-xs text-gray-700 dark:text-gray-300">
              <div>• Tài Khoản của chúng tôi nhập từ bên khác về để bán cho bạn</div>
              <div>• Có nhiều định dạng tài khoản khác nhau</div>
              <div>• Có sai password, sai email, sai 2fa</div>
              <div className="text-green-600 dark:text-green-400 font-semibold">• <strong>Vì thế các bạn nên mua với số lượng nhỏ và thử nghiệm trước</strong></div>
              
              <div className="mt-2 pt-2 border-t border-yellow-300 dark:border-yellow-600">
                <div className="font-semibold text-gray-800 dark:text-gray-200 mb-1 text-xs">LƯU Ý:</div>
                <div className="text-xs">Shop chỉ cung cấp DATA, <strong>không cam kết bất kỳ mọi trường hợp nào</strong>. Hãy <strong>mua và thử nghiệm trước với số lượng nhỏ</strong>.</div>
                <div className="text-xs mt-1">Không lạm dụng DATA làm trái pháp luật, chúng tôi sẽ <strong>Không chịu trách nhiệm và không hoàn tiền</strong> nếu phát hiện vi phạm.</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters and Search */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0 sm:space-x-4">
            <div className="flex items-center space-x-4 w-full sm:w-auto">
              <div className="relative flex-1 sm:flex-none">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Tìm kiếm sản phẩm..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full sm:w-80 pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category === 'all' ? 'Tất cả danh mục' : category}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === 'grid' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-lg transition-colors ${
                  viewMode === 'list' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Products Section */}
          <div className={`${showOrderHistory ? 'lg:col-span-2' : 'lg:col-span-4'}`}>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Sản phẩm ({filteredProducts.length})
              </h2>
              <button
                onClick={loadProducts}
                className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                <span className="text-sm font-medium">Làm mới</span>
              </button>
            </div>

            {viewMode === 'grid' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                          <Package className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                            {product.category}
                          </span>
                        </div>
                      </div>
                      {product.sold && product.sold > 0 && (
                        <div className="flex items-center space-x-1 text-xs text-green-600 dark:text-green-400">
                          <TrendingUp className="w-3 h-3" />
                          <span>Đã bán: {product.sold}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-semibold text-gray-900 dark:text-white line-clamp-2">
                          {product.name}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">
                          {product.content || product.description}
                        </p>
                      </div>
                      
                      <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">GIÁ</p>
                        <p className="text-lg font-bold text-green-600 dark:text-green-400">
                          {formatPrice(product.price)}
                        </p>
                      </div>
                      
                      <div>
                        <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">KHO HÀNG</p>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            {product.stock > 0 ? product.stock : 'Hết hàng'}
                          </span>
                          {product.stock > 0 && (
                            <span className="text-xs text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20 px-2 py-1 rounded-full">
                              Còn hàng
                            </span>
                          )}
                        </div>
                        
                        {/* Thống kê đã mua */}
                        {product.purchased && product.purchased > 0 && (
                          <div className="mt-2 pt-2 border-t border-gray-100 dark:border-gray-700">
                            <div className="flex items-center justify-center space-x-1 text-xs text-blue-600 dark:text-blue-400">
                              <ShoppingCart className="w-3 h-3" />
                              <span>Đã mua: {product.purchased}</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                      <button
                        onClick={() => openPurchaseModal(product)}
                        disabled={product.stock === 0}
                        className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 disabled:from-gray-400 disabled:to-gray-500 text-white px-4 py-2 rounded-lg font-medium transition-all duration-200 disabled:cursor-not-allowed"
                      >
                        Mua ngay
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                          <Package className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                            {product.name}
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                            {product.content || product.description}
                          </p>
                          <div className="flex items-center space-x-4 mt-2">
                            <span className="text-xs text-gray-500 dark:text-gray-400">
                              Danh mục: {product.category}
                            </span>
                            {product.sold && product.sold > 0 && (
                              <span className="text-xs text-green-600 dark:text-green-400">
                                Đã bán: {product.sold}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="text-lg font-bold text-green-600 dark:text-green-400">
                            {formatPrice(product.price)}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            Kho: {product.stock > 0 ? product.stock : 'Hết hàng'}
                          </p>
                          
                          {/* Thống kê đã mua */}
                          {product.purchased && product.purchased > 0 && (
                            <div className="mt-1">
                              <span className="text-xs text-blue-600 dark:text-blue-400 flex items-center space-x-1">
                                <ShoppingCart className="w-3 h-3" />
                                <span>Đã mua: {product.purchased}</span>
                              </span>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => openPurchaseModal(product)}
                          disabled={product.stock === 0}
                          className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 disabled:from-gray-400 disabled:to-gray-500 text-white px-6 py-2 rounded-lg font-medium transition-all duration-200 disabled:cursor-not-allowed"
                        >
                          Mua ngay
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Order History Section */}
          {showOrderHistory && (
            <div className="lg:col-span-2">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                    Lịch sử mua hàng
                  </h2>
                  <button
                    onClick={loadOrders}
                    className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 transition-colors"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span className="text-sm font-medium">Làm mới</span>
                  </button>
                </div>

                {(orders || []).length === 0 ? (
                  <div className="text-center py-8">
                    <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 dark:text-gray-400">Chưa có đơn hàng nào</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {paginatedOrders.map((order) => (
                      <div
                        key={order._id}
                        className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h3 className="font-semibold text-gray-900 dark:text-white">
                              {getOrderProductName(order)}
                            </h3>
                                                         <p className="text-sm text-gray-600 dark:text-gray-400">
                               Số lượng: {order.amount} | Tổng: {formatPrice(order.price)}
                             </p>
                          </div>
                          <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(order.status)}`}>
                            {getStatusIcon(order.status)}
                            <span>{getStatusText(order.status)}</span>
                          </span>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                          <span>{formatDate(order.createdAt)}</span>
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => handleCopyAccounts(order.accounts)}
                              className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 transition-colors"
                            >
                              <Copy className="w-3 h-3" />
                              <span>Copy</span>
                            </button>
                            <button
                              onClick={() => handleDownloadOrder(order)}
                              className="flex items-center space-x-1 text-green-600 hover:text-green-700 transition-colors"
                            >
                              <Download className="w-3 h-3" />
                              <span>Tải xuống</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    {totalOrderPages > 1 && (
                      <div className="flex items-center justify-center space-x-2 mt-6">
                        <button
                          onClick={() => setCurrentOrderPage(prev => Math.max(1, prev - 1))}
                          disabled={currentOrderPage === 1}
                          className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Trước
                        </button>
                        <span className="text-sm text-gray-600 dark:text-gray-400">
                          Trang {currentOrderPage} / {totalOrderPages}
                        </span>
                        <button
                          onClick={() => setCurrentOrderPage(prev => Math.min(totalOrderPages, prev + 1))}
                          disabled={currentOrderPage === totalOrderPages}
                          className="px-3 py-1 border border-gray-300 dark:border-gray-600 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          Sau
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Purchase Modal */}
      {showPurchaseModal && selectedProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Mua sản phẩm
              </h2>
              <button
                onClick={closePurchaseModal}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left Section - Product Details */}
                <div>
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                      <Package className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        {selectedProduct.name}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {selectedProduct.category}
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <span className="text-sm text-white bg-purple-600 px-3 py-1 rounded-full font-medium">
                        KHO HÀNG: {selectedProduct.stock}
                      </span>
                      {selectedProduct.sold && (
                        <span className="text-sm text-white bg-green-600 px-3 py-1 rounded-full font-medium">
                          ĐÃ BÁN: {selectedProduct.sold}
                        </span>
                      )}
                      {selectedProduct.purchased && (
                        <span className="text-sm text-white bg-blue-600 px-3 py-1 rounded-full font-medium">
                          ĐÃ MUA: {selectedProduct.purchased}
                        </span>
                      )}
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <h4 className="font-semibold text-gray-900 dark:text-white mb-3">Thông tin sản phẩm:</h4>
                      <div className="space-y-2 text-sm text-gray-700 dark:text-gray-300">
                        {selectedProduct.content ? (
                          parseContentToFeatures(selectedProduct.content).length > 0 ? (
                            parseContentToFeatures(selectedProduct.content).map((feature, index) => (
                              <div key={index} className="flex items-start">
                                <span className="text-purple-600 mr-2 font-bold">•</span>
                                <span>{feature}</span>
                              </div>
                            ))
                          ) : (
                            <div className="whitespace-pre-line text-gray-700 dark:text-gray-300">
                              {selectedProduct.content}
                            </div>
                          )
                        ) : selectedProduct.features && selectedProduct.features.length > 0 ? (
                          selectedProduct.features.map((feature, index) => (
                            <div key={index} className="flex items-start">
                              <span className="text-purple-600 mr-2 font-bold">•</span>
                              <span>{feature}</span>
                            </div>
                          ))
                        ) : (
                          <div className="text-gray-500 dark:text-gray-400">
                            Không có thông tin chi tiết
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Right Section - Purchase Form */}
                <div>
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Số dư hiện tại:</span>
                      <span className="text-lg font-semibold text-red-500 line-through">
                        {userBalance > 0 ? userBalance.toLocaleString('vi-VN') : '0'}₫
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Giá sản phẩm:</span>
                      <span className="text-lg font-bold text-green-600 dark:text-green-400">
                        {formatPrice(selectedProduct.price)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Số lượng cần mua: <span className="text-red-500">(*)</span>
                      </label>
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => setPurchaseAmount(Math.max(1, purchaseAmount - 1))}
                          className="w-10 h-10 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg flex items-center justify-center transition-colors"
                        >
                          <Minus className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                        </button>
                        <input
                          type="number"
                          min="1"
                          max={selectedProduct.stock}
                          value={purchaseAmount}
                          onChange={(e) => setPurchaseAmount(Math.max(1, Math.min(selectedProduct.stock, parseInt(e.target.value) || 1)))}
                          className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white text-center focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        <button
                          onClick={() => setPurchaseAmount(Math.min(selectedProduct.stock, purchaseAmount + 1))}
                          className="w-10 h-10 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg flex items-center justify-center transition-colors"
                        >
                          <Plus className="w-4 h-4 text-gray-600 dark:text-gray-400" />
                        </button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Mã giảm giá: <span className="text-gray-500">(Tùy chọn)</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Nhập mã giảm giá..."
                        className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Tổng tiền:</span>
                        <span className="text-xl font-bold text-green-600 dark:text-green-400">
                          {formatPrice(selectedProduct.price * purchaseAmount)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
                        <span>Đơn giá: {formatPrice(selectedProduct.price)}</span>
                        <span>Số lượng: {purchaseAmount}</span>
                      </div>
                    </div>
                    
                    <button
                      onClick={handlePurchase}
                      disabled={purchasing || userBalance < selectedProduct.price * purchaseAmount}
                      className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 disabled:from-gray-400 disabled:to-gray-500 text-white py-3 rounded-lg font-semibold transition-all duration-200 disabled:cursor-not-allowed"
                    >
                      {purchasing ? 'Đang xử lý...' : 'Xác nhận mua hàng'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Beautiful Notification Modal */}
      {notification.show && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={hideNotification}
          />
          
          {/* Modal */}
          <div className="relative bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full mx-4 transform transition-all duration-300 scale-100">
            {/* Header */}
            <div className={`px-8 py-6 rounded-t-2xl ${
              notification.type === 'success' ? 'bg-gradient-to-r from-green-500 to-emerald-600' :
              notification.type === 'error' ? 'bg-gradient-to-r from-red-500 to-pink-600' :
              'bg-gradient-to-r from-blue-500 to-indigo-600'
            }`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  {notification.type === 'success' && (
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-7 h-7 text-white" />
                    </div>
                  )}
                  {notification.type === 'error' && (
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                      <AlertCircle className="w-7 h-7 text-white" />
                    </div>
                  )}
                  {notification.type === 'info' && (
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                      <Package className="w-7 h-7 text-white" />
                    </div>
                  )}
                  <div>
                    <h3 className="text-xl font-semibold text-white">{notification.title}</h3>
                  </div>
                </div>
                <button
                  onClick={hideNotification}
                  className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-colors"
                >
                  <X className="w-5 h-5 text-white" />
                </button>
              </div>
            </div>
            
            {/* Content */}
            <div className="px-8 py-6">
              <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed mb-4">
                {notification.message}
              </p>
              
              {/* Details for errors */}
              {notification.details && notification.type === 'error' && (
                <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-3 mb-4">
                  <div className="text-xs text-red-600 dark:text-red-400 space-y-1">
                    {notification.details.required && (
                      <div>Yêu cầu: {notification.details.required.toLocaleString('vi-VN')} VNĐ</div>
                    )}
                    {notification.details.current && (
                      <div>Số dư hiện tại: {notification.details.current.toLocaleString('vi-VN')} VNĐ</div>
                    )}
                    {notification.details.unitPrice && (
                      <div>Giá đơn vị: {notification.details.unitPrice.toLocaleString('vi-VN')} VNĐ</div>
                    )}
                    {notification.details.minQuantity && (
                      <div>Số lượng tối thiểu: {notification.details.minQuantity}</div>
                    )}
                    {notification.details.requestedQuantity && (
                      <div>Số lượng yêu cầu: {notification.details.requestedQuantity}</div>
                    )}
                  </div>
                </div>
              )}
              
              {/* Danh sách tài khoản vừa mua */}
              {notification.accounts && notification.accounts.length > 0 && notification.type === 'success' && (
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4 mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-blue-900 dark:text-blue-100 text-sm">
                      Tài khoản vừa mua ({notification.accounts.length})
                    </h4>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => {
                          const text = notification.accounts!.join('\n');
                          navigator.clipboard.writeText(text);
                          showNotification('success', 'Đã copy!', 'Tất cả tài khoản đã được copy vào clipboard.');
                        }}
                        className="flex items-center space-x-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs rounded-lg transition-colors"
                      >
                        <Copy className="w-3 h-3" />
                        <span>Copy tất cả</span>
                      </button>
                      <button
                        onClick={() => {
                          const content = notification.accounts!.join('\n');
                          const blob = new Blob([content], { type: 'text/plain' });
                          const url = URL.createObjectURL(blob);
                          const a = document.createElement('a');
                          a.href = url;
                          a.download = `accounts-${new Date().toISOString().split('T')[0]}.txt`;
                          document.body.appendChild(a);
                          a.click();
                          document.body.removeChild(a);
                          URL.revokeObjectURL(url);
                        }}
                        className="flex items-center space-x-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs rounded-lg transition-colors"
                      >
                        <Download className="w-3 h-3" />
                        <span>Tải về</span>
                      </button>
                    </div>
                  </div>
                  
                  {/* Danh sách tài khoản */}
                  <div className="max-h-48 overflow-y-auto space-y-2">
                    {notification.accounts.map((account, index) => (
                      <div key={index} className="text-xs text-blue-800 dark:text-blue-200 bg-white dark:bg-blue-800/30 px-3 py-2 rounded border border-blue-200 dark:border-blue-700 break-all">
                        {account}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Action Button */}
              <div className="flex justify-end">
                <button
                  onClick={hideNotification}
                  className={`px-6 py-2 rounded-lg font-medium transition-all duration-200 ${
                    notification.type === 'success' 
                      ? 'bg-green-500 hover:bg-green-600 text-white' :
                    notification.type === 'error'
                      ? 'bg-red-500 hover:bg-red-600 text-white' :
                      'bg-blue-500 hover:bg-blue-600 text-white'
                  }`}
                >
                  Đóng
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
