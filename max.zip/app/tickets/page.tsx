'use client'

import React, { useEffect, useState, useRef } from 'react'
import { Send, MessageSquarePlus, Loader2, Eye, Clock, CheckCircle, MessageSquare, Plus, Search, Filter, X, Sun, Moon } from 'lucide-react'
import Navigation from '@/components/Navigation'

type Ticket = { 
  _id: string; 
  title: string; 
  status: 'open'|'closed'; 
  subject?: string;
  orderId?: string;
  createdAt: string; 
  updatedAt: string;
  messageCount?: number;
}

type TicketMessage = { 
  _id?: string; 
  senderType: 'user'|'admin'; 
  content: string; 
  imageUrl?: string; // URL của ảnh nếu có
  createdAt?: string;
  tempId?: number; // Temporary ID for optimistic updates
}

export default function TicketsPage() {
  const [tickets, setTickets] = useState<Ticket[]>([])
  const [loading, setLoading] = useState(true)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newTitle, setNewTitle] = useState('')
  const [newContent, setNewContent] = useState('')
  const [newSubject, setNewSubject] = useState('')
  const [activeId, setActiveId] = useState<string | null>(null)
  const [messages, setMessages] = useState<TicketMessage[]>([])
  const [msg, setMsg] = useState('')
  const [selectedImage, setSelectedImage] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [showImageModal, setShowImageModal] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [subjectFilter, setSubjectFilter] = useState('all')
  const listRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const loadTickets = async () => {
    setLoading(true)
    const res = await fetch('/api/tickets', { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
    const j = await res.json()
    if (j.success) setTickets(j.tickets)
    setLoading(false)
  }

  const [sseConnection, setSseConnection] = useState<EventSource | null>(null)



    const openTicket = async (id: string) => {
    setActiveId(id)

    // Close previous connection if exists
    if (sseConnection) {
      sseConnection.close()
    }

    const res = await fetch(`/api/tickets/${id}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token')}` } })
    const j = await res.json()
    if (j.success) setMessages(j.messages)

    // Mark admin messages as read
    try {
      await fetch(`/api/tickets/${id}/mark-read`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      })
    } catch (error) {
      // Silent error handling
    }

    // Use polling for real-time updates (more reliable than SSE in Next.js)
    startPolling(id)
  }

  // Polling function for real-time updates
  const startPolling = (ticketId: string) => {
    let lastMessageCount = 0
    
    const pollInterval = setInterval(async () => {
      try {
        const res = await fetch(`/api/tickets/${ticketId}`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        })
        const j = await res.json()
        
        if (j.success && j.messages) {
          const currentMessageCount = j.messages.length
          
          // Only update if we have new messages
          if (currentMessageCount > lastMessageCount) {
            setMessages(j.messages)
            lastMessageCount = currentMessageCount
            
            // Scroll to bottom when new messages arrive
            setTimeout(() => listRef.current && (listRef.current.scrollTop = listRef.current.scrollHeight), 100)
          }
        }
      } catch (error) {
        // Silent error handling
      }
    }, 1000) // Poll every 1 second for better responsiveness

    // Store interval ID for cleanup
    setSseConnection({ close: () => clearInterval(pollInterval) } as any)
  }

    useEffect(() => {
    loadTickets()

    // Cleanup connection on unmount
    return () => {
      if (sseConnection) {
        sseConnection.close()
      }
    }
  }, [])

  const createTicket = async () => {
    if (!newTitle || !newContent || !newSubject) return
    const res = await fetch('/api/tickets', { 
      method: 'POST', 
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` }, 
      body: JSON.stringify({ 
        title: newTitle, 
        content: newContent, 
        subject: newSubject 
      }) 
    })
    const j = await res.json()
    if (j.success) { 
      setNewTitle(''); 
      setNewContent(''); 
      setNewSubject('');
      setShowCreateForm(false);
      loadTickets() 
    }
  }

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        alert('Ảnh quá lớn. Vui lòng chọn ảnh nhỏ hơn 5MB.')
        return
      }
      
      if (!file.type.startsWith('image/')) {
        alert('Vui lòng chọn file ảnh hợp lệ.')
        return
      }
      
      setSelectedImage(file)
      const reader = new FileReader()
      reader.onload = (e) => setImagePreview(e.target?.result as string)
      reader.readAsDataURL(file)
    }
  }

  const removeImage = () => {
    setSelectedImage(null)
    setImagePreview(null)
    setShowImageModal(false)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const uploadImage = async (file: File): Promise<string> => {
    const formData = new FormData()
    formData.append('image', file)
    
    const response = await fetch('/api/upload-image', {
      method: 'POST',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      body: formData
    })
    
    if (!response.ok) {
      throw new Error('Upload failed')
    }
    
    const data = await response.json()
    return data.imageUrl
  }

  const sendMessage = async () => {
    if (!activeId || (!msg && !selectedImage)) return
    
    setIsUploading(true)
    let imageUrl = ''
    
    // Upload image first if selected
    if (selectedImage) {
      try {
        imageUrl = await uploadImage(selectedImage)
      } catch (error) {
        console.error('Error uploading image:', error)
        alert('Không thể tải ảnh lên. Vui lòng thử lại.')
        setIsUploading(false)
        return
      }
    }
    
    const tempMessage = {
      senderType: 'user' as const,
      content: msg || '',
      imageUrl: imageUrl || undefined,
      createdAt: new Date().toISOString(),
      tempId: Date.now()
    }
    
    // Add message to local state immediately (optimistic update)
    setMessages(prev => [...prev, tempMessage])
    setMsg('')
    setSelectedImage(null)
    setImagePreview(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
    
    // Scroll to bottom
    setTimeout(() => listRef.current && (listRef.current.scrollTop = listRef.current.scrollHeight), 50)
    
    try {
      const res = await fetch(`/api/tickets/${activeId}`, { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token')}` }, 
        body: JSON.stringify({ 
          content: msg || undefined, 
          imageUrl: imageUrl || undefined 
        }) 
      })
      const j = await res.json()
      
      if (j.success) {
        // Replace temp message with real message from server
        setMessages(prev => prev.map(m => 
          m.tempId === tempMessage.tempId 
            ? { ...j.message, senderType: 'user' as const }
            : m
        ))
      } else {
        // If failed, remove the temp message
        setMessages(prev => prev.filter(m => m.tempId !== tempMessage.tempId))
        if (imageUrl) {
          setSelectedImage(selectedImage)
          setImagePreview(imagePreview)
        }
        if (msg) setMsg(msg)
      }
    } catch (error) {
      console.error('Error sending message:', error)
      // If failed, remove the temp message
      setMessages(prev => prev.filter(m => m.tempId !== tempMessage.tempId))
      if (imageUrl) {
        setSelectedImage(selectedImage)
        setImagePreview(imagePreview)
      }
      if (msg) setMsg(msg)
    } finally {
      setIsUploading(false)
    }
  }

  const getStatusColor = (status: string) => {
    return status === 'open' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' : 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
  }

  const getSubjectColor = (subject: string) => {
    const colors: { [key: string]: string } = {
      'Tài khoản': 'bg-purple-500/20 text-purple-300 border border-purple-500/30',
      'Shop': 'bg-orange-500/20 text-orange-300 border border-orange-500/30',
      'default': 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
    }
    return colors[subject] || colors.default
  }

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter
    const matchesSubject = subjectFilter === 'all' || ticket.subject === subjectFilter
    return matchesSearch && matchesStatus && matchesSubject
  })

  const stats = {
    total: tickets.length,
    open: tickets.filter(t => t.status === 'open').length,
    pending: tickets.filter(t => t.status === 'open').length, // Assuming open = pending
    answered: tickets.filter(t => t.status === 'closed').length
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-950 transition-colors duration-300">
      {/* Navigation Sidebar */}
      <Navigation currentPage="tickets" />
      
      {/* Main Content */}
      <div className="md:ml-64 pt-20 md:pt-6 px-4 md:px-8 pb-6">
        {/* Top bar */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white transition-colors duration-300">Hỗ trợ Tickets</h1>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowCreateForm(true)}
              className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-lg text-sm font-medium shadow-sm hover:shadow-md transition-all duration-300"
            >
              + Tạo ticket mới
            </button>
          </div>
        </div>

        {/* Two-pane layout */}
        <div className="grid grid-cols-1 xl:grid-cols-5 gap-6 h-[calc(100vh-240px)]">
          {/* Left: list */}
          <div className="xl:col-span-2 bg-white dark:bg-slate-900/60 border border-gray-200 dark:border-slate-800 rounded-xl transition-colors duration-300 shadow-sm flex flex-col">
            <div className="p-4 border-b border-gray-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 dark:text-slate-400 transition-colors duration-300" />
                <input
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Tìm kiếm theo tiêu đề ticket..."
                  className="w-full pl-9 pr-3 py-2.5 bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-lg text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                />
              </div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2.5 bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-lg text-sm text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 min-w-[120px]"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="open">Đang mở</option>
                <option value="closed">Đã đóng</option>
              </select>
            </div>
            <div className="flex-1 divide-y divide-gray-200 dark:divide-slate-800 overflow-y-auto">
              {filteredTickets.map((t) => (
                <button
                  key={t._id}
                  onClick={() => openTicket(t._id)}
                  className={`w-full text-left p-4 hover:bg-gray-50 dark:hover:bg-slate-800 transition-all duration-300 ${activeId === t._id ? 'bg-blue-50 dark:bg-slate-800 border-r-2 border-blue-500' : ''}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 dark:text-white truncate transition-colors duration-300 mb-1">{t.title}</p>
                      <p className="text-xs text-gray-500 dark:text-slate-400 transition-colors duration-300">#{t._id.slice(-6)} • {new Date(t.createdAt).toLocaleDateString('vi-VN')}</p>
                    </div>
                    <span className={`ml-3 text-xs px-2.5 py-1 rounded-full font-medium ${getStatusColor(t.status)}`}>
                      {t.status === 'open' ? '🟢 Mở' : '🔴 Đóng'}
                    </span>
                  </div>
                </button>
              ))}
              {filteredTickets.length === 0 && (
                <div className="p-8 text-center text-gray-500 dark:text-slate-400">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-300 dark:text-slate-600" />
                  <p className="text-sm font-medium">Không có ticket nào</p>
                  <p className="text-xs mt-1">Tạo ticket đầu tiên để bắt đầu</p>
                </div>
              )}
            </div>
          </div>

          {/* Right: conversation */}
          <div className="xl:col-span-3 bg-white dark:bg-slate-900/60 border border-gray-200 dark:border-slate-800 rounded-xl flex flex-col transition-colors duration-300 shadow-sm">
            {!activeId ? (
              <div className="flex-1 flex items-center justify-center text-gray-500 dark:text-slate-400 text-sm transition-colors duration-300">Chọn một ticket để xem chi tiết</div>
            ) : (
              <>
                <div className="p-4 border-b border-gray-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-700">
                  <div className="flex items-center gap-3">
                    <MessageSquare className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    <div>
                      <div className="text-sm font-semibold text-gray-900 dark:text-white">Trò chuyện hỗ trợ</div>
                      <div className="text-xs text-gray-500 dark:text-slate-400">Ticket #{activeId?.slice(-6)}</div>
                    </div>
                  </div>
                  <button 
                    onClick={() => setActiveId(null)} 
                    className="p-2 text-gray-400 dark:text-slate-400 hover:text-gray-600 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-slate-700 rounded-lg transition-all duration-300"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="relative flex-1">
                  <div ref={listRef} className="h-full overflow-y-auto p-4 space-y-4 scroll-smooth">
                    {messages.map((m, i) => (
                      <div key={i} className={`max-w-[85%] ${m.senderType === 'user' ? 'ml-auto' : ''}`}>
                        <div className={`px-4 py-3 rounded-xl text-sm break-words ${m.senderType === 'user' ? 'bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md' : 'bg-white dark:bg-slate-800 text-gray-900 dark:text-slate-200 border border-gray-200 dark:border-slate-700 shadow-sm'}`}>
                          {m.content && m.content.trim().length > 0 && (
                            <div className="whitespace-pre-wrap leading-relaxed max-w-full overflow-hidden">
                              {m.content}
                            </div>
                          )}
                          {m.imageUrl && (
                            <div className="mt-3">
                              <img 
                                src={m.imageUrl} 
                                alt="Hình ảnh" 
                                className="max-w-full h-auto rounded-lg cursor-pointer hover:scale-105 transition-transform duration-200 shadow-sm"
                                onClick={() => window.open(m.imageUrl, '_blank')}
                              />
                            </div>
                          )}
                        </div>
                        <div className={`text-xs text-gray-400 dark:text-slate-500 mt-2 transition-colors duration-300 ${m.senderType === 'user' ? 'text-right' : ''}`}>
                          {m.createdAt ? new Date(m.createdAt).toLocaleString('vi-VN') : 'Vừa xong'}
                        </div>
                      </div>
                    ))}
                    
                    {/* Scroll to bottom indicator */}
                    {messages.length > 0 && (
                      <div className="text-center text-xs text-gray-400 dark:text-slate-500 py-2">
                        <div className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 dark:bg-slate-800 rounded-full">
                          <span>Cuộn để xem tin nhắn cũ hơn</span>
                          <svg className="w-3 h-3 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                          </svg>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {/* Scroll to bottom button */}
                  {messages.length > 3 && (
                    <button
                      onClick={() => {
                        listRef.current?.scrollTo({
                          top: listRef.current.scrollHeight,
                          behavior: 'smooth'
                        })
                      }}
                      className="absolute bottom-4 right-4 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 z-10"
                      title="Cuộn xuống tin nhắn mới nhất"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                      </svg>
                    </button>
                  )}
                </div>
                                <div className="p-4 border-t border-gray-200 dark:border-slate-800 bg-gray-50 dark:bg-slate-800/50">
                  {/* Image Preview - Hiển thị phía trên input */}
                  {imagePreview && (
                    <div className="mb-4 bg-white dark:bg-slate-800 rounded-xl p-4 border border-gray-200 dark:border-slate-700 shadow-lg">
                      <div className="relative inline-block">
                        <div className="text-xs text-gray-500 dark:text-slate-400 mb-2 font-medium">
                          Xem trước ảnh:
                        </div>
                        <img 
                          src={imagePreview} 
                          alt="Preview" 
                          className="w-24 h-24 object-cover rounded-lg cursor-pointer hover:scale-105 transition-transform duration-200 border border-gray-100 dark:border-slate-600"
                          onClick={() => setShowImageModal(true)}
                        />
                        <button
                          onClick={removeImage}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600 transition-colors shadow-md"
                        >
                          <X className="w-3 h-3" />
                        </button>
                        <div className="text-xs text-gray-400 dark:text-slate-500 mt-1 text-center">
                          Click để xem full size
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Input và nút gửi */}
                  <div className="flex gap-3">
                    {/* File Input */}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageSelect}
                      className="hidden"
                    />
                    
                    {/* Image Button */}
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-2.5 bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 text-white rounded-lg text-sm flex items-center gap-2 transition-all duration-300 shadow-sm hover:shadow-md"
                      title="Gửi ảnh"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    </button>
                    
                    <input
                      value={msg}
                      onChange={(e) => setMsg(e.target.value)}
                      placeholder="Nhập tin nhắn của bạn..."
                      className="flex-1 px-4 py-2.5 bg-white dark:bg-slate-900 border border-gray-300 dark:border-slate-800 rounded-lg text-sm text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    />
                    <button
                      onClick={sendMessage}
                      disabled={isUploading}
                      className={`px-4 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-lg text-sm flex items-center gap-2 transition-all duration-300 shadow-sm hover:shadow-md font-medium ${
                        isUploading ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    >
                      {isUploading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                      {isUploading ? 'Đang gửi...' : 'Gửi'}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Create Ticket Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="relative overflow-hidden bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl p-8 w-full max-w-2xl mx-4 border border-white/20 shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10"></div>
            <div className="relative">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-white">Tạo yêu cầu hỗ trợ mới</h3>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="text-slate-400 hover:text-white transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-300 mb-3">Tiêu đề</label>
                  <input
                    type="text"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="Nhập tiêu đề yêu cầu..."
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm transition-all duration-300"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-slate-300 mb-3">Chủ đề</label>
                  <select
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm transition-all duration-300"
                  >
                    <option value="" className="bg-slate-800 text-white">Chọn chủ đề</option>
                    <option value="Tài khoản" className="bg-slate-800 text-white">Tài khoản</option>
                    <option value="Shop" className="bg-slate-800 text-white">Shop</option>
                    <option value="Khác" className="bg-slate-800 text-white">Khác</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-slate-300 mb-3">Nội dung</label>
                  <textarea
                    value={newContent}
                    onChange={(e) => setNewContent(e.target.value)}
                    placeholder="Mô tả chi tiết yêu cầu của bạn..."
                    rows={4}
                    className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-slate-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm transition-all duration-300 resize-none"
                  />
                </div>
              </div>
              
              <div className="flex justify-end gap-4 mt-8">
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="px-6 py-3 text-slate-300 bg-white/10 hover:bg-white/20 rounded-xl transition-all duration-300 border border-white/20"
                >
                  Hủy
                </button>
                <button
                  onClick={createTicket}
                  className="px-6 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-orange-500/25 font-semibold"
                >
                  Tạo yêu cầu
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Image Preview Modal */}
      {showImageModal && imagePreview && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-sm flex items-center justify-center z-[9999]">
          <div className="relative max-w-5xl max-h-[95vh] p-4">
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Xem trước ảnh
                </h3>
                <button
                  onClick={() => setShowImageModal(false)}
                  className="text-gray-400 hover:text-gray-600 dark:hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="max-h-[70vh] overflow-auto">
                <img 
                  src={imagePreview} 
                  alt="Full Preview" 
                  className="max-w-full h-auto rounded-lg shadow-lg border border-gray-200 dark:border-slate-700"
                />
              </div>
              
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200 dark:border-slate-700">
                <div className="text-sm text-gray-500 dark:text-slate-400">
                  {selectedImage ? `${selectedImage.name} • ${(selectedImage.size / 1024 / 1024).toFixed(2)} MB` : 'Ảnh đã chọn'}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={removeImage}
                    className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors flex items-center gap-2"
                  >
                    <X className="w-4 h-4" />
                    Xóa ảnh
                  </button>
                  <button
                    onClick={() => setShowImageModal(false)}
                    className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                  >
                    Đóng
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}


