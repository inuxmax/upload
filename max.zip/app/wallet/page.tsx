'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  Wallet, Plus, History, CreditCard, ArrowRight, 
  Home, BarChart3, Settings, User, LogOut, Sun, Moon,
  RefreshCw, Check, Clock, X, DollarSign, TrendingUp,
  Download, Upload, Eye, Calendar, Filter
} from 'lucide-react';
import Navigation from '../../components/Navigation';
import { useNotification } from '../../components/NotificationSystem';

interface DepositTransaction {
  _id: string;
  userId: string;
  amount: number;
  transferContent: string;
  status: 'pending' | 'completed' | 'failed';
  bankInfo: {
    bankName: string;
    accountNumber: string;
    accountHolder: string;
  };
  createdAt: string;
  completedAt?: string;
}

interface PaymentInfo {
  bankName: string;
  accountNumber: string;
  accountHolder: string;
  transferContent: string;
}

export default function WalletPage() {
  const router = useRouter();

  const { addNotification } = useNotification();
  const [user, setUser] = useState<any>(null);
  const [balance, setBalance] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [depositAmount, setDepositAmount] = useState<string>('');
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo | null>(null);
  const [randomTransferContent, setRandomTransferContent] = useState<string>('');
  const [transactions, setTransactions] = useState<DepositTransaction[]>([]);
  const [transactionStatus, setTransactionStatus] = useState<'idle' | 'checking' | 'success' | 'failed'>('idle');
  const [checkingInterval, setCheckingInterval] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    checkAuth();
    loadPaymentInfo();
  }, []);

  useEffect(() => {
    if (showDepositModal && depositAmount) {
      const interval = setInterval(() => {
        checkDepositTransactions();
      }, 30000);
      
      setCheckingInterval(interval);
      
      setTimeout(() => {
        checkDepositTransactions();
      }, 5000);
      
      return () => {
        if (interval) clearInterval(interval);
      };
    } else {
      if (checkingInterval) {
        clearInterval(checkingInterval);
        setCheckingInterval(null);
      }
    }
  }, [showDepositModal, depositAmount, randomTransferContent]);

  const checkAuth = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        router.push('/auth/login');
        return;
      }

      const response = await fetch('/api/auth/verify', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        setBalance(userData.balance || 0);
        loadTransactions();
      } else {
        localStorage.removeItem('token');
        router.push('/auth/login');
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      router.push('/auth/login');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    router.push('/auth/login');
  };

  const loadPaymentInfo = async () => {
    try {
      const response = await fetch('/api/payment-info');
      if (response.ok) {
        const data = await response.json();
        setPaymentInfo(data);
      }
    } catch (error) {
      console.error('Error loading payment info:', error);
    }
  };

  const loadTransactions = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/wallet/transactions', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        setTransactions(data);
      }
    } catch (error) {
      console.error('Error loading transactions:', error);
    }
  };

  // Nội dung chuyển khoản sẽ được tạo từ server khi khởi tạo giao dịch pending
  const generateTransferContent = () => randomTransferContent || '';

  const generateQRCodeUrl = () => {
    if (!paymentInfo || !depositAmount) return '';
    
    const amount = parseInt(depositAmount);
    const content = randomTransferContent;
    
    const getBankCode = (bankName: string) => {
      const bankMap: { [key: string]: string } = {
        'ACB': '970416',
        'Vietcombank': '970436',
        'VietinBank': '970415',
        'BIDV': '970418',
        'Techcombank': '970407',
        'MBBank': '970422',
        'Sacombank': '970403',
        'VPBank': '970432',
        'TPBank': '970423',
        'Agribank': '970405'
      };
      return bankMap[bankName] || '970416';
    };

    const bankCode = getBankCode(paymentInfo.bankName);
    
    return `https://img.vietqr.io/image/${bankCode}-${paymentInfo.accountNumber}-compact1.png?amount=${amount}&addInfo=${encodeURIComponent(content)}&accountName=${encodeURIComponent(paymentInfo.accountHolder)}`;
  };

  const handleDeposit = async () => {
    const amount = parseInt(depositAmount);
    if (!amount || amount < 10000) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Số tiền nạp tối thiểu là 10,000 VNĐ'
      });
      return;
    }

    try {
      const resp = await fetch('/api/wallet/deposit/initiate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ amount })
      });
      const data = await resp.json();
      if (resp.ok && data.success) {
        setRandomTransferContent(data.transferContent);
        setShowDepositModal(true);
      } else {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: data?.error || 'Không khởi tạo được giao dịch nạp tiền'
        });
      }
    } catch (e) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể kết nối máy chủ'
      });
    }
  };

  const checkDepositTransactions = async () => {
    if (!depositAmount || !randomTransferContent) return;

    setTransactionStatus('checking');
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/wallet/transactions', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!response.ok) throw new Error('fetch transactions failed');
      const list: any[] = await response.json();
      const found = list.find(tx => tx.type === 'deposit' && tx.transferContent === randomTransferContent);
      if (found && found.status === 'completed') {
        setTransactionStatus('success');
        if (checkingInterval) {
          clearInterval(checkingInterval);
          setCheckingInterval(null);
        }
        addNotification({
          type: 'success',
          title: 'Nạp tiền thành công!',
          message: `Đã nạp ${formatPrice(parseInt(depositAmount))} vào tài khoản.`
        });
        setTimeout(() => {
          setShowDepositModal(false);
          setTransactionStatus('idle');
          setDepositAmount('');
          setRandomTransferContent('');
          checkAuth();
          loadTransactions();
        }, 1500);
      } else {
        setTransactionStatus('checking');
      }
    } catch (error) {
      setTransactionStatus('failed');
      setTimeout(() => setTransactionStatus('idle'), 3000);
    }
  };

  const formatPrice = (price: number) => {
    try {
      if (typeof price !== 'number' || isNaN(price)) {
        return `${(price || 0).toLocaleString('vi-VN')} ₫`;
      }
      return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
      }).format(price);
    } catch (error) {
      console.error('Error formatting price:', error);
      return `${(price || 0).toLocaleString('vi-VN')} ₫`;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return `Hôm nay ${date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays === 1) {
      return `Hôm qua ${date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays < 7) {
      return `${diffDays} ngày trước ${date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return date.toLocaleDateString('vi-VN', { 
        day: '2-digit', 
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100 dark:bg-green-900/20 dark:text-green-400';
      case 'pending': return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-400';
      case 'failed': return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400';
      default: return 'text-gray-600 bg-gray-100 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Hoàn thành';
      case 'pending': return 'Đang xử lý';
      case 'failed': return 'Thất bại';
      default: return 'Không xác định';
    }
  };

  const quickAmounts = [50000, 100000, 200000, 500000, 1000000, 2000000];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400 text-lg">Đang tải...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 md:ml-64">
      {/* Navigation */}
      <Navigation currentPage="wallet" />
      
      {/* Page Title */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="flex items-center bg-gradient-to-r from-green-600 to-emerald-600 p-2.5 rounded-xl shadow-lg">
            <Wallet className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Ví tiền
            </h1>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Quản lý ví tiền và giao dịch
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
        {/* Balance Card */}
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl shadow-xl p-8 text-white mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Số dư tài khoản</h2>
              <p className="text-4xl font-bold">{formatPrice(balance) || `${balance.toLocaleString('vi-VN')} ₫`}</p>
              <p className="text-green-100 mt-2">Tài khoản: {user?.username}</p>
            </div>
            <div className="text-right">
              <div className="p-4 bg-white/20 rounded-xl mb-4">
                <Wallet className="w-12 h-12" />
              </div>
              <button
                onClick={() => checkAuth()}
                className="flex items-center space-x-2 px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Làm mới</span>
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Deposit Section */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
              <div className="flex items-center space-x-3 mb-6">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                  <Plus className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Nạp tiền</h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Số tiền nạp (VNĐ)
                  </label>
                  <input
                    type="number"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white text-gray-900 font-medium"
                    placeholder="Nhập số tiền"
                    min="10000"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Số tiền tối thiểu: 10,000 VNĐ
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Chọn nhanh
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {quickAmounts.map((amount) => (
                      <button
                        key={amount}
                        onClick={() => setDepositAmount(amount.toString())}
                        className="px-4 py-3 text-sm border-2 border-gray-300 dark:border-gray-600 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:border-blue-500 transition-all text-gray-800 dark:text-gray-100 font-bold bg-white dark:bg-gray-800 shadow-sm"
                      >
                        {new Intl.NumberFormat('vi-VN', {
                          style: 'currency',
                          currency: 'VND',
                          minimumFractionDigits: 0,
                          maximumFractionDigits: 0
                        }).format(amount)}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleDeposit}
                  disabled={!depositAmount || parseInt(depositAmount) < 10000}
                  className="w-full py-3 px-4 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white rounded-lg font-bold transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2 shadow-lg"
                >
                  <Plus className="w-5 h-5" />
                  <span>Nạp tiền ngay</span>
                </button>
              </div>
            </div>
          </div>

          {/* Transaction History */}
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-100 dark:bg-purple-900/20 rounded-lg">
                    <History className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">Lịch sử giao dịch</h3>
                </div>
                <button
                  onClick={loadTransactions}
                  className="p-2 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 transition-colors"
                  title="Làm mới"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                {transactions.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="p-4 bg-gray-100 dark:bg-gray-700 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                      <History className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-gray-500 dark:text-gray-400">Chưa có giao dịch nào</p>
                  </div>
                ) : (
                  transactions.map((transaction) => (
                    <div
                      key={transaction._id}
                      className={`flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg transition-colors ${transaction.status === 'pending' ? 'hover:bg-blue-50 dark:hover:bg-blue-900/20 cursor-pointer' : 'hover:bg-gray-50 dark:hover:bg-gray-700/50'}`}
                      onClick={() => {
                        if (transaction.status === 'pending') {
                          setDepositAmount(String(transaction.amount || ''));
                          setRandomTransferContent(transaction.transferContent || '');
                          setShowDepositModal(true);
                        }
                      }}
                    >
                      <div className="flex items-center space-x-4">
                        <div className="p-2 bg-green-100 dark:bg-green-900/20 rounded-lg">
                          <Upload className="w-5 h-5 text-green-600 dark:text-green-400" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">
                            Nạp tiền
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            {formatDate(transaction.createdAt)}
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            Mã: {transaction.transferContent}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600 dark:text-green-400">
                          +{formatPrice(transaction.amount)}
                        </p>
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(transaction.status)}`}>
                          {getStatusText(transaction.status)}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Deposit Modal */}
      {showDepositModal && paymentInfo && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {/* Header */}
              <div className="text-center mb-6">
                <div className="inline-flex p-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white mb-4">
                  <Wallet className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                  Nạp tiền vào ví
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {formatPrice(parseInt(depositAmount))}
                </p>
              </div>

              {/* QR Code */}
              <div className="text-center mb-6">
                <div className="bg-white p-4 rounded-xl shadow-lg inline-block mb-4">
                  <img 
                    src={generateQRCodeUrl()} 
                    alt="QR Code thanh toán" 
                    className="w-60 h-56 mx-auto"
                  />
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Quét mã QR để thanh toán nhanh
                </p>
              </div>

              {/* Payment Info */}
              <div className="space-y-4 mb-6">
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-700 dark:text-gray-300 font-medium">Ngân hàng:</span>
                      <p className="font-bold text-gray-900 dark:text-white">{paymentInfo.bankName}</p>
                    </div>
                    <div>
                      <span className="text-gray-700 dark:text-gray-300 font-medium">Số tài khoản:</span>
                      <p className="font-bold text-gray-900 dark:text-white">{paymentInfo.accountNumber}</p>
                    </div>
                    <div>
                      <span className="text-gray-700 dark:text-gray-300 font-medium">Chủ tài khoản:</span>
                      <p className="font-bold text-gray-900 dark:text-white">{paymentInfo.accountHolder}</p>
                    </div>
                    <div>
                      <span className="text-gray-700 dark:text-gray-300 font-medium">Số tiền:</span>
                      <p className="font-bold text-green-600 dark:text-green-400 text-lg">{formatPrice(parseInt(depositAmount))}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                  <div className="flex items-start space-x-3">
                    <DollarSign className="w-5 h-5 text-yellow-600 dark:text-yellow-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-yellow-800 dark:text-yellow-200 mb-1">
                        Nội dung chuyển khoản:
                      </p>
                      <p className="text-xl font-bold text-yellow-900 dark:text-yellow-100 bg-yellow-100 dark:bg-yellow-800/30 px-4 py-3 rounded border-2 border-yellow-300 dark:border-yellow-600">
                        {randomTransferContent}
                      </p>
                      <p className="text-sm font-medium text-yellow-700 dark:text-yellow-300 mt-2">
                        ⚠️ Nội dung chuyển khoản dựa trên tên tài khoản của bạn. Vui lòng nhập chính xác để hệ thống tự động xác nhận thanh toán.
                      </p>
                      <p className="text-sm font-medium text-yellow-700 dark:text-yellow-300 mt-2">
                        ⚠️ Tự động cộng tiền sau 30s-1p, vui lòng không đóng trang.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status */}
              <div className="text-center mb-6">
                {transactionStatus === 'checking' && (
                  <div className="flex items-center justify-center space-x-3 text-blue-600 dark:text-blue-400">
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Đang kiểm tra thanh toán...</span>
                  </div>
                )}
                
                {transactionStatus === 'success' && (
                  <div className="flex items-center justify-center space-x-3 text-green-600 dark:text-green-400">
                    <Check className="w-5 h-5" />
                    <span>Nạp tiền thành công!</span>
                  </div>
                )}
                
                {transactionStatus === 'failed' && (
                  <div className="text-red-600 dark:text-red-400">
                    <span>Đang kiểm tra giao dịch</span>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex space-x-3">
                <button
                  onClick={() => {
                    setShowDepositModal(false);
                    setDepositAmount('');
                    setRandomTransferContent('');
                    if (checkingInterval) {
                      clearInterval(checkingInterval);
                      setCheckingInterval(null);
                    }
                  }}
                  className="flex-1 py-3 px-4 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors font-bold"
                >
                  Đóng
                </button>
                <button
                  onClick={checkDepositTransactions}
                  disabled={transactionStatus === 'checking'}
                  className="flex-1 py-3 px-4 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors font-bold disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {transactionStatus === 'checking' ? 'Đang kiểm tra...' : 'Kiểm tra thanh toán'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
