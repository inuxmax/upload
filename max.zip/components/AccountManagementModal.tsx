'use client';

import React, { useState, useEffect } from 'react';
import { 
  X, User, Users, Calendar, Eye, Trash, RefreshCw, Download, Filter, Star, 
  Activity, Target, Settings, Search, BarChart3, TrendingUp, UserCheck, UserX, 
  AlertCircle, MoreVertical, Edit, Lock, Unlock, Globe, Database, Shield, ChevronDown, ChevronRight, 
  Mail, Key, Cookie, Zap, Plus, Upload, Copy
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useNotification } from './NotificationSystem';
import { useStorage } from '../contexts/StorageContext';
import AddAccountModal from './AddAccountModal';
import StorageSettingsModal from './StorageSettingsModal';

interface FacebookAccount {
  _id: string;
  uid: string;
  pass: string;
  twofa: string;
  mail: string;
  passmail: string;
  mailkp: string;
  cookie: string;
  token: string;
  status: 'active' | 'checking' | 'error' | 'inactive';
  log: string;
  lastUpdated: string;
  createdAt: string;
  updatedAt: string;
  source?: 'local' | 'server';
}

interface AccountManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  refreshAccounts?: () => void;
}

export default function AccountManagementModal({ isOpen, onClose, refreshAccounts }: AccountManagementModalProps) {
  const { theme } = useTheme();
  const { addNotification } = useNotification();
  const { storageMode, isLocalStorageEnabled, saveToLocalStorage, loadFromLocalStorage } = useStorage();
  const [accounts, setAccounts] = useState<FacebookAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [compactView, setCompactView] = useState(true);
  const [expandedRows, setExpandedRows] = useState<Record<string, boolean>>({});

  const [showScrollTop, setShowScrollTop] = useState(false);
  const [showCopyMenu, setShowCopyMenu] = useState(false);
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [showBulkAdd, setShowBulkAdd] = useState(false);
  const [showStorageSettings, setShowStorageSettings] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Bulk add states
  const [bulkAccountsText, setBulkAccountsText] = useState('');
  const [parsedAccounts, setParsedAccounts] = useState<any[]>([]);
  const [detectedFormat, setDetectedFormat] = useState<string>('');
  const [showPreview, setShowPreview] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [importMode, setImportMode] = useState<'auto' | 'manual'>('auto');
  const [fieldMapping, setFieldMapping] = useState<string[]>([]);
  const [availableFields] = useState([
    'uid', 'pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token',
    'email_client_id', 'proxy', 'useragent', 'birthday', 'email_refresh_token', 'notes'
  ]);
  const [fieldLabels] = useState({
    uid: 'UID',
    pass: 'Mật khẩu', 
    twofa: '2FA',
    mail: 'Email',
    passmail: 'Mật khẩu email',
    mailkp: 'Email khôi phục',
    cookie: 'Cookie',
    token: 'Token',
    email_client_id: 'Email Client ID',
    proxy: 'Proxy',
    useragent: 'UserAgent',
    birthday: 'Ngày sinh',
    email_refresh_token: 'Email Refresh Token',
    notes: 'Ghi chú'
  });

  // Load accounts on mount and when storage mode changes
  useEffect(() => {
    if (isOpen) {
      loadAccounts();
      
      // Xóa các key bảo mật khỏi localStorage để bảo mật
      try { localStorage.removeItem('user_encryption_key') } catch {}
      try { localStorage.removeItem('admin_key') } catch {}
    }
  }, [isOpen, storageMode]);

  // Close copy menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('.copy-menu-container')) {
        setShowCopyMenu(false);
      }
    };

    if (showCopyMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showCopyMenu]);

  // Handle scroll to top functionality
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    setShowScrollTop(target.scrollTop > 200);
  };

  const scrollToTop = () => {
    const contentDiv = document.querySelector('.account-content') as HTMLDivElement;
    if (contentDiv) {
      contentDiv.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const loadAccounts = async () => {
    
    try {
      let data: FacebookAccount[] = [];
      
            // Load from server if enabled
      if (storageMode === 'server') {
        
      const response = await fetch('/api/facebook-accounts', {
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'x-user-key': sessionStorage.getItem('user_encryption_key') || ''
        }
      });
      
      if (response.ok) {
          data = (await response.json()).map((acc: any) => ({ ...acc, source: 'server' as const }));
          
      } else {
          
        }
      }
      
      // Load from localStorage if enabled
      if (storageMode === 'local') {
        
        const localData = (loadFromLocalStorage() || []).map((acc: any) => ({ ...acc, source: 'local' as const }));
        
        
        if (storageMode === 'local') {
          data = localData;
          
        } else if (storageMode === 'both') {
          // Merge server and local data, prioritize server data
          // Deduplicate by uid to avoid duplicates when saving to both stores
          const serverUids = new Set((data || []).map((acc: any) => String(acc.uid || '')));
          const localOnly = (localData || []).filter((acc: any) => !serverUids.has(String(acc.uid || '')));
          data = [...data, ...localOnly];
          
        }
      }
      
      
      setAccounts(data);
    } catch (error) {
      
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteAccount = async (accountId: string) => {
    try {
      const account = accounts.find(acc => acc._id === accountId);
      if (!account) return;

      // Delete from server if it's a server account
      if (account.source !== 'local' && storageMode === 'server') {
      const response = await fetch(`/api/facebook-accounts?id=${accountId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
        if (!response.ok) {
          addNotification({
            type: 'error',
            title: 'Lỗi',
            message: 'Không thể xóa tài khoản từ server. Vui lòng thử lại!'
          });
          return;
        }
      }

      // Delete from localStorage if it's a local account or if we're in local mode
      if (account.source === 'local' || storageMode === 'local') {
        const existingAccounts = loadFromLocalStorage();
        const updatedAccounts = existingAccounts.filter(acc => acc._id !== accountId);
        saveToLocalStorage(updatedAccounts);
        try { window.dispatchEvent(new Event('local-accounts-updated')) } catch {}
        try { localStorage.setItem('facebook_accounts', JSON.stringify(updatedAccounts)) } catch {}
      }

      // Update UI
        setAccounts(accounts.filter(account => account._id !== accountId));
        setSelectedAccounts(selectedAccounts.filter(id => id !== accountId));
        if (refreshAccounts) { try { refreshAccounts() } catch {} }
      
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã xóa tài khoản thành công!'
        });
    } catch (error) {
      
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể xóa tài khoản. Vui lòng thử lại!'
      });
    }
  };

  const handleSelectAll = () => {
    if (selectedAccounts.length === filteredAccounts.length) {
      setSelectedAccounts([]);
    } else {
      setSelectedAccounts(filteredAccounts.map(account => account._id));
    }
  };

  const handleDeselectAll = () => {
    setSelectedAccounts([]);
  };

  const handleSelectAccount = (accountId: string) => {
    if (selectedAccounts.includes(accountId)) {
      setSelectedAccounts(selectedAccounts.filter(id => id !== accountId));
    } else {
      setSelectedAccounts([...selectedAccounts, accountId]);
    }
  };

  const handleDeleteSelected = async () => {
    if (selectedAccounts.length === 0) return;
    
    setIsDeleting(true);
    try {
      // Separate local and server ids
      const selected = accounts.filter(a => selectedAccounts.includes(a._id));
      const localIds = selected.filter(a => a.source === 'local').map(a => a._id);
      const serverIds = selected.filter(a => a.source !== 'local').map(a => a._id);

      console.log(`Deleting ${selectedAccounts.length} accounts: ${localIds.length} local, ${serverIds.length} server`);

      // Delete local first
      if (localIds.length > 0) {
        const existing = loadFromLocalStorage();
        const updated = existing.filter((a: any) => !localIds.includes(a._id));
        saveToLocalStorage(updated);
        console.log(`Deleted ${localIds.length} local accounts`);
      }

      // Delete server ids using bulk delete for better performance
      if (serverIds.length > 0 && storageMode === 'server') {
        if (serverIds.length > 1) {
          // Use bulk delete for multiple accounts
          console.log(`Using bulk delete for ${serverIds.length} server accounts`);
          const response = await fetch(`/api/facebook-accounts/bulk-delete?ids=${serverIds.join(',')}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
          });
          
          if (response.ok) {
            const result = await response.json();
            console.log('Bulk delete result:', result);
          } else {
            throw new Error(`Bulk delete failed: ${response.status}`);
          }
        } else {
          // Use individual delete for single account
          const response = await fetch(`/api/facebook-accounts?id=${serverIds[0]}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
          });
          
          if (!response.ok) {
            throw new Error(`Individual delete failed: ${response.status}`);
          }
        }
        console.log(`Deleted ${serverIds.length} server accounts`);
      }

      setAccounts(accounts.filter(a => !selectedAccounts.includes(a._id)));
      setSelectedAccounts([]);
      if (refreshAccounts) { try { refreshAccounts() } catch {} }
      addNotification({ type: 'success', title: 'Thành công', message: `Đã xóa ${selectedAccounts.length} tài khoản thành công!` });
    } catch (error) {
      console.error('Delete selected accounts error:', error);
      addNotification({ type: 'error', title: 'Lỗi', message: 'Không thể xóa tài khoản đã chọn. Vui lòng thử lại!' });
    } finally {
      setIsDeleting(false);
    }
  };

  const copyToClipboard = async (value: string, label: string) => {
    try {
      if (!value) return;
      await navigator.clipboard.writeText(value);
      addNotification({ type: 'success', title: 'Đã copy', message: `${label} đã được copy vào clipboard` });
    } catch {
      addNotification({ type: 'error', title: 'Lỗi', message: `Không thể copy ${label}` });
    }
  };

  const handleCopySelected = () => {
    if (selectedAccounts.length === 0) return;
    
    const selectedAccountData = accounts
      .filter(account => selectedAccounts.includes(account._id))
      .map(account => `${account.uid}|${account.pass}|${account.twofa}|${account.mail}|${account.passmail}|${account.mailkp}|${account.cookie}|${account.token}`)
      .join('\n');
    
    navigator.clipboard.writeText(selectedAccountData);
    setShowCopyMenu(false);
    addNotification({
      type: 'success',
      title: 'Thành công',
      message: `Đã copy ${selectedAccounts.length} tài khoản vào clipboard!`
    });
  };

  const handleCopyAll = () => {
    const allAccountData = accounts
      .map(account => `${account.uid}|${account.pass}|${account.twofa}|${account.mail}|${account.passmail}|${account.mailkp}|${account.cookie}|${account.token}`)
      .join('\n');
    
    navigator.clipboard.writeText(allAccountData);
    setShowCopyMenu(false);
    addNotification({
      type: 'success',
      title: 'Thành công',
      message: `Đã copy ${accounts.length} tài khoản vào clipboard!`
    });
  };

  const handleCopyFiltered = () => {
    const filteredAccountData = filteredAccounts
      .map(account => `${account.uid}|${account.pass}|${account.twofa}|${account.mail}|${account.passmail}|${account.mailkp}|${account.cookie}|${account.token}`)
      .join('\n');
    
    navigator.clipboard.writeText(filteredAccountData);
    setShowCopyMenu(false);
    addNotification({
      type: 'success',
      title: 'Thành công',
      message: `Đã copy ${filteredAccounts.length} tài khoản đã lọc vào clipboard!`
    });
  };

  const handleRefresh = () => {
    setLoading(true);
    loadAccounts();
  };

  const handleExport = () => {
    const csvContent = [
      ['UID', 'PASS', '2FA', 'MAIL', 'PASSMAIL', 'MAILKP', 'COOKIE', 'TOKEN', 'STATUS'],
      ...filteredAccounts.map(account => [
        account.uid,
        account.pass,
        account.twofa,
        account.mail,
        account.passmail,
        account.mailkp,
        account.cookie,
        account.token,
        account.status
      ])
    ].map(row => row.join(',')).join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `facebook_accounts_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleBulkAddAccounts = async (accountsData: any[]) => {
    let serverSuccessCount = 0;
    let serverErrorCount = 0;
    let localSuccessCount = 0;

    try {
      // Add to server if enabled - USE BULK API for better performance
      if (storageMode === 'server') {
        console.log(`Using bulk API to add ${accountsData.length} accounts to server...`);
        
        try {
          const response = await fetch('/api/facebook-accounts/bulk', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`,
              'x-user-key': sessionStorage.getItem('user_encryption_key') || ''
            },
            body: JSON.stringify({
              accounts: accountsData,
              batchSize: 1000
            })
          });

          if (response.ok) {
            const result = await response.json();
            console.log('Bulk API response:', result);
            serverSuccessCount = result.stats?.inserted || accountsData.length;
            serverErrorCount = result.stats?.errors || 0;
          } else {
            const errorText = await response.text();
            console.error('Bulk API failed:', response.status, errorText);
            throw new Error(`Bulk API failed: ${response.status}`);
          }
        } catch (error) {
          console.error('Bulk API error, falling back to individual adds:', error);
          // Fallback to individual adds if bulk fails
          for (const accountData of accountsData) {
            const result = await handleAddAccount(accountData, false);
            if (result && result.success) {
              serverSuccessCount++;
            } else {
              serverErrorCount++;
            }
          }
        }
      }

      // Add to localStorage if enabled
      if (storageMode === 'local') {
        const existingAccounts = loadFromLocalStorage();
        const newAccounts = accountsData.map(accountData => ({
          uid: accountData.uid,
          pass: accountData.pass || '',
          twofa: accountData.twofa || '',
          mail: accountData.mail || '',
          passmail: accountData.passmail || '',
          mailkp: accountData.mailkp || '',
          cookie: accountData.cookie || '',
          token: accountData.token || '',
          status: 'active',
          log: 'Tài khoản mới được thêm',
          _id: `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          source: 'local'
        }));
        
        const updatedBulk = [...existingAccounts, ...newAccounts]
        saveToLocalStorage(updatedBulk);
        try { window.dispatchEvent(new Event('local-accounts-updated')) } catch {}
        try { localStorage.setItem('facebook_accounts', JSON.stringify(updatedBulk)) } catch {}
        localSuccessCount = newAccounts.length;
      }

      // Show notification
      let message = '';
      if (storageMode === 'server') {
        message += `Server: ${serverSuccessCount} thành công, ${serverErrorCount} lỗi. `;
      }
      if (storageMode === 'local') {
        message += `Local: ${localSuccessCount} thành công.`;
    }

    addNotification({
      type: 'success',
      title: 'Thêm tài khoản hàng loạt',
        message: message.trim()
      });

      // Refresh accounts list
      loadAccounts();

    // Call refresh callback to update parent component
    if (refreshAccounts) {
      refreshAccounts();
    }
    } catch (error) {

    addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Có lỗi xảy ra khi thêm tài khoản hàng loạt'
      });
    }
  };

  const handleAddAccount = async (accountData: any, showNotification: boolean = true) => {
    // Nếu accountData là array, sử dụng bulk add
    if (Array.isArray(accountData)) {
      return await handleBulkAddAccounts(accountData);
    }
    
    const accountToAdd = {
          uid: accountData.uid,
          pass: accountData.pass || '',
          twofa: accountData.twofa || '',
          mail: accountData.mail || '',
          passmail: accountData.passmail || '',
          mailkp: accountData.mailkp || '',
          cookie: accountData.cookie || '',
          token: accountData.token || '',
          status: 'active',
          log: 'Tài khoản mới được thêm'
      };

    try {
      // Encrypt on client for local storage path to guarantee privacy-at-rest
      const userKey = (typeof window !== 'undefined' ? sessionStorage.getItem('user_encryption_key') : '') || ''
      let localEncrypted: any = accountToAdd
      // Add to server if enabled
      if (storageMode === 'server') {
        const requestBody = { accounts: [accountToAdd] };
      
      const response = await fetch('/api/facebook-accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'x-user-key': sessionStorage.getItem('user_encryption_key') || ''
        },
        body: JSON.stringify(requestBody)
        });
      
      if (response.ok) {
          const result = await response.json();
        if (result.savedAccounts && result.savedAccounts.length > 0) {
          if (showNotification) {
            addNotification({
              type: 'success',
              title: 'Thành công',
                message: 'Tài khoản đã được thêm vào server thành công'
              });
          }
          } else if (result.errors && result.errors.length > 0) {
          if (showNotification) {
            addNotification({
              type: 'error',
              title: 'Lỗi',
                message: `Có ${result.errors.length} tài khoản không thể thêm vào server`
              });
          }
            return { success: false, errors: result.errors };
        }
      } else {
        if (showNotification) {
          addNotification({
            type: 'error',
            title: 'Lỗi',
              message: 'Lỗi khi thêm tài khoản vào server'
            });
          }
          return { success: false, error: 'Lỗi khi thêm tài khoản vào server' };
        }
      }

      // Add to localStorage if enabled (store encrypted when possible)
      if (storageMode === 'local') {
        const existingAccounts = loadFromLocalStorage();
        const newAccount = {
          ...(userKey ? localEncrypted : accountToAdd),
          _id: `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          source: 'local'
        };
        
        const updated = [...existingAccounts, newAccount]
        saveToLocalStorage(updated);
        try { window.dispatchEvent(new Event('local-accounts-updated')) } catch {}
        try { localStorage.setItem('facebook_accounts', JSON.stringify(updated)) } catch {}
        if (showNotification) {
          addNotification({
            type: 'success',
            title: 'Thành công',
            message: 'Tài khoản đã được thêm vào localStorage thành công'
          });
        }
      }

      // Refresh accounts list
      loadAccounts();
      
      // Call refresh callback to update parent component
      if (refreshAccounts) {
        refreshAccounts();
      }
      
      setShowAddAccount(false);
      return { success: true, savedAccounts: [accountToAdd] };
    } catch (error) {
      
      if (showNotification) {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Lỗi khi thêm tài khoản'
        })
      }
      return { success: false, error: 'Lỗi khi thêm tài khoản' }
    }
  };

     const getStatusColor = (status: string) => {
     switch (status) {
       case 'active': return 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-700';
       case 'checking': return 'bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 border-amber-200 dark:border-amber-700';
       case 'error': return 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300 border-red-200 dark:border-red-700';
       case 'inactive': return 'bg-gray-100 dark:bg-gray-900/30 text-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700';
       default: return 'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300 border-purple-200 dark:border-purple-700';
     }
   };

     const getStatusIcon = (status: string) => {
     switch (status) {
       case 'active': return <UserCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
       case 'checking': return <RefreshCw className="w-4 h-4 animate-spin text-amber-600 dark:text-amber-400" />;
       case 'error': return <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />;
       case 'inactive': return <UserX className="w-4 h-4 text-gray-600 dark:text-gray-400" />;
       default: return <User className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
     }
   };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Active';
      case 'checking': return 'Checking';
      case 'error': return 'Error';
      case 'inactive': return 'Inactive';
      default: return 'Pending';
    }
  };

  // Helper function to extract clean UID from account data
  const extractCleanUID = (account: any): string => {
    if (!account.uid) return '';
    
    // If UID contains |, extract the first part (should be the actual UID)
    if (account.uid.includes('|')) {
      const uid = account.uid.split('|')[0];
      // Validate that it looks like a Facebook UID (numeric, 10+ digits)
      if (uid && /^\d{10,}$/.test(uid)) {
        return uid;
      }
    }
    
    // If it's already a clean UID, return as is
    if (/^\d{10,}$/.test(account.uid)) {
      return account.uid;
    }
    
    // Fallback: return the original or empty
    return account.uid || '';
  }

  // Helper function to get account data - prioritizes individual fields over UID string parsing
  const getAccountData = (account: any) => {
    
    
    // Always extract clean UID
    const cleanUID = extractCleanUID(account);
    
    // First try to use individual fields from database (new format)
    if (account.pass || account.twofa || account.mail || account.cookie || account.token) {
      
      return {
        uid: cleanUID, // Use clean UID instead of account.uid
        pass: account.pass || '',
        twofa: account.twofa || '',
        mail: account.mail || '',
        passmail: account.passmail || '',
        mailkp: account.mailkp || '',
        cookie: account.cookie || '',
        token: account.token || ''
      };
    }
    
    // Fallback to parsing UID string (legacy format)
    if (account.uid && account.uid.includes('|')) {
      
      const parts = account.uid.trim().split('|');
      
      
      const result = {
        uid: cleanUID, // Use clean UID instead of parts[0]
        pass: parts[1] || '',
        twofa: parts[2] || '',
        mail: parts[3] || '',
        passmail: parts[4] || '',
        mailkp: parts[5] || '',
        cookie: parts[6] || '',
        token: parts[7] || ''
      };
      
      
      
      return result;
    }
    
    // Default fallback
    
    return {
      uid: cleanUID, // Use clean UID instead of account.uid
      pass: '',
      twofa: '',
      mail: '',
      passmail: '',
      mailkp: '',
      cookie: '',
      token: ''
    };
  };

  // Legacy function for backward compatibility - now uses getAccountData
  const parseUidString = (uidString: string, account?: any) => {
    if (account) {
      return getAccountData(account);
    }
    
    // Legacy parsing for when only UID string is available
    if (uidString.includes('|')) {
      const parts = uidString.trim().split('|');
      return {
        uid: parts[0] || '',
        pass: parts[1] || '',
        twofa: parts[2] || '',
        mail: parts[3] || '',
        passmail: parts[4] || '',
        mailkp: parts[5] || '',
        cookie: parts[6] || '',
        token: parts[7] || ''
      };
    }
    return {
      uid: uidString,
      pass: '',
      twofa: '',
      mail: '',
      passmail: '',
      mailkp: '',
      cookie: '',
      token: ''
    };
  };

  // Auto-detect format and parse accounts
  const detectFormatAndParse = (text: string) => {
    if (!text.trim()) {
      setParsedAccounts([]);
      setDetectedFormat('');
      setFieldMapping([]);
      return;
    }

    const lines = text.trim().split('\n').filter(line => line.trim());
    if (lines.length === 0) {
      setParsedAccounts([]);
      setDetectedFormat('');
      setFieldMapping([]);
      return;
    }

    // Get field count from first line and validate format
    const firstLine = lines[0];
    const fieldCount = firstLine.split('|').length;
    const firstLineParts = firstLine.split('|');
    
    // Additional validation: check if the line actually contains data
    if (fieldCount === 1 && firstLine.trim() === '') {
      setParsedAccounts([]);
      setDetectedFormat('');
      setFieldMapping([]);
      return;
    }
    
    // Check if all lines have the same number of fields
    const consistentFormat = lines.every(line => line.split('|').length === fieldCount);
    
    // Check for common issues
    const hasEmptyLines = lines.some(line => line.trim() === '');
    const hasInvalidFormat = lines.some(line => !line.includes('|'));
    
    

    if (importMode === 'auto') {
      // Auto-detect mode with more flexible mapping
      const formatMappings: Record<number, { name: string; fields: string[] }> = {
        8: {
          name: 'UID|PASS|2FA|MAIL|PASSMAIL|MAILKP|COOKIE|TOKEN',
          fields: ['uid', 'pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token']
        },
        7: {
          name: 'UID|PASS|2FA|MAIL|PASSMAIL|MAILKP|COOKIE',
          fields: ['uid', 'pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie']
        },
        6: {
          name: 'UID|PASS|2FA|MAIL|PASSMAIL|MAILKP',
          fields: ['uid', 'pass', 'twofa', 'mail', 'passmail', 'mailkp']
        },
        5: {
          name: 'UID|PASS|2FA|MAIL|PASSMAIL',
          fields: ['uid', 'pass', 'twofa', 'mail', 'passmail']
        },
        4: {
          name: 'UID|PASS|MAIL|PASSMAIL',
          fields: ['uid', 'pass', 'mail', 'passmail']
        },
        3: {
          name: 'UID|PASS|MAIL',
          fields: ['uid', 'pass', 'mail']
        },
        2: {
          name: 'UID|PASS',
          fields: ['uid', 'pass']
        },
        1: {
          name: 'UID only',
          fields: ['uid']
        }
      };

      // Use the detected mapping or fallback to a flexible mapping
      const detectedMapping = formatMappings[fieldCount];
      if (detectedMapping) {
        setDetectedFormat(detectedMapping.name);
        setFieldMapping(detectedMapping.fields);
      } else {
        // For unknown field counts, create a flexible mapping
        const flexibleFields = ['uid', 'pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token'];
        const flexibleMapping = flexibleFields.slice(0, fieldCount);
        setDetectedFormat(`Flexible mapping (${fieldCount} fields)`);
        setFieldMapping(flexibleMapping);
      }
    } else {
      // Manual mode - initialize field mapping if empty
      if (fieldMapping.length !== fieldCount) {
        const newMapping = Array(fieldCount).fill('').map((_, index) => {
          // Smart defaults for common positions
          const defaults = ['uid', 'pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token'];
          return defaults[index] || '';
        });
        setFieldMapping(newMapping);
      }
      setDetectedFormat(`Manual mapping (${fieldCount} fields)`);
    }

    parseAccountsWithMapping(lines);
  };

  // Parse accounts using current field mapping
  const parseAccountsWithMapping = (lines: string[]) => {
    const currentMapping = importMode === 'auto' ? fieldMapping : fieldMapping;
    
    const parsed = lines.map((line, index) => {
      // Clean the line and split by |
      const cleanLine = line.trim();
      const parts = cleanLine.split('|').map(part => part.trim());
      
      
      const account: any = {
        _tempId: `temp_${index}`,
        uid: '',
        pass: '',
        twofa: '',
        mail: '',
        passmail: '',
        mailkp: '',
        cookie: '',
        token: '',
        email_client_id: '',
        proxy: '',
        useragent: '',
        birthday: '',
        email_refresh_token: '',
        notes: ''
      };

      // Map parts to fields based on current mapping
      currentMapping.forEach((field, fieldIndex) => {
        if (field && parts[fieldIndex] !== undefined && parts[fieldIndex] !== '') {
          account[field] = parts[fieldIndex];
        }
      });

      // Ensure UID is set from first part if not mapped
      if (!account.uid && parts[0] && parts[0] !== '') {
        account.uid = parts[0];
      }

      

      // Additional validation: ensure we have at least UID and one other field
      const hasValidData = account.uid && (account.pass || account.mail || account.twofa || account.cookie || account.token);
      
      
      
      return account;
    }).filter(account => {
      // More flexible filtering: accept accounts with just UID if they have some data
      const hasUID = account.uid && account.uid.length > 0;
      const hasSomeData = account.pass || account.mail || account.twofa || account.cookie || account.token;
      
      // Accept if has UID and at least one other field, or if UID looks like a valid Facebook ID
      const isValidUID = /^\d{10,}$/.test(account.uid); // Facebook IDs are typically 10+ digits
      
      
      return hasUID && (hasSomeData || isValidUID);
    });

    setParsedAccounts(parsed);
  };

  // Handle bulk text change with auto-detection
  const handleBulkTextChange = (text: string) => {
    setBulkAccountsText(text);
    
    
    // Use setTimeout to ensure state is updated before parsing
    setTimeout(() => {
      detectFormatAndParse(text);
    }, 0);
  };

  // Handle import mode change
  const handleImportModeChange = (mode: 'auto' | 'manual') => {
    setImportMode(mode);
    if (bulkAccountsText) {
      detectFormatAndParse(bulkAccountsText);
    }
  };

  // Handle field mapping change
  const handleFieldMappingChange = (index: number, field: string) => {
    const newMapping = [...fieldMapping];
    newMapping[index] = field;
    setFieldMapping(newMapping);
    
    // Re-parse with new mapping
    if (bulkAccountsText) {
      const lines = bulkAccountsText.trim().split('\n').filter(line => line.trim());
      parseAccountsWithMapping(lines);
    }
  };

  // Re-parse when fieldMapping changes (for auto mode)
  useEffect(() => {
    if (bulkAccountsText && fieldMapping.length > 0) {
      
      const lines = bulkAccountsText.trim().split('\n').filter(line => line.trim());
      
      // Only re-parse if we have a valid mapping
      if (fieldMapping.some(field => field !== '')) {
        parseAccountsWithMapping(lines);
      }
    }
  }, [fieldMapping]);

  // Get field color for visual indication
  const getFieldColor = (field: string) => {
    const colors: Record<string, string> = {
      uid: 'bg-blue-100 text-blue-800 border-blue-200',
      pass: 'bg-green-100 text-green-800 border-green-200',
      twofa: 'bg-purple-100 text-purple-800 border-purple-200',
      mail: 'bg-orange-100 text-orange-800 border-orange-200',
      passmail: 'bg-red-100 text-red-800 border-red-200',
      mailkp: 'bg-pink-100 text-pink-800 border-pink-200',
      cookie: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      token: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      email_client_id: 'bg-cyan-100 text-cyan-800 border-cyan-200',
      proxy: 'bg-gray-100 text-gray-800 border-gray-200',
      useragent: 'bg-slate-100 text-slate-800 border-slate-200',
      birthday: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      email_refresh_token: 'bg-amber-100 text-amber-800 border-amber-200',
      notes: 'bg-neutral-100 text-neutral-800 border-neutral-200'
    };
    return colors[field] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const filteredAccounts = accounts.filter(account => {
    const matchesSearch = account.uid.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         account.pass.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         account.mail.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || account.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: accounts.length,
    active: accounts.filter(a => a.status === 'active').length,
    checking: accounts.filter(a => a.status === 'checking').length,
    error: accounts.filter(a => a.status === 'error').length,
    inactive: accounts.filter(a => a.status === 'inactive').length,
    selected: selectedAccounts.length
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-7xl h-[90vh] flex flex-col">
        {/* Header - Compact */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-700">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">Quản lý tài khoản</h2>
              <p className="text-xs text-gray-600 dark:text-gray-400">Quản lý tất cả tài khoản Facebook của bạn</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Stats Bar - Compact */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
          <div className="flex flex-wrap items-center justify-center gap-3">
            <div className="flex items-center space-x-2 bg-blue-50 dark:bg-blue-900/20 px-3 py-2 rounded-lg">
              <Users className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="text-sm font-semibold text-gray-900 dark:text-white">{stats.total}</span>
              <span className="text-xs text-gray-600 dark:text-gray-400">Tổng</span>
            </div>
            <div className="flex items-center space-x-2 bg-emerald-50 dark:bg-emerald-900/20 px-3 py-2 rounded-lg">
              <UserCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span className="text-sm font-semibold text-gray-900 dark:text-white">{stats.active}</span>
              <span className="text-xs text-gray-600 dark:text-gray-400">Active</span>
            </div>
            <div className="flex items-center space-x-2 bg-amber-50 dark:bg-amber-900/20 px-3 py-2 rounded-lg">
              <RefreshCw className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span className="text-sm font-semibold text-gray-900 dark:text-white">{stats.checking}</span>
              <span className="text-xs text-gray-600 dark:text-gray-400">Checking</span>
            </div>
            <div className="flex items-center space-x-2 bg-red-50 dark:bg-red-900/20 px-3 py-2 rounded-lg">
              <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
              <span className="text-sm font-semibold text-gray-900 dark:text-white">{stats.error}</span>
              <span className="text-xs text-gray-600 dark:text-gray-400">Error</span>
            </div>
            <div className="flex items-center space-x-2 bg-gray-50 dark:bg-gray-900/20 px-3 py-2 rounded-lg">
              <UserX className="w-4 h-4 text-gray-600 dark:text-gray-400" />
              <span className="text-sm font-semibold text-gray-900 dark:text-white">{stats.inactive}</span>
              <span className="text-xs text-gray-600 dark:text-gray-400">Inactive</span>
            </div>
            <div className="flex items-center space-x-2 bg-purple-50 dark:bg-purple-900/20 px-3 py-2 rounded-lg">
              <Star className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span className="text-sm font-semibold text-gray-900 dark:text-white">{stats.selected}</span>
              <span className="text-xs text-gray-600 dark:text-gray-400">Đã chọn</span>
            </div>
          </div>
        </div>

        {/* Controls - Compact */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
          <div className="flex flex-col space-y-3">
            {/* Top Row - Action Buttons */}
            {selectedAccounts.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleDeleteSelected}
                  disabled={isDeleting}
                  className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg transition-colors text-sm ${
                    isDeleting 
                      ? 'bg-gray-400 cursor-not-allowed' 
                      : 'bg-red-500 hover:bg-red-600'
                  } text-white`}
                >
                  {isDeleting ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span className="font-medium">Đang xóa...</span>
                    </>
                  ) : (
                    <>
                      <Trash className="w-3.5 h-3.5" />
                      <span className="font-medium">Xóa đã chọn ({selectedAccounts.length})</span>
                    </>
                  )}
                </button>
                <button
                  onClick={handleCopySelected}
                  className="flex items-center space-x-2 px-3 py-1.5 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors text-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="font-medium">Copy đã chọn</span>
                </button>
                <button
                  onClick={handleDeselectAll}
                  className="flex items-center space-x-2 px-3 py-1.5 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors text-sm"
                >
                  <X className="w-3.5 h-3.5" />
                  <span className="font-medium">Bỏ chọn tất cả</span>
                </button>
              </div>
            )}
            
            {/* Bottom Row - Tools and Search */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              {/* Left Tools */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Copy Menu */}
                <div className="relative copy-menu-container">
                  <button
                    onClick={() => setShowCopyMenu(!showCopyMenu)}
                    className="flex items-center space-x-2 px-3 py-1.5 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors text-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span className="font-medium">Copy</span>
                    <ChevronDown className="w-3 h-3" />
                  </button>
                  
                  {showCopyMenu && (
                    <div className="absolute top-full left-0 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-10 min-w-[200px]">
                      <button
                        onClick={handleCopyAll}
                        className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                      >
                        Copy tất cả ({accounts.length})
                      </button>
                      <button
                        onClick={handleCopyFiltered}
                        className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                      >
                        Copy đã lọc ({filteredAccounts.length})
                      </button>
                      {selectedAccounts.length > 0 && (
                        <button
                          onClick={handleCopySelected}
                          className="w-full px-4 py-2 text-left text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        >
                          Copy đã chọn ({selectedAccounts.length})
                        </button>
                      )}
                    </div>
                  )}
                </div>
                
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-3 py-1.5 border border-gray-200 dark:border-gray-600 rounded-lg focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                >
                  <option value="all">Tất cả trạng thái</option>
                  <option value="active">Active</option>
                  <option value="checking">Checking</option>
                  <option value="error">Error</option>
                  <option value="inactive">Inactive</option>
                </select>
                
                <button
                  onClick={handleRefresh}
                  className="flex items-center space-x-2 px-3 py-1.5 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors text-sm"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span className="font-medium">Tải lại</span>
                </button>
                
                <button
                  onClick={handleExport}
                  className="flex items-center space-x-2 px-3 py-1.5 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors text-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span className="font-medium">Xuất CSV</span>
                </button>
                
                <button
                  onClick={() => setShowBulkAdd(true)}
                  className="flex items-center space-x-2 px-3 py-1.5 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors text-sm"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span className="font-medium">Thêm hàng loạt</span>
                </button>

                <button
                  onClick={() => setShowStorageSettings(true)}
                  className="flex items-center space-x-2 px-3 py-1.5 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors text-sm"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span className="font-medium">
                    {storageMode === 'local' ? 'Local' : 'Server'}
                  </span>
                </button>
              </div>

              {/* Right Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewMode('table')}
                  className={`p-1.5 rounded-lg transition-colors ${viewMode === 'table' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  <BarChart3 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-1.5 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
                >
                  <Users className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setCompactView(!compactView)}
                  className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${compactView ? 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200'}`}
                  title={compactView ? 'Đang ở chế độ gọn' : 'Đang ở chế độ đầy đủ'}
                >
                  {compactView ? 'Gọn' : 'Đầy đủ'}
                </button>
              </div>
            </div>
            
            {/* Search Bar - Full Width */}
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Tìm kiếm tài khoản..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none text-gray-900 placeholder-gray-500 font-medium"
              />
            </div>
          </div>
        </div>



        {/* Content */}
        <div className="flex-1 overflow-hidden">
          <div 
            className="h-full overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-gray-100 hover:scrollbar-thumb-gray-400 account-content"
            onScroll={handleScroll}
          >
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <div className="text-gray-600 dark:text-gray-400 text-xl font-medium">Đang tải...</div>
              </div>
            </div>
          ) : (
            <>
                             {filteredAccounts.length > 10 && (
                 <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                   <div className="flex items-center space-x-2 text-blue-700 dark:text-blue-300">
                     <div className="w-2 h-2 bg-blue-500 dark:bg-blue-400 rounded-full animate-pulse"></div>
                     <span className="text-sm font-medium">Có {filteredAccounts.length} tài khoản - Cuộn xuống để xem thêm</span>
                   </div>
                 </div>
               )}
              {filteredAccounts.length === 0 ? (
                <div className="flex items-center justify-center h-64">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Users className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Không có tài khoản nào</h3>
                    <p className="text-gray-600 dark:text-gray-400 text-sm">
                      {searchTerm || filterStatus !== 'all' 
                        ? 'Không tìm thấy tài khoản phù hợp với bộ lọc'
                        : 'Bạn chưa thêm tài khoản nào. Hãy thêm tài khoản đầu tiên!'
                      }
                    </p>
                  </div>
                </div>
              ) : viewMode === 'table' ? (
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                                             <thead className="bg-gray-50 dark:bg-gray-700">
                        {compactView ? (
                         <tr>
                           <th className="text-left py-4 px-6">
                             <input
                               type="checkbox"
                               checked={selectedAccounts.length === filteredAccounts.length && filteredAccounts.length > 0}
                               onChange={handleSelectAll}
                               className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                             />
                           </th>
                           <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                            <div className="flex items-center space-x-2">
                              <User className="w-4 h-4 text-blue-600" />
                              <span>USER ID</span>
                            </div>
                          </th>
                                                     <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                             <div className="flex items-center space-x-2">
                               <Lock className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
                               <span>PASS</span>
                             </div>
                           </th>
                           <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                             <div className="flex items-center space-x-2">
                               <Mail className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                               <span>MAIL</span>
                             </div>
                           </th>
                           <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                             <div className="flex items-center space-x-2">
                                <Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                                <span>TRẠNG THÁI</span>
                             </div>
                           </th>
                            <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">CHI TIẾT</th>
                           <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                             <div className="flex items-center space-x-2">
                                <Settings className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                                <span>THAO TÁC</span>
                             </div>
                           </th>
                          </tr>
                        ) : (
                          <tr>
                            <th className="text-left py-4 px-6">
                              <input
                                type="checkbox"
                                checked={selectedAccounts.length === filteredAccounts.length && filteredAccounts.length > 0}
                                onChange={handleSelectAll}
                                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                              />
                           </th>
                            <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm"><div className="flex items-center space-x-2"><User className="w-4 h-4 text-blue-600" /><span>USER ID</span></div></th>
                            <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm"><div className="flex items-center space-x-2"><Lock className="w-4 h-4 text-yellow-600 dark:text-yellow-400" /><span>PASS</span></div></th>
                            <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm"><div className="flex items-center space-x-2"><Mail className="w-4 h-4 text-purple-600 dark:text-purple-400" /><span>MAIL</span></div></th>
                            <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm"><div className="flex items-center space-x-2"><Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /><span>TRẠNG THÁI</span></div></th>
                            <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm"><div className="flex items-center space-x-2"><Settings className="w-4 h-4 text-indigo-600 dark:text-indigo-400" /><span>THAO TÁC</span></div></th>
                            <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">CHI TIẾT</th>
                           <th className="text-left py-4 px-6 text-gray-700 dark:text-gray-300 font-semibold text-sm">
                             <div className="flex items-center space-x-2">
                               <Settings className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                               <span>THAO TÁC</span>
                             </div>
                           </th>
                        </tr>
                        )}
                      </thead>
                      <tbody>
                                                 {filteredAccounts.map((account) => (
                          <React.Fragment key={account._id}>
                            <tr className="border-b border-gray-100 dark:border-gray-700 hover:bg-blue-50 dark:hover:bg-gray-700 transition-colors">
                             <td className="py-4 px-6">
                               <input
                                 type="checkbox"
                                 checked={selectedAccounts.includes(account._id)}
                                 onChange={() => handleSelectAccount(account._id)}
                                 className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                               />
                             </td>
                             {(() => {
                              const parsed = getAccountData(account);
                                if (compactView) {
                               return (
                                 <>
                                      <td className="py-4 px-6 text-gray-900 dark:text-white font-medium text-sm">
                                        <div className="flex items-center space-x-2">
                                          <span>{parsed.uid || '—'}</span>
                                          {parsed.uid && (
                                            <button onClick={() => copyToClipboard(parsed.uid, 'USER ID')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                              <Copy className="w-4 h-4" />
                                            </button>
                                          )}
                                        </div>
                                      </td>
                                      <td className="py-4 px-6 text-gray-700 dark:text-gray-300 text-sm">
                                        <div className="flex items-center space-x-2">
                                          <div className="truncate max-w-[160px]" title={parsed.pass || ''}>{parsed.pass || '—'}</div>
                                          {parsed.pass && (
                                            <button onClick={() => copyToClipboard(parsed.pass, 'PASS')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                              <Copy className="w-4 h-4" />
                                            </button>
                                          )}
                                        </div>
                                      </td>
                                      <td className="py-4 px-6 text-gray-600 dark:text-gray-400 text-sm">
                                        <div className="flex items-center space-x-2">
                                          <div className="truncate max-w-[180px]" title={parsed.mail || ''}>{parsed.mail || '—'}</div>
                                          {parsed.mail && (
                                            <button onClick={() => copyToClipboard(parsed.mail, 'MAIL')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                              <Copy className="w-4 h-4" />
                                            </button>
                                          )}
                                        </div>
                                      </td>
                                      <td className="py-4 px-6">
                                        <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(account.status)}`}>
                                          {getStatusIcon(account.status)}
                                          <span>{getStatusText(account.status)}</span>
                                        </span>
                                      </td>
                                      <td className="py-4 px-6">
                                        <button
                                          onClick={() => setExpandedRows(prev => ({ ...prev, [account._id]: !prev[account._id] }))}
                                          title={expandedRows[account._id] ? 'Ẩn chi tiết' : 'Xem chi tiết'}
                                          aria-expanded={!!expandedRows[account._id]}
                                          className={`h-8 w-8 flex items-center justify-center rounded-lg border transition-colors focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-0
                                            ${expandedRows[account._id]
                                              ? 'bg-blue-600 text-white border-blue-600 hover:bg-blue-600'
                                              : 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800'}
                                          `}
                                        >
                                          {expandedRows[account._id] ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                                        </button>
                                      </td>
                                 </>
                               );
                                }
                                return (
                                  <>
                                    <td className="py-4 px-6 text-gray-900 dark:text-white font-medium text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span>{parsed.uid || '—'}</span>
                                        {parsed.uid && (
                                          <button onClick={() => copyToClipboard(parsed.uid, 'USER ID')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                    <td className="py-4 px-6 text-gray-700 dark:text-gray-300 text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span className="truncate max-w-[180px]" title={parsed.pass || ''}>{parsed.pass || '—'}</span>
                                        {parsed.pass && (
                                          <button onClick={() => copyToClipboard(parsed.pass, 'PASS')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                    <td className="py-4 px-6 text-gray-600 dark:text-gray-400 text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span className="truncate max-w-[200px]" title={parsed.twofa || ''}>{parsed.twofa || '—'}</span>
                                        {parsed.twofa && (
                                          <button onClick={() => copyToClipboard(parsed.twofa, '2FA')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                    <td className="py-4 px-6 text-gray-600 dark:text-gray-400 text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span className="truncate max-w-[200px]" title={parsed.mail || ''}>{parsed.mail || '—'}</span>
                                        {parsed.mail && (
                                          <button onClick={() => copyToClipboard(parsed.mail, 'MAIL')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                    <td className="py-4 px-6 text-gray-600 dark:text-gray-400 text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span className="truncate max-w-[200px]" title={parsed.passmail || ''}>{parsed.passmail || '—'}</span>
                                        {parsed.passmail && (
                                          <button onClick={() => copyToClipboard(parsed.passmail, 'PASSMAIL')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                    <td className="py-4 px-6 text-gray-600 dark:text-gray-400 text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span className="truncate max-w-[200px]" title={parsed.mailkp || ''}>{parsed.mailkp || '—'}</span>
                                        {parsed.mailkp && (
                                          <button onClick={() => copyToClipboard(parsed.mailkp, 'MAILKP')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                    <td className="py-4 px-6 text-gray-600 dark:text-gray-400 text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span className="truncate max-w-[220px]" title={parsed.cookie || ''}>{parsed.cookie || '—'}</span>
                                        {parsed.cookie && (
                                          <button onClick={() => copyToClipboard(parsed.cookie, 'COOKIE')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                                    <td className="py-4 px-6 text-gray-600 dark:text-gray-400 text-sm">
                                      <div className="flex items-center space-x-2">
                                        <span className="truncate max-w-[220px]" title={parsed.token || ''}>{parsed.token || '—'}</span>
                                        {parsed.token && (
                                          <button onClick={() => copyToClipboard(parsed.token, 'TOKEN')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                            <Copy className="w-4 h-4" />
                                          </button>
                                        )}
                                      </div>
                                    </td>
                             <td className="py-4 px-6">
                               <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(account.status)}`}>
                                 {getStatusIcon(account.status)}
                                 <span>{getStatusText(account.status)}</span>
                               </span>
                             </td>
                                  </>
                                );
                              })()}
                            <td className="py-4 px-6">
                              <div className="flex items-center space-x-2">
                                <button className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                                  <Eye className="w-4 h-4" />
                                </button>
                                <button 
                                  onClick={() => handleDeleteAccount(account._id)}
                                  className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                                >
                                  <Trash className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                            {compactView && expandedRows[account._id] && (
                              <tr className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                                <td colSpan={7} className="px-6 py-4">
                                  {(() => {
                                    const parsed = getAccountData(account);
                                    return (
                                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                                        <div>
                                          <p className="text-gray-500 dark:text-gray-400 text-xs">2FA</p>
                                          <div className="flex items-center space-x-2">
                                            <span className="text-gray-800 dark:text-gray-200 truncate max-w-[260px]" title={parsed.twofa || ''}>{parsed.twofa || '—'}</span>
                                            {parsed.twofa && (
                                              <button onClick={() => copyToClipboard(parsed.twofa, '2FA')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                <Copy className="w-4 h-4" />
                                              </button>
                                            )}
                                          </div>
                                        </div>
                                        <div>
                                          <p className="text-gray-500 dark:text-gray-400 text-xs">PASSMAIL</p>
                                          <div className="flex items-center space-x-2">
                                            <span className="text-gray-800 dark:text-gray-200 truncate max-w-[260px]" title={parsed.passmail || ''}>{parsed.passmail || '—'}</span>
                                            {parsed.passmail && (
                                              <button onClick={() => copyToClipboard(parsed.passmail, 'PASSMAIL')} className="p-1 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                <Copy className="w-4 h-4" />
                                              </button>
                                            )}
                                          </div>
                                        </div>
                                        <div>
                                          <p className="text-gray-500 dark:text-gray-400 text-xs">MAILKP</p>
                                          <div className="flex items-center space-x-2">
                                            <span className="text-gray-500 dark:text-gray-200 truncate max-w-[260px]" title={parsed.mailkp || ''}>{parsed.mailkp || '—'}</span>
                                            {parsed.mailkp && (
                                              <button onClick={() => copyToClipboard(parsed.mailkp, 'MAILKP')} className="p-1.5 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                <Copy className="w-4 h-4" />
                                              </button>
                                            )}
                                          </div>
                                        </div>
                                        <div className="md:col-span-3">
                                          <p className="text-gray-500 dark:text-gray-400 text-xs">COOKIE</p>
                                          <div className="flex items-center space-x-2">
                                            <div className="truncate max-w-[600px] text-gray-800 dark:text-gray-200" title={parsed.cookie || ''}>{parsed.cookie || '—'}</div>
                                            {parsed.cookie && (
                                              <button onClick={() => copyToClipboard(parsed.cookie, 'COOKIE')} className="p-1.5 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                <Copy className="w-4 h-4" />
                                              </button>
                                            )}
                                          </div>
                                        </div>
                                        <div className="md:col-span-3">
                                          <p className="text-gray-500 dark:text-gray-400 text-xs">TOKEN</p>
                                          <div className="flex items-center space-x-2">
                                            <div className="truncate max-w-[600px] text-gray-800 dark:text-gray-200" title={parsed.token || ''}>{parsed.token || '—'}</div>
                                            {parsed.token && (
                                              <button onClick={() => copyToClipboard(parsed.token, 'TOKEN')} className="p-1.5 rounded border border-gray-300 dark:border-gray-500 bg-gray-50 dark:bg-gray-800/40 hover:bg-gray-100 dark:hover:bg-gray-700">
                                                <Copy className="w-4 h-4" />
                                              </button>
                                            )}
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })()}
                                </td>
                              </tr>
                            )}
                          </React.Fragment>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredAccounts.map((account) => (
                    <div
                      key={account._id}
                      className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 hover:shadow-xl transition-all duration-300"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={selectedAccounts.includes(account._id)}
                            onChange={() => handleSelectAccount(account._id)}
                            className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                          />
                          <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                            <User className="w-5 h-5 text-white" />
                          </div>
                        </div>
                        <div className="flex items-center space-x-1">
                          <button className="p-1 text-gray-400 hover:text-gray-600">
                            <MoreVertical className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        {(() => {
                          // Always use getAccountData for consistent parsing
                          const parsed = getAccountData(account);
                          return (
                            <>
                              <div>
                                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">USER ID</p>
                                <p className="text-sm font-semibold text-gray-900 dark:text-white">{parsed.uid}</p>
                              </div>
                              
                              <div>
                                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">PASS</p>
                                <p className="text-sm text-gray-700 dark:text-gray-300">{parsed.pass || '—'}</p>
                              </div>
                              
                              <div>
                                <p className="text-xs text-gray-500 dark:text-gray-400 font-medium">COOKIE</p>
                                <div className="flex items-center space-x-2">
                                  <p className="text-sm text-gray-700 dark:text-gray-300 truncate max-w-[220px]" title={parsed.cookie || ''}>{parsed.cookie || '—'}</p>
                                  {parsed.cookie && (
                                    <button onClick={() => copyToClipboard(parsed.cookie, 'COOKIE')} className="p-1.5 rounded border border-gray-200 dark:border-gray-600 hover:bg-gray-100 dark:hover:bg-gray-700">
                                      <Copy className="w-4 h-4" />
                                    </button>
                                  )}
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-3 text-xs">
                                <div>
                                  <p className="text-gray-500 dark:text-gray-400 font-medium">MAIL</p>
                                  <p className="text-gray-700 dark:text-gray-300">{parsed.mail || '—'}</p>
                                </div>
                                <div>
                                  <p className="text-gray-500 dark:text-gray-400 font-medium">TOKEN</p>
                                  <p className="text-gray-700 dark:text-gray-300">{parsed.token || '—'}</p>
                                </div>
                              </div>
                            </>
                          );
                        })()}
                      </div>
                      
                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                        <button 
                          onClick={() => handleDeleteAccount(account._id)}
                          className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                        >
                          <Trash className="w-4 h-4" />
                        </button>
                        <button className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
          
          {/* Scroll to Top Button */}
          {showScrollTop && (
            <button
              onClick={scrollToTop}
              className="fixed bottom-24 right-8 p-3 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition-all duration-300 z-10"
              title="Cuộn lên đầu"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </button>
          )}
            </div>
          </div>

        {/* Footer - Compact */}
        <div className="flex-shrink-0 flex items-center justify-between p-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
          <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
            <span className="font-medium">Tổng cộng: {filteredAccounts.length}</span>
            <span className="font-medium">Đã chọn: {selectedAccounts.length}</span>
          </div>
          <div className="flex items-center space-x-3">
            <button className="px-3 py-1.5 text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors font-medium text-sm">
              Xuất dữ liệu
            </button>
            <button className="px-3 py-1.5 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-colors font-medium text-sm">
              Cập nhật
            </button>
          </div>
        </div>
       </div>

       {/* Add Account Modal */}
       {showAddAccount && (
         <AddAccountModal 
           isOpen={showAddAccount} 
           onClose={() => setShowAddAccount(false)} 
           onAddAccount={handleAddAccount}
         />
       )}

       {/* Bulk Add Modal */}
       {showBulkAdd && (
         <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-3">
               <div className="p-3 bg-gradient-to-r from-amber-500 to-orange-600 rounded-lg">
                 <Upload className="w-6 h-6 text-white" />
               </div>
                <div>
               <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Thêm tài khoản hàng loạt</h2>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Tự động nhận diện định dạng và import tài khoản</p>
             </div>
              </div>
              <button
                onClick={() => {
                  setShowBulkAdd(false);
                  setBulkAccountsText('');
                  setParsedAccounts([]);
                  setDetectedFormat('');
                  setShowPreview(false);
                  setImportMode('auto');
                  setFieldMapping([]);
                }}
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-gray-500 dark:text-gray-400" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-hidden flex" style={{ height: 'calc(100vh - 200px)' }}>
              {/* Left Panel - Input */}
              <div className="w-1/2 border-r border-gray-200 dark:border-gray-700 flex flex-col">
                <div className="p-6 space-y-4 flex-1 overflow-y-auto">
                  {/* Import Mode Tabs */}
                  <div className="flex space-x-1 bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                    <button
                      onClick={() => handleImportModeChange('auto')}
                      className={`flex-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        importMode === 'auto'
                          ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                      }`}
                    >
                      🤖 Tự động
                    </button>
                    <button
                      onClick={() => handleImportModeChange('manual')}
                      className={`flex-1 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        importMode === 'manual'
                          ? 'bg-white dark:bg-gray-600 text-gray-900 dark:text-white shadow-sm'
                          : 'text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white'
                      }`}
                    >
                      ⚙️ Thủ công
                    </button>
                  </div>

               <div>
                    <label className="block text-gray-700 dark:text-gray-300 text-sm font-semibold mb-2">
                      📝 Danh sách tài khoản
                    </label>
                 <textarea
                      value={bulkAccountsText}
                      onChange={(e) => handleBulkTextChange(e.target.value)}
                      placeholder="Nhập danh sách tài khoản (mỗi dòng một tài khoản)...&#10;&#10;Ví dụ:&#10;100001234567890|password123|ABCD1234|user@gmail.com|mailpass|backup@gmail.com|cookie_data|token_data&#10;100001234567891|password456|EFGH5678|user2@gmail.com|mailpass2|backup2@gmail.com||&#10;100001234567892|password789||user3@gmail.com|mailpass3|||"
                      className="w-full h-48 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-gray-900 dark:text-white bg-white dark:bg-gray-700 placeholder-gray-500 dark:placeholder-gray-400 font-mono text-sm resize-none"
                 />
               </div>

                  {/* Manual Field Mapping */}
                  {importMode === 'manual' && fieldMapping.length > 0 && (
                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                      <h4 className="text-sm font-semibold text-blue-900 dark:text-blue-100 mb-3">
                        🎯 Mapping trường dữ liệu ({fieldMapping.length} trường)
                      </h4>
                      <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto">
                        {fieldMapping.map((selectedField, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <span className="text-xs font-medium text-blue-700 dark:text-blue-300 w-8">
                              #{index + 1}
                            </span>
                            <select
                              value={selectedField}
                              onChange={(e) => handleFieldMappingChange(index, e.target.value)}
                              className="flex-1 text-xs px-2 py-1 border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                            >
                              <option value="">-- Bỏ qua --</option>
                              {availableFields.map(field => (
                                <option key={field} value={field}>
                                  {fieldLabels[field as keyof typeof fieldLabels] || field}
                                </option>
                              ))}
                            </select>
                          </div>
                        ))}
                      </div>
                      <div className="mt-2 text-xs text-blue-600 dark:text-blue-400">
                        💡 Chọn trường tương ứng cho từng vị trí trong dữ liệu
                      </div>
                    </div>
                  )}
                  
                  {/* Format Detection */}
                  {detectedFormat && (
                    <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
                      <div className="flex items-center space-x-2 text-green-700 dark:text-green-300">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-sm font-medium">✅ Đã nhận diện định dạng:</span>
                      </div>
                      <p className="text-sm font-mono text-green-800 dark:text-green-200 mt-1">{detectedFormat}</p>
                      <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                        Tìm thấy {parsedAccounts.length} tài khoản hợp lệ
                      </p>
                      
                      {/* Warning if no accounts found */}
                      {parsedAccounts.length === 0 && bulkAccountsText.trim() && (
                        <div className="mt-2 p-2 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded text-xs">
                          <p className="font-semibold text-yellow-700 dark:text-yellow-300">⚠️ Cảnh báo:</p>
                          <p className="text-yellow-600 dark:text-yellow-400">Không tìm thấy tài khoản hợp lệ nào. Vui lòng kiểm tra:</p>
                          <ul className="list-disc list-inside mt-1 text-yellow-600 dark:text-yellow-400">
                            <li>Định dạng dữ liệu có đúng không? (sử dụng | để phân cách)</li>
                            <li>Có dòng trống hoặc dữ liệu không hợp lệ không?</li>
                            <li>UID phải có ít nhất 10 chữ số và có ít nhất 1 trường khác</li>
                            <li>Thử chuyển sang chế độ "Thủ công" để mapping thủ công</li>
                          </ul>
                          <div className="mt-2 p-2 bg-white dark:bg-gray-700 rounded text-xs">
                            <p className="font-semibold text-gray-700 dark:text-gray-300">Gợi ý:</p>
                            <p className="text-gray-600 dark:text-gray-400">Thử dán một dòng mẫu: 100001234567890|password123|ABCD1234|user@gmail.com</p>
                          </div>
                        </div>
                      )}
                      
                      {/* Debug Info */}
                      <div className="mt-2 p-2 bg-white dark:bg-gray-700 rounded text-xs">
                        <p className="font-semibold text-gray-700 dark:text-gray-300">Debug Info:</p>
                        <p className="text-gray-600 dark:text-gray-400">Total lines: {bulkAccountsText.split('\n').filter(line => line.trim()).length}</p>
                        <p className="text-gray-600 dark:text-gray-400">Field count: {fieldMapping.length}</p>
                        <p className="text-gray-600 dark:text-gray-400">Import mode: {importMode}</p>
                        <p className="text-gray-600 dark:text-gray-400">Field mapping: {fieldMapping.join(', ')}</p>
                        <p className="text-gray-600 dark:text-gray-400">Raw text length: {bulkAccountsText.length}</p>
                      </div>
                    </div>
                  )}

                  {/* Format Guide */}
                  <div className="text-xs text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                    <p className="font-semibold mb-2">🔧 Định dạng hỗ trợ:</p>
                    <ul className="list-disc list-inside space-y-1 font-mono">
                   <li>UID|PASS|2FA|MAIL|PASSMAIL|MAILKP|COOKIE|TOKEN</li>
                      <li>UID|PASS|2FA|MAIL|PASSMAIL|MAILKP|TOKEN</li>
                      <li>UID|PASS|2FA|MAIL|PASSMAIL</li>
                      <li>UID|PASS|MAIL|PASSMAIL</li>
                      <li>UID|PASS|MAIL</li>
                      <li>UID|PASS</li>
                 </ul>
                    <p className="mt-2 text-orange-600 dark:text-orange-400">
                      💡 Hệ thống tự động nhận diện định dạng dựa trên số trường
                    </p>
               </div>
             </div>
              </div>

              {/* Right Panel - Preview */}
              <div className="w-1/2 p-6">
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      👀 Xem trước ({parsedAccounts.length})
                    </h3>
                    {parsedAccounts.length > 0 && (
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {parsedAccounts.filter(acc => acc.uid && acc.pass).length} tài khoản đầy đủ
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 overflow-y-auto border border-gray-200 dark:border-gray-600 rounded-lg">
                    {parsedAccounts.length === 0 ? (
                      <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
                        <div className="text-center">
                          <Upload className="w-12 h-12 mx-auto mb-2 opacity-50" />
                          <p>Nhập dữ liệu để xem preview</p>
                        </div>
                      </div>
                    ) : (
                      <div className="p-4 space-y-3">
                        {/* Field Mapping Header */}
                        {importMode === 'manual' && fieldMapping.length > 0 && (
                          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 border border-blue-200 dark:border-blue-800">
                            <h5 className="text-xs font-semibold text-blue-900 dark:text-blue-100 mb-2">
                              🗂️ Mapping hiện tại:
                            </h5>
                            <div className="flex flex-wrap gap-1">
                              {fieldMapping.map((field, index) => (
                                <span
                                  key={index}
                                  className={`px-2 py-1 rounded text-xs font-medium border ${
                                    field ? getFieldColor(field) : 'bg-gray-100 text-gray-500 border-gray-200'
                                  }`}
                                >
                                  #{index + 1}: {field ? (fieldLabels[field as keyof typeof fieldLabels] || field) : 'Bỏ qua'}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {parsedAccounts.slice(0, 10).map((account, index) => {
                          
                          return (
                            <div key={account._tempId} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3 border border-gray-200 dark:border-gray-600">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-xs font-medium text-gray-500 dark:text-gray-400">#{index + 1}</span>
                                <div className="flex items-center space-x-1">
                                  {account.uid && <span className="w-2 h-2 bg-blue-500 rounded-full" title="UID"></span>}
                                  {account.pass && <span className="w-2 h-2 bg-green-500 rounded-full" title="PASS"></span>}
                                  {account.mail && <span className="w-2 h-2 bg-orange-500 rounded-full" title="MAIL"></span>}
                                  {account.cookie && <span className="w-2 h-2 bg-indigo-500 rounded-full" title="COOKIE"></span>}
                                  {account.token && <span className="w-2 h-2 bg-yellow-500 rounded-full" title="TOKEN"></span>}
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-2 text-xs">
                                {/* Show all mapped fields */}
                                {Object.entries(account)
                                  .filter(([key, value]) => key !== '_tempId' && value && value.toString().trim())
                                  .slice(0, 8) // Show max 8 fields in preview
                                  .map(([key, value]) => (
                                    <div key={key}>
                                      <span className="text-gray-500 dark:text-gray-400">
                                        {fieldLabels[key as keyof typeof fieldLabels] || key.toUpperCase()}:
                                      </span>
                                      <span className="ml-1 font-mono text-gray-900 dark:text-white">
                                        {String(value).length > 15 ? String(value).substring(0, 15) + '...' : String(value)}
                                      </span>
                                    </div>
                                  ))}
                              </div>
                            </div>
                          );
                        })}
                        {parsedAccounts.length > 10 && (
                          <div className="text-center text-sm text-gray-500 dark:text-gray-400 py-2">
                            ... và {parsedAccounts.length - 10} tài khoản khác
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {parsedAccounts.length > 0 && (
                  <div>
                    <div>Sẵn sàng import <strong>{parsedAccounts.length}</strong> tài khoản</div>
                  </div>
                )}
              </div>
              <div className="flex space-x-3">
               <button
                  onClick={() => {
                    setShowBulkAdd(false);
                    setBulkAccountsText('');
                    setParsedAccounts([]);
                    setDetectedFormat('');
                    setShowPreview(false);
                    setImportMode('auto');
                    setFieldMapping([]);
                  }}
                  className="px-6 py-2 text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors font-medium"
               >
                 Hủy
               </button>
               <button
                  onClick={async () => {
                    if (parsedAccounts.length === 0) return;
                    
                    setIsProcessing(true);
                    try {
                      console.log(`Starting bulk import of ${parsedAccounts.length} accounts...`);
                      console.log('Storage mode:', storageMode);
                      
                      await handleBulkAddAccounts(parsedAccounts);
                      
                      console.log('Bulk import completed successfully');
                      setShowBulkAdd(false);
                      setBulkAccountsText('');
                      setParsedAccounts([]);
                      setDetectedFormat('');
                      setShowPreview(false);
                      setImportMode('auto');
                      setFieldMapping([]);
                      loadAccounts(); // Refresh the accounts list
                    } catch (error) {
                      console.error('Bulk import failed:', error);
                    } finally {
                      setIsProcessing(false);
                    }
                  }}
                  disabled={parsedAccounts.length === 0 || isProcessing}
                  className={`px-6 py-2 rounded-lg font-medium transition-colors ${
                    parsedAccounts.length === 0 || isProcessing
                      ? 'bg-gray-400 cursor-not-allowed text-white'
                      : 'bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:from-amber-600 hover:to-orange-700 shadow-lg'
                  }`}
                >
                  {isProcessing ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Đang thêm...</span>
                    </div>
                  ) : (
                    `🚀 Thêm ${parsedAccounts.length} tài khoản`
                  )}
               </button>
              </div>
             </div>
           </div>
         </div>
       )}

       {/* Storage Settings Modal */}
       <StorageSettingsModal 
         isOpen={showStorageSettings} 
         onClose={() => setShowStorageSettings(false)}
         onStorageModeChange={() => loadAccounts()}
       />
     </div>
   );
 } 