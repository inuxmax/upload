'use client';

import React, { useState } from 'react';
import { X, Plus, Upload, User, Lock, Shield, Mail, Key, Database, Cookie, Zap, Eye } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useNotification } from './NotificationSystem';

interface AddAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddAccount: (accountData: any) => void;
}

export default function AddAccountModal({ isOpen, onClose, onAddAccount }: AddAccountModalProps) {
  const { theme } = useTheme();
  const { addNotification } = useNotification();
  const [isBulkAdd, setIsBulkAdd] = useState(false);
  const [accountData, setAccountData] = useState({
    uid: '',
    pass: '',
    twofa: '',
    mail: '',
    passmail: '',
    mailkp: '',
    cookie: '',
    token: '',
    name: 'Chưa có',
    friends: 'Chưa có',
    gender: 'Chưa có',
    creationDate: 'Chưa có'
  });
  const [bulkData, setBulkData] = useState('');
  const [loading, setLoading] = useState(false);
  const [parsedAccounts, setParsedAccounts] = useState<any[]>([]);
  const [importMode, setImportMode] = useState<'auto' | 'manual'>('auto');
  const [formatDetected, setFormatDetected] = useState<string>('');
  const [debugInfo, setDebugInfo] = useState<any>({});
  const [importProgress, setImportProgress] = useState<{
    isImporting: boolean;
    current: number;
    total: number;
    status: string;
  }>({
    isImporting: false,
    current: 0,
    total: 0,
    status: ''
  });

  const parseAccountLine = (line: string) => {
    // Optimized parsing with early returns
    if (!line || !line.trim()) return null;
    
    // If the line contains the full format with all data
    if (line.includes('|')) {
      const parts = line.trim().split('|');
      
      // Early validation
      if (parts.length < 2 || !parts[0] || !parts[1]) return null;
      
      // Extract individual components, not store full line as UID
      const parsed = {
        uid: parts[0].trim(),
        pass: parts[1]?.trim() || '',
        twofa: parts[2]?.trim() || '',
        mail: parts[3]?.trim() || '',
        passmail: parts[4]?.trim() || '',
        mailkp: parts[5]?.trim() || '',
        cookie: parts[6]?.trim() || '',
        token: parts[7]?.trim() || '',
        name: 'Chưa có',
        friends: 'Chưa có',
        gender: 'Chưa có',
        creationDate: 'Chưa có'
      };
      return parsed;
    }
    
    // If it's just a simple UID
    const trimmedLine = line.trim();
    if (trimmedLine) {
      const parsed = {
        uid: trimmedLine,
        pass: '',
        twofa: '',
        mail: '',
        passmail: '',
        mailkp: '',
        cookie: '',
        token: '',
        name: 'Chưa có',
        friends: 'Chưa có',
        gender: 'Chưa có',
        creationDate: 'Chưa có'
      };
      return parsed;
    }
    
    return null;
  };

  // New function to parse bulk data and detect format
  const parseBulkData = (data: string) => {
    if (!data.trim()) return;
    
    const lines = data.trim().split('\n').filter(line => line.trim());
    if (lines.length === 0) return;
    
    // Detect format from first line
    const firstLine = lines[0];
    const fieldCount = firstLine.split('|').length;
    const fieldMapping = ['uid', 'pass', 'twofa', 'mail', 'passmail', 'mailkp', 'cookie', 'token'];
    
    let detectedFormat = '';
    if (fieldCount >= 2) {
      detectedFormat = fieldMapping.slice(0, fieldCount).join('|');
    }
    
    setFormatDetected(detectedFormat);
    setDebugInfo({
      totalLines: lines.length,
      fieldCount: fieldCount,
      importMode: importMode,
      fieldMapping: fieldMapping.slice(0, fieldCount),
      rawTextLength: data.length
    });
    
    // Parse all accounts with optimization
    const parsed: any[] = [];
    const batchSize = 100; // Process in smaller batches for better performance
    
    for (let i = 0; i < lines.length; i += batchSize) {
      const batch = lines.slice(i, i + batchSize);
      const batchParsed = batch
        .map(line => line.trim())
        .filter(line => line)
        .map(line => parseAccountLine(line))
        .filter(account => account && account.uid && account.pass);
      
      parsed.push(...batchParsed);
      
      // Update progress for large datasets
      if (lines.length > 1000) {
        setImportProgress(prev => ({
          ...prev,
          current: Math.min(i + batchSize, lines.length),
          total: lines.length,
          status: `Đang parse dữ liệu... ${Math.round(((i + batchSize) / lines.length) * 100)}%`
        }));
      }
    }
    
    setParsedAccounts(parsed);
    
    // Reset progress
    setImportProgress(prev => ({
      ...prev,
      current: 0,
      total: 0,
      status: ''
    }));
  };

  // Helper function to parse UID string into components
  const parseUidString = (uidString: string) => {
    if (uidString.includes('|') && uidString.split('|').length >= 8) {
      const parts = uidString.trim().split('|');
      return {
        uid: parts[0] || '',
        pass: parts[1] || '',
        twofa: parts[2] || '',
        mail: parts[3] || '',
        passmail: parts[4] || '',
        mailkp: parts[5] || '',
        cookie: parts[6] || '',
        token: parts[7] || ''
      };
    }
    return {
      uid: uidString,
      pass: '',
      twofa: '',
      mail: '',
      passmail: '',
      mailkp: '',
      cookie: '',
      token: ''
    };
  };

  const formatAccountForDB = (account: any) => {
    // Return clean data without concatenating into UID string
    return {
      uid: account.uid || '',
      pass: account.pass || '',
      twofa: account.twofa || '',
      mail: account.mail || '',
      passmail: account.passmail || '',
      mailkp: account.mailkp || '',
      cookie: account.cookie || '',
      token: account.token || '',
      name: account.name || 'Chưa có',
      friends: account.friends || 'Chưa có',
      gender: account.gender || 'Chưa có',
      creationDate: account.creationDate || 'Chưa có',
      status: 'active',
      log: 'Tài khoản mới được thêm'
    };
  };

  const handleSingleAdd = async () => {
    if (!accountData.uid || !accountData.pass) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'UID và PASS là bắt buộc!'
      });
      return;
    }

    setLoading(true);
    try {
      const formattedAccount = formatAccountForDB(accountData);
      await onAddAccount(formattedAccount);
      addNotification({
        type: 'success',
        title: 'Thành công',
        message: 'Đã thêm tài khoản thành công!'
      });
      setAccountData({
        uid: '',
        pass: '',
        twofa: '',
        mail: '',
        passmail: '',
        mailkp: '',
        cookie: '',
        token: '',
        name: 'Chưa có',
        friends: 'Chưa có',
        gender: 'Chưa có',
        creationDate: 'Chưa có'
      });
      onClose();
    } catch (error) {
      console.error('Error adding account:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể thêm tài khoản. Vui lòng thử lại!'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBulkAdd = async () => {
    if (parsedAccounts.length === 0) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Vui lòng nhập dữ liệu tài khoản hợp lệ!'
      });
      return;
    }

    setLoading(true);
    setImportProgress({
      isImporting: true,
      current: 0,
      total: parsedAccounts.length,
      status: 'Đang chuẩn bị dữ liệu...'
    });
    
    try {
      // Format all accounts for database
      const accountsToAdd = parsedAccounts.map(account => formatAccountForDB(account));
      
      console.log(`Sending ${accountsToAdd.length} accounts to bulk API...`);
      console.log('Sample account data:', accountsToAdd[0]);
      console.log('API endpoint: /api/facebook-accounts/bulk');
      setImportProgress(prev => ({ ...prev, status: 'Đang gửi dữ liệu đến server...' }));
      
      // Use high-performance bulk insert API
      const response = await fetch('/api/facebook-accounts/bulk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'x-user-key': sessionStorage.getItem('user_encryption_key') || ''
        },
        body: JSON.stringify({
          accounts: accountsToAdd,
          batchSize: 1000 // Process in batches of 1000 for optimal performance
        })
      });
      
      console.log('Response status:', response.status);
      console.log('Response headers:', Object.fromEntries(response.headers.entries()));

      if (response.ok) {
        const result = await response.json();
        console.log('Bulk API response:', result);
        
        // Show detailed success message with stats
        if (result.stats) {
          const { total, inserted, duplicates, processingTime } = result.stats;
          addNotification({
            type: 'success',
            title: 'Thêm hàng loạt thành công!',
            message: `Đã thêm ${inserted}/${total} tài khoản trong ${processingTime}ms${duplicates > 0 ? ` (${duplicates} trùng lặp)` : ''}`
          });
        } else if (result.savedAccounts && result.savedAccounts.length > 0) {
          addNotification({
            type: 'success',
            title: 'Thành công',
            message: `Đã thêm ${result.savedAccounts.length} tài khoản thành công!`
          });
        }
        
        // Show errors if any
        if (result.errors && result.errors.length > 0) {
          addNotification({
            type: 'warning',
            title: 'Cảnh báo',
            message: `${result.stats?.inserted || result.savedAccounts?.length || 0} tài khoản thành công, ${result.errors.length} lỗi`
          });
        }
        
        // Refresh accounts list in parent component
        if (typeof window !== 'undefined') {
          window.dispatchEvent(new Event('accounts-refresh'));
        }
      } else {
        const errorText = await response.text();
        console.error('Bulk API failed:', response.status, errorText);
        throw new Error(`API request failed: ${response.status} - ${errorText}`);
      }
      
      setBulkData('');
      setParsedAccounts([]);
      setFormatDetected('');
      setDebugInfo({});
      setImportProgress({
        isImporting: false,
        current: 0,
        total: 0,
        status: ''
      });
      onClose();
    } catch (error) {
      console.error('Error adding bulk accounts:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể thêm tài khoản hàng loạt. Vui lòng thử lại!'
      });
    } finally {
      setLoading(false);
      setImportProgress({
        isImporting: false,
        current: 0,
        total: 0,
        status: ''
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setAccountData(prev => ({ ...prev, [field]: value }));
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData('text');
    const parsed = parseAccountLine(pastedText);
    if (parsed) {
      setAccountData(prev => ({
        ...prev,
        ...parsed
      }));
      addNotification({
        type: 'success',
        title: 'Thành công',
        message: 'Đã tự động điền thông tin từ clipboard!'
      });
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg">
              <Plus className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                {isBulkAdd ? 'Thêm tài khoản hàng loạt' : 'Thêm tài khoản'}
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {isBulkAdd 
                  ? 'Nhập danh sách tài khoản theo format: UID|PASS|2FA|MAIL|PASSMAIL|MAILKP|COOKIE|TOKEN'
                  : 'Nhập thông tin tài khoản hoặc paste từ clipboard'
                }
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Toggle Buttons */}
        <div className="flex items-center space-x-2 p-6 border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setIsBulkAdd(false)}
            className={`px-4 py-2 rounded-lg transition-colors ${
              !isBulkAdd 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
            }`}
          >
            Thêm từng tài khoản
          </button>
          <button
            onClick={() => setIsBulkAdd(true)}
            className={`px-4 py-2 rounded-lg transition-colors ${
              isBulkAdd 
                ? 'bg-blue-500 text-white' 
                : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
            }`}
          >
            Thêm hàng loạt
          </button>
        </div>

        {/* Import Mode Selection for Bulk Add */}
        {isBulkAdd && (
          <div className="flex items-center space-x-2 px-6 pb-4 border-b border-gray-200 dark:border-gray-700">
            <button
              onClick={() => setImportMode('auto')}
              className={`px-4 py-2 rounded-lg transition-colors text-sm ${
                importMode === 'auto'
                  ? 'bg-green-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              Tự động
            </button>
            <button
              onClick={() => setImportMode('manual')}
              className={`px-4 py-2 rounded-lg transition-colors text-sm ${
                importMode === 'manual'
                  ? 'bg-green-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              Thủ công
            </button>
          </div>
        )}

        {/* Content */}
        <div className="p-6">
          {!isBulkAdd ? (
            /* Single Account Form */
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <User className="w-4 h-4 inline mr-2" />
                    UID *
                  </label>
                  <input
                    type="text"
                    value={accountData.uid}
                    onChange={(e) => handleInputChange('uid', e.target.value)}
                    onPaste={handlePaste}
                    placeholder="Nhập UID hoặc thông tin tài khoản đầy đủ"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Lock className="w-4 h-4 inline mr-2" />
                    PASS *
                  </label>
                  <input
                    type="password"
                    value={accountData.pass}
                    onChange={(e) => handleInputChange('pass', e.target.value)}
                    placeholder="Nhập mật khẩu"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Shield className="w-4 h-4 inline mr-2" />
                    2FA
                  </label>
                  <input
                    type="text"
                    value={accountData.twofa}
                    onChange={(e) => handleInputChange('twofa', e.target.value)}
                    placeholder="Nhập mã 2FA"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Mail className="w-4 h-4 inline mr-2" />
                    MAIL
                  </label>
                  <input
                    type="email"
                    value={accountData.mail}
                    onChange={(e) => handleInputChange('mail', e.target.value)}
                    placeholder="Nhập email"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Key className="w-4 h-4 inline mr-2" />
                    PASSMAIL
                  </label>
                  <input
                    type="password"
                    value={accountData.passmail}
                    onChange={(e) => handleInputChange('passmail', e.target.value)}
                    placeholder="Nhập mật khẩu email"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Database className="w-4 h-4 inline mr-2" />
                    MAILKP
                  </label>
                  <input
                    type="text"
                    value={accountData.mailkp}
                    onChange={(e) => handleInputChange('mailkp', e.target.value)}
                    placeholder="Nhập email khôi phục"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Cookie className="w-4 h-4 inline mr-2" />
                    COOKIE
                  </label>
                  <textarea
                    value={accountData.cookie}
                    onChange={(e) => handleInputChange('cookie', e.target.value)}
                    placeholder="Nhập cookie"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium resize-none"
                    rows={3}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    <Zap className="w-4 h-4 inline mr-2" />
                    TOKEN
                  </label>
                  <textarea
                    value={accountData.token}
                    onChange={(e) => handleInputChange('token', e.target.value)}
                    placeholder="Nhập token"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium resize-none"
                    rows={3}
                  />
                </div>
              </div>
            </div>
          ) : (
            /* Bulk Add Form */
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left: Data Input */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  <Upload className="w-4 h-4 inline mr-2" />
                  Danh sách tài khoản
                </label>
                              <textarea
                value={bulkData}
                onChange={(e) => {
                  setBulkData(e.target.value);
                  // Debounce parsing for better performance
                  clearTimeout((window as any).parseTimeout);
                  (window as any).parseTimeout = setTimeout(() => {
                    parseBulkData(e.target.value);
                  }, 300);
                }}
                placeholder="Nhập danh sách tài khoản (mỗi dòng một tài khoản)..."
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium resize-none"
                rows={10}
              />
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                  Mỗi dòng một tài khoản, các trường cách nhau bằng dấu |
                </p>
                
                {/* Format Detection */}
                {formatDetected && (
                  <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded-lg">
                    <div className="flex items-center space-x-2 text-green-700 dark:text-green-300">
                      <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">✓</span>
                      </div>
                      <span className="font-medium">Đã nhận diện định dạng: {formatDetected}</span>
                    </div>
                    <p className="text-sm mt-1">Tìm thấy {parsedAccounts.length} tài khoản hợp lệ</p>
                  </div>
                )}
                
                {/* Debug Info */}
                {debugInfo.totalLines && (
                  <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg">
                    <h4 className="font-medium text-blue-700 dark:text-blue-300 mb-2">Debug Info:</h4>
                    <div className="text-xs text-blue-600 dark:text-blue-400 space-y-1">
                      <div>Total lines: {debugInfo.totalLines}</div>
                      <div>Field count: {debugInfo.fieldCount}</div>
                      <div>Import mode: {debugInfo.importMode}</div>
                      <div>Field mapping: {debugInfo.fieldMapping?.join(', ')}</div>
                      <div>Raw text length: {debugInfo.rawTextLength?.toLocaleString()}</div>
                    </div>
                  </div>
                )}
                
                {/* Supported Formats */}
                <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-900/20 border border-gray-200 dark:border-gray-700 rounded-lg">
                  <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-2">Định dạng hỗ trợ:</h4>
                  <div className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                    <div>UID|PASS|2FA|MAIL|PASSMAIL|MAILKP|COOKIE|TOKEN</div>
                    <div>UID|PASS|2FA|MAIL|PASSMAIL|MAILKP|TOKEN</div>
                    <div>UID|PASS|2FA|MAIL|PASSMAIL</div>
                    <div>UID|PASS|MAIL|PASSMAIL</div>
                    <div>UID|PASS|MAIL</div>
                    <div>UID|PASS</div>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Hệ thống tự động nhận diện định dạng dựa trên số trường
                  </p>
                </div>
              </div>
              
              {/* Right: Preview */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  <Eye className="w-4 h-4 inline mr-2" />
                  Xem trước ({parsedAccounts.length})
                </label>
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 bg-gray-50 dark:bg-gray-800 max-h-80 overflow-y-auto">
                  {parsedAccounts.length > 0 ? (
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {parsedAccounts.length} tài khoản đầy đủ
                      </div>
                      {parsedAccounts.slice(0, 10).map((account, index) => (
                        <div key={index} className="text-xs bg-white dark:bg-gray-700 p-2 rounded border">
                          <div className="grid grid-cols-2 gap-2">
                            <div><span className="font-medium">UID:</span> {account.uid}</div>
                            <div><span className="font-medium">2FA:</span> {account.twofa || 'N/A'}</div>
                            <div><span className="font-medium">Mật khẩu email:</span> {account.passmail || 'N/A'}</div>
                            <div><span className="font-medium">Mật khẩu:</span> {account.pass}</div>
                            <div><span className="font-medium">Email:</span> {account.mail || 'N/A'}</div>
                            <div><span className="font-medium">Email khôi phục:</span> {account.mailkp || 'N/A'}</div>
                          </div>
                        </div>
                      ))}
                      {parsedAccounts.length > 10 && (
                        <div className="text-center text-xs text-gray-500 dark:text-gray-400 py-2">
                          ... và {parsedAccounts.length - 10} tài khoản khác
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-gray-500 dark:text-gray-400 py-8">
                      Chưa có dữ liệu để xem trước
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex flex-col space-y-4 p-6 border-t border-gray-200 dark:border-gray-700">
                  {/* Progress Bar for Bulk Import */}
        {isBulkAdd && (importProgress.isImporting || (parsedAccounts.length > 1000 && importProgress.current > 0)) && (
          <div className="w-full">
            <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
              <span>{importProgress.status || 'Đang xử lý dữ liệu...'}</span>
              <span>{importProgress.current}/{importProgress.total}</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-300 ease-out"
                style={{ 
                  width: `${importProgress.total > 0 ? (importProgress.current / importProgress.total) * 100 : 0}%` 
                }}
              ></div>
            </div>
            {/* Performance Info */}
            {parsedAccounts.length > 100 && (
              <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                Tối ưu hóa: Sử dụng API bulk insert để tăng tốc độ x{Math.max(10, Math.floor(parsedAccounts.length / 100))}
              </div>
            )}
          </div>
        )}
          
          {/* Status Message */}
          {isBulkAdd && parsedAccounts.length > 0 && !importProgress.isImporting && (
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Sẵn sàng import {parsedAccounts.length} tài khoản
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-3">
            <button
              onClick={onClose}
              disabled={importProgress.isImporting}
              className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors disabled:opacity-50"
            >
              Hủy
            </button>
            <button
              onClick={isBulkAdd ? handleBulkAdd : handleSingleAdd}
              disabled={loading || importProgress.isImporting || (isBulkAdd && parsedAccounts.length === 0)}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              {loading || importProgress.isImporting ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>{importProgress.isImporting ? 'Đang import...' : 'Đang thêm...'}</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  <span>{isBulkAdd ? 'Thêm hàng loạt' : 'Thêm tài khoản'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
} 