'use client'

import { useState } from 'react'
import { Mail, Shield, User, Image, Save, RefreshCw } from 'lucide-react'
import toast from 'react-hot-toast'

const CHANGE_TYPES = [
  { id: 'change-mail', label: 'Đổi Email', icon: Mail, description: 'Thay đổi email đăng nhập Facebook' },
  { id: 'enable-2fa', label: 'Bật 2FA', icon: Shield, description: 'Kích hoạt xác thực hai yếu tố' },
  { id: 'change-profile', label: 'Đổi Tên & Ảnh', icon: User, description: 'Thay đổi tên hiển thị và ảnh đại diện' },
]

interface ChangeTask {
  id: string
  email: string
  type: string
  status: 'pending' | 'processing' | 'success' | 'error'
  message?: string
}

export default function ChangeViaPanel() {
  const [selectedType, setSelectedType] = useState('change-mail')
  const [emailList, setEmailList] = useState('')
  const [newEmails, setNewEmails] = useState('')
  const [newNames, setNewNames] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [tasks, setTasks] = useState<ChangeTask[]>([])

  const handleSubmit = async () => {
    if (!emailList.trim()) {
      toast.error('Vui lòng nhập danh sách email')
      return
    }

    // Validate based on selected type
    if (selectedType === 'change-mail' && !newEmails.trim()) {
      toast.error('Vui lòng nhập danh sách email mới')
      return
    }

    if (selectedType === 'change-profile' && !newNames.trim()) {
      toast.error('Vui lòng nhập danh sách tên mới')
      return
    }

    setIsProcessing(true)
    setTasks([])

    try {
      const emails = emailList.split('\n').filter(email => email.trim())
      const newEmailArray = selectedType === 'change-mail' 
        ? newEmails.split('\n').filter(email => email.trim())
        : []
      const newNameArray = selectedType === 'change-profile' 
        ? newNames.split('\n').filter(name => name.trim())
        : []

      // Initialize tasks
      const initialTasks = emails.map((email, index) => ({
        id: `task-${index}`,
        email: email.trim(),
        type: selectedType,
        status: 'pending' as const
      }))
      
      setTasks(initialTasks)

      // Process each task
      for (let i = 0; i < emails.length; i++) {
        const email = emails[i].trim()
        
        // Update task status to processing
        setTasks(prev => prev.map(task => 
          task.id === `task-${i}` 
            ? { ...task, status: 'processing' }
            : task
        ))

        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 2000))
        
        // Random success/failure for demo
        const success = Math.random() > 0.2
        
        setTasks(prev => prev.map(task => 
          task.id === `task-${i}` 
            ? { 
                ...task, 
                status: success ? 'success' : 'error',
                message: success 
                  ? getSuccessMessage(selectedType, newEmailArray[i], newNameArray[i])
                  : getErrorMessage(selectedType)
              }
            : task
        ))
      }
      
      toast.success(`Đã xử lý xong ${emails.length} tài khoản`)
    } catch (error) {
      toast.error('Có lỗi xảy ra khi xử lý')
    } finally {
      setIsProcessing(false)
    }
  }

  const getSuccessMessage = (type: string, newEmail?: string, newName?: string) => {
    switch (type) {
      case 'change-mail':
        return `Đã đổi email thành: ${newEmail}`
      case 'enable-2fa':
        return 'Đã bật 2FA thành công'
      case 'change-profile':
        return `Đã đổi tên thành: ${newName}`
      default:
        return 'Thành công'
    }
  }

  const getErrorMessage = (type: string) => {
    switch (type) {
      case 'change-mail':
        return 'Lỗi: Không thể đổi email'
      case 'enable-2fa':
        return 'Lỗi: Không thể bật 2FA'
      case 'change-profile':
        return 'Lỗi: Không thể đổi thông tin'
      default:
        return 'Có lỗi xảy ra'
    }
  }

  const selectedTypeInfo = CHANGE_TYPES.find(type => type.id === selectedType)

  return (
    <div className="p-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Panel - Configuration */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Chọn loại thay đổi
          </h3>
          
          {/* Type Selection */}
          <div className="space-y-3 mb-6">
            {CHANGE_TYPES.map((type) => {
              const Icon = type.icon
              return (
                <label key={type.id} className="flex items-start cursor-pointer">
                  <input
                    type="radio"
                    name="changeType"
                    value={type.id}
                    checked={selectedType === type.id}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="mt-1 mr-3"
                  />
                  <div className="flex items-start">
                    <Icon className="h-5 w-5 mr-2 mt-0.5 text-indigo-600" />
                    <div>
                      <div className="font-medium text-gray-900">{type.label}</div>
                      <div className="text-sm text-gray-500">{type.description}</div>
                    </div>
                  </div>
                </label>
              )
            })}
          </div>

          {/* Email List Input */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Danh sách email Facebook (mỗi email một dòng)
            </label>
            <textarea
              value={emailList}
              onChange={(e) => setEmailList(e.target.value)}
              className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="email1@gmail.com&#10;email2@gmail.com&#10;email3@gmail.com"
            />
          </div>

          {/* Conditional Inputs */}
          {selectedType === 'change-mail' && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Danh sách email mới (cùng thứ tự)
              </label>
              <textarea
                value={newEmails}
                onChange={(e) => setNewEmails(e.target.value)}
                className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="newemail1@gmail.com&#10;newemail2@gmail.com&#10;newemail3@gmail.com"
              />
            </div>
          )}

          {selectedType === 'change-profile' && (
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Danh sách tên mới (cùng thứ tự)
              </label>
              <textarea
                value={newNames}
                onChange={(e) => setNewNames(e.target.value)}
                className="w-full h-32 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Nguyễn Văn A&#10;Trần Thị B&#10;Lê Văn C"
              />
            </div>
          )}

          {/* Action Button */}
          <button
            onClick={handleSubmit}
            disabled={isProcessing}
            className="flex items-center w-full justify-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {isProcessing ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            {isProcessing ? 'Đang xử lý...' : `Bắt đầu ${selectedTypeInfo?.label}`}
          </button>
        </div>

        {/* Right Panel - Progress & Results */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Tiến trình ({tasks.length})
          </h3>
          
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {tasks.map((task) => (
              <div
                key={task.id}
                className={`p-3 rounded-md border ${
                  task.status === 'success' 
                    ? 'bg-green-50 border-green-200' 
                    : task.status === 'error'
                    ? 'bg-red-50 border-red-200'
                    : task.status === 'processing'
                    ? 'bg-blue-50 border-blue-200'
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-sm">{task.email}</span>
                  <div className={`px-2 py-1 rounded-full text-xs ${
                    task.status === 'success' 
                      ? 'bg-green-100 text-green-800' 
                      : task.status === 'error'
                      ? 'bg-red-100 text-red-800'
                      : task.status === 'processing'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {task.status === 'pending' && 'Chờ xử lý'}
                    {task.status === 'processing' && 'Đang xử lý...'}
                    {task.status === 'success' && 'Thành công'}
                    {task.status === 'error' && 'Lỗi'}
                  </div>
                </div>
                {task.message && (
                  <div className="text-xs text-gray-600">{task.message}</div>
                )}
              </div>
            ))}
            
            {tasks.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Image className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>Chưa có tác vụ nào</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Info Box */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-md p-4">
        <div className="flex">
          <Shield className="h-5 w-5 text-blue-400 mr-3 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-blue-900 mb-1">Lưu ý quan trọng</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• Cần đăng nhập Hotmail trước khi sử dụng chức năng này</li>
              <li>• Đảm bảo danh sách email và dữ liệu mới có cùng thứ tự</li>
              <li>• Quá trình có thể mất vài phút tùy thuộc vào số lượng tài khoản</li>
              <li>• Một số thay đổi có thể cần thời gian để có hiệu lực</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}