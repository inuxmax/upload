'use client'

import { useState } from 'react'
import { Search, Download, RefreshCw, Eye, AlertCircle } from 'lucide-react'
import toast from 'react-hot-toast'

const CHECK_TYPES = [
  { id: 'via-quality', label: 'Check Chất Lượng Via', description: 'Kiểm tra chất lượng tài khoản Facebook' },
  { id: 'tkqc-full', label: 'Check Full TKQC', description: 'Kiểm tra đầy đủ thông tin tài khoản quảng cáo' },
  { id: 'bm-full', label: 'Check Full BM', description: 'Kiểm tra đầy đủ thông tin Business Manager' },
  { id: 'tkqc-bm', label: 'Check Full TKQC BM', description: 'Kiểm tra TKQC trong Business Manager' },
  { id: 'personal-info', label: 'Check Info Cá Nhân', description: 'Kiểm tra thông tin cá nhân Facebook' },
]

interface CheckResult {
  id: string
  email: string
  status: 'success' | 'error' | 'warning'
  data: any
}

export default function CheckInfoPanel() {
  const [selectedType, setSelectedType] = useState('via-quality')
  const [emailList, setEmailList] = useState('')
  const [isChecking, setIsChecking] = useState(false)
  const [results, setResults] = useState<CheckResult[]>([])
  const [viewingResult, setViewingResult] = useState<CheckResult | null>(null)

  const handleCheck = async () => {
    if (!emailList.trim()) {
      toast.error('Vui lòng nhập danh sách email')
      return
    }

    setIsChecking(true)
    setResults([])

    try {
      const emails = emailList.split('\n').filter(email => email.trim())
      
      // Simulate checking process
      for (let i = 0; i < emails.length; i++) {
        const email = emails[i].trim()
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        const mockResult: CheckResult = {
          id: `${selectedType}-${i}`,
          email,
          status: Math.random() > 0.3 ? 'success' : Math.random() > 0.5 ? 'warning' : 'error',
          data: generateMockData(selectedType)
        }
        
        setResults(prev => [...prev, mockResult])
      }
      
      toast.success(`Đã check xong ${emails.length} tài khoản`)
    } catch (error) {
      toast.error('Có lỗi xảy ra khi check')
    } finally {
      setIsChecking(false)
    }
  }

  const generateMockData = (type: string) => {
    switch (type) {
      case 'via-quality':
        return {
          quality: Math.random() > 0.5 ? 'Tốt' : 'Trung bình',
          score: Math.floor(Math.random() * 100),
          issues: ['2FA chưa bật', 'Thiếu ảnh đại diện']
        }
      case 'tkqc-full':
        return {
          limit: '$500',
          balance: '$127.45',
          threshold: '$250',
          spent: '$372.55',
          remaining: '$127.45',
          adminRights: 'Admin',
          createdDate: '2023-10-15',
          currency: 'USD',
          billingDate: '15',
          accountType: 'Personal',
          name: 'TKQC Test 001',
          id: 'act_123456789'
        }
      case 'bm-full':
        return {
          currency: 'USD',
          name: 'BM Test Business',
          id: '123456789012345',
          adminRights: 'Admin',
          tkqcCount: 5,
          createdDate: '2023-08-20'
        }
      case 'personal-info':
        return {
          name: 'Nguyễn Văn A',
          birthday: '1990-01-15',
          gender: 'Nam',
          friends: 245,
          location: 'Hà Nội, Việt Nam',
          workHistory: ['Công ty ABC', 'Công ty XYZ'],
          education: 'Đại học Bách Khoa'
        }
      default:
        return {}
    }
  }

  const exportResults = () => {
    if (results.length === 0) {
      toast.error('Không có dữ liệu để xuất')
      return
    }

    const csvContent = convertToCSV(results)
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)
    link.setAttribute('href', url)
    link.setAttribute('download', `check-results-${selectedType}-${Date.now()}.csv`)
    link.style.visibility = 'hidden'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const convertToCSV = (data: CheckResult[]) => {
    if (data.length === 0) return ''
    
    const headers = ['Email', 'Status', ...Object.keys(data[0].data || {})]
    const rows = data.map(item => [
      item.email,
      item.status,
      ...Object.values(item.data || {}).map(val => 
        typeof val === 'object' ? JSON.stringify(val) : val
      )
    ])
    
    return [headers, ...rows].map(row => 
      row.map(field => `"${field}"`).join(',')
    ).join('\n')
  }

  return (
    <div className="p-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Panel - Input */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Chọn loại kiểm tra
          </h3>
          
          {/* Check Type Selection */}
          <div className="space-y-3 mb-6">
            {CHECK_TYPES.map((type) => (
              <label key={type.id} className="flex items-start">
                <input
                  type="radio"
                  name="checkType"
                  value={type.id}
                  checked={selectedType === type.id}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="mt-1 mr-3"
                />
                <div>
                  <div className="font-medium text-gray-900">{type.label}</div>
                  <div className="text-sm text-gray-500">{type.description}</div>
                </div>
              </label>
            ))}
          </div>

          {/* Email List Input */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Danh sách email (mỗi email một dòng)
            </label>
            <textarea
              value={emailList}
              onChange={(e) => setEmailList(e.target.value)}
              className="w-full h-40 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="email1@gmail.com&#10;email2@gmail.com&#10;email3@gmail.com"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3">
            <button
              onClick={handleCheck}
              disabled={isChecking}
              className="flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
            >
              {isChecking ? (
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Search className="h-4 w-4 mr-2" />
              )}
              {isChecking ? 'Đang check...' : 'Bắt đầu check'}
            </button>
            
            <button
              onClick={exportResults}
              disabled={results.length === 0}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
            >
              <Download className="h-4 w-4 mr-2" />
              Xuất CSV
            </button>
          </div>
        </div>

        {/* Right Panel - Results */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Kết quả ({results.length})
          </h3>
          
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {results.map((result) => (
              <div
                key={result.id}
                className={`p-3 rounded-md border ${
                  result.status === 'success' 
                    ? 'bg-green-50 border-green-200' 
                    : result.status === 'warning'
                    ? 'bg-yellow-50 border-yellow-200'
                    : 'bg-red-50 border-red-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className={`w-3 h-3 rounded-full mr-2 ${
                      result.status === 'success' 
                        ? 'bg-green-500' 
                        : result.status === 'warning'
                        ? 'bg-yellow-500'
                        : 'bg-red-500'
                    }`}></div>
                    <span className="font-medium text-sm">{result.email}</span>
                  </div>
                  <button
                    onClick={() => setViewingResult(result)}
                    className="text-indigo-600 hover:text-indigo-800"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
            
            {results.length === 0 && !isChecking && (
              <div className="text-center py-8 text-gray-500">
                <AlertCircle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>Chưa có kết quả nào</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Result Detail Modal */}
      {viewingResult && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-96 overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-lg font-semibold">Chi tiết: {viewingResult.email}</h4>
                <button
                  onClick={() => setViewingResult(null)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
              <pre className="bg-gray-50 p-4 rounded-md text-sm overflow-x-auto">
                {JSON.stringify(viewingResult.data, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}