'use client';

import React, { useState } from 'react';
import { X, Search, Shield, AlertTriangle, CheckCircle, XCircle, DollarSign, Calendar, User, Building2, Eye, Loader2 } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useNotification } from './NotificationSystem';

interface TKQCInfo {
  account_id: string;
  name: string;
  account_status: number;
  balance?: string;
  currency?: string;
  adtrust_dsl?: number;
  disable_reason?: number;
  owner?: string;
  created_time?: string;
  next_bill_date?: string;
  is_prepay_account?: boolean;
  threshold_amount?: number;
  user_role?: string;
}

interface BMInfo {
  id: string;
  name: string;
  is_disabled_for_integrity_reasons: boolean;
  verification_status: string;
  created_time: string;
  restriction_type?: string | null;
}

interface CheckTKQCModalProps {
  isOpen: boolean;
  onClose: () => void;
  accountData?: any;
}

export default function CheckTKQCModal({ isOpen, onClose, accountData }: CheckTKQCModalProps) {
  const { theme } = useTheme();
  const { addNotification } = useNotification();
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{
    tkqc_list: TKQCInfo[];
    bm_list: BMInfo[];
    account_info: TKQCInfo | null;
    success: boolean;
    message: string;
  } | null>(null);

  const getAccountStatusText = (status: number) => {
    switch (status) {
      case 1: return { text: 'Active', color: 'text-green-600', icon: CheckCircle };
      case 2: return { text: 'Disabled', color: 'text-red-600', icon: XCircle };
      case 3: return { text: 'Unsettled', color: 'text-yellow-600', icon: AlertTriangle };
      case 7: return { text: 'Pending Review', color: 'text-blue-600', icon: Eye };
      case 9: return { text: 'In Grace Period', color: 'text-orange-600', icon: AlertTriangle };
      case 101: return { text: 'Pending Closure', color: 'text-red-500', icon: XCircle };
      default: return { text: 'Unknown', color: 'text-gray-600', icon: AlertTriangle };
    }
  };

  const getBMStatusText = (restrictionType: string | null | undefined) => {
    if (restrictionType === null) {
      return { text: 'Live Ads', color: 'text-green-600', icon: CheckCircle };
    } else if (restrictionType === 'ALE') {
      return { text: 'Die Ads', color: 'text-red-600', icon: XCircle };
    } else {
      return { text: 'Unknown', color: 'text-gray-600', icon: AlertTriangle };
    }
  };

  const handleCheckTKQC = async () => {
    setLoading(true);
    try {
      let currentToken = accountData?.eaagToken || accountData?.token || '';
      let currentCookie = accountData?.cookie || '';
      
      // Kiểm tra nếu không có token hoặc token rỗng
      if (!currentToken || currentToken.trim() === '') {
        addNotification({
          type: 'info',
          title: 'Thông báo',
          message: 'Không có token, đang thực hiện login để lấy token...'
        });
        
        try {
          const loginResponse = await fetch('/api/facebook/login', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
              accountId: accountData?._id,
              useProxy: true
            })
          });

          const loginResult = await loginResponse.json();
          
          if (loginResult.success) {
            addNotification({
              type: 'success',
              title: 'Thành công',
              message: 'Login thành công, đã lấy token!'
            });
            
            // Sử dụng token từ response
            currentToken = loginResult.data?.eaag_token || loginResult.data?.access_token || '';
            currentCookie = loginResult.data?.cookies || '';
          } else {
            addNotification({
              type: 'error',
              title: 'Lỗi',
              message: `Login thất bại: ${loginResult.message}`
            });
            return;
          }
        } catch (loginError) {
          addNotification({
            type: 'error',
            title: 'Lỗi',
            message: 'Không thể login để lấy token'
          });
          return;
        }
      }

      const response = await fetch('/api/check-tkqc', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          token: currentToken,
          cookie: currentCookie,
          accountId: accountData?._id,
          runQualityAfter: true
        }),
      });

      const data = await response.json();
      
      if (data.success) {
        setResults(data);
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: `Tìm thấy ${data.tkqc_list.length} TKQC và ${data.bm_list.length} BM`
        });
      } else {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: data.message || 'Không thể check TKQC'
        });
      }
    } catch (error) {
      console.error('Error checking TKQC:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Có lỗi xảy ra khi check TKQC'
      });
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('vi-VN');
    } catch {
      return dateString;
    }
  };

  const formatCurrency = (amount: string, currency: string = 'USD') => {
    return `${amount} ${currency}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg">
              <Search className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                Check TKQC & Business Manager
              </h2>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Kiểm tra thông tin tài khoản quảng cáo và business manager
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {/* Check Button */}
          <div className="mb-6">
            <button
              onClick={handleCheckTKQC}
              disabled={loading}
              className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Đang kiểm tra...</span>
                </>
              ) : (
                <>
                  <Search className="w-5 h-5" />
                  <span>Kiểm tra TKQC</span>
                </>
              )}
            </button>
          </div>

          {results && (
            <div className="space-y-6">
              {/* Account Info */}
              {results.account_info && (
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Thông tin tài khoản chính
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Account ID</label>
                      <p className="text-gray-900 dark:text-white font-mono">{results.account_info.account_id}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Tên tài khoản</label>
                      <p className="text-gray-900 dark:text-white">{results.account_info.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Trạng thái</label>
                      <div className="flex items-center space-x-2">
                        {(() => {
                          const status = getAccountStatusText(results.account_info.account_status);
                          const Icon = status.icon;
                          return (
                            <>
                              <Icon className={`w-4 h-4 ${status.color}`} />
                              <span className={status.color}>{status.text}</span>
                            </>
                          );
                        })()}
                      </div>
                    </div>
                    {results.account_info.balance && (
                      <div>
                        <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Số dư</label>
                        <p className="text-gray-900 dark:text-white flex items-center">
                          <DollarSign className="w-4 h-4 mr-1" />
                          {formatCurrency(results.account_info.balance, results.account_info.currency)}
                        </p>
                      </div>
                    )}
                    {results.account_info.adtrust_dsl && (
                      <div>
                        <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Ad Trust DSL</label>
                        <p className="text-gray-900 dark:text-white">{results.account_info.adtrust_dsl}</p>
                      </div>
                    )}
                    {results.account_info.created_time && (
                      <div>
                        <label className="text-sm font-medium text-gray-600 dark:text-gray-400">Ngày tạo</label>
                        <p className="text-gray-900 dark:text-white flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {formatDate(results.account_info.created_time)}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TKQC List */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                  <Shield className="w-5 h-5 mr-2" />
                  Danh sách TKQC ({results.tkqc_list.length})
                </h3>
                <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">Account ID</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">Tên</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">Trạng thái</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {results.tkqc_list.map((account, index) => {
                          const status = getAccountStatusText(account.account_status);
                          const Icon = status.icon;
                          return (
                            <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                              <td className="px-4 py-3 text-sm font-mono text-gray-900 dark:text-white">
                                {account.account_id}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                                {account.name}
                              </td>
                              <td className="px-4 py-3 text-sm">
                                <div className="flex items-center space-x-2">
                                  <Icon className={`w-4 h-4 ${status.color}`} />
                                  <span className={status.color}>{status.text}</span>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* BM List */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                  <Building2 className="w-5 h-5 mr-2" />
                  Danh sách Business Manager ({results.bm_list.length})
                </h3>
                <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 dark:bg-gray-700">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">BM ID</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">Tên</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">Trạng thái Ads</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">Verification</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-gray-600 dark:text-gray-400">Ngày tạo</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                        {results.bm_list.map((bm, index) => {
                          const adsStatus = getBMStatusText(bm.restriction_type);
                          const AdsIcon = adsStatus.icon;
                          return (
                            <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                              <td className="px-4 py-3 text-sm font-mono text-gray-900 dark:text-white">
                                {bm.id}
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                                {bm.name}
                              </td>
                              <td className="px-4 py-3 text-sm">
                                <div className="flex items-center space-x-2">
                                  <AdsIcon className={`w-4 h-4 ${adsStatus.color}`} />
                                  <span className={adsStatus.color}>{adsStatus.text}</span>
                                </div>
                              </td>
                              <td className="px-4 py-3 text-sm">
                                <span className={`px-2 py-1 rounded-full text-xs ${
                                  bm.verification_status === 'verified' 
                                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                                    : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                                }`}>
                                  {bm.verification_status}
                                </span>
                              </td>
                              <td className="px-4 py-3 text-sm text-gray-900 dark:text-white">
                                {formatDate(bm.created_time)}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end space-x-3 p-6 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
}