'use client'

import React from 'react'

export default function ConsoleSilencer() {
  React.useEffect(() => {
    if (typeof window === 'undefined') return

    const methods: Array<keyof Console> = ['log', 'error', 'warn', 'info', 'debug']
    const original: Partial<Record<keyof Console, any>> = {}

    methods.forEach((m) => { original[m] = console[m] })

    if (process.env.NODE_ENV !== 'development') {
      methods.forEach((m) => { (console as any)[m] = () => {} })
    }

    return () => {
      methods.forEach((m) => { if (original[m]) (console as any)[m] = original[m] })
    }
  }, [])

  return null
}


