'use client'

import React, { useState } from 'react'
import { 
  X, 
  Shield, 
  UserCheck, 
  Building2, 
  Edit,
  Settings,
  User,
  Database,
  Globe,
  Info,
  Mail
} from 'lucide-react'

interface RegBmOptions {
  createAdAccount?: boolean
  createPixel?: boolean
  createCatalog?: boolean
  pixelName?: string
  catalogName?: string
  method?: 'graph' | 'server2'
  businessName?: string
}

interface ShareBmOptions {
  mode?: 'single' | 'all'
  bmId?: string
  email?: string
  useMail1s?: boolean
  mail1sApiKey?: string
  mail1sAddress?: string
  role?: 'ADMIN' | 'EMPLOYEE'
  quantity?: number
  tutBackupLink?: boolean
}

interface ChangeMailOptions {
  method?: 'mail1s' | 'outlook'
  mail1sAddress?: string
  autoConfirm?: boolean
}

interface FunctionPanelProps {
  isOpen: boolean
  onClose: () => void
  selectedFunction: string | null
  onFunctionSelect: (functionName: string) => void
  regBmOptions?: RegBmOptions
  onRegBmOptionsChange?: (opts: RegBmOptions) => void
  loginOptions?: { loginFirst?: boolean; loginMethod?: 'cookie' | 'password' }
  onLoginOptionsChange?: (opts: { loginFirst?: boolean; loginMethod?: 'cookie' | 'password' }) => void
  shareBmOptions?: ShareBmOptions
  onShareBmOptionsChange?: (opts: ShareBmOptions) => void
  shareBmLinks?: { title?: string; url: string }[]
  changeMailOptions?: ChangeMailOptions
  onChangeMailOptionsChange?: (opts: ChangeMailOptions) => void
}

export default function FunctionPanel({ isOpen, onClose, selectedFunction, onFunctionSelect, regBmOptions, onRegBmOptionsChange, loginOptions, onLoginOptionsChange, shareBmOptions, onShareBmOptionsChange, shareBmLinks, changeMailOptions, onChangeMailOptionsChange }: FunctionPanelProps) {
  if (!isOpen) return null

  const loginFirst = !!(loginOptions?.loginFirst)
  const loginMethod = (loginOptions?.loginMethod || 'cookie') as 'cookie' | 'password'

  const functions = [
    {
      id: 'login-facebook',
      title: 'Đăng nhập Facebook',
      icon: User,
      functionName: 'Đăng nhập Facebook'
    },
    //{
     // id: 'login-cookie',
      //title: 'Đăng nhập bằng Cookie',
      //icon: UserCheck,
      //functionName: 'Đăng nhập bằng Cookie'
    //},
    {
      id: 'check-info-via',
      title: 'Check Info Via',
      icon: Info,
      functionName: 'Check Info Via'
    },
    {
      id: 'check-tkqc',
      title: 'Kiểm tra TKQC',
      icon: Database,
      functionName: 'Kiểm tra TKQC'
    },
    {
      id: 'reg-bm',
      title: 'Reg BM',
      icon: Building2,
      functionName: 'Reg BM'
    },
    {
      id: 'share-bm',
      title: 'Share BM',
      icon: Globe,
      functionName: 'Share BM'
    },
    {
      id: 'change-mail',
      title: 'Change Mail (tỷ lệ thấp)',
      icon: Mail,
      functionName: 'Change Mail'
    },
    {
      id: 'share-tkqc',
      title: 'Share TKQC',
      icon: Database,
      functionName: 'Share TKQC'
    },
    {
      id: 'nhet-dong-1-bm',
      title: 'Nhét Dòng 1 BM',
      icon: Edit,
      functionName: 'Nhét Dòng 1 BM'
    },
    {
      id: 'Unlook 956',
      title: 'Unlock 956 (Nội bộ)',
      icon: Edit,
      functionName: 'Unlock 956 (Nội bộ)'
    },
    {
      id: 'enable-2fa',
      title: 'Enable 2FA (tỷ lệ thấp)',
      icon: Shield,
      functionName: 'Enable 2FA'
    }
  ]

  return (
    <div className="fixed top-20 right-4 z-40 w-80">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 h-[80vh] max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="font-semibold text-gray-900 dark:text-white">Chức năng xử lý</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Function List (scrollable) */}
        <div className="p-3 overflow-y-auto flex-1">
          {functions.map((func) => {
            const Icon = func.icon
            const isSelected = selectedFunction === func.functionName
            return (
              <div key={func.id} className="mb-3">
                <button
                  onClick={() => onFunctionSelect(func.functionName)}
                  className={`w-full flex items-center justify-between p-3 rounded-lg border transition-all ${
                    isSelected 
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30' 
                      : 'border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-600/50'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      isSelected 
                        ? 'bg-blue-100 dark:bg-blue-800' 
                        : 'bg-white dark:bg-gray-600'
                    }`}>
                      <Icon className={`w-4 h-4 ${
                        isSelected 
                          ? 'text-blue-600 dark:text-blue-400' 
                          : 'text-gray-600 dark:text-gray-400'
                      }`} />
                    </div>
                    <span className={`font-medium text-sm ${
                      isSelected 
                        ? 'text-blue-700 dark:text-blue-300' 
                        : 'text-gray-700 dark:text-gray-300'
                    }`}>{func.title}</span>
                  </div>
                  
                  {/* Selected Indicator */}
                  {isSelected && (
                    <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                  )}
                </button>
              </div>
            )
          })}
          {/* Reg BM Options */}
          {selectedFunction === 'Reg BM' && (
            <div className="mt-4 space-y-3 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-800">
              <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">Tùy chọn Reg BM</div>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-sm text-gray-700 dark:text-gray-300 col-span-1">Phương thức</label>
                <select
                  className="col-span-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                  value={regBmOptions?.method || 'graph'}
                  onChange={e => onRegBmOptionsChange?.({
                    ...regBmOptions,
                    method: e.target.value as 'graph' | 'server2'
                  })}
                >
                  <option value="graph">BM 50</option>
                  <option value="server2">BM 350</option>
                </select>
              </div>
              <input
                type="text"
                placeholder="Tên doanh nghiệp (tuỳ chọn)"
                value={regBmOptions?.businessName || ''}
                onChange={e => onRegBmOptionsChange?.({
                  ...regBmOptions,
                  businessName: e.target.value
                })}
                className="w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
              />
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Tạo Ad Account</label>
                <input
                  type="checkbox"
                  checked={regBmOptions?.createAdAccount !== false}
                  onChange={e => onRegBmOptionsChange?.({
                    ...regBmOptions,
                    createAdAccount: e.target.checked
                  })}
                  className="h-4 w-4"
                />
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Tạo Pixel</label>
                <input
                  type="checkbox"
                  checked={!!regBmOptions?.createPixel}
                  onChange={e => onRegBmOptionsChange?.({
                    ...regBmOptions,
                    createPixel: e.target.checked
                  })}
                  className="h-4 w-4"
                />
              </div>
              <input
                type="text"
                placeholder="Tên Pixel (tuỳ chọn)"
                value={regBmOptions?.pixelName || ''}
                onChange={e => onRegBmOptionsChange?.({
                  ...regBmOptions,
                  pixelName: e.target.value
                })}
                disabled={!regBmOptions?.createPixel}
                className="w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100 disabled:opacity-50"
              />
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Tạo Catalog</label>
                <input
                  type="checkbox"
                  checked={!!regBmOptions?.createCatalog}
                  onChange={e => onRegBmOptionsChange?.({
                    ...regBmOptions,
                    createCatalog: e.target.checked
                  })}
                  className="h-4 w-4"
                />
              </div>
              <input
                type="text"
                placeholder="Tên Catalog (tuỳ chọn)"
                value={regBmOptions?.catalogName || ''}
                onChange={e => onRegBmOptionsChange?.({
                  ...regBmOptions,
                  catalogName: e.target.value
                })}
                disabled={!regBmOptions?.createCatalog}
                className="w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100 disabled:opacity-50"
              />
            </div>
          )}

          {selectedFunction === 'Share BM' && (
            <div className="mt-4 space-y-3 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-800">
              <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">Tùy chọn Share BM</div>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-sm text-gray-700 dark:text-gray-300 col-span-1">Chế độ share</label>
                <select
                  className="col-span-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                  value={shareBmOptions?.mode || 'single'}
                  onChange={e => onShareBmOptionsChange?.({
                    ...shareBmOptions,
                    mode: e.target.value as 'single' | 'all'
                  })}
                >
                  <option value="single">Theo ID BM</option>
                  <option value="all">Toàn bộ BM trong via</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-sm text-gray-700 dark:text-gray-300 col-span-1">Quyền</label>
                <select
                  className="col-span-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                  value={shareBmOptions?.role || 'ADMIN'}
                  onChange={e => onShareBmOptionsChange?.({ ...shareBmOptions, role: e.target.value as 'ADMIN' | 'EMPLOYEE' })}
                >
                  <option value="ADMIN">Quản trị viên</option>
                  <option value="EMPLOYEE">Nhân viên</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-sm text-gray-700 dark:text-gray-300 col-span-1">Số lượng</label>
                <input
                  type="number"
                  min={1}
                  className="col-span-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                  value={shareBmOptions?.quantity || 1}
                  onChange={e => onShareBmOptionsChange?.({ ...shareBmOptions, quantity: Math.max(1, Number(e.target.value || 1)) })}
                />
              </div>
              {(shareBmOptions?.mode || 'single') === 'single' && (
                <input
                  type="text"
                  placeholder="Nhập ID BM (ví dụ 175411228997401)"
                  value={shareBmOptions?.bmId || ''}
                  onChange={e => onShareBmOptionsChange?.({
                    ...shareBmOptions,
                    bmId: e.target.value
                  })}
                  className="w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                />
              )}
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Dùng Mail1s.Net (tự tạo email)</label>
                <input
                  type="checkbox"
                  checked={!!shareBmOptions?.useMail1s}
                  onChange={e => onShareBmOptionsChange?.({
                    ...shareBmOptions,
                    useMail1s: e.target.checked
                  })}
                  className="h-4 w-4"
                />
              </div>
              <div className="flex items-center space-x-2">
                <input
                  id="tut-backup"
                  type="checkbox"
                  checked={!!shareBmOptions?.tutBackupLink}
                  onChange={e => onShareBmOptionsChange?.({ ...shareBmOptions, tutBackupLink: e.target.checked })}
                />
                <label htmlFor="tut-backup" className="text-sm text-gray-700 dark:text-gray-300">Tut Backup Link very (fix)</label>
              </div>
              {!shareBmOptions?.useMail1s && (
                <input
                  type="email"
                  placeholder="Email nhận lời mời (ví dụ: [email protected])"
                  value={shareBmOptions?.email || ''}
                  onChange={e => onShareBmOptionsChange?.({
                    ...shareBmOptions,
                    email: e.target.value
                  })}
                  className="w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                />
              )}
              {shareBmOptions?.useMail1s && (
                <>
                  {/* API key dùng mặc định trong backend; không cần nhập */}
                  <input
                    type="text"
                    placeholder="Địa chỉ email (tuỳ chọn) ví dụ: fb_xxx@mail1s.net"
                    value={shareBmOptions?.mail1sAddress || ''}
                    onChange={e => onShareBmOptionsChange?.({
                      ...shareBmOptions,
                      mail1sAddress: e.target.value
                    })}
                    className="w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                  />
                </>
              )}

              {/* Links xác nhận (luôn hiển thị) */}
              <div className="mt-2 p-2 rounded-md bg-gray-50 dark:bg-gray-700/50 border border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between mb-1">
                  <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">Link xác nhận (Mail1s)</div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300">{Array.isArray(shareBmLinks) ? shareBmLinks.length : 0}</span>
                </div>
                <textarea
                  readOnly
                  placeholder="Chưa có link"
                  value={(shareBmLinks || []).map(l => (shareBmOptions?.mode === 'single' && shareBmOptions?.bmId ? `${shareBmOptions.bmId}|${l.url}` : l.url)).join('\n')}
                  className="w-full h-32 md:h-40 resize-none rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-xs text-gray-800 dark:text-gray-100 p-2"
                />
              </div>
            </div>
          )}

          {selectedFunction === 'Change Mail' && (
            <div className="mt-4 space-y-3 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-800">
              <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">Tùy chọn Change Mail</div>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-sm text-gray-700 dark:text-gray-300 col-span-1">Phương thức</label>
                <select
                  className="col-span-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                  value={changeMailOptions?.method || 'mail1s'}
                  onChange={e => onChangeMailOptionsChange?.({ ...(changeMailOptions || {}), method: e.target.value as 'mail1s' | 'outlook' })}
                >
                  <option value="mail1s">Mail1s (tự tạo email)</option>
                  <option value="outlook">Outlook (dùng mail đã lưu)</option>
                </select>
              </div>
              {(changeMailOptions?.method || 'mail1s') === 'mail1s' && (
                <input
                  type="text"
                  placeholder="Địa chỉ Mail1s (để trống để tự tạo)"
                  value={changeMailOptions?.mail1sAddress || ''}
                  onChange={e => onChangeMailOptionsChange?.({ ...(changeMailOptions || {}), mail1sAddress: e.target.value })}
                  className="w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                />
              )}
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Tự động xác nhận (đọc mã trong inbox)</label>
                <input
                  type="checkbox"
                  checked={changeMailOptions?.autoConfirm !== false}
                  onChange={e => onChangeMailOptionsChange?.({ ...(changeMailOptions || {}), autoConfirm: e.target.checked })}
                  className="h-4 w-4"
                />
              </div>
              <div className="text-[11px] text-gray-500 dark:text-gray-400">
                {changeMailOptions?.autoConfirm !== false 
                  ? 'Hệ thống sẽ tự động đọc inbox và xác nhận mail'
                  : 'Chỉ thêm mail mới, không xác nhận (cần xác nhận thủ công trên Facebook)'
                }
              </div>

              {/* Login options (reused) */}
              <div className="mt-4 space-y-3 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-800">
                <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">Tùy chọn đăng nhập trước khi chạy</div>
                <div className="flex items-center justify-between">
                  <label className="text-sm text-gray-700 dark:text-gray-300">Đăng nhập trước khi chạy</label>
                  <input
                    type="checkbox"
                    checked={loginFirst}
                    onChange={e => onLoginOptionsChange?.({ ...(loginOptions || {}), loginFirst: e.target.checked })}
                    className="h-4 w-4"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <label className="text-sm text-gray-700 dark:text-gray-300 col-span-1">Phương thức đăng nhập</label>
                  <select
                    className="col-span-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                    value={loginMethod}
                    onChange={e => onLoginOptionsChange?.({ ...(loginOptions || {}), loginMethod: e.target.value as 'cookie' | 'password' })}
                    disabled={!loginFirst}
                  >
                    <option value="cookie">Cookie (khuyến nghị)</option>
                    <option value="password">Password</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* Login options for selected functions */}
          {['Check Info Via', 'Enable 2FA', 'Reg BM', 'Kiểm tra TKQC', 'Check Quality Via', 'Share BM'].includes(selectedFunction || '') && (
            <div className="mt-4 space-y-3 rounded-lg border border-gray-200 dark:border-gray-700 p-3 bg-white dark:bg-gray-800">
              <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">Tùy chọn đăng nhập trước khi chạy</div>
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Đăng nhập trước khi chạy</label>
                <input
                  type="checkbox"
                  checked={loginFirst}
                  onChange={e => onLoginOptionsChange?.({ ...(loginOptions || {}), loginFirst: e.target.checked })}
                  className="h-4 w-4"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-sm text-gray-700 dark:text-gray-300 col-span-1">Phương thức đăng nhập</label>
                <select
                  className="col-span-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"
                  value={loginMethod}
                  onChange={e => onLoginOptionsChange?.({ ...(loginOptions || {}), loginMethod: e.target.value as 'cookie' | 'password' })}
                  disabled={!loginFirst}
                >
                  <option value="cookie">Cookie (khuyến nghị)</option>
                  <option value="password">Password</option>
                </select>
              </div>
              <div className="text-[11px] text-gray-500 dark:text-gray-400">
                Bật tùy chọn này để hệ thống tự đăng nhập (giữ session mới) trước khi chạy chức năng.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50">
          <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
            {selectedFunction ? `Đã chọn: ${selectedFunction}` : 'Chọn chức năng để bắt đầu xử lý'}
          </div>
        </div>
      </div>
    </div>
  )
}
