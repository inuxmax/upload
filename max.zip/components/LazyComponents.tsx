import dynamic from 'next/dynamic'

// Lazy load các component nặng
export const LazyTKQCDataTable = dynamic(() => import('./TKQCDataTable'), {
  loading: () => <div className="animate-pulse p-4">Đang tải dữ liệu...</div>,
  ssr: false
})

export const LazyFunctionPanel = dynamic(() => import('./FunctionPanel'), {
  loading: () => <div className="animate-pulse p-4">Đang tải panel...</div>,
  ssr: false
})

export const LazyAccountManagementModal = dynamic(() => import('./AccountManagementModal'), {
  loading: () => <div className="animate-pulse p-4">Đang tải modal...</div>,
  ssr: false
})

export const LazySettingsModal = dynamic(() => import('./SettingsModal'), {
  loading: () => <div className="animate-pulse p-4">Đang tải cài đặt...</div>,
  ssr: false
})
