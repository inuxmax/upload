'use client'

import { useState } from 'react'
import { Facebook, Mail, Eye, EyeOff, LogIn } from 'lucide-react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'

interface LoginFormProps {
  type: 'facebook' | 'hotmail'
}

export default function LoginForm({ type }: LoginFormProps) {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    token: '',
  })
  const [showPassword, setShowPassword] = useState(false)
  const [loginMethod, setLoginMethod] = useState<'www' | 'api'>('www')
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const isFacebook = type === 'facebook'

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Placeholder for login logic
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      toast.success(`Đăng nhập ${isFacebook ? 'Facebook' : 'Hotmail'} thành công!`)
      
      if (isFacebook) {
        router.push('/dashboard')
      } else {
        toast.success('Đã đăng nhập Hotmail để sử dụng chức năng Change Info')
      }
    } catch (error) {
      toast.error('Đăng nhập thất bại')
    } finally {
      setIsLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      {/* Header */}
      <div className="flex items-center justify-center mb-6">
        {isFacebook ? (
          <Facebook className="h-8 w-8 text-facebook mr-3" />
        ) : (
          <Mail className="h-8 w-8 text-hotmail mr-3" />
        )}
        <h3 className="text-xl font-bold text-gray-900">
          Đăng nhập {isFacebook ? 'Facebook' : 'Hotmail'}
        </h3>
      </div>

      {/* Login Method Selection for Facebook */}
      {isFacebook && (
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Phương thức đăng nhập
          </label>
          <div className="flex space-x-4">
            <label className="flex items-center">
              <input
                type="radio"
                name="loginMethod"
                value="www"
                checked={loginMethod === 'www'}
                onChange={(e) => setLoginMethod(e.target.value as 'www' | 'api')}
                className="mr-2"
              />
              Login qua WWW
            </label>
            <label className="flex items-center">
              <input
                type="radio"
                name="loginMethod"
                value="api"
                checked={loginMethod === 'api'}
                onChange={(e) => setLoginMethod(e.target.value as 'www' | 'api')}
                className="mr-2"
              />
              Login qua API
            </label>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email */}
        <div>
          <label htmlFor={`${type}-email`} className="block text-sm font-medium text-gray-700 mb-1">
            Email
          </label>
          <input
            type="email"
            id={`${type}-email`}
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            placeholder={`Nhập email ${isFacebook ? 'Facebook' : 'Hotmail'}`}
            required
          />
        </div>

        {/* Password */}
        <div>
          <label htmlFor={`${type}-password`} className="block text-sm font-medium text-gray-700 mb-1">
            Mật khẩu
          </label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              id={`${type}-password`}
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Nhập mật khẩu"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Token for API login */}
        {isFacebook && loginMethod === 'api' && (
          <div>
            <label htmlFor="token" className="block text-sm font-medium text-gray-700 mb-1">
              Access Token
            </label>
            <input
              type="text"
              id="token"
              name="token"
              value={formData.token}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="Nhập Facebook Access Token"
              required
            />
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className={`w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
            isFacebook 
              ? 'bg-facebook hover:bg-blue-700' 
              : 'bg-hotmail hover:bg-blue-700'
          } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          {isLoading ? (
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
          ) : (
            <LogIn className="h-4 w-4 mr-2" />
          )}
          {isLoading ? 'Đang đăng nhập...' : 'Đăng nhập'}
        </button>
      </form>

      {/* Note */}
      <div className="mt-4 text-xs text-gray-500 text-center">
        {isFacebook ? (
          <>
            <p>Đăng nhập Facebook để sử dụng tất cả tính năng</p>
            <p className="mt-1">WWW: Đăng nhập qua trình duyệt | API: Đăng nhập qua token</p>
          </>
        ) : (
          <p>Đăng nhập Hotmail để sử dụng các chức năng Change Info</p>
        )}
      </div>
    </div>
  )
}