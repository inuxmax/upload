'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import PreloadManager from './PreloadManager'
import { 
  Home, 
  Mail, 
  Globe, 
  RefreshCw, 
  Sun, 
  Moon, 
  User, 
  ChevronDown, 
  Crown, 
  Calendar, 
  LogOut,
  Package,
  ShoppingCart,
  Wallet,
  Settings,
  BarChart3,
  Server,
  CreditCard,
  History,
  Flag,
  MessageSquare,
  Menu,
  X
} from 'lucide-react'

interface NavigationProps {
  currentPage?: string
}

export default function Navigation({ currentPage = 'dashboard' }: NavigationProps) {
  const router = useRouter()
  const [showUserDropdown, setShowUserDropdown] = useState(false)
  const [showMobileMenu, setShowMobileMenu] = useState(false)
  const [theme, setTheme] = useState<'light' | 'dark'>('light')
  const [user, setUser] = useState<any>(null)
  const [userSubscription, setUserSubscription] = useState<any>(null)
  const [proxyInfo, setProxyInfo] = useState<any>(null)
  const [unreadCount, setUnreadCount] = useState(0)
  const unreadCountIntervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Load theme from localStorage
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark'
    if (savedTheme) {
      setTheme(savedTheme)
      document.documentElement.classList.toggle('dark', savedTheme === 'dark')
    }

    // Check token validity first
    if (!isTokenValid()) {
      console.log('Token invalid on mount, handling expiration')
      handleTokenExpiration()
      return
    }

    // Load user info
    const token = localStorage.getItem('token')
    if (token) {
      loadUserInfo()
      loadUserSubscription()
      loadProxyInfo()
      loadUnreadCount()
      
      // Start polling for unread messages
      unreadCountIntervalRef.current = setInterval(loadUnreadCount, 5000) // Check every 5 seconds
      
      return () => {
        if (unreadCountIntervalRef.current) {
          clearInterval(unreadCountIntervalRef.current)
        }
      }
    }
  }, [])

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element
      if (showUserDropdown && !target.closest('.user-dropdown')) {
        setShowUserDropdown(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [showUserDropdown])

  const loadUserInfo = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const userData = await response.json()
        setUser(userData.user)
      } else if (response.status === 401) {
        // Token expired, handle it
        console.log('Token expired in loadUserInfo')
        handleTokenExpiration()
      }
    } catch (error) {
      console.error('Error loading user info:', error)
    }
  }

  const loadUserSubscription = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/user/subscription', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setUserSubscription(data.subscription)
      } else if (response.status === 401) {
        // Token expired, handle it
        console.log('Token expired in loadUserSubscription')
        handleTokenExpiration()
      }
    } catch (error) {
      console.error('Error loading subscription:', error)
    }
  }

  const loadProxyInfo = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/proxy/get-proxy', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({})
      })

      if (response.ok) {
        const data = await response.json()
        setProxyInfo(data)
      } else if (response.status === 401) {
        // Token expired, handle it
        console.log('Token expired in loadProxyInfo')
        handleTokenExpiration()
      }
    } catch (error) {
      console.error('Error loading proxy info:', error)
    }
  }

  // Helper function to check if token is valid
  const isTokenValid = () => {
    const token = localStorage.getItem('token')
    if (!token) return false
    
    try {
      // Basic JWT expiration check (if token is JWT)
      const payload = JSON.parse(atob(token.split('.')[1]))
      const currentTime = Date.now() / 1000
      if (payload.exp && payload.exp < currentTime) {
        console.log('Token expired based on JWT payload')
        return false
      }
      return true
    } catch (error) {
      // If not JWT or can't parse, assume valid and let server decide
      return true
    }
  }

  // Function to handle token expiration
  const handleTokenExpiration = () => {
    console.log('Handling token expiration')
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    if (unreadCountIntervalRef.current) {
      clearInterval(unreadCountIntervalRef.current)
      unreadCountIntervalRef.current = null
    }
    setUser(null)
    setUserSubscription(null)
    setProxyInfo(null)
    setUnreadCount(0)
    
    // Redirect to auth page if not already there
    if (window.location.pathname !== '/auth') {
      router.push('/auth')
    }
  }

  const loadUnreadCount = async () => {
    try {
      // Check token validity before making API call
      if (!isTokenValid()) {
        console.log('Token invalid in loadUnreadCount')
        handleTokenExpiration()
        return
      }

      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/tickets/unread-count', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setUnreadCount(data.count || 0)
      } else if (response.status === 401) {
        // Token expired or invalid, handle it
        console.log('Token expired in loadUnreadCount')
        handleTokenExpiration()
      }
    } catch (error) {
      // Silent error handling for network errors
      console.debug('Network error loading unread count:', error)
    }
  }

  const updateProxyNow = async () => {
    try {
      const token = localStorage.getItem('token')
      if (!token) return

      const response = await fetch('/api/proxy/update', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        await loadProxyInfo()
      }
    } catch (error) {
      console.error('Error updating proxy:', error)
    }
  }

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light'
    setTheme(newTheme)
    localStorage.setItem('theme', newTheme)
    document.documentElement.classList.toggle('dark', newTheme === 'dark')
  }

  const toggleMobileMenu = () => {
    setShowMobileMenu(!showMobileMenu)
  }

  const closeMobileMenu = () => {
    setShowMobileMenu(false)
  }

  const handleLogout = () => {
    // Clear all data and stop polling
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    if (unreadCountIntervalRef.current) {
      clearInterval(unreadCountIntervalRef.current)
      unreadCountIntervalRef.current = null
    }
    setUser(null)
    setUserSubscription(null)
    setProxyInfo(null)
    setUnreadCount(0)
    router.push('/auth')
  }

  const getNavButtonClass = (page: string) => {
    const baseClass = "flex items-center space-x-3 text-gray-700 dark:text-gray-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors px-4 py-3 rounded-lg hover:bg-orange-50 dark:hover:bg-orange-900/20 text-sm font-medium w-full"
    const activeClass = "bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400"
    
    return currentPage === page 
      ? `${baseClass} ${activeClass}`
      : baseClass
  }

  return (
    <>
      <PreloadManager />
      {/* Desktop Navigation */}
      <div className="hidden lg:flex fixed left-0 top-0 h-full w-64 bg-white dark:bg-gray-800 shadow-xl border-r border-gray-200 dark:border-gray-700 z-50 flex-col overflow-hidden">
        {/* Logo Section */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">F</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-900 dark:text-white">FTool.VN</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">CHECKVIA</p>
            </div>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="p-4 space-y-2 flex-1 overflow-y-auto">
          {/* Dashboard Section */}
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
              Dashboard
            </h3>
            <button 
              onClick={() => router.push('/home')}
              className={getNavButtonClass('home')}
            >
              <Home className="w-5 h-5" />
              <span>Trang Chủ</span>
            </button>
          </div>

          {/* Sản Phẩm Section */}
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
              Sản Phẩm
            </h3>
            <button 
              onClick={() => router.push('/dashboard')}
              className={getNavButtonClass('dashboard')}
            >
              <Flag className="w-5 h-5" />
              <span>Facebook Tool</span>
            </button>
            <button 
              onClick={() => router.push('/outlook')}
              className={getNavButtonClass('outlook')}
            >
              <Mail className="w-5 h-5" />
              <span>Outlook</span>
            </button>
            <button 
              onClick={() => router.push('/shop-external')}
              className={getNavButtonClass('shop-external')}
            >
              <Package className="w-5 h-5" />
              <span>Shop</span>
            </button>
          </div>

          {/* Tài Khoản Section */}
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
              Tài Khoản
            </h3>
            <button 
              onClick={() => router.push('/profile?tab=orders')}
              className={getNavButtonClass('profile')}
            >
              <History className="w-5 h-5" />
              <span>Lịch sử mua hàng</span>
            </button>
          </div>

          {/* Hỗ Trợ Section */}
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
              Hỗ Trợ
            </h3>
            <button 
              onClick={() => {
                router.push('/tickets')
                // Refresh unread count when navigating to tickets
                setTimeout(loadUnreadCount, 1000)
              }}
              className={getNavButtonClass('tickets')}
            >
              <div className="relative">
                <MessageSquare className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold animate-pulse">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </div>
              <span>Hỗ trợ ticket</span>
            </button>
          </div>

          {/* Quản Lý Ví Section */}
          <div className="mb-4">
            <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
              Quản Lý Ví
            </h3>
            <button 
              onClick={() => router.push('/wallet')}
              className="flex items-center space-x-3 text-gray-700 dark:text-gray-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors px-4 py-3 rounded-lg hover:bg-orange-50 dark:hover:bg-orange-900/20 text-sm font-medium w-full"
            >
              <Wallet className="w-5 h-5" />
              <span>Nạp Tiền</span>
            </button>
            <button 
              onClick={() => router.push('/pricing')}
              className="flex items-center space-x-3 text-gray-700 dark:text-gray-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors px-4 py-3 rounded-lg hover:bg-orange-50 dark:hover:bg-orange-900/20 text-sm font-medium w-full"
            >
              <CreditCard className="w-5 h-5" />
              <span>Nâng Cấp</span>
            </button>
          </div>
        </nav>

        {/* Bottom Section - User Info & Theme Toggle */}
        <div className="mt-auto p-4 border-t border-gray-200 dark:border-gray-700">
          {/* Balance Info */}
          {user && (
            <div className="mb-3 p-3 bg-gradient-to-r from-yellow-500 to-orange-600 text-white rounded-lg shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 bg-white rounded-full flex items-center justify-center">
                    <span className="text-orange-600 text-xs font-bold">₫</span>
                  </div>
                  <span className="text-xs font-medium">Số dư</span>
                </div>
                <span className="text-sm font-bold">
                  {user.balance?.toLocaleString('vi-VN') || '0'} ₫
                </span>
              </div>
            </div>
          )}

          {/* Proxy Info */}
          {proxyInfo && (proxyInfo.proxy || proxyInfo.databaseIP) && (
            <div className="mb-3 p-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Globe className="w-3 h-3" />
                  <span className="text-xs font-medium">Proxy IP</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs">{proxyInfo.proxy || proxyInfo.databaseIP}</span>
                  <button
                    onClick={updateProxyNow}
                    className="p-0.5 text-green-100 hover:text-white transition-colors"
                    title="Làm mới proxy"
                  >
                    <RefreshCw className="w-2.5 h-2.5" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* User Profile & Theme */}
          <div className="flex items-center justify-between">
            <div className="relative user-dropdown">
              <button
                onClick={() => setShowUserDropdown(!showUserDropdown)}
                className="flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg p-2 transition-colors"
              >
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="text-left">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{user?.username || 'Unknown'}</p>
                  <div className="flex items-center space-x-1">
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {userSubscription?.plan ? userSubscription.plan.toUpperCase() : 'FREE'}
                    </p>
                    <ChevronDown className="w-3 h-3 text-gray-400" />
                  </div>
                </div>
              </button>

              {/* User Dropdown Menu */}
              {showUserDropdown && (
                <div className="absolute bottom-full left-0 mb-2 w-64 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 z-50">
                  {/* Header */}
                  <div className="p-3 border-b border-gray-200 dark:border-gray-700">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{user?.username || 'Unknown'}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {userSubscription?.plan ? userSubscription.plan.toUpperCase() : 'FREE'} Plan
                    </p>
                  </div>

                  {/* Menu Items */}
                  <div className="py-1">
                    <button
                      onClick={() => {
                        router.push('/profile')
                        setShowUserDropdown(false)
                      }}
                      className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    >
                      <User className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                      <span>Thông tin cá nhân</span>
                    </button>

                    <button
                      onClick={() => {
                        router.push('/wallet')
                        setShowUserDropdown(false)
                      }}
                      className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    >
                      <Wallet className="w-4 h-4 text-green-500" />
                      <span>Ví tiền</span>
                    </button>

                    <button
                      onClick={() => {
                        router.push('/pricing')
                        setShowUserDropdown(false)
                      }}
                      className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                    >
                      <Crown className="w-4 h-4 text-purple-500" />
                      <span>Nâng cấp</span>
                    </button>

                    <div className="border-t border-gray-200 dark:border-gray-700 my-1"></div>

                    <button
                      onClick={() => {
                        handleLogout()
                        setShowUserDropdown(false)
                      }}
                      className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Đăng xuất</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
            
            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4" />
              ) : (
                <Moon className="w-4 h-4" />
              )}
            </button>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full mt-3 flex items-center justify-center space-x-2 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors rounded-lg"
          >
            <LogOut className="w-4 h-4" />
            <span>Đăng xuất</span>
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className="lg:hidden">
        {/* Mobile Header */}
        <div className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-lg border-b border-gray-200 dark:border-gray-700 z-50 px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-orange-500 to-red-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">F</span>
              </div>
              <div>
                <h1 className="text-sm font-bold text-gray-900 dark:text-white">FTool.VN</h1>
                <p className="text-xs text-gray-500 dark:text-gray-400">CHECKVIA</p>
              </div>
            </div>

            {/* Mobile Menu Button & Theme Toggle */}
            <div className="flex items-center space-x-2">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                {theme === 'dark' ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>
              
              <button
                onClick={toggleMobileMenu}
                className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                {showMobileMenu ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Content Spacer - Prevents content from being hidden behind header */}
        <div className="h-16"></div>

        {/* Mobile Menu Overlay */}
        {showMobileMenu && (
          <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={closeMobileMenu}>
            <div className="fixed top-0 left-0 h-full w-80 bg-white dark:bg-gray-800 shadow-xl z-50 overflow-y-auto">
              {/* Mobile Menu Header */}
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-600 rounded-lg flex items-center justify-center">
                      <span className="text-white font-bold text-lg">F</span>
                    </div>
                    <div>
                      <h1 className="text-lg font-bold text-gray-900 dark:text-white">FTool.VN</h1>
                      <p className="text-xs text-gray-500 dark:text-gray-400">CHECKVIA</p>
                    </div>
                  </div>
                  <button
                    onClick={closeMobileMenu}
                    className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
                  </button>
                </div>
              </div>

              {/* Mobile Navigation Menu */}
              <nav className="p-4 space-y-2">
                {/* Dashboard Section */}
                <div className="mb-4">
                  <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
                    Dashboard
                  </h3>
                  <button 
                    onClick={() => { router.push('/home'); closeMobileMenu(); }}
                    className={getNavButtonClass('home')}
                  >
                    <Home className="w-5 h-5" />
                    <span>Trang Chủ</span>
                  </button>
                </div>

                {/* Sản Phẩm Section */}
                <div className="mb-4">
                  <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
                    Sản Phẩm
                  </h3>
                  <button 
                    onClick={() => { router.push('/dashboard'); closeMobileMenu(); }}
                    className={getNavButtonClass('dashboard')}
                  >
                    <Flag className="w-5 h-5" />
                    <span>Facebook Tool</span>
                  </button>
                  <button 
                    onClick={() => { router.push('/outlook'); closeMobileMenu(); }}
                    className={getNavButtonClass('outlook')}
                  >
                    <Mail className="w-5 h-5" />
                    <span>Outlook</span>
                  </button>
                  <button 
                    onClick={() => { router.push('/shop-external'); closeMobileMenu(); }}
                    className={getNavButtonClass('shop-external')}
                  >
                    <Package className="w-5 h-5" />
                    <span>Shop</span>
                  </button>
                </div>

                {/* Tài Khoản Section */}
                <div className="mb-4">
                  <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
                    Tài Khoản
                  </h3>
                  <button 
                    onClick={() => { router.push('/profile?tab=orders'); closeMobileMenu(); }}
                    className={getNavButtonClass('profile')}
                  >
                    <History className="w-5 h-5" />
                    <span>Lịch sử mua hàng</span>
                  </button>
                </div>

                {/* Hỗ Trợ Section */}
                <div className="mb-4">
                  <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
                    Hỗ Trợ
                  </h3>
                  <button 
                    onClick={() => { 
                      router.push('/tickets'); 
                      closeMobileMenu();
                      setTimeout(loadUnreadCount, 1000);
                    }}
                    className={getNavButtonClass('tickets')}
                  >
                    <div className="relative">
                      <MessageSquare className="w-5 h-5" />
                      {unreadCount > 0 && (
                        <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold animate-pulse">
                          {unreadCount > 99 ? '99+' : unreadCount}
                        </span>
                      )}
                    </div>
                    <span>Hỗ trợ ticket</span>
                  </button>
                </div>

                {/* Quản Lý Ví Section */}
                <div className="mb-4">
                  <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-2 px-4">
                    Quản Lý Ví
                  </h3>
                  <button 
                    onClick={() => { router.push('/wallet'); closeMobileMenu(); }}
                    className="flex items-center space-x-3 text-gray-700 dark:text-gray-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors px-4 py-3 rounded-lg hover:bg-orange-50 dark:hover:bg-orange-900/20 text-sm font-medium w-full"
                  >
                    <Wallet className="w-5 h-5" />
                    <span>Nạp Tiền</span>
                  </button>
                  <button 
                    onClick={() => { router.push('/pricing'); closeMobileMenu(); }}
                    className="flex items-center space-x-3 text-gray-700 dark:text-gray-300 hover:text-orange-600 dark:hover:text-orange-400 transition-colors px-4 py-3 rounded-lg hover:bg-orange-50 dark:hover:bg-orange-900/20 text-sm font-medium w-full"
                  >
                    <CreditCard className="w-5 h-5" />
                    <span>Nâng Cấp</span>
                  </button>
                </div>
              </nav>

              {/* Mobile Bottom Section */}
              <div className="mt-auto p-4 border-t border-gray-200 dark:border-gray-700">
                {/* Balance Info */}
                {user && (
                  <div className="mb-3 p-3 bg-gradient-to-r from-yellow-500 to-orange-600 text-white rounded-lg shadow-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-white rounded-full flex items-center justify-center">
                          <span className="text-orange-600 text-xs font-bold">₫</span>
                        </div>
                        <span className="text-xs font-medium">Số dư</span>
                      </div>
                      <span className="text-sm font-bold">
                        {user.balance?.toLocaleString('vi-VN') || '0'} ₫
                      </span>
                    </div>
                  </div>
                )}

                {/* Proxy Info */}
                {proxyInfo && (proxyInfo.proxy || proxyInfo.databaseIP) && (
                  <div className="mb-3 p-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-lg shadow-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Globe className="w-3 h-3" />
                        <span className="text-xs font-medium">Proxy IP</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs">{proxyInfo.proxy || proxyInfo.databaseIP}</span>
                        <button
                          onClick={updateProxyNow}
                          className="p-0.5 text-green-100 hover:text-white transition-colors"
                          title="Làm mới proxy"
                        >
                          <RefreshCw className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* User Profile */}
                <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{user?.username || 'Unknown'}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {userSubscription?.plan ? userSubscription.plan.toUpperCase() : 'FREE'} Plan
                    </p>
                  </div>
                </div>

                {/* Logout Button */}
                <button
                  onClick={() => { handleLogout(); closeMobileMenu(); }}
                  className="w-full mt-3 flex items-center justify-center space-x-2 px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors rounded-lg"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Đăng xuất</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  )
}
