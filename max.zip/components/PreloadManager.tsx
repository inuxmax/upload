import { useEffect } from 'react'

interface PreloadManagerProps {
  onPreloadComplete?: () => void
}

export default function PreloadManager({ onPreloadComplete }: PreloadManagerProps) {
  useEffect(() => {
    const preloadCriticalData = async () => {
      try {
        // Preload user info
        const token = localStorage.getItem('token')
        if (token) {
          // Preload user data in background
          fetch('/api/auth/me', {
            headers: { 'Authorization': `Bearer ${token}` }
          }).catch(() => {}) // Silent fail

          // Preload subscription data
          fetch('/api/user/subscription', {
            headers: { 'Authorization': `Bearer ${token}` }
          }).catch(() => {}) // Silent fail

          // Preload proxy info
          fetch('/api/proxy/get-proxy', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({})
          }).catch(() => {}) // Silent fail
        }

        // Preload critical CSS and fonts
        const link = document.createElement('link')
        link.rel = 'preload'
        link.href = '/fonts/inter-var.woff2'
        link.as = 'font'
        link.type = 'font/woff2'
        link.crossOrigin = 'anonymous'
        document.head.appendChild(link)

        onPreloadComplete?.()
      } catch (error) {
        console.warn('Preload failed:', error)
        onPreloadComplete?.()
      }
    }

    preloadCriticalData()
  }, [onPreloadComplete])

  return null
}
