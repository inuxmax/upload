import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { Activity, Clock, CheckCircle, XCircle, Loader2, ChevronDown, ChevronUp, Trash2, X } from 'lucide-react';

interface StatusLog {
  id: string;
  status: 'running' | 'success' | 'error' | 'waiting' | 'completed';
  message: string;
  timestamp: Date;
  progress?: number;
  details?: string;
}

interface RealTimeStatusLogProps {
  accountId: string;
  email: string;
  currentStatus: string;
  onStatusUpdate: (accountId: string, status: string, message?: string) => void;
}

export interface RealTimeStatusLogRef {
  addLog: (status: StatusLog['status'], message: string, details?: string, progress?: number) => void;
  clearLogs: () => void;
  getLogs: () => StatusLog[];
  loadLogsFromDatabase: () => Promise<void>;
  getCurrentStatus: () => string;
  forceRefresh: () => Promise<void>;
}

const RealTimeStatusLog = forwardRef<RealTimeStatusLogRef, RealTimeStatusLogProps>(({ 
  accountId, 
  email, 
  currentStatus, 
  onStatusUpdate 
}, ref) => {
  const [logs, setLogs] = useState<StatusLog[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [displayStatus, setDisplayStatus] = useState(currentStatus);
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Update display status when logs change
  useEffect(() => {
    if (logs.length > 0) {
      const latestLog = logs[0]; // Most recent log
      
      // Auto-update status based on latest log
      if (latestLog.status === 'completed') {
        setDisplayStatus('completed');
      } else if (latestLog.status === 'success') {
        setDisplayStatus('success');
      } else if (latestLog.status === 'error') {
        setDisplayStatus('error');
      } else if (latestLog.status === 'running') {
        setDisplayStatus('running');
      } else if (latestLog.status === 'waiting') {
        setDisplayStatus('waiting');
      } else if (latestLog.status === 'reading') {
        setDisplayStatus('reading');
      }
      
    } else {
      // If no logs, keep original status
      setDisplayStatus(currentStatus);
    }
  }, [logs, currentStatus, accountId]);

  // Load logs from database when component mounts
  useEffect(() => {
    loadLogsFromDatabase();
    
    // Tắt auto-refresh để giảm spam API calls
    // const interval = setInterval(() => {
    //   loadLogsFromDatabase();
    // }, 10000);
    
    // return () => clearInterval(interval);
  }, [accountId]);

  // Load logs from database
  const loadLogsFromDatabase = async () => {
    if (!accountId) return;
    
    try {
      setIsLoading(true);
      // Reduced logging - only log errors
      
      const response = await fetch(`/api/outlook/logs?accountId=${accountId}`);
      
      if (response.ok) {
        const result = await response.json();
        if (result.success && result.data) {
          // Convert database logs to component logs
          const dbLogs: StatusLog[] = result.data.map((log: any) => ({
            id: log._id || Date.now().toString(),
            status: log.status,
            message: log.message,
            timestamp: new Date(log.timestamp),
            progress: log.emailCount ? (log.emailCount / 100) * 100 : undefined,
            details: log.details
          }));
          
          setLogs(dbLogs);
          
          // Tắt auto-expand - chỉ mở khi người dùng chủ động click
          // setIsExpanded(false); // Luôn giữ đóng mặc định
        }
        // Removed success logging to reduce console spam
      } else {
        // Only log errors, not normal responses
        console.error(`❌ [${accountId}] Failed to load logs:`, response.status, response.statusText);
      }
    } catch (error) {
      console.error(`❌ [${accountId}] Error loading logs:`, error);
    } finally {
      setIsLoading(false);
    }
  };

  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    addLog: (status: StatusLog['status'], message: string, details?: string, progress?: number) => {
      const newLog: StatusLog = {
        id: Date.now().toString(),
        status,
        message,
        timestamp: new Date(),
        details,
        progress
      };

      setLogs(prev => [newLog, ...prev]); // Add to beginning for latest first
      
      // Update parent component status
      onStatusUpdate(accountId, status, message);
      
      // Tắt auto-expand - chỉ mở khi người dùng chủ động click
      // if (status === 'error' || status === 'success') {
      //   setIsExpanded(true);
      // }
    },
    
    clearLogs: async () => {
      try {
        // Clear from database
        await fetch(`/api/outlook/logs?accountId=${accountId}`, {
          method: 'DELETE'
        });
        
        // Clear from local state
        setLogs([]);
        // Reset to original status
        setDisplayStatus(currentStatus);
      } catch (error) {
        console.error('Failed to clear logs:', error);
        // Still clear local state even if DB clear fails
        setLogs([]);
        setDisplayStatus(currentStatus);
      }
    },
    
    getLogs: () => logs,
    
    loadLogsFromDatabase,
    
    getCurrentStatus: () => displayStatus,

    forceRefresh: async () => {
      await loadLogsFromDatabase();
    }
  }));

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  // Get status icon and color
  const getStatusDisplay = (status: string) => {
    switch (status) {
      case 'running':
        return {
          icon: <Loader2 className="h-4 w-4 animate-spin text-blue-600" />,
          color: 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-300',
          text: 'Đang chạy...'
        };
      case 'success':
        return {
          icon: <CheckCircle className="h-4 w-4 text-green-600" />,
          color: 'text-green-600 bg-green-100 dark:bg-green-900/20 dark:text-green-300',
          text: 'Thành công'
        };
      case 'error':
        return {
          icon: <XCircle className="h-4 w-4 text-red-600" />,
          color: 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-300',
          text: 'Lỗi'
        };
      case 'waiting':
        return {
          icon: <Clock className="h-4 w-4 text-yellow-600" />,
          color: 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-300',
          text: 'Đang chờ...'
        };
      case 'completed':
        return {
          icon: <CheckCircle className="h-4 w-4 text-green-600" />,
          color: 'text-green-600 bg-green-100 dark:bg-green-900/20 dark:text-green-300',
          text: 'Hoàn thành đọc mail'
        };
      case 'reading':
        return {
          icon: <Loader2 className="h-4 w-4 animate-spin text-blue-600" />,
          color: 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-300',
          text: 'Đang đọc mail...'
        };
      default:
        return {
          icon: <Activity className="h-4 w-4 text-gray-600" />,
          color: 'text-gray-600 bg-gray-100 dark:bg-gray-900/20 dark:text-gray-300',
          text: status
        };
    }
  };

  // Format timestamp
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('vi-VN', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  // Get current status display
  const currentStatusDisplay = getStatusDisplay(displayStatus);

  // Handle clear logs
  const handleClearLogs = async () => {
    try {
      await fetch(`/api/outlook/logs?accountId=${accountId}`, {
        method: 'DELETE'
      });
      setLogs([]);
      setDisplayStatus(currentStatus); // Reset to original status
    } catch (error) {
      console.error('Failed to clear logs:', error);
    }
  };

  // Handle refresh logs
  const handleRefreshLogs = () => {
    loadLogsFromDatabase();
  };

  return (
    <div className="space-y-2">
      {/* Status Badge - Clickable */}
      <div 
        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium cursor-pointer hover:opacity-80 transition-opacity ${currentStatusDisplay.color}`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {currentStatusDisplay.icon}
        <span>{currentStatusDisplay.text}</span>
        {logs.length > 0 && (
          <span className="ml-1 px-2 py-0.5 bg-white/20 rounded-full text-xs">
            {logs.length}
          </span>
        )}
        {isExpanded ? (
          <ChevronUp className="h-3 w-3" />
        ) : (
          <ChevronDown className="h-3 w-3" />
        )}
      </div>

      {/* Expandable Logs Panel */}
      {isExpanded && (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg max-h-64 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-gray-600" />
              <span className="font-medium text-sm">Logs cho {email}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleRefreshLogs}
                disabled={isLoading}
                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors disabled:opacity-50"
                title="Làm mới logs"
              >
                <Loader2 className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
              </button>
              <button
                onClick={handleClearLogs}
                className="p-1 hover:bg-red-100 dark:hover:bg-red-900/20 text-red-600 rounded transition-colors"
                title="Xóa tất cả logs"
              >
                <Trash2 className="h-3 w-3" />
              </button>
              <button
                onClick={() => setIsExpanded(false)}
                className="p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
                title="Đóng"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          </div>

          {/* Logs Content */}
          <div className="p-3 max-h-48 overflow-y-auto bg-gray-50 dark:bg-gray-900">
            {logs.length === 0 ? (
              <div className="text-center text-gray-500 dark:text-gray-400 py-8">
                <Activity className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Chưa có logs nào</p>
                <p className="text-xs">Thực hiện thao tác để tạo logs</p>
              </div>
            ) : (
              <div className="space-y-2">
                {logs.map((log) => {
                  const statusDisplay = getStatusDisplay(log.status);
                  return (
                    <div key={log.id} className="flex items-start gap-3 p-2 bg-white dark:bg-gray-800 rounded border border-gray-200 dark:border-gray-700">
                      <div className="flex-shrink-0 mt-0.5">
                        {statusDisplay.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {log.message}
                          </p>
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {formatTime(log.timestamp)}
                          </span>
                        </div>
                        
                        {log.details && (
                          <p className="text-xs text-gray-600 dark:text-gray-300 mt-1">
                            {log.details}
                          </p>
                        )}
                        
                        {log.progress !== undefined && (
                          <div className="mt-2">
                            <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
                              <span>Tiến độ</span>
                              <span>{Math.round(log.progress)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                                style={{ width: `${log.progress}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
                <div ref={logsEndRef} />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
});

RealTimeStatusLog.displayName = 'RealTimeStatusLog';

export default RealTimeStatusLog;

