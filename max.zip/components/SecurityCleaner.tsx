'use client';

import { useEffect } from 'react';

export default function SecurityCleaner() {
  useEffect(() => {
    // Xóa các key bảo mật khỏi localStorage để bảo mật
    try { localStorage.removeItem('user_encryption_key') } catch {}
    try { localStorage.removeItem('admin_key') } catch {}
    
    // Log để debug
    
  }, []);

  return null; // Component này không render gì
}
