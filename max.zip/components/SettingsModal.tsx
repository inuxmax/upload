'use client';

import React, { useState, useEffect } from 'react';
import { X, Save, Settings, Globe, Shield, Mail, User, Bell, Palette, Languages, Plus, Trash2, AlertCircle, Eye, EyeOff, Database, Cloud, HardDrive, CheckCircle, Download, Upload, AlertTriangle } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useNotification } from './NotificationSystem';
import { useStorage } from '../contexts/StorageContext';

interface SettingsData {
  httpProxies: string[];
  hotmailAccounts: string[];
  enable2FA: boolean;
  changeName: boolean;
  checkBM: boolean;
  checkTKQC: boolean;
  checkFullInfo: boolean;
  autoLogin: boolean;
  notifications: boolean;
  maxThreads: number;
  theme: 'light' | 'dark' | 'auto';
  language: 'vi' | 'en';
  globalMaxThreads?: number;
  allowUserThreadSettings?: boolean;
  selectedProxyId?: string; // Proxy server ID được chọn từ admin
  selectedProxyDetails?: any; // Chi tiết proxy đã chọn
  proxyFBKeys?: string[];
  proxyFBLocationId?: number;
  // New encryption settings
  encryption?: {
    enabled?: boolean;
    userKeyEncrypted?: string | null;
    userKeyPlain?: string; // client-only, not returned by API
  };
}

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userSubscription?: any;
}

export default function SettingsModal({ isOpen, onClose, userSubscription }: SettingsModalProps) {
  const { theme } = useTheme();
  const { addNotification } = useNotification();
  const { storageMode, setStorageMode, saveToLocalStorage, loadFromLocalStorage, clearLocalStorage, getLocalStorageAccounts } = useStorage();
  const [settings, setSettings] = useState<SettingsData>({
    httpProxies: [],
    hotmailAccounts: [],
    enable2FA: false,
    changeName: false,
    checkBM: false,
    checkTKQC: false,
    checkFullInfo: false,
    autoLogin: false,
    notifications: true,
    maxThreads: 10,
    theme: 'auto',
    language: 'vi',
    proxyFBKeys: [],
    proxyFBLocationId: 0,
    encryption: { enabled: false, userKeyEncrypted: null }
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');
  const [newProxy, setNewProxy] = useState('');
  const [newProxyFBKey, setNewProxyFBKey] = useState('');
  const [newHotmail, setNewHotmail] = useState('');
  const [availableProxyServers, setAvailableProxyServers] = useState<any[]>([]);
  const [isLoadingProxies, setIsLoadingProxies] = useState(false);
  const [threadError, setThreadError] = useState('');
  const [proxyFBCountries, setProxyFBCountries] = useState<string[]>([]);
  const [isLoadingCountries, setIsLoadingCountries] = useState(false);
  const [countryError, setCountryError] = useState('');
  const [showUserKey, setShowUserKey] = useState(false);
  const [deletingKey, setDeletingKey] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  // Helper function to calculate effective max threads
  const getEffectiveMaxThreads = () => {
    let effectiveMax = settings.globalMaxThreads || 50;
    
    // If user has a subscription plan with limits, apply those limits
    if (userSubscription && userSubscription.plan !== 'enterprise' && userSubscription.maxThreads !== -1) {
      effectiveMax = Math.min(effectiveMax, userSubscription.maxThreads);
    }
    
    return effectiveMax;
  };

  // LocalStorage functions
  const handleExportToLocal = async () => {
    setIsExporting(true);
    try {
      // Get accounts from server
      const response = await fetch('/api/facebook-accounts', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'x-user-key': sessionStorage.getItem('user_encryption_key') || ''
        }
      });
      
      if (response.ok) {
        const accounts = await response.json();
        saveToLocalStorage(accounts);
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: `Đã xuất ${accounts.length} tài khoản vào localStorage!`
        });
      } else {
        throw new Error('Không thể tải tài khoản từ server');
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể xuất tài khoản vào localStorage!'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleImportFromLocal = () => {
    setIsImporting(true);
    try {
      const localAccounts = loadFromLocalStorage();
      if (localAccounts.length === 0) {
        addNotification({
          type: 'warning',
          title: 'Thông báo',
          message: 'Không có tài khoản nào trong localStorage!'
        });
        return;
      }
      
      addNotification({
        type: 'success',
        title: 'Thành công',
        message: `Đã tải ${localAccounts.length} tài khoản từ localStorage!`
      });
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể tải tài khoản từ localStorage!'
      });
    } finally {
      setIsImporting(false);
    }
  };

  const handleClearLocal = () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa tất cả tài khoản trong localStorage?')) {
      setIsClearing(true);
      try {
        clearLocalStorage();
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã xóa tất cả tài khoản trong localStorage!'
        });
      } catch (error) {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể xóa tài khoản trong localStorage!'
        });
      } finally {
        setIsClearing(false);
      }
    }
  };

  const getLocalStorageInfo = () => {
    const accounts = getLocalStorageAccounts();
    const totalSize = new Blob([JSON.stringify(accounts)]).size;
    return {
      count: accounts.length,
      size: totalSize,
      sizeFormatted: totalSize > 1024 ? `${(totalSize / 1024).toFixed(1)} KB` : `${totalSize} B`
    };
  };

  // Load settings on mount
  useEffect(() => {
    if (isOpen) {
      loadSettings();
      loadAvailableProxyServers();
      loadNetProxyCountries();
      
      // Xóa user_encryption_key khỏi localStorage để bảo mật
      try { localStorage.removeItem('user_encryption_key') } catch {}
    }
  }, [isOpen]);

  // Reload settings when userSubscription changes
  useEffect(() => {
    if (isOpen && userSubscription) {
      loadSettings();
    }
  }, [isOpen, userSubscription]);

  // Xóa các key bảo mật khỏi localStorage khi component mount để bảo mật
  useEffect(() => {
    try { localStorage.removeItem('user_encryption_key') } catch {}
    try { localStorage.removeItem('admin_key') } catch {}
  }, []);

  const loadSettings = async () => {
    try {
      const response = await fetch('/api/settings', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Nếu user có gói subscription giới hạn, áp dụng giới hạn đó
        if (userSubscription && userSubscription.plan !== 'enterprise' && userSubscription.maxThreads !== -1) {
          data.maxThreads = Math.min(data.maxThreads, userSubscription.maxThreads);
        }
        
        setSettings(data);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const loadNetProxyCountries = async () => {
    setIsLoadingCountries(true);
    setCountryError('');
    try {
      const res = await fetch('https://api.netproxy.io/api/rotateProxy/location');
      const text = await res.text();
      let json: any = null;
      try { json = JSON.parse(text); } catch { json = null; }
      const list = json?.success && Array.isArray(json?.data?.countries) ? json.data.countries as string[] : [];
      if (list.length > 0) {
        setProxyFBCountries(list);
      } else {
        setProxyFBCountries(['Vietnam']);
      }
    } catch (e: any) {
      setCountryError(e?.message || 'Lỗi tải quốc gia');
      setProxyFBCountries(['Vietnam']);
    } finally {
      setIsLoadingCountries(false);
    }
  };

  const loadAvailableProxyServers = async () => {
    setIsLoadingProxies(true);
    try {
      const response = await fetch('/api/proxy/available', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setAvailableProxyServers(data.availableProxies || []);
      } else {
        const errorData = await response.json();
        console.error('❌ Error response:', errorData);
      }
    } catch (error) {
      console.error('❌ Error loading available proxy servers:', error);
    } finally {
      setIsLoadingProxies(false);
    }
  };

  const saveSettings = async () => {
    setIsLoading(true);
    setSaveStatus('saving');
    
    try {
      // Cập nhật số user đang sử dụng proxy
      if (settings.selectedProxyId !== undefined) {
        console.log('🔄 Calling update-usage API with:', settings.selectedProxyId);
        const updateResponse = await fetch('/api/proxy/update-usage', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          },
          body: JSON.stringify({ selectedProxyId: settings.selectedProxyId })
        });
        
        if (updateResponse.ok) {
          const updateData = await updateResponse.json();
          console.log('✅ Update usage response:', updateData);
        } else {
          console.error('❌ Update usage failed:', updateResponse.status);
        }
      }
      
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(settings)
      });
      
      if (response.ok) {
        setSaveStatus('success');
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã lưu cài đặt thành công!'
        });
        setTimeout(() => setSaveStatus('idle'), 2000);
        
        // Reload available proxy servers để cập nhật số user
        loadAvailableProxyServers();
        // Reload settings to reflect encrypted key status and clear plain key input
        await loadSettings();
        // Persist user session key locally for this browser session only (sessionStorage only)
        if (settings.encryption?.userKeyPlain) {
          // Verify key immediately to inform user
          try {
            const verifyRes = await fetch('/api/settings/verify-key', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
              body: JSON.stringify({ userKeyPlain: settings.encryption.userKeyPlain, adminKey: sessionStorage.getItem('admin_key') || undefined })
            })
            const verify = await verifyRes.json()
            if (verify.success && verify.hasKey) {
              if (verify.match) {
                addNotification({ type: 'success', title: 'Khóa hợp lệ', message: 'Đã xác thực khóa người dùng.' })
      } else {
                addNotification({ type: 'error', title: 'Sai khóa', message: 'Khóa bạn nhập không trùng với khóa đã lưu.' })
              }
            } else if (verify.success && !verify.hasKey) {
              addNotification({ type: 'info', title: 'Khóa mới', message: 'Chưa có khóa lưu. Khóa bạn nhập sẽ được lưu sau khi bấm Lưu cài đặt.' })
            }
          } catch {}
          // Chỉ lưu trong sessionStorage, không lưu trong localStorage
          try { sessionStorage.setItem('user_encryption_key', settings.encryption.userKeyPlain) } catch {}
          // Xóa key khỏi localStorage nếu có
          try { localStorage.removeItem('user_encryption_key') } catch {}
        }
        setSettings(prev => ({ ...prev, encryption: { ...(prev.encryption || {}), userKeyPlain: '' } }));
      } else {
        const err = await response.json().catch(() => ({} as any))
        if (err?.error_type === 'key_already_set') {
          addNotification({ type: 'warning', title: 'Không thể thay đổi khóa', message: 'Khóa người dùng đã được lưu trước đó. Không thể tạo khóa mới.' })
        }
        setSaveStatus('error');
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể lưu cài đặt. Vui lòng thử lại!'
        });
        setTimeout(() => setSaveStatus('idle'), 3000);
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      setSaveStatus('error');
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể lưu cài đặt. Vui lòng thử lại!'
      });
      setTimeout(() => setSaveStatus('idle'), 3000);
    } finally {
      setIsLoading(false);
    }
  };

  const saveSettingsWith = async (nextSettings: SettingsData) => {
    setIsLoading(true);
    setSaveStatus('saving');
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(nextSettings)
      });
      if (response.ok) {
        setSaveStatus('success');
        addNotification({ type: 'success', title: 'Thành công', message: 'Đã lưu cài đặt thành công!' });
        setTimeout(() => setSaveStatus('idle'), 1500);
        await loadSettings();
        if (nextSettings.encryption?.userKeyPlain) {
          try {
            const verifyRes = await fetch('/api/settings/verify-key', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
              body: JSON.stringify({ userKeyPlain: nextSettings.encryption.userKeyPlain, adminKey: sessionStorage.getItem('admin_key') || undefined })
            })
            const verify = await verifyRes.json()
            if (verify.success && verify.hasKey) {
              if (verify.match) {
                addNotification({ type: 'success', title: 'Khóa hợp lệ', message: 'Đã xác thực khóa người dùng.' })
      } else {
                addNotification({ type: 'error', title: 'Sai khóa', message: 'Khóa bạn nhập không trùng với khóa đã lưu.' })
              }
            } else if (verify.success && !verify.hasKey) {
              addNotification({ type: 'info', title: 'Khóa mới', message: 'Chưa có khóa lưu. Khóa bạn nhập sẽ được lưu sau khi bấm Lưu cài đặt.' })
            }
          } catch {}
          // Chỉ lưu trong sessionStorage, không lưu trong localStorage
          try { sessionStorage.setItem('user_encryption_key', nextSettings.encryption.userKeyPlain) } catch {}
          // Xóa key khỏi localStorage nếu có
          try { localStorage.removeItem('user_encryption_key') } catch {}
        }
        setSettings(prev => ({ ...prev, encryption: { ...(prev.encryption || {}), userKeyPlain: '' } }));
      } else {
        const err = await response.json().catch(() => ({} as any))
        if (err?.error_type === 'key_already_set') {
          addNotification({ type: 'warning', title: 'Không thể thay đổi khóa', message: 'Khóa người dùng đã được lưu trước đó. Không thể tạo khóa mới.' })
        }
        setSaveStatus('error');
        addNotification({ type: 'error', title: 'Lỗi', message: 'Không thể lưu cài đặt. Vui lòng thử lại!' });
        setTimeout(() => setSaveStatus('idle'), 2000);
      }
    } catch (e) {
      setSaveStatus('error');
      addNotification({ type: 'error', title: 'Lỗi', message: 'Không thể lưu cài đặt. Vui lòng thử lại!' });
      setTimeout(() => setSaveStatus('idle'), 2000);
    } finally {
      setIsLoading(false);
    }
  };

  const addAndSaveProxyFBKey = async () => {
    const key = newProxyFBKey.trim();
    if (!key) return;
    const nextSettings: SettingsData = {
      ...settings,
      proxyFBKeys: [...(settings.proxyFBKeys || []), key],
      selectedProxyId: ''
    } as any;
    setSettings(nextSettings);
    setNewProxyFBKey('');
    await saveSettingsWith(nextSettings);
  };

  const addProxy = async () => {
    if (newProxy.trim()) {
      try {
        // Cập nhật local state
        const newSettings = {
          ...settings,
          httpProxies: [...settings.httpProxies, newProxy.trim()]
        };
        setSettings(newSettings);
        setNewProxy('');
        
        // Lưu ngay vào database
        await saveSettingsWith(newSettings);
        
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã thêm proxy!'
        });
      } catch (error) {
        console.error('Error adding proxy:', error);
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể thêm proxy. Vui lòng thử lại!'
        });
      }
    }
  };

  const removeProxy = async (index: number) => {
    try {
      // Cập nhật local state
      const newSettings = {
        ...settings,
        httpProxies: settings.httpProxies.filter((_, i) => i !== index)
      };
      setSettings(newSettings);
      
      // Lưu ngay vào database
      await saveSettingsWith(newSettings);
      
      addNotification({
        type: 'success',
        title: 'Thành công',
        message: 'Đã xóa proxy!'
      });
    } catch (error) {
      console.error('Error removing proxy:', error);
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể xóa proxy. Vui lòng thử lại!'
      });
    }
  };

  const addHotmail = () => {
    if (newHotmail.trim()) {
      setSettings(prev => ({
        ...prev,
        hotmailAccounts: [...prev.hotmailAccounts, newHotmail.trim()]
      }));
      setNewHotmail('');
    }
  };

  const removeHotmail = (index: number) => {
    setSettings(prev => ({
      ...prev,
      hotmailAccounts: prev.hotmailAccounts.filter((_, i) => i !== index)
    }));
  };

  // Add CSS for slider
  React.useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      .slider::-webkit-slider-thumb {
        appearance: none;
        height: 16px;
        width: 16px;
        border-radius: 50%;
        background: #3b82f6;
        cursor: pointer;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      }
      .slider::-moz-range-thumb {
        height: 16px;
        width: 16px;
        border-radius: 50%;
        background: #3b82f6;
        cursor: pointer;
        border: none;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
      }
    `;
    document.head.appendChild(style);
    return () => {
      if (document.head.contains(style)) {
        document.head.removeChild(style);
      }
    };
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-2 sm:p-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[95vh] sm:max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200 dark:border-gray-700 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-700">
          <div className="flex items-center space-x-2 sm:space-x-3">
            <div className="p-1.5 sm:p-2 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-lg">
              <Settings className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg sm:text-2xl font-bold text-gray-900 dark:text-white">Cài đặt chung</h2>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">Quản lý cài đặt hệ thống</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6 text-gray-500 dark:text-gray-400" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 space-y-6 sm:space-y-8">
          

          {/* ProxyFB Keys */}
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-4 sm:p-6 border border-purple-100">
            <div className="flex items-start space-x-3 mb-4">
              <div className="p-1.5 sm:p-2 bg-purple-500 rounded-lg flex-shrink-0">
                <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">NetProxy.io Keys</h3>
                <p className="text-xs sm:text-sm text-gray-600">Thêm các key của NetProxy để sử dụng proxy IPv4 xoay</p>
                <p className="text-xs sm:text-sm text-red-600">Nếu chạy nhiều tài khoản thì thêm nhiều key vào đây để login tỉ lệ thành công cao hơn</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                <input
                  type="text"
                  value={newProxyFBKey}
                  onChange={(e) => setNewProxyFBKey(e.target.value)}
                  placeholder="Nhập NetProxy key"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  onKeyPress={(e) => { if (e.key === 'Enter') { void addAndSaveProxyFBKey(); } }}
                />
                <button
                  onClick={() => { void addAndSaveProxyFBKey(); }}
                  className="px-4 sm:px-6 py-2 sm:py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-lg hover:from-purple-600 hover:to-pink-700 transition-all duration-300 shadow-md hover:shadow-lg flex items-center justify-center space-x-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm Key</span>
                </button>
              </div>

              {/* List keys */}
              <div className="space-y-2">
                {(settings.proxyFBKeys || []).map((k, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
                    <span className="text-sm text-gray-700 font-medium">{k}</span>
                    <button
                      onClick={() => setSettings(prev => ({
                        ...prev,
                        proxyFBKeys: (prev.proxyFBKeys || []).filter((_, i) => i !== idx)
                      }))}
                      className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Location */}
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Location ID (0 = Ngẫu nhiên)</label>
                  <input
                    type="number"
                    min={0}
                    value={settings.proxyFBLocationId ?? 0}
                    onChange={(e) => setSettings(prev => ({ ...prev, proxyFBLocationId: parseInt(e.target.value || '0', 10) }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Quốc gia</label>
                  <select
                    value={(settings.proxyFBLocationId ?? 0) === 0 
                      ? -1 
                      : Math.max(1, Math.min(((settings.proxyFBLocationId ?? 1) || 1), Math.max(1, proxyFBCountries.length))) - 1}
                    onChange={(e) => {
                      const idx = parseInt(e.target.value, 10);
                      if (idx === -1) {
                        setSettings(prev => ({ ...prev, proxyFBLocationId: 0 }));
                      } else {
                        setSettings(prev => ({ ...prev, proxyFBLocationId: (idx + 1) }));
                      }
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent text-gray-900 font-medium"
                  >
                    {isLoadingCountries && <option>Đang tải...</option>}
                    {!isLoadingCountries && (
                      <>
                        <option value={-1}>0. Ngẫu nhiên (Random)</option>
                        {proxyFBCountries.length > 0 
                          ? proxyFBCountries.map((c, i) => (
                              <option key={i} value={i}>{`${i + 1}. ${c}`}</option>
                            ))
                          : <option value={0}>1. Vietnam</option>}
                      </>
                    )}
                  </select>
                  {!!countryError && (
                    <div className="mt-1 text-xs text-red-600">{countryError}</div>
                  )}
                  <div className="mt-1 text-xs text-gray-600">Mặc định 1 (Vietnam), chọn 0 để ngẫu nhiên</div>
                </div>
              </div>
            </div>
          </div>

          {/* HTTP Proxy List */}
          <div className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl p-4 sm:p-6 border border-orange-100">
            <div className="flex items-start space-x-3 mb-4">
              <div className="p-1.5 sm:p-2 bg-orange-500 rounded-lg flex-shrink-0">
                <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">HTTP Proxy List</h3>
                <p className="text-xs sm:text-sm text-gray-600">Thêm danh sách HTTP proxy để sử dụng khi không có NetProxy hoặc admin proxy</p>
                <p className="text-xs sm:text-sm text-orange-600">Format: ip:port hoặc ip:port:username:password</p>
              </div>
            </div>
            <div className="space-y-4">
              {/* Single proxy input */}
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
                <input
                  type="text"
                  value={newProxy}
                  onChange={(e) => setNewProxy(e.target.value)}
                  placeholder="Nhập proxy đơn lẻ (ví dụ: 192.168.1.1:8080)"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium"
                  onKeyPress={(e) => { if (e.key === 'Enter') { addProxy(); } }}
                />
                <button
                  onClick={addProxy}
                  className="px-4 sm:px-6 py-2 sm:py-3 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg hover:from-orange-600 hover:to-red-700 transition-all duration-300 shadow-md hover:shadow-lg flex items-center justify-center space-x-2"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm</span>
                </button>
              </div>

              {/* Bulk proxy input */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-700">Nhập danh sách proxy (bulk)</label>
                  <button
                    onClick={() => {
                      const proxyList = [
                        "192.168.1.1:8080",
                        "192.168.1.2:8080:user1:pass1",
                        "192.168.1.3:8080:user2:pass2",
                        "10.0.0.1:3128",
                        "10.0.0.2:3128:admin:123456"
                      ].join('\n');
                      setNewProxy(proxyList);
                    }}
                    className="text-xs text-orange-600 hover:text-orange-700 underline"
                  >
                    Load mẫu
                  </button>
                </div>
                <textarea
                  value={newProxy}
                  onChange={(e) => setNewProxy(e.target.value)}
                  placeholder={`Nhập danh sách proxy, mỗi proxy một dòng hoặc phân cách bằng dấu phẩy:

Ví dụ:
192.168.1.1:8080
192.168.1.2:8080:user1:pass1
192.168.1.3:8080:user2:pass2
10.0.0.1:3128
10.0.0.2:3128:admin:123456`}
                  rows={6}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-gray-900 placeholder-gray-500 font-medium resize-vertical"
                />
                <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                  <button
                    onClick={async () => {
                      if (!newProxy.trim()) return;
                      
                      try {
                        // Parse proxy list - support both newlines and commas
                        const proxyLines = newProxy
                          .split(/[\n,]/)
                          .map(line => line.trim())
                          .filter(line => line.length > 0);
                        
                        // Add all valid proxies
                        const validProxies = proxyLines.filter(proxy => {
                          const parts = proxy.split(':');
                          return parts.length === 2 || parts.length === 4;
                        });
                        
                        if (validProxies.length > 0) {
                          // Cập nhật local state
                          const newSettings = {
                            ...settings,
                            httpProxies: [...settings.httpProxies, ...validProxies]
                          };
                          setSettings(newSettings);
                          setNewProxy('');
                          
                          // Lưu ngay vào database
                          await saveSettingsWith(newSettings);
                          
                          addNotification({
                            type: 'success',
                            title: 'Thành công',
                            message: `Đã thêm ${validProxies.length} proxy vào danh sách!`
                          });
                        } else {
                          addNotification({
                            type: 'error',
                            title: 'Lỗi',
                            message: 'Không có proxy hợp lệ nào được tìm thấy!'
                          });
                        }
                      } catch (error) {
                        console.error('Error adding all proxies:', error);
                        addNotification({
                          type: 'error',
                          title: 'Lỗi',
                          message: 'Không thể thêm proxy. Vui lòng thử lại!'
                        });
                      }
                    }}
                    className="flex-1 px-4 py-2 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg hover:from-orange-600 hover:to-red-700 transition-all duration-300 shadow-md hover:shadow-lg font-medium"
                  >
                    Thêm Tất Cả Proxy
                  </button>
                  <button
                    onClick={() => setNewProxy('')}
                    className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    Xóa
                  </button>
                </div>
              </div>

              {/* List HTTP proxies */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-medium text-gray-700">Danh sách proxy hiện tại ({settings.httpProxies.length})</h4>
                  {settings.httpProxies.length > 0 && (
                    <button
                      onClick={async () => {
                        if (window.confirm('Bạn có chắc chắn muốn xóa tất cả proxy?')) {
                          try {
                            // Cập nhật local state
                            const newSettings = { ...settings, httpProxies: [] };
                            setSettings(newSettings);
                            
                            // Lưu ngay vào database
                            await saveSettingsWith(newSettings);
                            
                            addNotification({
                              type: 'success',
                              title: 'Thành công',
                              message: 'Đã xóa tất cả proxy!'
                            });
                          } catch (error) {
                            console.error('Error clearing all proxies:', error);
                            addNotification({
                              type: 'error',
                              title: 'Lỗi',
                              message: 'Không thể xóa tất cả proxy. Vui lòng thử lại!'
                            });
                          }
                        }
                      }}
                      className="text-xs text-red-600 hover:text-red-700 underline"
                    >
                      Xóa tất cả
                    </button>
                  )}
                </div>
                
                {/* Scrollable proxy list container */}
                <div className="max-h-64 overflow-y-auto border border-gray-200 rounded-lg bg-gray-50">
                  <div className="p-2 space-y-2">
                    {settings.httpProxies.map((proxy, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex-1 min-w-0">
                          <span className="text-sm text-gray-700 font-medium break-all">{proxy}</span>
                          {proxy.includes(':') && proxy.split(':').length === 4 && (
                            <div className="text-xs text-gray-500 mt-1">
                              IP: {proxy.split(':')[0]}, Port: {proxy.split(':')[1]}, User: {proxy.split(':')[2]}
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => removeProxy(idx)}
                          className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors ml-3 flex-shrink-0"
                          title="Xóa proxy này"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
                
                {settings.httpProxies.length === 0 && (
                  <div className="text-center py-6 text-gray-500">
                    <Globe className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p>Chưa có HTTP proxy nào được thêm</p>
                    <p className="text-sm">Thêm proxy để sử dụng khi không có NetProxy hoặc admin proxy</p>
                  </div>
                )}

                {/* Scroll indicator */}
                {settings.httpProxies.length > 8 && (
                  <div className="text-center py-2">
                    <div className="inline-flex items-center space-x-2 text-xs text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <span>Cuộn xuống để xem thêm proxy</span>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    </div>
                  </div>
                )}
              </div>

              {/* Proxy Priority Info */}
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div className="text-sm text-orange-800">
                    <p className="font-medium mb-1">Thứ tự ưu tiên proxy:</p>
                    <ol className="list-decimal list-inside space-y-1">
                      <li>Admin Proxy Server (nếu được chọn)</li>
                      <li>ProxyFB Keys (nếu có)</li>
                      <li>HTTP Proxy List (danh sách này)</li>
                    </ol>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Proxy Server Selection */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4 sm:p-6 border border-green-100">
            <div className="flex items-start space-x-3 mb-4">
              <div className="p-1.5 sm:p-2 bg-green-500 rounded-lg flex-shrink-0">
                <Globe className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">Chọn Server Proxy</h3>
                <p className="text-xs sm:text-sm text-gray-600">Chọn proxy server từ danh sách được cấu hình bởi admin</p>
              </div>
            </div>
            <div className="space-y-4">
              {isLoadingProxies ? (
                <div className="flex items-center justify-center py-4">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-500"></div>
                  <span className="ml-2 text-sm text-gray-600">Đang tải danh sách proxy...</span>
                </div>
              ) : (
                <div className="space-y-3">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Chọn Proxy Server:
                  </label>
                  <select
                    value={settings.selectedProxyId || ''}
                    onChange={(e) => setSettings(prev => {
                      const newProxyId = e.target.value;
                      if (newProxyId) {
                        return { ...prev, selectedProxyId: newProxyId, proxyFBKeys: [] };
                      }
                      return { ...prev, selectedProxyId: '' } as any;
                    })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-900 font-medium"
                  >
                    <option value="">-- Chọn proxy server --</option>
                    {availableProxyServers.map((proxy) => (
                      <option key={proxy._id} value={proxy._id}>
                        {proxy.name} ({proxy.currentUsers}/{proxy.maxUsers} users) - {proxy.isResidential ? 'Residential' : 'Datacenter'}
                      </option>
                    ))}
                  </select>
                  
                  {/* Hiển thị proxy đã chọn */}
                  {settings.selectedProxyId && (
                    <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-sm text-green-800">
                        <strong>Đã chọn:</strong> {
                          settings.selectedProxyDetails?.name || 
                          availableProxyServers.find(p => p._id === settings.selectedProxyId)?.name || 
                          'Unknown'
                        }
                        {settings.selectedProxyDetails && (
                          <span className="ml-2 text-xs">
                            ({settings.selectedProxyDetails.currentUsers}/{settings.selectedProxyDetails.maxUsers} users)
                            {!settings.selectedProxyDetails.isActive && ' - Không hoạt động'}
                          </span>
                        )}
                      </p>
                    </div>
                  )}
                  
                  {/* Hiển thị thông báo nếu không có proxy khả dụng */}
                  {availableProxyServers.length === 0 && !settings.selectedProxyId && (
                    <div className="text-center py-4">
                      <AlertCircle className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm text-gray-600">Không có proxy server nào khả dụng</p>
                      <p className="text-xs text-gray-500 mt-1">Vui lòng liên hệ admin để được cấu hình proxy</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Data Storage Settings */}
          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-xl p-4 sm:p-6 border border-indigo-200 dark:border-indigo-700">
            <div className="flex items-start space-x-3 mb-4">
              <div className="p-1.5 sm:p-2 bg-indigo-600 rounded-lg flex-shrink-0">
                <Database className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white">Cài đặt lưu trữ tài khoản</h3>
                <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300">Chọn nơi lưu trữ tài khoản Facebook của bạn</p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <h4 className="text-md font-medium text-gray-900 dark:text-white mb-3">Chế độ lưu trữ</h4>
                <div className="space-y-3">
                  {[
                    { 
                      mode: 'server' as const, 
                      icon: Cloud, 
                      title: 'Chỉ Server', 
                      desc: 'Lưu trữ tài khoản trên server an toàn' 
                    },
                    { 
                      mode: 'local' as const, 
                      icon: HardDrive, 
                      title: 'Chỉ Local', 
                      desc: 'Lưu trữ tài khoản trên thiết bị của bạn' 
                    }
                    //{ 
                      //mode: 'both' as const, 
                     // icon: Database, 
                      //title: 'Cả hai', 
                     // desc: 'Lưu trữ đồng thời trên server và thiết bị' 
                   // }
                  ].map(({ mode, icon: Icon, title, desc }) => (
                    <label
                      key={mode}
                      className={`flex items-center p-4 border rounded-lg cursor-pointer transition-all ${
                        storageMode === mode
                          ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20'
                          : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                      }`}
                    >
                      <input
                        type="radio"
                        name="storageMode"
                        value={mode}
                        checked={storageMode === mode}
                        onChange={() => setStorageMode(mode as 'local' | 'server')}
                        className="sr-only"
                      />
                      <Icon className={`w-5 h-5 mr-3 ${
                        storageMode === mode ? 'text-indigo-600' : 'text-gray-400'
                      }`} />
                      <div className="flex-1">
                        <div className={`font-medium ${
                          storageMode === mode ? 'text-indigo-900 dark:text-indigo-100' : 'text-gray-900 dark:text-white'
                        }`}>
                          {title}
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {desc}
                        </div>
                      </div>
                      {storageMode === mode && (
                        <CheckCircle className="w-5 h-5 text-indigo-600" />
                      )}
                    </label>
                  ))}
                </div>
              </div>

              {/* LocalStorage Info */}
              <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">Thông tin localStorage</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">Số tài khoản:</span>
                    <div className="font-medium text-gray-900 dark:text-white">
                      {getLocalStorageInfo().count}
                    </div>
                  </div>
                  <div>
                    <span className="text-gray-500 dark:text-gray-400">Kích thước:</span>
                    <div className="font-medium text-gray-900 dark:text-white">
                      {getLocalStorageInfo().sizeFormatted}
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                <button
                  onClick={handleExportToLocal}
                  disabled={isExporting}
                  className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  <Download className="w-4 h-4 mr-2" />
                  {isExporting ? 'Đang xuất...' : 'Xuất từ Server'}
                </button>

                <button
                  onClick={handleImportFromLocal}
                  disabled={isImporting || getLocalStorageInfo().count === 0}
                  className="flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  {isImporting ? 'Đang tải...' : 'Tải từ Local'}
                </button>

                <button
                  onClick={handleClearLocal}
                  disabled={isClearing || getLocalStorageInfo().count === 0}
                  className="flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  {isClearing ? 'Đang xóa...' : 'Xóa Local'}
                </button>
              </div>

              {/* Warning */}
              <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div className="text-sm text-yellow-800 dark:text-yellow-200">
                    <p className="font-medium mb-1">Lưu ý:</p>
                    <p>Dữ liệu trong localStorage sẽ bị mất khi xóa cache trình duyệt hoặc chuyển thiết bị.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Data Encryption Settings */}
          <div className="bg-gradient-to-r from-slate-50 to-gray-50 dark:from-gray-800 dark:to-gray-700 rounded-xl p-4 sm:p-6 border border-gray-200 dark:border-gray-700">
            <div className="flex items-start space-x-3 mb-4">
              <div className="p-1.5 sm:p-2 bg-gray-600 rounded-lg flex-shrink-0">
                <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 dark:text-white">Mã hóa dữ liệu tài khoản</h3>
                <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300">Bảo vệ các trường nhạy cảm (mật khẩu, 2FA, cookie, token) bằng khóa riêng của bạn</p>
              </div>
            </div>
            <div className="space-y-4">
              <label className="inline-flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={!!settings.encryption?.enabled}
                  onChange={(e) => setSettings(prev => ({
                    ...prev,
                    encryption: { ...(prev.encryption || {}), enabled: e.target.checked }
                  }))}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-800 dark:text-gray-200">Bật mã hóa dữ liệu</span>
              </label>

              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Khóa người dùng (nhập để cập nhật)</label>
                  <div className="relative">
                    <input
                      type={showUserKey ? 'text' : 'password'}
                      placeholder="Nhập khóa bí mật của bạn"
                      value={settings.encryption?.userKeyPlain || ''}
                      onChange={(e) => setSettings(prev => ({
                        ...prev,
                        encryption: { ...(prev.encryption || {}), userKeyPlain: e.target.value }
                      }))}
                      className="w-full pr-10 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-gray-500 focus:border-transparent"
                    />
                    <button
                      type="button"
                      onClick={() => setShowUserKey(v => !v)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 dark:text-gray-300 dark:hover:text-gray-100"
                      aria-label={showUserKey ? 'Ẩn khóa' : 'Hiển thị khóa'}
                    >
                      {showUserKey ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Khóa này sẽ được mã hóa bằng master key server và lưu trữ an toàn.</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Trạng thái khóa hiện tại</label>
                  <input
                    type="text"
                    readOnly
                    value={settings.encryption?.userKeyEncrypted ? 'Đã lưu khóa (ẩn)' : 'Chưa lưu khóa'}
                    className="w-full px-3 py-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300"
                  />
                  <div className="mt-2">
                    <button
                      type="button"
                      onClick={async () => {
                        if (!settings.encryption?.userKeyEncrypted) return;
                        if (!settings.encryption?.userKeyPlain) {
                          addNotification({ type: 'warning', title: 'Cần khóa', message: 'Nhập đúng khóa hiện tại để xóa.' });
                          return;
                        }
                        setDeletingKey(true);
                        try {
                          const res = await fetch('/api/settings/remove-key', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
                            body: JSON.stringify({ userKeyPlain: settings.encryption.userKeyPlain, adminKey: sessionStorage.getItem('admin_key') || undefined })
                          });
                          const data = await res.json();
                          if (res.ok && data.success) {
                            addNotification({ type: 'success', title: 'Đã xóa khóa', message: 'Đã tắt mã hóa và xóa khóa.' });
                            try { sessionStorage.removeItem('user_encryption_key'); localStorage.removeItem('user_encryption_key'); } catch {}
                            await loadSettings();
                            setSettings(prev => ({ ...prev, encryption: { enabled: false, userKeyEncrypted: null, userKeyPlain: '' } }));
                          } else if (data?.error_type === 'invalid_key') {
                            addNotification({ type: 'error', title: 'Sai khóa', message: 'Khóa nhập không đúng. Không thể xóa.' });
                          } else if (data?.error_type === 'no_key') {
                            addNotification({ type: 'info', title: 'Chưa có khóa', message: 'Hiện không có khóa để xóa.' });
                          } else {
                            addNotification({ type: 'error', title: 'Lỗi', message: 'Không thể xóa khóa. Vui lòng thử lại.' });
                          }
                        } catch {
                          addNotification({ type: 'error', title: 'Lỗi', message: 'Không thể xóa khóa. Vui lòng thử lại.' });
                        } finally {
                          setDeletingKey(false);
                        }
                      }}
                      className={`px-3 py-2 rounded-lg text-sm ${settings.encryption?.userKeyEncrypted ? 'bg-red-600 text-white hover:bg-red-700' : 'bg-gray-200 text-gray-500 cursor-not-allowed'}`}
                      disabled={!settings.encryption?.userKeyEncrypted || deletingKey}
                    >
                      {deletingKey ? 'Đang xóa...' : 'Xóa khóa'}
                    </button>
                  </div>
                </div>
              </div>
              <div className="text-xs text-amber-600">Lưu ý: Nếu tắt mã hóa, dữ liệu mới sẽ lưu dạng thuần; dữ liệu đã mã hóa vẫn cần khóa để sử dụng.</div>
              <div className="text-xs text-red-600">- Quản trị viên cũng không thể biết key của bạn đã cài đặt.</div>
              <div className="text-xs text-blue-600">- Quản trị viên không thể xóa key của bạn, cũng không thể cấp lại key. vì thế các bạn hãy lưu trữ key cẩn thận. Bảo mật tuyệt đối dữ liệu của bạn.</div>
            </div>
          </div>

          {/* Thread Settings */}
          <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl p-4 sm:p-6 border border-cyan-100">
            <div className="flex items-start space-x-3 mb-6">
              <div className="p-1.5 sm:p-2 bg-cyan-500 rounded-lg flex-shrink-0">
                <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">Cài đặt đa luồng</h3>
                <p className="text-xs sm:text-sm text-gray-600">Cấu hình số luồng tối đa cho hệ thống</p>
              </div>
            </div>
            <div className="space-y-4">
              {/* Check if user is on a limited plan */}
              {userSubscription && userSubscription.plan !== 'enterprise' && userSubscription.maxThreads !== -1 && (
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg mb-4">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-5 h-5 text-blue-600" />
                    <span className="text-sm font-medium text-blue-800">
                      Giới hạn gói {userSubscription.plan === 'free' ? 'Free' : userSubscription.plan === 'basic' ? 'Basic' : 'Premium'}
                    </span>
                  </div>
                  <p className="text-xs text-blue-600 mt-1">
                    Gói {userSubscription.plan === 'free' ? 'Free' : userSubscription.plan === 'basic' ? 'Basic' : 'Premium'} giới hạn tối đa {userSubscription.maxThreads} luồng
                  </p>
                </div>
              )}
              
              {settings.allowUserThreadSettings === false && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg mb-4">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-5 h-5 text-amber-600" />
                    <span className="text-sm font-medium text-amber-800">
                      Cài đặt luồng đã bị khóa bởi quản trị viên
                    </span>
                  </div>
                  <p className="text-xs text-amber-600 mt-1">
                    Số luồng hiện tại: {settings.maxThreads}
                  </p>
                </div>
              )}
              
              <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                <div>
                  <label className="text-sm font-medium text-gray-700">Số luồng tối đa</label>
                  <p className="text-xs text-gray-500">
                    Tối đa {getEffectiveMaxThreads()} luồng (hiện tại: {Math.min(settings.maxThreads, getEffectiveMaxThreads())})
                    {settings.allowUserThreadSettings === false && ' - Bị khóa bởi admin'}
                    {userSubscription && userSubscription.plan !== 'enterprise' && userSubscription.maxThreads !== -1 && 
                      ` - Giới hạn gói ${userSubscription.plan === 'free' ? 'Free' : userSubscription.plan === 'basic' ? 'Basic' : 'Premium'}: ${userSubscription.maxThreads} luồng`
                    }
                    {userSubscription && userSubscription.plan === 'free' && (
                      <span className="text-red-600 font-medium"> - Gói Free giới hạn tối đa 2 luồng</span>
                    )}
                  </p>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="range"
                    min="1"
                    max={getEffectiveMaxThreads()}
                    value={Math.min(settings.maxThreads, getEffectiveMaxThreads())}
                    onChange={(e) => {
                      const newValue = parseInt(e.target.value);
                      setThreadError(''); // Clear previous error
                      
                      // Nếu user có gói subscription giới hạn, không cho phép vượt quá
                      if (userSubscription && userSubscription.plan !== 'enterprise' && userSubscription.maxThreads !== -1) {
                        if (newValue > userSubscription.maxThreads) {
                          setThreadError(`Gói ${userSubscription.plan === 'free' ? 'Free' : userSubscription.plan === 'basic' ? 'Basic' : 'Premium'} giới hạn tối đa ${userSubscription.maxThreads} luồng`);
                          return; // Không cho phép thay đổi
                        }
                      }
                      setSettings(prev => ({ ...prev, maxThreads: newValue }));
                    }}
                    disabled={settings.allowUserThreadSettings === false}
                    className={`flex-1 h-2 rounded-lg appearance-none cursor-pointer slider ${
                      settings.allowUserThreadSettings === false 
                        ? 'bg-gray-100 cursor-not-allowed' 
                        : 'bg-gray-200'
                    }`}
                  />
                  <span className="text-sm font-semibold text-gray-800 min-w-[2rem] text-center">
                    {Math.min(settings.maxThreads, getEffectiveMaxThreads())}
                  </span>
                </div>
                
                {/* Error Message */}
                {threadError && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-lg mt-3">
                    <div className="flex items-center space-x-2">
                      <AlertCircle className="w-4 h-4 text-red-600" />
                      <span className="text-sm text-red-700">{threadError}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

         
        </div>

        {/* Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between p-4 sm:p-6 border-t border-gray-200 bg-gray-50 space-y-3 sm:space-y-0">
          <div className="flex items-center space-x-2">
            {saveStatus === 'saving' && (
              <>
                <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-sm text-gray-600">Đang lưu...</span>
              </>
            )}
            {saveStatus === 'success' && (
              <span className="text-sm text-green-600 font-medium">✅ Đã lưu thành công!</span>
            )}
            {saveStatus === 'error' && (
              <span className="text-sm text-red-600 font-medium">❌ Lỗi khi lưu!</span>
            )}
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2 text-gray-700 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors font-medium text-sm"
            >
              Hủy
            </button>
            <button
              onClick={saveSettings}
              disabled={isLoading}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg hover:from-blue-600 hover:to-indigo-700 transition-all duration-300 shadow-md hover:shadow-lg disabled:opacity-50 font-medium text-sm"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Lưu cài đặt</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
