'use client';

import React, { useState, useEffect } from 'react';
import { X, Database, HardDrive, Cloud, Download, Upload, Trash2, AlertTriangle, CheckCircle } from 'lucide-react';
import { useStorage } from '../contexts/StorageContext';
import { useNotification } from './NotificationSystem';

interface StorageSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStorageModeChange?: () => void;
}

export default function StorageSettingsModal({ isOpen, onClose, onStorageModeChange }: StorageSettingsModalProps) {
  const { 
    storageMode, 
    setStorageMode, 
    saveToLocalStorage, 
    loadFromLocalStorage, 
    clearLocalStorage, 
    getLocalStorageAccounts 
  } = useStorage();
  const { addNotification } = useNotification();
  
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);

  // Xóa các key bảo mật khỏi localStorage để bảo mật
  useEffect(() => {
    try { localStorage.removeItem('user_encryption_key') } catch {}
    try { localStorage.removeItem('admin_key') } catch {}
  }, []);

  if (!isOpen) return null;

  const handleExportToLocal = async () => {
    setIsExporting(true);
    try {
      // Get accounts from server
      const response = await fetch('/api/facebook-accounts', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'x-user-key': sessionStorage.getItem('user_encryption_key') || ''
        }
      });
      
      if (response.ok) {
        const accounts = await response.json();
        saveToLocalStorage(accounts);
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: `Đã xuất ${accounts.length} tài khoản vào localStorage!`
        });
      } else {
        throw new Error('Không thể tải tài khoản từ server');
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể xuất tài khoản vào localStorage!'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleImportFromLocal = () => {
    setIsImporting(true);
    try {
      const localAccounts = loadFromLocalStorage();
      if (localAccounts.length === 0) {
        addNotification({
          type: 'warning',
          title: 'Thông báo',
          message: 'Không có tài khoản nào trong localStorage!'
        });
        return;
      }
      
      // Here you would typically send accounts to server
      // For now, just show a notification
      addNotification({
        type: 'success',
        title: 'Thành công',
        message: `Đã tải ${localAccounts.length} tài khoản từ localStorage!`
      });
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Lỗi',
        message: 'Không thể tải tài khoản từ localStorage!'
      });
    } finally {
      setIsImporting(false);
    }
  };

  const handleClearLocal = () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa tất cả tài khoản trong localStorage?')) {
      setIsClearing(true);
      try {
        clearLocalStorage();
        addNotification({
          type: 'success',
          title: 'Thành công',
          message: 'Đã xóa tất cả tài khoản trong localStorage!'
        });
      } catch (error) {
        addNotification({
          type: 'error',
          title: 'Lỗi',
          message: 'Không thể xóa tài khoản trong localStorage!'
        });
      } finally {
        setIsClearing(false);
      }
    }
  };

  const getLocalStorageInfo = () => {
    const accounts = getLocalStorageAccounts();
    const totalSize = new Blob([JSON.stringify(accounts)]).size;
    return {
      count: accounts.length,
      size: totalSize,
      sizeFormatted: totalSize > 1024 ? `${(totalSize / 1024).toFixed(1)} KB` : `${totalSize} B`
    };
  };

  const localInfo = getLocalStorageInfo();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center space-x-3">
            <Database className="w-6 h-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              Cài đặt lưu trữ
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Storage Mode Selection */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
              Chế độ lưu trữ
            </h3>
            <div className="space-y-3">
              {[
                { 
                  mode: 'server' as const, 
                  icon: Cloud, 
                  title: 'Chỉ Server', 
                  desc: 'Lưu trữ tài khoản trên server an toàn' 
                },
                { 
                  mode: 'local' as const, 
                  icon: HardDrive, 
                  title: 'Chỉ Local', 
                  desc: 'Lưu trữ tài khoản trên thiết bị của bạn' 
                },
                // Removed 'both' mode to avoid duplicates and cross-store sync issues
              ].map(({ mode, icon: Icon, title, desc }) => (
                <label
                  key={mode}
                  className={`flex items-center p-4 border rounded-lg cursor-pointer transition-all ${
                    storageMode === mode
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                      : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'
                  }`}
                >
                  <input
                    type="radio"
                    name="storageMode"
                    value={mode}
                    checked={storageMode === mode}
                    onChange={() => {
                      setStorageMode(mode);
                      onStorageModeChange?.();
                    }}
                    className="sr-only"
                  />
                  <Icon className={`w-5 h-5 mr-3 ${
                    storageMode === mode ? 'text-blue-600' : 'text-gray-400'
                  }`} />
                  <div className="flex-1">
                    <div className={`font-medium ${
                      storageMode === mode ? 'text-blue-900 dark:text-blue-100' : 'text-gray-900 dark:text-white'
                    }`}>
                      {title}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {desc}
                    </div>
                  </div>
                  {storageMode === mode && (
                    <CheckCircle className="w-5 h-5 text-blue-600" />
                  )}
                </label>
              ))}
            </div>
          </div>

          {/* LocalStorage Info */}
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 dark:text-white mb-3">
              Thông tin localStorage
            </h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500 dark:text-gray-400">Số tài khoản:</span>
                <div className="font-medium text-gray-900 dark:text-white">
                  {localInfo.count}
                </div>
              </div>
              <div>
                <span className="text-gray-500 dark:text-gray-400">Kích thước:</span>
                <div className="font-medium text-gray-900 dark:text-white">
                  {localInfo.sizeFormatted}
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <button
              onClick={handleExportToLocal}
              disabled={isExporting}
              className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Download className="w-4 h-4 mr-2" />
              {isExporting ? 'Đang xuất...' : 'Xuất từ Server'}
            </button>

            <button
              onClick={handleImportFromLocal}
              disabled={isImporting || localInfo.count === 0}
              className="w-full flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Upload className="w-4 h-4 mr-2" />
              {isImporting ? 'Đang tải...' : 'Tải từ Local'}
            </button>

            <button
              onClick={handleClearLocal}
              disabled={isClearing || localInfo.count === 0}
              className="w-full flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              {isClearing ? 'Đang xóa...' : 'Xóa Local'}
            </button>
          </div>

          {/* Warning */}
          <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
            <div className="flex items-start">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
              <div className="text-sm text-yellow-800 dark:text-yellow-200">
                <p className="font-medium mb-1">Lưu ý:</p>
                <p>Dữ liệu trong localStorage sẽ bị mất khi xóa cache trình duyệt hoặc chuyển thiết bị.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
