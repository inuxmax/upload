'use client'

import { useState, useEffect } from 'react'
// Using custom components instead of shadcn/ui
import { RefreshCw, Eye, EyeOff } from 'lucide-react'

interface TKQCAccount {
  id: string
  name: string
  account_id: string
  account_status: string | number
  account_status_text?: string
  profile_picture?: string
  currency?: string
  amount_spent?: string
  balance?: string
  spend?: string
  adtrust_dsl?: number
  threshold_amount?: number
  disable_reason?: number
  created_time?: string
  next_bill_date?: string
  user_role?: string
  is_prepay_account?: boolean
  owner?: string
  source?: string
  business_country_code?: string
  timezone_name?: string
  account_type?: string
  owner_display?: string
  bm_name?: string
}

interface BMAccount {
  id: string
  name: string
  verification_status: string
  profile_picture?: string
  restriction_type?: string
  url?: string
  created_time?: string
  email?: string
  phone?: string
  website?: string
  category?: string
  adAccountId?: string
}

interface FacebookAccountData {
  _id: string
  uid: string
  mail: string
  name: string
  status: string
  tkqcData: TKQCAccount[]
  bmData: BMAccount[]
  accountInfo: any
  lastTkqcCheck: string
  tkqcCount: number
  bmCount: number
  log: string
  birthday?: string
  gender?: string
}

interface TKQCDataTableProps {
  selectedAccountId?: string | null
}

export default function TKQCDataTable({ selectedAccountId }: TKQCDataTableProps) {
  const [accounts, setAccounts] = useState<FacebookAccountData[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedAccount, setExpandedAccount] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [typeFilter, setTypeFilter] = useState('all')
  const [showShareModal, setShowShareModal] = useState(false)
  const [shareAccountId, setShareAccountId] = useState<string | null>(null)
  const [shareBmId, setShareBmId] = useState<string>('')
  const [shareLoading, setShareLoading] = useState(false)
  const [shareLoginFirst, setShareLoginFirst] = useState(true)
  const [shareLoginMethod, setShareLoginMethod] = useState<'cookie' | 'password'>('cookie')
  const [shareUseMail1s, setShareUseMail1s] = useState(true)
  const [shareEmail, setShareEmail] = useState('')
  const [shareRole, setShareRole] = useState<'ADMIN' | 'EMPLOYEE'>('ADMIN')
  const [shareQuantity, setShareQuantity] = useState<number>(1)
  const [shareLinks, setShareLinks] = useState<{ title?: string; url: string }[]>([])
  const [shareResultStatus, setShareResultStatus] = useState<'idle' | 'success' | 'failed'>('idle')

  const fetchTKQCData = async () => {
    try {
      setLoading(true)
      
      // Kiểm tra storage mode từ localStorage
      const storageMode = localStorage.getItem('storage_mode') || 'server'
      
      if (storageMode === 'local') {
        // Lấy dữ liệu TKQC từ localStorage
        const tkqcData = localStorage.getItem('tkqc_data')
        
        if (tkqcData) {
          try {
            const allTKQCData = JSON.parse(tkqcData)
            
            // Chuyển đổi dữ liệu để phù hợp với interface
            const accounts = allTKQCData.map((tkqcItem: any) => ({
              _id: tkqcItem.accountId,
              uid: tkqcItem.email, // Sử dụng email làm uid tạm thời
              mail: tkqcItem.email,
              name: tkqcItem.email, // Sử dụng email làm tên tạm thời
              status: 'active',
              tkqcData: tkqcItem.tkqcList || [],
              bmData: tkqcItem.bmList || [],
              accountInfo: tkqcItem.accountInfo,
              lastTkqcCheck: tkqcItem.timestamp,
              tkqcCount: tkqcItem.totalTKQC || 0,
              bmCount: tkqcItem.totalBM || 0,
              log: `TKQC: ${tkqcItem.totalTKQC || 0} accounts, ${tkqcItem.totalBM || 0} BM`,
              birthday: undefined,
              gender: undefined
            }))
            
            setAccounts(accounts)
          } catch (parseError) {
            console.error('Lỗi parse TKQC data từ localStorage:', parseError)
            setAccounts([])
          }
        } else {
          setAccounts([])
        }
      } else {
        // Lấy dữ liệu TKQC từ server
        try {
          const response = await fetch('/api/tkqc-data-server', {
            headers: {
              'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
          })

          if (response.ok) {
            const data = await response.json()
            setAccounts(data.accounts || [])
          } else {
            console.error('Server response error:', response.status)
            setAccounts([])
          }
        } catch (serverError) {
          console.error('Error fetching TKQC data from server:', serverError)
          setAccounts([])
        }
      }
    } catch (error) {
      console.error('Error loading TKQC data:', error)
      setAccounts([])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTKQCData()
    
    // Lắng nghe sự kiện cập nhật TKQC data
    const handleTKQCUpdate = () => {
      fetchTKQCData()
    }
    
    window.addEventListener('tkqc-data-updated', handleTKQCUpdate)
    
    return () => {
      window.removeEventListener('tkqc-data-updated', handleTKQCUpdate)
    }
  }, [])

  const getStatusBadge = (status: string) => {
    const statusColors = {
      active: 'bg-green-500',
      checking: 'bg-yellow-500',
      error: 'bg-red-500',
      inactive: 'bg-gray-500'
    }
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[status as keyof typeof statusColors] || 'bg-gray-500'} text-white`}>
        {status}
      </span>
    )
  }

  const extractUIDFromString = (uidString: string, account?: any) => {
    // Always extract UID from string if it contains |
    if (uidString && uidString.includes('|')) {
      const uid = uidString.split('|')[0]
      // Only return if it looks like a valid UID (numeric and reasonable length)
      if (uid && /^\d{10,}$/.test(uid)) {
        return uid
      }
    }
    
    // If we have the account object and a clean UID
    if (account && account.uid && !account.uid.includes('|')) {
      return account.uid
    }
    
    // Fallback: return the first part or the string itself
    if (uidString && uidString.includes('|')) {
      return uidString.split('|')[0]
    }
    
    return uidString || 'N/A'
  }

  const getAccountStatusBadge = (status: string | number) => {
    // Map status numbers to meaningful text
    const statusMap: { [key: string]: { text: string, color: string } } = {
      '1': { text: 'Live', color: 'bg-green-500' },
      '2': { text: 'Die', color: 'bg-red-500' },
      '3': { text: 'Nợ', color: 'bg-yellow-500' },
      '4': { text: 'Pending', color: 'bg-orange-500' },
      '5': { text: 'Disabled', color: 'bg-gray-500' },
      '7': { text: 'Pending', color: 'bg-orange-500' },
      '9': { text: 'Pending', color: 'bg-orange-500' },
      '101': { text: 'Die', color: 'bg-red-500' },
      'ACTIVE': { text: 'Live', color: 'bg-green-500' },
      'DISABLED': { text: 'Die', color: 'bg-red-500' },
      'UNSETTLED': { text: 'Nợ', color: 'bg-yellow-500' },
      'PENDING_REVIEW': { text: 'Pending', color: 'bg-orange-500' }
    }
    
    const statusInfo = statusMap[String(status)] || { text: String(status), color: 'bg-gray-500' }
    
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusInfo.color} text-white`}>
        {statusInfo.text}
      </span>
    )
  }

  // Helper function to get status text from status number
  const getStatusText = (status: string | number) => {
    const statusMap: { [key: string]: string } = {
      '1': 'Live',
      '2': 'Die', 
      '3': 'Nợ',
      '4': 'Pending',
      '5': 'Disabled',
      '7': 'Pending',
      '9': 'Pending', 
      '101': 'Die',
      'ACTIVE': 'Live',
      'DISABLED': 'Die',
      'UNSETTLED': 'Nợ',
      'PENDING_REVIEW': 'Pending'
    }
    return statusMap[String(status)] || String(status)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('vi-VN')
  }

  const formatCurrency = (amount: string | number, currency: string) => {
    if (!amount || !currency) return 'N/A'
    
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount
    if (isNaN(numAmount)) return 'N/A'
    
    // Define locale and formatting options for different currencies
    const currencyFormats: { [key: string]: { locale: string, options: Intl.NumberFormatOptions } } = {
      'VND': { 
        locale: 'vi-VN', 
        options: { 
          style: 'decimal',
          minimumFractionDigits: 0,
          maximumFractionDigits: 0
        }
      },
      'USD': { 
        locale: 'en-US', 
        options: { 
          style: 'decimal',
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        }
      },
      'EUR': { 
        locale: 'de-DE', 
        options: { 
          style: 'decimal',
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        }
      },
      'GBP': { 
        locale: 'en-GB', 
        options: { 
          style: 'decimal',
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        }
      },
      'JPY': { 
        locale: 'ja-JP', 
        options: { 
          style: 'decimal',
          minimumFractionDigits: 0,
          maximumFractionDigits: 0
        }
      }
    }
    
    const format = currencyFormats[currency.toUpperCase()] || currencyFormats['USD']
    const formattedAmount = new Intl.NumberFormat(format.locale, format.options).format(numAmount)
    
    return `${formattedAmount} ${currency}`
  }

  const filterTKQCData = (tkqcData: TKQCAccount[]) => {
    return tkqcData.filter(tkqc => {
      const matchesSearch = searchTerm === '' || 
        tkqc.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tkqc.account_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tkqc.id?.toLowerCase().includes(searchTerm.toLowerCase())

      // Get status text from either account_status_text or account_status number
      const statusText = tkqc.account_status_text || getStatusText(tkqc.account_status)
      
      const matchesStatus = statusFilter === 'all' || 
        (statusFilter === 'live' && statusText.includes('Live')) ||
        (statusFilter === 'die' && statusText.includes('Die')) ||
        (statusFilter === 'debt' && statusText.includes('Nợ'))

      const matchesType = typeFilter === 'all' ||
        (typeFilter === 'personal' && tkqc.source === 'Personal') ||
        (typeFilter === 'bm' && tkqc.source !== 'Personal')

      return matchesSearch && matchesStatus && matchesType
    })
  }

  if (loading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center gap-2">
          <RefreshCw className="h-5 w-5 animate-spin text-gray-600 dark:text-gray-400" />
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Đang tải dữ liệu TKQC...</h2>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Dữ liệu TKQC ({accounts.length} accounts)</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Storage: {localStorage.getItem('storage_mode') === 'local' ? 'Local' : 'Server'} 
                {localStorage.getItem('storage_mode') === 'local' && ' (Chỉ hiển thị dữ liệu từ localStorage)'}
                {localStorage.getItem('storage_mode') === 'server' && ' (Hiển thị dữ liệu từ database)'}
              </p>
            </div>
            <button 
              onClick={fetchTKQCData} 
              className="flex items-center gap-2 px-3 py-2 text-sm text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              <RefreshCw className="h-4 w-4" />
              Refresh
            </button>
          </div>
        </div>
        <div className="p-6">
          {(() => {
            const filteredAccounts = selectedAccountId 
              ? accounts.filter(account => account._id === selectedAccountId)
              : accounts
            
            return filteredAccounts.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                {selectedAccountId 
                  ? "Không tìm thấy dữ liệu TKQC cho tài khoản này."
                  : "Chưa có dữ liệu TKQC nào. Hãy chạy Check TKQC để lấy dữ liệu."
                }
              </p>
            ) : (
              <div className="space-y-4">
                {filteredAccounts.map((account) => (
                <div key={account._id} className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 border-l-4 border-l-blue-500">
                  <div className="p-4 pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div>
                          <h3 className="font-semibold text-gray-900 dark:text-white">{account.name || account.mail}</h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{extractUIDFromString(account.uid, account)}</p>
                        </div>
                        {getStatusBadge(account.status)}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
                          {account.tkqcCount} TKQC
                        </span>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-50 text-purple-700 border border-purple-200">
                          {account.bmCount} BM
                        </span>
                        <button
                          className="relative p-2 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 border border-blue-400 hover:border-blue-500"
                          onClick={() => setExpandedAccount(
                            expandedAccount === account._id ? null : account._id
                          )}
                          title={expandedAccount === account._id ? "Ẩn chi tiết TKQC" : "Xem chi tiết TKQC"}
                        >
                          {expandedAccount === account._id ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                          {/* Pulse effect when not expanded */}
                          {expandedAccount !== account._id && (
                            <span className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full animate-pulse"></span>
                          )}
                        </button>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      <p>Last check: {formatDate(account.lastTkqcCheck)}</p>
                      <p>{account.log}</p>
                    </div>
                  </div>

                  {expandedAccount === account._id && (
                    <div className="px-4 pb-4 pt-0">
                      {/* Summary Cards */}
                      {account.tkqcData.length > 0 && (
                        <div className="mb-6">
                          <h4 className="font-semibold mb-3 text-gray-700 dark:text-gray-300">Tổng quan TKQC</h4>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg p-4 text-white">
                              <p className="text-sm opacity-90">Tổng TKQC</p>
                              <p className="text-2xl font-bold">{account.tkqcData.length}</p>
                            </div>
                            <div className="bg-gradient-to-r from-green-500 to-green-600 rounded-lg p-4 text-white">
                              <p className="text-sm opacity-90">Live</p>
                              <p className="text-2xl font-bold">
                                {account.tkqcData.filter(t => {
                                  const statusText = t.account_status_text || getStatusText(t.account_status)
                                  return statusText.includes('Live')
                                }).length}
                              </p>
                            </div>
                            <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-lg p-4 text-white">
                              <p className="text-sm opacity-90">Die</p>
                              <p className="text-2xl font-bold">
                                {account.tkqcData.filter(t => {
                                  const statusText = t.account_status_text || getStatusText(t.account_status)
                                  return statusText.includes('Die')
                                }).length}
                              </p>
                            </div>
                            <div className="bg-gradient-to-r from-purple-500 to-purple-600 rounded-lg p-4 text-white">
                              <p className="text-sm opacity-90">TKQC BM</p>
                              <p className="text-2xl font-bold">
                                {account.tkqcData.filter(t => t.source !== 'Personal').length}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* TKQC Data */}
                      {account.tkqcData.length > 0 && (
                        <div className="mb-6">
                          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                            <h4 className="font-semibold text-blue-600 dark:text-blue-400 mb-3 md:mb-0">
                              TKQC Accounts ({filterTKQCData(account.tkqcData).length}/{account.tkqcData.length})
                            </h4>
                            
                            {/* Filters */}
                            <div className="flex flex-col sm:flex-row gap-3">
                              <input
                                type="text"
                                placeholder="Tìm kiếm TKQC..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              />
                              <select
                                value={statusFilter}
                                onChange={(e) => setStatusFilter(e.target.value)}
                                className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              >
                                <option value="all">Tất cả trạng thái</option>
                                <option value="live">Live</option>
                                <option value="die">Die</option>
                                <option value="debt">Nợ</option>
                              </select>
                              <select
                                value={typeFilter}
                                onChange={(e) => setTypeFilter(e.target.value)}
                                className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm text-gray-900 dark:text-white bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              >
                                <option value="all">Tất cả loại</option>
                                <option value="personal">TKQC Cá Nhân</option>
                                <option value="bm">TKQC BM</option>
                              </select>
                            </div>
                          </div>
                          <div className="grid gap-4">
                            {filterTKQCData(account.tkqcData).length === 0 ? (
                              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                                <p>Không tìm thấy TKQC nào phù hợp với bộ lọc</p>
                              </div>
                            ) : (
                              filterTKQCData(account.tkqcData).map((tkqc) => (
                              <div key={tkqc.id} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-blue-50 dark:bg-blue-900/20">
                                {/* Header với tên và status */}
                                <div className="flex items-center justify-between mb-3">
                                  <div className="flex items-center gap-3">
                                    {tkqc.profile_picture && (
                                      <img 
                                        src={tkqc.profile_picture} 
                                        alt={tkqc.name}
                                        className="w-10 h-10 rounded-full"
                                      />
                                    )}
                                    <div>
                                      <p className="font-semibold text-lg text-gray-900 dark:text-white">{tkqc.name}</p>
                                      <p className="text-sm text-gray-600 dark:text-gray-400">ID: {tkqc.account_id}</p>
                                      <div className="flex items-center gap-2 mt-1">
                                        {tkqc.source && (
                                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                                            {tkqc.source}
                                          </span>
                                        )}
                                        {tkqc.user_role && (
                                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                            {tkqc.user_role}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                  <div className="text-right">
                                    {(() => {
                                      const statusText = tkqc.account_status_text || getStatusText(tkqc.account_status)
                                      return (
                                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                                          statusText.includes('Live') ? 'bg-green-100 text-green-800' :
                                          statusText.includes('Die') ? 'bg-red-100 text-red-800' :
                                          statusText.includes('Nợ') ? 'bg-yellow-100 text-yellow-800' :
                                          'bg-gray-100 text-gray-800'
                                        }`}>
                                          {statusText}
                                        </span>
                                      )
                                    })()}
                                  </div>
                                </div>

                                {/* Thông tin tài chính */}
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                                  {tkqc.balance && (
                                    <div className="bg-white dark:bg-gray-800 rounded-lg p-3">
                                      <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Số Dư</p>
                                      <p className="text-lg font-semibold text-green-600">{formatCurrency(tkqc.balance, tkqc.currency || 'VND')}</p>
                                    </div>
                                  )}
                                  {tkqc.spend && (
                                    <div className="bg-white dark:bg-gray-800 rounded-lg p-3">
                                      <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Chi Tiêu</p>
                                      <p className="text-lg font-semibold text-blue-600">{formatCurrency(tkqc.spend, tkqc.currency || 'VND')}</p>
                                    </div>
                                  )}
                                  {tkqc.adtrust_dsl && (
                                    <div className="bg-white dark:bg-gray-800 rounded-lg p-3">
                                      <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Hạn Mức</p>
                                      <p className="text-lg font-semibold text-purple-600">{formatCurrency(tkqc.adtrust_dsl, tkqc.currency || 'VND')}</p>
                                    </div>
                                  )}
                                  {tkqc.threshold_amount && (
                                    <div className="bg-white dark:bg-gray-800 rounded-lg p-3">
                                      <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Ngưỡng Thanh Toán</p>
                                      <p className="text-lg font-semibold text-orange-600">{formatCurrency(tkqc.threshold_amount, tkqc.currency || 'VND')}</p>
                                    </div>
                                  )}
                                  {tkqc.amount_spent && (
                                    <div className="bg-white dark:bg-gray-800 rounded-lg p-3">
                                      <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Đã Chi Tiêu</p>
                                      <p className="text-lg font-semibold text-red-600">{formatCurrency(tkqc.amount_spent, tkqc.currency || 'VND')}</p>
                                    </div>
                                  )}
                                  {tkqc.disable_reason !== undefined && (
                                    <div className="bg-white dark:bg-gray-800 rounded-lg p-3">
                                      <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide">Lý Do Vô Hiệu</p>
                                      <p className="text-lg font-semibold text-red-600">{tkqc.disable_reason || 'Không có'}</p>
                                    </div>
                                  )}
                                </div>

                                {/* Thông tin chi tiết */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                  <div className="space-y-2">
                                    {tkqc.created_time && (
                                      <div className="flex justify-between">
                                        <span className="text-gray-600 dark:text-gray-400">Ngày Tạo:</span>
                                        <span className="font-medium text-gray-900 dark:text-white">{new Date(tkqc.created_time).toLocaleDateString('vi-VN')}</span>
                                      </div>
                                    )}
                                    {tkqc.next_bill_date && (
                                      <div className="flex justify-between">
                                        <span className="text-gray-600 dark:text-gray-400">Ngày Thanh Toán:</span>
                                        <span className="font-medium text-gray-900 dark:text-white">{new Date(tkqc.next_bill_date).toLocaleDateString('vi-VN')}</span>
                                      </div>
                                    )}
                                    {tkqc.currency && (
                                      <div className="flex justify-between">
                                        <span className="text-gray-600 dark:text-gray-400">Tiền Tệ:</span>
                                        <span className="font-medium text-gray-900 dark:text-white">{tkqc.currency}</span>
                                      </div>
                                    )}
                                    {tkqc.user_role && (
                                      <div className="flex justify-between">
                                        <span className="text-gray-600 dark:text-gray-400">Vai Trò:</span>
                                        <span className="font-medium text-gray-900 dark:text-white">{tkqc.user_role}</span>
                                      </div>
                                    )}
                                  </div>
                                  <div className="space-y-2">
                                    {tkqc.is_prepay_account !== undefined && (
                                      <div className="flex justify-between">
                                        <span className="text-gray-600 dark:text-gray-400">Tài Khoản Trả Trước:</span>
                                        <span className="font-medium text-gray-900 dark:text-white">{tkqc.is_prepay_account ? 'Có' : 'Không'}</span>
                                      </div>
                                    )}
                                    {tkqc.owner && (
                                      <div className="flex justify-between">
                                        <span className="text-gray-600 dark:text-gray-400">Chủ Sở Hữu:</span>
                                        <span className="font-medium text-gray-900 dark:text-white">{tkqc.owner}</span>
                                      </div>
                                    )}
                                    {tkqc.source && (
                                      <div className="flex justify-between">
                                        <span className="text-gray-600 dark:text-gray-400">Nguồn:</span>
                                        <span className="font-medium text-gray-900 dark:text-white">{tkqc.source}</span>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                            ))
                            )}
                          </div>
                        </div>
                      )}

                      {/* BM Data */}
                      {account.bmData.length > 0 && (
                        <div>
                          <h4 className="font-semibold mb-3 text-purple-600 dark:text-purple-400">
                            Business Managers ({account.bmData.length})
                          </h4>
                          <div className="grid gap-3">
                            {account.bmData.map((bm) => (
                              <div key={bm.id} className="border border-gray-200 dark:border-gray-600 rounded-lg p-3 bg-purple-50 dark:bg-purple-900/20">
                                <div className="flex items-center justify-between mb-2">
                                  <div className="flex items-center gap-2">
                                    {bm.profile_picture && (
                                      <img 
                                        src={bm.profile_picture} 
                                        alt={bm.name}
                                        className="w-8 h-8 rounded-full"
                                      />
                                    )}
                                    <div>
                                      <p className="font-medium text-gray-900 dark:text-white">{bm.name}</p>
                                      <p className="text-xs text-gray-500 dark:text-gray-400">ID: {bm.id}</p>
                                      {bm.category && (
                                        <p className="text-xs text-purple-600 dark:text-purple-400">📂 {bm.category}</p>
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex gap-2">
                                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-50 text-gray-700 border border-gray-200">
                                      {bm.verification_status}
                                    </span>
                                    {bm.restriction_type && (
                                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-50 text-red-700 border border-red-200">
                                        {bm.restriction_type}
                                      </span>
                                    )}
                                    <button
                                      onClick={() => { setShowShareModal(true); setShareAccountId(account._id); setShareBmId(bm.id); setShareLinks([]) }}
                                      className="px-2 py-1 text-xs rounded-md bg-blue-600 hover:bg-blue-700 text-white border border-blue-500"
                                      title="Share BM"
                                    >
                                      Share BM
                                    </button>
                                  </div>
                                </div>
                                
                                {/* Additional BM Info */}
                                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 dark:text-gray-400 mt-2">
                                  {bm.email && (
                                    <div className="flex items-center gap-1">
                                      <span>📧</span>
                                      <span className="truncate">{bm.email}</span>
                                    </div>
                                  )}
                                  {bm.phone && (
                                    <div className="flex items-center gap-1">
                                      <span>📱</span>
                                      <span>{bm.phone}</span>
                                    </div>
                                  )}
                                  {bm.website && (
                                    <div className="flex items-center gap-1 col-span-2">
                                      <span>🌐</span>
                                      <a 
                                        href={bm.website} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-blue-600 dark:text-blue-400 hover:underline truncate"
                                      >
                                        {bm.website}
                                      </a>
                                    </div>
                                  )}
                                  {bm.created_time && (
                                    <div className="flex items-center gap-1 col-span-2">
                                      <span>📅</span>
                                      <span>{new Date(bm.created_time).toLocaleDateString('vi-VN')}</span>
                                    </div>
                                  )}
                                  {bm.adAccountId && (
                                    <div className="flex items-center gap-1 col-span-2">
                                      <span>💳</span>
                                      <span className="text-green-600 dark:text-green-400">Ad Account: {bm.adAccountId}</span>
                                    </div>
                                  )}
                                </div>
                                
                                {/* BM Actions */}
                                {bm.url && (
                                  <div className="mt-2 pt-2 border-t border-gray-200 dark:border-gray-600">
                                    <a
                                      href={bm.url}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 hover:underline"
                                    >
                                      🔗 Mở Business Manager
                                    </a>
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
                ))}
              </div>
            )
          })()}
        </div>
      </div>
      {/* Share BM Modal */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700">
            <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <h3 className="font-semibold text-gray-900 dark:text-white">Share BM</h3>
              <button onClick={() => setShowShareModal(false)} className="text-gray-500 hover:text-gray-700 dark:text-gray-400">✕</button>
            </div>
            <div className="p-4 space-y-3">
              <div>
                <label className="text-sm text-gray-700 dark:text-gray-300">BM ID</label>
                <input value={shareBmId} readOnly className="mt-1 w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-sm text-gray-700 dark:text-gray-300">Quyền</label>
                  <select value={shareRole} onChange={e => setShareRole(e.target.value as 'ADMIN' | 'EMPLOYEE')} className="mt-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100">
                    <option value="ADMIN">Quản trị viên</option>
                    <option value="EMPLOYEE">Nhân viên</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-gray-700 dark:text-gray-300">Số lượng</label>
                  <input type="number" min={1} value={shareQuantity} onChange={e => setShareQuantity(Math.max(1, Number(e.target.value||1)))} className="mt-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100"/>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Dùng Mail1s.Net</label>
                <input type="checkbox" checked={shareUseMail1s} onChange={e => setShareUseMail1s(e.target.checked)} />
              </div>
              {!shareUseMail1s && (
                <div>
                  <label className="text-sm text-gray-700 dark:text-gray-300">Email nhận lời mời</label>
                  <input placeholder="user@example.com" value={shareEmail} onChange={e => setShareEmail(e.target.value)} className="mt-1 w-full px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100" />
                </div>
              )}
              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-700 dark:text-gray-300">Đăng nhập trước khi chạy</label>
                <input type="checkbox" checked={shareLoginFirst} onChange={e => setShareLoginFirst(e.target.checked)} />
              </div>
              <div>
                <label className="text-sm text-gray-700 dark:text-gray-300">Phương thức đăng nhập</label>
                <select value={shareLoginMethod} onChange={e => setShareLoginMethod(e.target.value as 'cookie'|'password')} className="mt-1 w-full px-2 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700/50 text-sm text-gray-800 dark:text-gray-100" disabled={!shareLoginFirst}>
                  <option value="cookie">Cookie (khuyến nghị)</option>
                  <option value="password">Password</option>
                </select>
              </div>
              <div>
                <label className="text-sm text-gray-700 dark:text-gray-300">Link xác nhận</label>
                <textarea readOnly placeholder="Chưa có link" value={(shareLinks||[]).map(l => `${shareBmId}|${l.url}`).join('\n')} className="mt-1 w-full h-28 resize-none rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-xs text-gray-800 dark:text-gray-100 p-2" />
              </div>
              <div className="mt-2 min-h-[36px]">
                {shareLoading && (
                  <div className="text-xs text-blue-600 dark:text-blue-400">Đang share BM...</div>
                )}
                {!shareLoading && shareResultStatus === 'success' && (
                  <div className="text-xs px-3 py-2 rounded-md bg-green-50 text-green-700 border border-green-200">
                    Share thành công. Số link: <span className="font-semibold">{shareLinks.length}</span>
                  </div>
                )}
                {!shareLoading && shareResultStatus === 'failed' && (
                  <div className="text-xs px-3 py-2 rounded-md bg-red-50 text-red-700 border border-red-200">
                    Share thất bại. Không nhận được link xác nhận.
                  </div>
                )}
              </div>
            </div>
            <div className="p-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-end gap-2">
              <button onClick={() => setShowShareModal(false)} className="px-3 py-2 text-sm rounded-md border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300">Đóng</button>
              <button disabled={shareLoading} onClick={async () => {
                if (!shareAccountId) return; setShareLoading(true); setShareLinks([]); setShareResultStatus('idle');
                try {
                  const res = await fetch('/api/facebook/share-bm', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` }, body: JSON.stringify({ accountId: shareAccountId, bmId: shareBmId, shareAll: false, role: shareRole, quantity: shareQuantity, email: shareUseMail1s ? undefined : shareEmail, useMail1s: shareUseMail1s, loginFirst: shareLoginFirst, loginMethod: shareLoginMethod }) })
                  const j = await res.json()
                  const confirmations = j?.data?.confirmations || []
                  if (res.ok && j?.success && confirmations.length > 0) {
                    setShareLinks(confirmations)
                    setShareResultStatus('success')
                  } else {
                    setShareLinks([])
                    setShareResultStatus('failed')
                  }
                } catch {}
                finally { setShareLoading(false); }
              }} className="px-3 py-2 text-sm rounded-md bg-blue-600 hover:bg-blue-700 text-white">{shareLoading ? 'Đang share...' : 'Share'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}