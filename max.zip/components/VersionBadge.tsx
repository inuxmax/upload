'use client'

import React from 'react'

export default function VersionBadge({ prefix = '' }: { prefix?: string }) {
  const [name, setName] = React.useState<string>(prefix)
  const [version, setVersion] = React.useState<string>('')

  React.useEffect(() => {
    let isMounted = true
    const load = async () => {
      try {
        const res = await fetch('/version.json', { cache: 'no-store' })
        if (!res.ok) return
        const data = await res.json().catch(() => null)
        if (!isMounted || !data) return
        if (typeof data.name === 'string' && data.name.trim()) setName(data.name)
        if (typeof data.version === 'string') setVersion(data.version)
      } catch {
        /* ignore */
      }
    }
    load()
    return () => { isMounted = false }
  }, [prefix])

  return (
    <span>{name}{version ? ` ${version}` : ''}</span>
  )
}


