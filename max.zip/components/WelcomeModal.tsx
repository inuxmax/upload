'use client'

import { useState, useEffect } from 'react'
import { X, Bell, Sparkles } from 'lucide-react'

interface WelcomeModalProps {
  isOpen: boolean
  onClose: () => void
  title?: string
  message?: string
  showDontShowAgain?: boolean
}

export default function WelcomeModal({ 
  isOpen, 
  onClose, 
  title = "Thông báo",
  message = "Chào mừng bạn quay trở lại !",
  showDontShowAgain = true
}: WelcomeModalProps) {
  const [dontShowAgain, setDontShowAgain] = useState(false)

  const handleClose = () => {
    if (dontShowAgain) {
      localStorage.setItem('welcomeModalDismissed', 'true')
    }
    onClose()
  }

  const handleDontShowAgainChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDontShowAgain(e.target.checked)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in-0 duration-300">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full mx-auto relative transform animate-in zoom-in-95 duration-300 border border-gray-100">
        {/* Header with gradient background */}
        <div className="relative overflow-hidden rounded-t-2xl">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-90"></div>
          <div className="relative flex items-center justify-between p-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
                <Bell className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">{title}</h2>
                <div className="flex items-center space-x-1 mt-1">
                  <Sparkles className="w-3 h-3 text-yellow-300" />
                  <span className="text-xs text-white/80">Thông báo mới</span>
                </div>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/20 rounded-xl transition-all duration-200 backdrop-blur-sm"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="text-gray-800 text-base leading-relaxed whitespace-pre-line bg-gradient-to-br from-gray-50 to-blue-50 p-4 rounded-xl border border-gray-100">
            {message}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 pb-6">
          {showDontShowAgain && (
            <div className="mb-4">
              <label className="flex items-center space-x-3 text-sm text-gray-600 cursor-pointer group">
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={dontShowAgain}
                    onChange={handleDontShowAgainChange}
                    className="sr-only peer"
                  />
                  <div className="w-5 h-5 border-2 border-gray-300 rounded-md peer-checked:border-blue-500 peer-checked:bg-blue-500 transition-all duration-200 group-hover:border-blue-400">
                    <div className="w-full h-full flex items-center justify-center">
                      {dontShowAgain && (
                        <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                  </div>
                </div>
                <span className="group-hover:text-gray-800 transition-colors duration-200">Không hiển thị lại</span>
              </label>
            </div>
          )}
          
          <div className="flex justify-end">
            <button
              onClick={handleClose}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 font-medium shadow-lg hover:shadow-xl transform hover:scale-105 active:scale-95"
            >
              Đóng
            </button>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute -top-2 -right-2 w-4 h-4 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full animate-pulse"></div>
        <div className="absolute -bottom-2 -left-2 w-3 h-3 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full animate-pulse delay-1000"></div>
      </div>
    </div>
  )
}
