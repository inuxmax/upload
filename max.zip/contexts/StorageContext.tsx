'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

interface StorageContextType {
  storageMode: 'local' | 'server';
  setStorageMode: (mode: 'local' | 'server') => void;
  saveToLocalStorage: (accounts: any[]) => void;
  loadFromLocalStorage: () => any[];
  clearLocalStorage: () => void;
  getLocalStorageAccounts: () => any[];
  isLocalStorageEnabled: boolean;
}

const StorageContext = createContext<StorageContextType | undefined>(undefined);

export function StorageProvider({ children }: { children: React.ReactNode }) {
  const [storageMode, setStorageModeState] = useState<'local' | 'server'>('server');

  // Load storage mode from localStorage on mount
  useEffect(() => {
    const savedMode = localStorage.getItem('storage_mode');
    if (savedMode && ['local', 'server'].includes(savedMode)) {
      setStorageModeState(savedMode as 'local' | 'server');
    }
  }, []);

  const setStorageMode = (mode: 'local' | 'server') => {
    
    setStorageModeState(mode);
    localStorage.setItem('storage_mode', mode);
  };

  const saveToLocalStorage = (accounts: any[]) => {
    try {
      const accountsToSave = accounts.map(account => ({
        ...account,
        savedAt: new Date().toISOString(),
        source: 'local'
      }));
      localStorage.setItem('facebook_accounts', JSON.stringify(accountsToSave));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
    }
  };

  const loadFromLocalStorage = (): any[] => {
    try {
      const saved = localStorage.getItem('facebook_accounts');
      const data = saved ? JSON.parse(saved) : [];
      
      return data;
    } catch (error) {
      console.error('Error loading from localStorage:', error);
      return [];
    }
  };

  const clearLocalStorage = () => {
    try {
      localStorage.removeItem('facebook_accounts');
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  };

  const getLocalStorageAccounts = (): any[] => {
    return loadFromLocalStorage();
  };

  const isLocalStorageEnabled = storageMode === 'local';

  const value: StorageContextType = {
    storageMode,
    setStorageMode,
    saveToLocalStorage,
    loadFromLocalStorage,
    clearLocalStorage,
    getLocalStorageAccounts,
    isLocalStorageEnabled
  };

  return (
    <StorageContext.Provider value={value}>
      {children}
    </StorageContext.Provider>
  );
}

export function useStorage() {
  const context = useContext(StorageContext);
  if (context === undefined) {
    throw new Error('useStorage must be used within a StorageProvider');
  }
  return context;
}
