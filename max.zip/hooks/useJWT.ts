import { useState, useEffect, useCallback } from 'react';
import { checkClientToken, handleJWTError, autoRefreshToken } from '@/lib/jwt';

interface JWTState {
  token: string | null;
  isValid: boolean;
  needsRefresh: boolean;
  isLoading: boolean;
  error: string | null;
}

export function useJWT() {
  const [jwtState, setJwtState] = useState<JWTState>({
    token: null,
    isValid: false,
    needsRefresh: false,
    isLoading: true,
    error: null
  });

  // Kiểm tra token khi component mount
  useEffect(() => {
    checkToken();
  }, []);

  // Kiểm tra token
  const checkToken = useCallback(() => {
    try {
      setJwtState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const tokenCheck = checkClientToken();
      setJwtState({
        token: tokenCheck.token,
        isValid: tokenCheck.isValid,
        needsRefresh: tokenCheck.needsRefresh,
        isLoading: false,
        error: null
      });
    } catch (error) {
      setJwtState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Lỗi kiểm tra token'
      }));
    }
  }, []);

  // Refresh token
  const refreshToken = useCallback(async () => {
    try {
      setJwtState(prev => ({ ...prev, isLoading: true, error: null }));
      
      const success = await autoRefreshToken();
      
      if (success) {
        // Kiểm tra lại token sau khi refresh
        checkToken();
      } else {
        setJwtState(prev => ({
          ...prev,
          isLoading: false,
          error: 'Không thể refresh token'
        }));
      }
    } catch (error) {
      setJwtState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Lỗi refresh token'
      }));
    }
  }, [checkToken]);

  // Xử lý JWT errors
  const handleError = useCallback((error: any, currentPath: string = '/') => {
    const handled = handleJWTError(error, currentPath);
    
    if (handled) {
      // Error đã được xử lý (redirect), cập nhật state
      setJwtState({
        token: null,
        isValid: false,
        needsRefresh: false,
        isLoading: false,
        error: null
      });
    }
    
    return handled;
  }, []);

  // Logout
  const logout = useCallback(() => {
    localStorage.removeItem('token');
    sessionStorage.removeItem('token');
    
    setJwtState({
      token: null,
      isValid: false,
      needsRefresh: false,
      isLoading: false,
      error: null
    });
    
    // Redirect về trang login
    window.location.href = '/auth';
  }, []);

  // Tự động refresh token nếu cần
  useEffect(() => {
    if (jwtState.needsRefresh && jwtState.isValid) {
      const timer = setTimeout(() => {
        refreshToken();
      }, 5000); // Delay 5 giây trước khi refresh
      
      return () => clearTimeout(timer);
    }
  }, [jwtState.needsRefresh, jwtState.isValid, refreshToken]);

  // Kiểm tra token định kỳ (mỗi 5 phút)
  useEffect(() => {
    const interval = setInterval(() => {
      if (jwtState.isValid) {
        checkToken();
      }
    }, 5 * 60 * 1000); // 5 phút
    
    return () => clearInterval(interval);
  }, [jwtState.isValid, checkToken]);

  return {
    ...jwtState,
    checkToken,
    refreshToken,
    handleError,
    logout
  };
}

// Hook để tạo authenticated fetch function
export function useAuthenticatedFetch() {
  const { token, isValid, needsRefresh, refreshToken } = useJWT();

  const authenticatedFetch = useCallback(async (input: RequestInfo | URL, init?: RequestInit) => {
    try {
      // Nếu token sắp hết hạn, refresh trước
      if (needsRefresh && isValid) {
        await refreshToken();
      }
      
      // Thêm Authorization header
      const headers = new Headers(init?.headers);
      if (token) {
        headers.set('Authorization', `Bearer ${token}`);
      }
      
      // Thực hiện request
      const response = await fetch(input, {
        ...init,
        headers
      });
      
      // Kiểm tra response status
      if (response.status === 401) {
        const errorData = await response.json().catch(() => ({}));
        
        // Xử lý JWT errors
        if (errorData.code === 'TOKEN_EXPIRED' || errorData.code === 'TOKEN_INVALID') {
          // Token hết hạn, logout
          localStorage.removeItem('token');
          sessionStorage.removeItem('token');
          window.location.href = `/auth?redirect=${encodeURIComponent(window.location.pathname)}&error=${errorData.code}`;
          return response;
        }
      }
      
      return response;
    } catch (error) {
      console.error('Authenticated fetch error:', error);
      throw error;
    }
  }, [token, isValid, needsRefresh, refreshToken]);

  return authenticatedFetch;
}
