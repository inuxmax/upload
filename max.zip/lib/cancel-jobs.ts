// In-memory cancel registry. Note: scoped per process instance.
const canceledRunIds = new Set<string>()

export function cancelRun(runId: string) {
  if (!runId) return
  canceledRunIds.add(String(runId))
}

export function isRunCanceled(runId?: string | null) {
  if (!runId) return false
  return canceledRunIds.has(String(runId))
}

export function clearRun(runId?: string | null) {
  if (!runId) return
  canceledRunIds.delete(String(runId))
}


