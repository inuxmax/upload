import cron from 'node-cron';
import { initProxyCronJob } from './proxy-cron';

let isRunning = false;
let totalRuns = 0;
let successCount = 0;
let errorCount = 0;
let lastRun: Date | null = null;
let nextRun: Date | null = null;

// Hàm gọi ACB API
async function checkACBTransactions() {
  try {
    console.log('🕐 Cron job: Checking ACB transactions...', new Date().toISOString());
    lastRun = new Date();
    totalRuns++;
    
    const response = await fetch('http://localhost:3000/api/acb-payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log('✅ ACB Cron job successful!');
      console.log(`Processed: ${data.processed} transactions`);
      console.log(`Downgraded: ${data.downgraded || 0} subscriptions`);
      successCount++;
      
      if (data.processed > 0) {
        console.log('💰 New payments detected!');
        // Có thể thêm thông báo email/SMS ở đây
      }
      
      if (data.downgraded > 0) {
        console.log('⬇️ Expired subscriptions downgraded!');
      }
    } else {
      console.log('❌ ACB Cron job failed:', data.error);
      errorCount++;
    }
  } catch (error) {
    console.error('❌ ACB Cron job error:', error);
    errorCount++;
  }
}

// Hàm kiểm tra và hạ cấp subscription đã hết hạn
async function checkExpiredSubscriptions() {
  try {
    console.log('🕐 Cron job: Checking expired subscriptions...', new Date().toISOString());
    
    const response = await fetch('http://localhost:3000/api/subscription/downgrade', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log('✅ Subscription downgrade check successful!');
      console.log(`Checked: ${data.checked} subscriptions`);
      console.log(`Downgraded: ${data.downgraded} expired subscriptions`);
      
      if (data.downgraded > 0) {
        console.log('⬇️ Expired subscriptions automatically downgraded!');
      }
    } else {
      console.log('❌ Subscription downgrade check failed:', data.error);
    }
  } catch (error) {
    console.error('❌ Subscription downgrade check error:', error);
  }
}

// Khởi tạo cron jobs tự động
export function initCronJobs() {
  try {
    if (isRunning) {
      console.log('🔄 Cron jobs already running');
      return;
    }

    console.log('🚀 Initializing cron jobs...');
    
    // Chạy ACB check mỗi 30 giây
    cron.schedule('*/30 * * * * *', () => {
      checkACBTransactions();
    }, {
      timezone: "Asia/Ho_Chi_Minh"
    });
    
    // Chạy subscription downgrade check mỗi 5 phút
    cron.schedule('0 */5 * * * *', () => {
      checkExpiredSubscriptions();
    }, {
      timezone: "Asia/Ho_Chi_Minh"
    });
    
    // Khởi tạo proxy cron job
    initProxyCronJob();
    
    // Chạy ngay lập tức lần đầu
    checkACBTransactions();
    checkExpiredSubscriptions();
    
    isRunning = true;
    console.log('✅ Cron jobs initialized and started automatically');
    console.log('📅 ACB Schedule: Every 30 seconds');
    console.log('📅 Subscription Downgrade Schedule: Every 5 minutes');
    console.log('📅 Proxy IP Update Schedule: Every 2 minutes');
    console.log('🌏 Timezone: Asia/Ho_Chi_Minh');
    console.log('🔄 Auto-start: Enabled');
  } catch (error) {
    console.error('❌ Error initializing cron jobs:', error);
  }
}

// Hàm dừng cron jobs
export function stopCronJobs() {
  try {
    console.log('🛑 Stopping cron jobs...');
    cron.getTasks().forEach(task => task.stop());
    isRunning = false;
    console.log('✅ Cron jobs stopped');
  } catch (error) {
    console.error('❌ Error stopping cron jobs:', error);
  }
}

// Hàm lấy trạng thái cron
export function getCronStatus() {
  return {
    isRunning,
    lastRun,
    nextRun,
    totalRuns,
    successCount,
    errorCount
  };
}

// Hàm reset stats
export function resetCronStats() {
  totalRuns = 0;
  successCount = 0;
  errorCount = 0;
  lastRun = null;
  nextRun = null;
  console.log('📊 Cron stats reset');
}

// Tự động khởi tạo khi import
try {
  initCronJobs();
} catch (error) {
  console.error('❌ Failed to auto-start cron jobs:', error);
} 