import crypto from 'crypto'
import connectMongoDB from '@/lib/mongodb'
import Settings from '@/models/Settings'

// Simple AES-256-GCM helpers with deterministic envelope format
// Stored value format: enc:v1:<ivBase64>:<cipherBase64>:<tagBase64>

function getAesKeyFromString(keyString: string): Buffer {
  return crypto.createHash('sha256').update(String(keyString)).digest()
}

export function encryptStringWithKey(plainText: string, keyString: string): string {
  const key = getAesKeyFromString(keyString)
  const iv = crypto.randomBytes(12)
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv)
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()])
  const tag = cipher.getAuthTag()
  return `enc:v1:${iv.toString('base64')}:${encrypted.toString('base64')}:${tag.toString('base64')}`
}

export function decryptStringWithKey(encryptedValue: string, keyString: string): string {
  if (!isEncrypted(encryptedValue)) return encryptedValue
  const key = getAesKeyFromString(keyString)
  const [, , ivB64, dataB64, tagB64] = encryptedValue.split(':')
  const iv = Buffer.from(ivB64, 'base64')
  const data = Buffer.from(dataB64, 'base64')
  const tag = Buffer.from(tagB64, 'base64')
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv)
  decipher.setAuthTag(tag)
  const decrypted = Buffer.concat([decipher.update(data), decipher.final()])
  return decrypted.toString('utf8')
}

export function isEncrypted(value?: string | null): boolean {
  return typeof value === 'string' && value.startsWith('enc:v1:')
}

// Master key used solely to encrypt user's personal encryption key
// Support key rotation: ENCRYPTION_KEYS="k1,k2" (k1 newest). Fallback to ENCRYPTION_KEY for backward compat.
export function getMasterKeys(): string[] {
  const keysEnv = process.env.ENCRYPTION_KEYS || ''
  const single = process.env.ENCRYPTION_KEY || ''
  const arr = keysEnv
    .split(',')
    .map(s => s.trim())
    .filter(Boolean)
  if (arr.length > 0) return arr
  // Development fallback (avoid crashing locally). In production, please set ENCRYPTION_KEYS or ENCRYPTION_KEY.
  return single ? [single] : ['default-master-key']
}

export function getMasterKey(): string {
  return getMasterKeys()[0]
}

export function encryptUserKey(userKeyPlain: string): { encrypted: string } {
  const encrypted = encryptStringWithKey(userKeyPlain, getMasterKey())
  return { encrypted }
}

export function decryptUserKey(encrypted: string | null | undefined): string | null {
  if (!encrypted) return null
  try {
    // Try all configured master keys to support rotation/back-compat
    for (const k of getMasterKeys()) {
      try {
        return decryptStringWithKey(encrypted, k)
      } catch {}
    }
    return null
  } catch {
    return null
  }
}

export function isValidAdminKey(adminKeyPlain?: string | null): boolean {
  if (!adminKeyPlain) return false
  try {
    const provided = Buffer.from(String(adminKeyPlain))
    for (const k of getMasterKeys()) {
      const expected = Buffer.from(k)
      if (provided.length === expected.length && crypto.timingSafeEqual(provided, expected)) {
        return true
      }
      // For unequal lengths, fall back to string compare to avoid throwing
      if (String(adminKeyPlain) === k) return true
    }
    return false
  } catch { return false }
}

export async function getUserEncryptionKey(userId: string): Promise<{ enabled: boolean; key: string | null }>
{
  await connectMongoDB()
  const settings: any = await (Settings as any).findOne({ userId })
  if (!settings) return { enabled: false, key: null }
  const enabled = !!(settings.encryptionEnabled || settings.encryption?.enabled)
  const encrypted = settings.userEncryptionKey || settings.encryption?.userKeyEncrypted || null
  const key = decryptUserKey(encrypted)
  return { enabled, key }
}

export function encryptFields<T extends Record<string, any>>(doc: T, fields: string[], key: string | null): T {
  if (!key) return doc
  const result: any = { ...doc }
  for (const f of fields) {
    if (result[f] && !isEncrypted(result[f])) {
      result[f] = encryptStringWithKey(String(result[f]), key)
    }
  }
  return result
}

export function decryptFields<T extends Record<string, any>>(doc: T, fields: string[], key: string | null): T {
  if (!key) return doc
  const result: any = { ...doc }
  for (const f of fields) {
    if (result[f] && isEncrypted(result[f])) {
      try { result[f] = decryptStringWithKey(String(result[f]), key) } catch {}
    }
  }
  return result
}


