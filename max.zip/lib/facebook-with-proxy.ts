import { getActiveProxy, createProxyHeaders } from './proxy';

export async function makeFacebookRequestWithProxy(url: string, options: RequestInit = {}) {
  try {
    // Get active proxy
    const proxy = await getActiveProxy();
    
    if (!proxy) {
      console.log('No proxy available, making direct request');
      return fetch(url, options);
    }
    
    // Parse proxy
    const [proxyHost, proxyPort] = proxy.split(':');
    
    // Create proxy headers
    const proxyHeaders = createProxyHeaders({
      refreshAt: new Date(),
      nextChange: 0,
      acceptIp: '',
      isResidential: false
    } as any);
    
    // Add proxy headers to request
    const requestOptions: RequestInit = {
      ...options,
      headers: {
        ...options.headers,
        ...proxyHeaders,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    };
    
    console.log(`Making Facebook request with proxy: ${proxy}`);
    return fetch(url, requestOptions);
    
  } catch (error) {
    console.error('Error making Facebook request with proxy:', error);
    // Fallback to direct request
    return fetch(url, options);
  }
}

export async function getFacebookUserInfoWithProxy(userId: string, accessToken: string) {
  const url = `https://graph.facebook.com/v18.0/${userId}?fields=id,name,email&access_token=${accessToken}`;
  
  return makeFacebookRequestWithProxy(url);
}

export async function postToFacebookWithProxy(pageId: string, message: string, accessToken: string) {
  const url = `https://graph.facebook.com/v18.0/${pageId}/feed`;
  
  const formData = new FormData();
  formData.append('message', message);
  formData.append('access_token', accessToken);
  
  return makeFacebookRequestWithProxy(url, {
    method: 'POST',
    body: formData
  });
}

export async function uploadImageToFacebookWithProxy(pageId: string, imageUrl: string, caption: string, accessToken: string) {
  const url = `https://graph.facebook.com/v18.0/${pageId}/photos`;
  
  const formData = new FormData();
  formData.append('url', imageUrl);
  formData.append('caption', caption);
  formData.append('access_token', accessToken);
  
  return makeFacebookRequestWithProxy(url, {
    method: 'POST',
    body: formData
  });
} 