// JWT library tương thích với Edge Runtime
// Sử dụng Web Crypto API thay vì Node.js crypto

/**
 * Lấy JWT secret key
 */
export function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    console.warn('Biến môi trường JWT_SECRET chưa được thiết lập, sử dụng key mặc định.');
    return 'your-super-secret-jwt-key-change-this-in-production';
  }
  return secret;
}

/**
 * Decode JWT token (không verify signature)
 * @param token JWT token string
 * @returns decoded payload hoặc null
 */
export function decodeJWT(token: string): any {
  try {
    if (!token) return null;
    
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    
    const payload = parts[1];
    const decoded = JSON.parse(atob(payload));
    return decoded;
  } catch (error) {
    console.error('JWT decode error:', error);
    return null;
  }
}

/**
 * Kiểm tra JWT token có hợp lệ không (chỉ decode, không verify signature)
 * @param token JWT token string
 * @returns { isValid: boolean, decoded?: any, error?: string }
 */
export function checkTokenValidityEdge(token: string): { isValid: boolean; decoded?: any; error?: string } {
  try {
    if (!token || token === 'null' || token === 'undefined' || token.trim() === '') {
      return { isValid: false, error: 'NO_TOKEN' };
    }

    const decoded = decodeJWT(token);
    if (!decoded) {
      return { isValid: false, error: 'TOKEN_MALFORMED' };
    }

    // Kiểm tra expiration
    const currentTime = Math.floor(Date.now() / 1000);
    if (decoded.exp && decoded.exp < currentTime) {
      return { isValid: false, error: 'TOKEN_EXPIRED' };
    }

    // Kiểm tra not before
    if (decoded.nbf && decoded.nbf > currentTime) {
      return { isValid: false, error: 'TOKEN_NOT_ACTIVE' };
    }

    return { isValid: true, decoded };
  } catch (error) {
    console.error('Token validation error:', error);
    return { isValid: false, error: 'TOKEN_INVALID' };
  }
}

/**
 * Kiểm tra token có sắp hết hạn không
 * @param token JWT token string
 * @returns boolean
 */
export function isTokenExpiringSoonEdge(token: string): boolean {
  try {
    const decoded = decodeJWT(token);
    if (!decoded || !decoded.exp) return false;
    
    const currentTime = Math.floor(Date.now() / 1000);
    const timeUntilExpiry = decoded.exp - currentTime;
    
    // Nếu token hết hạn trong vòng 1 giờ, coi như sắp hết hạn
    return timeUntilExpiry <= 3600;
  } catch (error) {
    return false;
  }
}

/**
 * Debug function để kiểm tra JWT token
 * @param token JWT token string
 * @returns thông tin debug về token
 */
export function debugJWTTokenEdge(token: string): {
  hasToken: boolean;
  tokenLength: number;
  tokenPrefix: string;
  canDecode: boolean;
  decodedInfo?: any;
  error?: string;
} {
  try {
    if (!token || token === 'null' || token === 'undefined' || token.trim() === '') {
      return {
        hasToken: false,
        tokenLength: 0,
        tokenPrefix: 'null',
        canDecode: false,
        error: 'NO_TOKEN'
      };
    }

    const tokenLength = token.length;
    const tokenPrefix = token.substring(0, 20) + '...';
    
    // Thử decode token
    const decoded = decodeJWT(token);
    const canDecode = !!decoded;
    
    if (canDecode && decoded) {
      const currentTime = Math.floor(Date.now() / 1000);
      const timeUntilExpiry = decoded.exp ? decoded.exp - currentTime : null;
      
      return {
        hasToken: true,
        tokenLength,
        tokenPrefix,
        canDecode,
        decodedInfo: {
          exp: decoded.exp,
          iat: decoded.iat,
          userId: decoded.userId,
          id: decoded.id,
          _id: decoded._id,
          timeUntilExpiry,
          isExpired: timeUntilExpiry !== null ? timeUntilExpiry <= 0 : null,
          expiresIn: timeUntilExpiry !== null ? Math.floor(timeUntilExpiry / 3600) : null
        }
      };
    }
    
    return {
      hasToken: true,
      tokenLength,
      tokenPrefix,
      canDecode: false,
      error: 'CANNOT_DECODE'
    };
    
  } catch (error) {
    return {
      hasToken: !!token,
      tokenLength: token ? token.length : 0,
      tokenPrefix: token ? token.substring(0, 20) + '...' : 'null',
      canDecode: false,
      error: error instanceof Error ? error.message : 'UNKNOWN_ERROR'
    };
  }
}
