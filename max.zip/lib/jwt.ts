import jwt from 'jsonwebtoken';

/**
 * Lấy JWT secret key
 * Ưu tiên sử dụng biến môi trường, nếu không có thì sử dụng key mặc định
 */
export function getJwtSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    console.warn('Biến môi trường JWT_SECRET chưa được thiết lập, sử dụng key mặc định. Trong môi trường production, hãy thiết lập JWT_SECRET an toàn.');
    return 'your-super-secret-jwt-key-change-this-in-production';
  }
  return secret;
}

/**
 * Kiểm tra JWT token có sắp hết hạn không (trong vòng 1 giờ)
 * @param token JWT token string
 * @returns boolean
 */
export function isTokenExpiringSoon(token: string): boolean {
  try {
    const secret = getJwtSecret();
    const decoded: any = jwt.decode(token);
    if (!decoded || !decoded.exp) return false;
    
    const currentTime = Math.floor(Date.now() / 1000);
    const timeUntilExpiry = decoded.exp - currentTime;
    
    // Nếu token hết hạn trong vòng 1 giờ, coi như sắp hết hạn
    return timeUntilExpiry <= 3600;
  } catch (error) {
    return false;
  }
}

/**
 * Xác thực JWT token
 * @param token JWT token string
 * @returns Payload đã được decode
 * @throws JWTError với các loại lỗi cụ thể
 */
export function verifyToken(token: string): any {
  try {
    const secret = getJwtSecret();
    return jwt.verify(token, secret);
  } catch (error) {
    // Log chi tiết lỗi để debug
    console.error('JWT verification error details:', {
      errorType: error.constructor.name,
      errorMessage: error.message,
      errorStack: error.stack,
      tokenLength: token ? token.length : 0,
      tokenPrefix: token ? token.substring(0, 20) + '...' : 'null'
    });

    if (error instanceof jwt.JsonWebTokenError) {
      console.error('JWT xác thực thất bại:', error.message);
      throw new JWTError('TOKEN_INVALID', `Token xác thực thất bại: ${error.message}`);
    }
    if (error instanceof jwt.TokenExpiredError) {
      console.error('JWT token đã hết hạn');
      throw new JWTError('TOKEN_EXPIRED', 'Token đã hết hạn, vui lòng đăng nhập lại');
    }
    if (error instanceof jwt.NotBeforeError) {
      console.error('JWT token chưa có hiệu lực');
      throw new JWTError('TOKEN_NOT_ACTIVE', 'Token chưa có hiệu lực');
    }
    
    // Xử lý các lỗi khác dựa trên message
    if (error instanceof Error) {
      const errorMessage = error.message.toLowerCase();
      
      if (errorMessage.includes('malformed') || errorMessage.includes('invalid token')) {
        console.error('JWT token có định dạng không đúng');
        throw new JWTError('TOKEN_MALFORMED', 'Token có định dạng không đúng');
      }
      
      if (errorMessage.includes('invalid signature')) {
        console.error('JWT token có chữ ký không hợp lệ');
        throw new JWTError('TOKEN_INVALID_SIGNATURE', 'Token có chữ ký không hợp lệ');
      }
      
      if (errorMessage.includes('jwt expired')) {
        console.error('JWT token đã hết hạn');
        throw new JWTError('TOKEN_EXPIRED', 'Token đã hết hạn, vui lòng đăng nhập lại');
      }
      
      if (errorMessage.includes('jwt not active')) {
        console.error('JWT token chưa có hiệu lực');
        throw new JWTError('TOKEN_NOT_ACTIVE', 'Token chưa có hiệu lực');
      }
      
      console.error('JWT xác thực lỗi không xác định:', error.message);
      throw new JWTError('TOKEN_INVALID', `Lỗi xác thực: ${error.message}`);
    }
    
    // Fallback cho các lỗi không xác định
    console.error('JWT xác thực lỗi không xác định:', error);
    throw new JWTError('TOKEN_INVALID', 'Lỗi không xác định trong quá trình xác thực token');
  }
}

/**
 * Tạo JWT token
 * @param payload token payload
 * @param expiresIn thời gian hết hạn, mặc định 7 ngày
 * @returns JWT token string
 */
export function generateToken(payload: any, expiresIn: string = '7d'): string {
  try {
    const secret = getJwtSecret();
    return jwt.sign(payload, secret, { expiresIn } as jwt.SignOptions);
  } catch (error) {
    console.error('JWT token tạo thất bại:', error);
    throw new Error('Tạo token thất bại');
  }
}

/**
 * Làm mới JWT token (nếu sắp hết hạn)
 * @param token JWT token string
 * @returns token mới hoặc token cũ nếu chưa cần làm mới
 */
export function refreshTokenIfNeeded(token: string): string {
  try {
    if (isTokenExpiringSoon(token)) {
      const decoded: any = jwt.decode(token);
      if (decoded) {
        // Tạo token mới với thông tin từ token cũ
        const { iat, exp, ...payload } = decoded;
        return generateToken(payload);
      }
    }
    return token;
  } catch (error) {
    console.error('Làm mới token thất bại:', error);
    return token;
  }
}

/**
 * Trích xuất token từ request
 * @param request NextRequest object
 * @returns token string hoặc null
 */
export function extractTokenFromRequest(request: any): string | null {
  // Lấy từ Authorization header
  const authHeader = request.headers.get('authorization');
  let token = authHeader?.startsWith('Bearer ') ? authHeader.substring(7) : '';
  
  // Nếu không có trong header, lấy từ cookie
  if (!token || token === 'null' || token === 'undefined') {
    token = request.cookies.get('token')?.value || '';
  }
  
  return token || null;
}

/**
 * Custom JWT Error class với error type cụ thể
 */
export class JWTError extends Error {
  public type: string;
  
  constructor(type: string, message: string) {
    super(message);
    this.name = 'JWTError';
    this.type = type;
  }
}

/**
 * Kiểm tra token có hợp lệ không (không throw error)
 * @param token JWT token string
 * @returns { isValid: boolean, decoded?: any, error?: string }
 */
export function checkTokenValidity(token: string): { isValid: boolean; decoded?: any; error?: string } {
  try {
    if (!token || token === 'null' || token === 'undefined' || token.trim() === '') {
      return { isValid: false, error: 'NO_TOKEN' };
    }

    const decoded = verifyToken(token);
    return { isValid: true, decoded };
  } catch (error) {
    if (error instanceof JWTError) {
      return { isValid: false, error: error.type };
    }
    
    // Xử lý các lỗi khác
    if (error instanceof Error) {
      const errorMessage = error.message.toLowerCase();
      
      if (errorMessage.includes('jwt expired')) {
        return { isValid: false, error: 'TOKEN_EXPIRED' };
      }
      
      if (errorMessage.includes('invalid signature')) {
        return { isValid: false, error: 'TOKEN_INVALID_SIGNATURE' };
      }
      
      if (errorMessage.includes('malformed') || errorMessage.includes('invalid token')) {
        return { isValid: false, error: 'TOKEN_MALFORMED' };
      }
      
      if (errorMessage.includes('jwt not active')) {
        return { isValid: false, error: 'TOKEN_NOT_ACTIVE' };
      }
      
      // Fallback cho các lỗi khác
      return { isValid: false, error: 'TOKEN_INVALID' };
    }
    
    // Fallback cuối cùng
    return { isValid: false, error: 'TOKEN_INVALID' };
  }
}

/**
 * Debug function để kiểm tra JWT token
 * @param token JWT token string
 * @returns thông tin debug về token
 */
export function debugJWTToken(token: string): {
  hasToken: boolean;
  tokenLength: number;
  tokenPrefix: string;
  canDecode: boolean;
  decodedInfo?: any;
  error?: string;
} {
  try {
    if (!token || token === 'null' || token === 'undefined' || token.trim() === '') {
      return {
        hasToken: false,
        tokenLength: 0,
        tokenPrefix: 'null',
        canDecode: false,
        error: 'NO_TOKEN'
      };
    }

    const tokenLength = token.length;
    const tokenPrefix = token.substring(0, 20) + '...';
    
    // Thử decode token (không verify)
    const decoded = jwt.decode(token);
    const canDecode = !!decoded;
    
    if (canDecode && decoded) {
      const currentTime = Math.floor(Date.now() / 1000);
      const timeUntilExpiry = (decoded as any).exp ? (decoded as any).exp - currentTime : null;
      
      return {
        hasToken: true,
        tokenLength,
        tokenPrefix,
        canDecode,
        decodedInfo: {
          exp: (decoded as any).exp,
          iat: (decoded as any).iat,
          userId: (decoded as any).userId,
          id: (decoded as any).id,
          _id: (decoded as any)._id,
          timeUntilExpiry,
          isExpired: timeUntilExpiry !== null ? timeUntilExpiry <= 0 : null,
          expiresIn: timeUntilExpiry !== null ? Math.floor(timeUntilExpiry / 3600) : null
        }
      };
    }
    
    return {
      hasToken: true,
      tokenLength,
      tokenPrefix,
      canDecode: false,
      error: 'CANNOT_DECODE'
    };
    
  } catch (error) {
    return {
      hasToken: !!token,
      tokenLength: token ? token.length : 0,
      tokenPrefix: token ? token.substring(0, 20) + '...' : 'null',
      canDecode: false,
      error: error instanceof Error ? error.message : 'UNKNOWN_ERROR'
    };
  }
}

// ==================== CLIENT-SIDE FUNCTIONS ====================

/**
 * Client-side: Kiểm tra token trong localStorage/sessionStorage
 * @returns { token: string | null, isValid: boolean, needsRefresh: boolean }
 */
export function checkClientToken(): { token: string | null; isValid: boolean; needsRefresh: boolean } {
  try {
    // Kiểm tra token trong localStorage trước
    let token = localStorage.getItem('token') || sessionStorage.getItem('token');
    
    if (!token) {
      return { token: null, isValid: false, needsRefresh: false };
    }
    
    // Decode token để kiểm tra expiration
    const decoded: any = jwt.decode(token);
    if (!decoded || !decoded.exp) {
      return { token: null, isValid: false, needsRefresh: false };
    }
    
    const currentTime = Math.floor(Date.now() / 1000);
    const timeUntilExpiry = decoded.exp - currentTime;
    
    // Token đã hết hạn
    if (timeUntilExpiry <= 0) {
      // Xóa token hết hạn
      localStorage.removeItem('token');
      sessionStorage.removeItem('token');
      return { token: null, isValid: false, needsRefresh: false };
    }
    
    // Token sắp hết hạn (trong vòng 1 giờ)
    const needsRefresh = timeUntilExpiry <= 3600;
    
    return { 
      token, 
      isValid: true, 
      needsRefresh 
    };
  } catch (error) {
    console.error('Lỗi kiểm tra client token:', error);
    return { token: null, isValid: false, needsRefresh: false };
  }
}

/**
 * Client-side: Xử lý JWT errors và redirect nếu cần
 * @param error API error response
 * @param currentPath đường dẫn trang hiện tại
 */
export function handleJWTError(error: any, currentPath: string = '/') {
  if (error?.code === 'TOKEN_EXPIRED' || error?.code === 'TOKEN_INVALID') {
    // Xóa token hết hạn
    localStorage.removeItem('token');
    sessionStorage.removeItem('token');
    
    // Redirect về trang login với thông báo
    const loginUrl = `/auth?redirect=${encodeURIComponent(currentPath)}&error=${error.code}`;
    window.location.href = loginUrl;
    return true; // Đã xử lý error
  }
  
  if (error?.code === 'NO_TOKEN') {
    // Không có token, redirect về login
    const loginUrl = `/auth?redirect=${encodeURIComponent(currentPath)}`;
    window.location.href = loginUrl;
    return true; // Đã xử lý error
  }
  
  return false; // Chưa xử lý error
}

/**
 * Client-side: Tự động làm mới token nếu cần
 * @returns Promise<boolean> - true nếu làm mới thành công
 */
export async function autoRefreshToken(): Promise<boolean> {
  try {
    const tokenCheck = checkClientToken();
    
    if (!tokenCheck.isValid || !tokenCheck.token) {
      return false;
    }
    
    if (tokenCheck.needsRefresh) {
      // Gọi API để làm mới token
      const response = await fetch('/api/auth/refresh', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${tokenCheck.token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.token) {
          // Cập nhật token mới
          localStorage.setItem('token', data.token);
          sessionStorage.setItem('token', data.token);
          return true;
        }
      }
    }
    
    return true; // Token không cần làm mới
  } catch (error) {
    console.error('Tự động làm mới token thất bại:', error);
    return false;
  }
}

/**
 * Client-side: Tạo interceptor cho fetch requests
 * @param originalFetch fetch function gốc
 * @returns fetch function với JWT handling
 */
export function createJWTInterceptor(originalFetch: typeof fetch): typeof fetch {
  return async (input: RequestInfo | URL, init?: RequestInit) => {
    try {
      // Kiểm tra và làm mới token nếu cần
      await autoRefreshToken();
      
      // Thực hiện request
      const response = await originalFetch(input, init);
      
      // Kiểm tra response status
      if (response.status === 401) {
        const errorData = await response.json().catch(() => ({}));
        
        // Xử lý JWT errors
        if (handleJWTError(errorData, window.location.pathname)) {
          // Error đã được xử lý (redirect), không cần làm gì thêm
          return response;
        }
      }
      
      return response;
    } catch (error) {
      console.error('Lỗi JWT interceptor:', error);
      throw error;
    }
  };
}
