import { EventEmitter } from 'events'

type LogEvent = {
  userId: string
  message: string
  timestamp: number
  accountId?: string
}

class LogBus extends EventEmitter {}

export const logBus = new LogBus()

export function emitLog(userId: string, message: string, accountId?: string) {
  const evt: LogEvent = { userId, message, timestamp: Date.now(), accountId }
  logBus.emit('log', evt)
}

export type { LogEvent }


