import nodemailer from 'nodemailer'

export function createGmailTransport() {
  const user = process.env.GMAIL_SMTP_USER
  const pass = process.env.GMAIL_SMTP_PASS
  if (!user || !pass) {
    throw new Error('Missing GMAIL_SMTP_USER or GMAIL_SMTP_PASS')
  }
  return nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: { user, pass }
  })
}

export async function sendPasswordResetEmail(to: string, resetUrl: string) {
  const transporter = createGmailTransport()
  const from = process.env.GMAIL_FROM || process.env.GMAIL_SMTP_USER as string
  const brand = 'Ftool.vn'
  const html = `
  <!DOCTYPE html>
  <html lang="vi">
    <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Đặt lại mật khẩu</title>
    </head>
    <body style="margin:0;padding:0;background:#f4f6fb;font-family:Inter,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#0f172a;">
      <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="background:#f4f6fb;padding:24px 0;">
        <tr>
          <td align="center">
            <table role="presentation" cellpadding="0" cellspacing="0" width="640" style="max-width:640px;background:#ffffff;border-radius:16px;box-shadow:0 10px 30px rgba(2,6,23,0.08);overflow:hidden;">
              <tr>
                <td style="padding:28px 32px;background:linear-gradient(90deg,#2563eb,#7c3aed);color:#fff;">
                  <div style="font-size:18px;font-weight:700;letter-spacing:0.2px;">${brand}</div>
                  <div style="opacity:.9;font-size:12px;margin-top:2px;">ALL IN ONE</div>
                </td>
              </tr>
              <tr>
                <td style="padding:28px 32px;">
                  <h1 style="margin:0 0 12px 0;font-size:22px;color:#0f172a;">Đặt lại mật khẩu</h1>
                  <p style="margin:0 0 16px 0;line-height:1.6;color:#334155;">Chúng tôi nhận được yêu cầu đặt lại mật khẩu cho tài khoản của bạn. Liên kết dưới đây sẽ hết hạn sau <strong>15 phút</strong>.</p>
                  <div style="margin:24px 0;">
                    <a href="${resetUrl}" style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;padding:12px 18px;border-radius:10px;font-weight:600">Đặt lại mật khẩu</a>
                  </div>
                  <p style="margin:0 0 6px 0;line-height:1.6;color:#334155;">Nếu nút không bấm được, hãy sao chép liên kết bên dưới và dán vào trình duyệt:</p>
                  <a href="${resetUrl}" style="word-break:break-all;color:#2563eb;text-decoration:underline;">${resetUrl}</a>
                  <div style="height:20px"></div>
                  <p style="margin:0;color:#64748b;font-size:12px;">Nếu bạn không yêu cầu, hãy bỏ qua email này.</p>
                </td>
              </tr>
              <tr>
                <td style="padding:16px 32px;background:#f8fafc;color:#64748b;font-size:12px;text-align:center;">
                  © ${new Date().getFullYear()} ${brand}. Mọi quyền được bảo lưu.
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
  </html>`
  await transporter.sendMail({
    from,
    to,
    subject: 'Đặt lại mật khẩu - Ftool.vn',
    html,
    text: `Chúng tôi nhận được yêu cầu đặt lại mật khẩu cho tài khoản của bạn.\nTruy cập liên kết trong 15 phút: ${resetUrl}\nNếu không phải bạn yêu cầu, hãy bỏ qua email này.`
  })
}

export async function sendEmailVerification(to: string, verifyUrl: string) {
  const transporter = createGmailTransport()
  const from = process.env.GMAIL_FROM || process.env.GMAIL_SMTP_USER as string
  const brand = 'Ftool.vn'
  const html = `
  <!DOCTYPE html>
  <html lang="vi">
    <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Xác thực tài khoản</title>
    </head>
    <body style="margin:0;padding:0;background:#f4f6fb;font-family:Inter,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#0f172a;">
      <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="background:#f4f6fb;padding:24px 0;">
        <tr><td align="center">
          <table role="presentation" cellpadding="0" cellspacing="0" width="640" style="max-width:640px;background:#ffffff;border-radius:16px;box-shadow:0 10px 30px rgba(2,6,23,0.08);overflow:hidden;">
            <tr>
              <td style="padding:28px 32px;background:linear-gradient(90deg,#2563eb,#7c3aed);color:#fff;">
                <div style="font-size:18px;font-weight:700;">${brand}</div>
                <div style="opacity:.9;font-size:12px;margin-top:2px;">ALL IN ONE</div>
              </td>
            </tr>
            <tr>
              <td style="padding:28px 32px;">
                <h1 style="margin:0 0 12px 0;font-size:22px;color:#0f172a;">Xác thực tài khoản</h1>
                <p style="margin:0 0 16px 0;line-height:1.6;color:#334155;">Cảm ơn bạn đã đăng ký. Nhấn vào nút dưới đây để xác thực tài khoản của bạn trong <strong>30 phút</strong>.</p>
                <div style="margin:24px 0;">
                  <a href="${verifyUrl}" style="display:inline-block;background:#16a34a;color:#fff;text-decoration:none;padding:12px 18px;border-radius:10px;font-weight:600">Xác thực tài khoản</a>
                </div>
                <p style="margin:0 0 6px 0;line-height:1.6;color:#334155;">Nếu nút không bấm được, hãy sao chép liên kết bên dưới:</p>
                <a href="${verifyUrl}" style="word-break:break-all;color:#2563eb;text-decoration:underline;">${verifyUrl}</a>
              </td>
            </tr>
            <tr>
              <td style="padding:16px 32px;background:#f8fafc;color:#64748b;font-size:12px;text-align:center;">© ${new Date().getFullYear()} ${brand}. Mọi quyền được bảo lưu.</td>
            </tr>
          </table>
        </td></tr>
      </table>
    </body>
  </html>`
  await transporter.sendMail({ from, to, subject: 'Xác thực tài khoản - Ftool.vn', html, text: `Vui lòng xác thực tài khoản: ${verifyUrl}` })
}


