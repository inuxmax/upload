// Outlook Logs - Database-backed logging system for real-time status updates
// This file provides a persistent interface for publishing logs that can be consumed by the frontend

import dbConnect from './mongodb';

export interface LogEntry {
  accountId?: string;
  level: 'debug' | 'info' | 'warn' | 'error';
  status: 'reading' | 'success' | 'error' | 'completed' | 'waiting' | 'running';
  message: string;
  emailCount?: number;
  timestamp?: Date;
  details?: any;
}

// MongoDB Schema for logs
interface LogDocument {
  accountId?: string;
  level: string;
  status: string;
  message: string;
  emailCount?: number;
  timestamp: Date;
  details?: any;
  createdAt: Date;
}

/**
 * Publish a log entry for real-time status updates
 * @param logEntry - The log entry to publish
 */
export async function publish(logEntry: LogEntry): Promise<void> {
  try {
    const entry: LogEntry = {
      ...logEntry,
      timestamp: new Date()
    };

    // Reduced console logging to prevent spam - only log errors
    if (entry.level === 'error') {
      const timestamp = entry.timestamp.toISOString();
      const accountInfo = entry.accountId ? `[${entry.accountId}]` : '[SYSTEM]';
      console.error(`❌ [${timestamp}] ERROR ${accountInfo} ${entry.status}: ${entry.message}`);
    }

    // Save to database
    try {
      await saveLogToDatabase(entry);
    } catch (dbError) {
      console.warn('Failed to save log to database:', dbError);
      // Continue with console logging even if DB fails
    }

  } catch (error) {
    // Silently fail if logging fails - don't break the main functionality
    console.warn('Failed to publish log entry:', error);
  }
}

/**
 * Save log entry to MongoDB
 */
async function saveLogToDatabase(logEntry: LogEntry): Promise<void> {
  try {
    await dbConnect();
    
    // Dynamic import to avoid circular dependencies
    const mongoose = await import('mongoose');
    
    // Create or get the logs collection
    const logsCollection = mongoose.connection.collection('outlook_logs');
    
    const logDoc: LogDocument = {
      accountId: logEntry.accountId,
      level: logEntry.level,
      status: logEntry.status,
      message: logEntry.message,
      emailCount: logEntry.emailCount,
      timestamp: logEntry.timestamp || new Date(),
      details: logEntry.details,
      createdAt: new Date()
    };

    await logsCollection.insertOne(logDoc);
    
    // Keep only last 100 logs per account to prevent database bloat
    if (logEntry.accountId) {
      const accountLogs = await logsCollection
        .find({ accountId: logEntry.accountId })
        .sort({ timestamp: -1 })
        .limit(100)
        .toArray();
      
      if (accountLogs.length > 100) {
        const logsToDelete = accountLogs.slice(100);
        const idsToDelete = logsToDelete.map(log => log._id);
        await logsCollection.deleteMany({ _id: { $in: idsToDelete } });
      }
    }

  } catch (error) {
    // Reduced logging to prevent console spam
    throw error;
  }
}

/**
 * Get logs for a specific account from database
 * @param accountId - The account ID to get logs for
 * @param limit - Maximum number of logs to return (default: 50)
 * @returns Array of log entries
 */
export async function getLogs(accountId: string, limit: number = 50): Promise<LogEntry[]> {
  try {
    await dbConnect();
    
    const mongoose = await import('mongoose');
    const logsCollection = mongoose.connection.collection('outlook_logs');
    
    const logs = await logsCollection
      .find({ accountId })
      .sort({ timestamp: -1 })
      .limit(limit)
      .toArray();
    
    return logs.map(log => ({
      accountId: log.accountId,
      level: log.level as any,
      status: log.status as any,
      message: log.message,
      emailCount: log.emailCount,
      timestamp: log.timestamp,
      details: log.details
    }));
    
  } catch (error) {
    // Reduced logging to prevent console spam
    return [];
  }
}

/**
 * Clear logs for a specific account from database
 * @param accountId - The account ID to clear logs for
 */
export async function clearLogs(accountId: string): Promise<void> {
  try {
    await dbConnect();
    
    const mongoose = await import('mongoose');
    const logsCollection = mongoose.connection.collection('outlook_logs');
    
    await logsCollection.deleteMany({ accountId });
    
  } catch (error) {
    // Reduced logging to prevent console spam
    throw error;
  }
}

/**
 * Clear all logs from database
 */
export async function clearAllLogs(): Promise<void> {
  try {
    await dbConnect();
    
    const mongoose = await import('mongoose');
    const logsCollection = mongoose.connection.collection('outlook_logs');
    
    await logsCollection.deleteMany({});
    
  } catch (error) {
    // Reduced logging to prevent console spam
    throw error;
  }
}

/**
 * Get all logs from database (for admin purposes)
 * @param limit - Maximum number of logs per account (default: 20)
 * @returns Map of account ID to log entries
 */
export async function getAllLogs(limit: number = 20): Promise<Map<string, LogEntry[]>> {
  try {
    await dbConnect();
    
    const mongoose = await import('mongoose');
    const logsCollection = mongoose.connection.collection('outlook_logs');
    
    // Get all unique account IDs
    const accountIds = await logsCollection.distinct('accountId');
    
    const allLogs = new Map<string, LogEntry[]>();
    
    for (const accountId of accountIds) {
      if (accountId) {
        const logs = await getLogs(accountId, limit);
        allLogs.set(accountId, logs);
      }
    }
    
    return allLogs;
    
  } catch (error) {
    // Reduced logging to prevent console spam
    return new Map();
  }
}

/**
 * Get log statistics from database
 * @returns Object with log counts and other statistics
 */
export async function getLogStats(): Promise<{
  totalAccounts: number;
  totalLogs: number;
  logsByLevel: Record<string, number>;
  logsByStatus: Record<string, number>;
}> {
  try {
    await dbConnect();
    
    const mongoose = await import('mongoose');
    const logsCollection = mongoose.connection.collection('outlook_logs');
    
    const stats = {
      totalAccounts: 0,
      totalLogs: 0,
      logsByLevel: {} as Record<string, number>,
      logsByStatus: {} as Record<string, number>
    };

    // Get total logs count
    stats.totalLogs = await logsCollection.countDocuments();
    
    // Get unique account count
    stats.totalAccounts = await logsCollection.distinct('accountId').then(ids => 
      ids.filter(id => id !== null && id !== undefined).length
    );
    
    // Get counts by level
    const levelAggregation = await logsCollection.aggregate([
      { $group: { _id: '$level', count: { $sum: 1 } } }
    ]).toArray();
    
    levelAggregation.forEach(({ _id, count }) => {
      stats.logsByLevel[_id] = count;
    });
    
    // Get counts by status
    const statusAggregation = await logsCollection.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]).toArray();
    
    statusAggregation.forEach(({ _id, count }) => {
      stats.logsByStatus[_id] = count;
    });

    return stats;
    
  } catch (error) {
    // Reduced logging to prevent console spam
    return {
      totalAccounts: 0,
      totalLogs: 0,
      logsByLevel: {},
      logsByStatus: {}
    };
  }
}

// Export default for backward compatibility
export default {
  publish,
  getLogs,
  clearLogs,
  clearAllLogs,
  getAllLogs,
  getLogStats
};
