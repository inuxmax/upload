import cron from 'node-cron';
import connectMongoDB from '@/lib/mongodb';
import ProxySettings from '@/models/ProxySettings';

// Hàm lấy IP proxy mới từ NetProxy.io
async function fetchNewProxyIP(apiKey: string) {
  try {
    const response = await fetch(`https://api.netproxy.io/api/rotateProxy/getNewProxy?type=all&apiKey=${apiKey}&country=Vietnam`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.success && data.data && data.data.proxy) {
      console.log(`✅ Successfully fetched new proxy IP: ${data.data.proxy}`);
      console.log(`📊 Proxy details:`, {
        proxy: data.data.proxy,
        username: data.data.username,
        refreshAt: data.data.refreshAt,
        nextChange: data.data.nextChange,
        acceptIp: data.data.acceptIp,
        isResidential: data.data.isResidential
      });
      return data.data.proxy; // Trả về IP proxy mới
    } else {
      console.error('❌ Invalid response format from NetProxy API:', data);
      return null;
    }
  } catch (error) {
    console.error('❌ Error fetching new proxy IP:', error);
    return null;
  }
}

// Hàm cập nhật IP proxy cho tất cả proxy settings
async function updateAllProxyIPs() {
  try {
    await connectMongoDB();
    
    // Lấy tất cả proxy settings đang active
    const activeProxies = await (ProxySettings as any).find({ isActive: true });
    
    console.log(`🔄 Updating IPs for ${activeProxies.length} active proxies...`);
    
    for (const proxy of activeProxies) {
      try {
        console.log(`🔄 Fetching new IP for proxy: ${proxy.name} (${proxy.apiKey.substring(0, 8)}...)`);
        
        // Lấy IP proxy mới
        const newProxyIP = await fetchNewProxyIP(proxy.apiKey);
        
        if (newProxyIP) {
          // Cập nhật IP mới và thời gian cập nhật
          await (ProxySettings as any).findByIdAndUpdate(proxy._id, {
            $set: {
              currentProxy: newProxyIP,
              refreshAt: new Date(),
              nextChange: Date.now() + (2 * 60 * 1000) // 2 phút nữa
            }
          });
          
          console.log(`✅ Updated ${proxy.name}: ${newProxyIP}`);
        } else {
          console.log(`❌ Failed to get new IP for ${proxy.name}`);
        }
      } catch (error) {
        console.error(`❌ Error updating ${proxy.name}:`, error);
      }
    }
    
    console.log('✅ All proxy IPs updated successfully');
  } catch (error) {
    console.error('❌ Error in updateAllProxyIPs:', error);
  }
}

// Khởi tạo cron job
export function initProxyCronJob() {
  console.log('🚀 Initializing proxy cron job...');
  
  // Chạy mỗi 2 phút
  cron.schedule('*/2 * * * *', async () => {
    console.log('⏰ Running proxy IP update cron job...');
    await updateAllProxyIPs();
  }, {
    timezone: "Asia/Ho_Chi_Minh"
  });
  
  console.log('✅ Proxy cron job initialized - running every 2 minutes');
}

// Hàm để chạy ngay lập tức (không cần đợi cron)
export async function runProxyUpdateNow() {
  console.log('🔄 Running proxy update immediately...');
  try {
    await updateAllProxyIPs();
    console.log('✅ Proxy update completed');
  } catch (error) {
    console.error('❌ Error in runProxyUpdateNow:', error);
    throw error;
  }
} 