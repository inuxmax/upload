import connectMongoDB from './mongodb';
import ProxySettings from '@/models/ProxySettings';

export interface ProxyConfig {
  id: string;
  name: string;
  apiKey: string;
  isActive: boolean;
  currentProxy?: string;
  refreshAt?: Date;
  nextChange?: number;
  acceptIp?: string;
  isResidential?: boolean;
}

// Lấy tất cả proxy settings đang hoạt động
export async function getActiveProxyConfigs(): Promise<ProxyConfig[]> {
  try {
    await connectMongoDB();
    const proxySettings = await (ProxySettings as any).find({ isActive: true });
    
    return proxySettings.map(setting => ({
      id: setting._id.toString(),
      name: setting.name,
      apiKey: setting.apiKey,
      isActive: setting.isActive,
      currentProxy: setting.currentProxy,
      refreshAt: setting.refreshAt,
      nextChange: setting.nextChange,
      acceptIp: setting.acceptIp,
      isResidential: setting.isResidential
    }));
  } catch (error) {
    console.error('Error getting active proxy configs:', error);
    return [];
  }
}

// Lấy proxy setting ngẫu nhiên từ danh sách đang hoạt động
export async function getRandomProxyConfig(): Promise<ProxyConfig | null> {
  try {
    const activeConfigs = await getActiveProxyConfigs();
    
    if (activeConfigs.length === 0) {
      return null;
    }

    // Chọn ngẫu nhiên một proxy setting
    const randomIndex = Math.floor(Math.random() * activeConfigs.length);
    return activeConfigs[randomIndex];
  } catch (error) {
    console.error('Error getting random proxy config:', error);
    return null;
  }
}

// Làm mới proxy cho một proxy setting cụ thể
export async function refreshProxy(proxyConfig: ProxyConfig): Promise<ProxyConfig | null> {
  try {
    const response = await fetch('https://api.netproxy.io/proxy', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${proxyConfig.apiKey}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      console.error('NetProxy API error:', response.status, response.statusText);
      return null;
    }

    const proxyData = await response.json();
    
    // Cập nhật proxy setting trong database
    await connectMongoDB();
    const updateData: any = {
      currentProxy: proxyData.proxy || proxyData.data?.proxy,
      refreshAt: new Date()
    };

    if (proxyData.next_change) {
      updateData.nextChange = proxyData.next_change;
    }

    const updatedSetting = await (ProxySettings as any).findByIdAndUpdate(
      proxyConfig.id,
      updateData,
      { new: true }
    );

    if (!updatedSetting) {
      return null;
    }

    return {
      id: updatedSetting._id.toString(),
      name: updatedSetting.name,
      apiKey: updatedSetting.apiKey,
      isActive: updatedSetting.isActive,
      currentProxy: updatedSetting.currentProxy,
      refreshAt: updatedSetting.refreshAt,
      nextChange: updatedSetting.nextChange,
      acceptIp: updatedSetting.acceptIp,
      isResidential: updatedSetting.isResidential
    };
  } catch (error) {
    console.error('Error refreshing proxy:', error);
    return null;
  }
}

// Kiểm tra xem có cần làm mới proxy không
export function shouldRefreshProxy(proxyConfig: ProxyConfig): boolean {
  if (!proxyConfig.currentProxy) {
    return true;
  }

  if (!proxyConfig.nextChange) {
    return false;
  }

  const now = Date.now();
  const nextChangeTime = proxyConfig.nextChange * 1000; // Convert to milliseconds
  
  return now >= nextChangeTime;
}

// Lấy proxy đang hoạt động, tự động làm mới nếu cần
export async function getActiveProxy(): Promise<string | null> {
  try {
    const proxyConfig = await getRandomProxyConfig();
    
    if (!proxyConfig) {
      console.log('No active proxy configurations found');
      return null;
    }

    // Kiểm tra xem có cần làm mới proxy không
    if (shouldRefreshProxy(proxyConfig)) {
      console.log(`Refreshing proxy for ${proxyConfig.name}`);
      const refreshedConfig = await refreshProxy(proxyConfig);
      
      if (refreshedConfig && refreshedConfig.currentProxy) {
        return refreshedConfig.currentProxy;
      }
    } else if (proxyConfig.currentProxy) {
      console.log(`Using current proxy from ${proxyConfig.name}`);
      return proxyConfig.currentProxy;
    }

    // Nếu không có proxy hiện tại, thử làm mới
    console.log(`No current proxy, refreshing ${proxyConfig.name}`);
    const refreshedConfig = await refreshProxy(proxyConfig);
    
    return refreshedConfig?.currentProxy || null;
  } catch (error) {
    console.error('Error getting active proxy:', error);
    return null;
  }
}

// Tạo headers cho request với proxy
export function createProxyHeaders(proxyConfig: ProxyConfig) {
  return {
    'X-Proxy-Name': proxyConfig.name,
    'X-Proxy-Key': proxyConfig.apiKey,
    'X-Proxy-Type': proxyConfig.isResidential ? 'residential' : 'datacenter'
  };
}

// Lấy thông tin tất cả proxy settings (cho admin dashboard)
export async function getAllProxySettings() {
  try {
    await connectMongoDB();
    const settings = await (ProxySettings as any).find({}).sort({ createdAt: -1 });
    
    return settings.map(setting => ({
      id: setting._id.toString(),
      name: setting.name,
      apiKey: setting.apiKey,
      isActive: setting.isActive,
      currentProxy: setting.currentProxy,
      refreshAt: setting.refreshAt,
      nextChange: setting.nextChange,
      acceptIp: setting.acceptIp,
      isResidential: setting.isResidential,
      createdAt: setting.createdAt,
      updatedAt: setting.updatedAt
    }));
  } catch (error) {
    console.error('Error getting all proxy settings:', error);
    return [];
  }
} 