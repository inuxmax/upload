// NetProxy (rotateProxy) integration helper

export type ProxyConfig = {
  host: string;
  port: number;
  protocol: 'http' | 'https';
};

type NetProxySuccessData = {
  proxy?: string;
  refreshAt?: string;
  nextChange?: number;
  acceptIp?: string;
  isResidential?: boolean;
};

type NetProxyResponse = {
  success?: boolean;
  data?: NetProxySuccessData | null;
};

type NetProxyCountriesResponse = {
  success?: boolean;
  data?: { countries?: string[] } | null;
};

async function fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs = 8000): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

function parseProxyString(proxy: string | undefined | null): ProxyConfig | null {
  if (!proxy) return null;
  const parts = String(proxy).trim();
  const [host, portStr] = parts.split(':');
  if (!host || !portStr) return null;
  const port = parseInt(portStr, 10);
  if (Number.isNaN(port)) return null;
  return { host, port, protocol: 'http' };
}

// Cache for countries list to avoid frequent network calls
let countriesCache: { countries: string[]; fetchedAt: number } | null = null;

async function getCountriesFromNetProxy(timeoutMs: number): Promise<string[]> {
  const now = Date.now();
  if (countriesCache && now - countriesCache.fetchedAt < 10 * 60 * 1000) {
    return countriesCache.countries;
  }
  const url = 'https://api.netproxy.io/api/rotateProxy/location';
  const res = await fetchWithTimeout(url, { method: 'GET' }, timeoutMs);
  const text = await res.text();
  let json: NetProxyCountriesResponse | null = null;
  try { json = JSON.parse(text); } catch { json = null; }
  const list = (json?.success && json?.data?.countries && Array.isArray(json.data.countries))
    ? json.data.countries.filter(Boolean)
    : [];
  if (list.length > 0) {
    countriesCache = { countries: list, fetchedAt: now };
    return list;
  }
  // Fallback minimal list
  return ['Vietnam'];
}

// Map numeric locationId (1-based) to country string from NetProxy list
async function mapLocationToCountry(locationId: number | undefined, timeoutMs: number): Promise<string> {
  const countries = await getCountriesFromNetProxy(timeoutMs);
  if (typeof locationId === 'number') {
    if (locationId === 0 && countries.length > 0) {
      const randomIndex = Math.floor(Math.random() * countries.length);
      return countries[randomIndex];
    }
    if (locationId >= 1 && locationId <= countries.length) {
      return countries[locationId - 1];
    }
  }
  return 'Vietnam';
}

async function getCurrentProxyFromNetProxy(apiKey: string, timeoutMs: number): Promise<ProxyConfig | null> {
  const url = `https://api.netproxy.io/api/rotateProxy/getCurrentProxy?apiKey=${encodeURIComponent(apiKey)}`;
  const res = await fetchWithTimeout(url, { method: 'GET' }, timeoutMs);
  const text = await res.text();
  let json: NetProxyResponse | null = null;
  try { json = JSON.parse(text); } catch { json = null; }
  if (json?.success && json.data && json.data.proxy) {
    return parseProxyString(json.data.proxy);
  }
  return null;
}

async function getNewProxyFromNetProxy(apiKey: string, country: string, timeoutMs: number): Promise<ProxyConfig | null> {
  const url = `https://api.netproxy.io/api/rotateProxy/getNewProxy?type=all&apiKey=${encodeURIComponent(apiKey)}&country=${encodeURIComponent(country)}`;
  const res = await fetchWithTimeout(url, { method: 'GET' }, timeoutMs);
  const text = await res.text();
  let json: NetProxyResponse | null = null;
  try { json = JSON.parse(text); } catch { json = null; }
  if (json?.success && json.data && json.data.proxy) {
    return parseProxyString(json.data.proxy);
  }
  return null;
}

// Keep per-scope round-robin index in memory (scope = userId or any identifier)
const roundRobinIndexByScope = new Map<string, number>();

export async function getProxyFromProxyFB(
  keys: string[],
  locationId = 1,
  timeoutMs = 8000,
  distributionScope?: string
): Promise<ProxyConfig | null> {
  if (!Array.isArray(keys) || keys.length === 0) return null;
  const country = await mapLocationToCountry(locationId, timeoutMs);

  // Compute iteration order (round-robin per scope if provided)
  let order: number[] = [];
  if (distributionScope && keys.length > 1) {
    const start = roundRobinIndexByScope.get(distributionScope) ?? 0;
    for (let i = 0; i < keys.length; i++) {
      order.push((start + i) % keys.length);
    }
  } else {
    order = keys.map((_, idx) => idx);
  }

  for (const idx of order) {
    const apiKey = keys[idx];
    // Prefer requesting a new proxy first
    try {
      const newCfg = await getNewProxyFromNetProxy(apiKey, country, timeoutMs);
      if (newCfg) {
        if (distributionScope && keys.length > 1) {
          roundRobinIndexByScope.set(distributionScope, (idx + 1) % keys.length);
        }
        return newCfg;
      }
    } catch {}

    // Fallback to current proxy if new is not available
    try {
      const curCfg = await getCurrentProxyFromNetProxy(apiKey, timeoutMs);
      if (curCfg) {
        if (distributionScope && keys.length > 1) {
          roundRobinIndexByScope.set(distributionScope, (idx + 1) % keys.length);
        }
        return curCfg;
      }
    } catch {}
  }

  return null;
}

export async function forceChangeProxyFB(key: string, locationId = 1, timeoutMs = 8000): Promise<ProxyConfig | null> {
  if (!key) return null;
  const country = await mapLocationToCountry(locationId, timeoutMs);
  try {
    return await getNewProxyFromNetProxy(key, country, timeoutMs);
  } catch {
    return null;
  }
}


