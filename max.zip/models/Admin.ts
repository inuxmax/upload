import mongoose from 'mongoose';

const AdminSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['super_admin', 'admin'], default: 'admin' },
  permissions: [{
    type: String,
    enum: ['manage_users', 'manage_accounts', 'manage_general', 'manage_threads', 'manage_subscriptions', 'manage_nav', 'manage_seo', 'manage_transactions']
  }],
  isActive: { type: Boolean, default: true },
  lastLogin: { type: Date },
  avatar: { type: String, default: '' }
}, { timestamps: true });

const Admin = mongoose.models.Admin || mongoose.model('Admin', AdminSchema);
export default Admin; 