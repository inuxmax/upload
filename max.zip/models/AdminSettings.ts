import mongoose from 'mongoose';

const AdminSettingsSchema = new mongoose.Schema({
  // Thread Management
  globalMaxThreads: {
    type: Number,
    min: 10,
    max: 100,
    default: 50
  },
  defaultUserThreads: {
    type: Number,
    min: 1,
    max: 50,
    default: 10
  },
  allowUserThreadSettings: {
    type: Boolean,
    default: true
  },
  
  // System Status
  systemStatus: {
    type: String,
    enum: ['active', 'maintenance', 'offline'],
    default: 'active'
  },
  maintenanceMessage: {
    type: String,
    default: ''
  }
}, {
  timestamps: true
});

export default mongoose.models.AdminSettings || mongoose.model('AdminSettings', AdminSettingsSchema); 