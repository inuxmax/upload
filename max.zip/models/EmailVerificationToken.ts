import mongoose from 'mongoose'

export interface IEmailVerificationToken extends mongoose.Document {
  userId: mongoose.Types.ObjectId
  tokenHash: string
  expiresAt: Date
  usedAt?: Date | null
  createdAt: Date
  updatedAt: Date
}

const EmailVerificationTokenSchema = new mongoose.Schema<IEmailVerificationToken>({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  tokenHash: { type: String, required: true, unique: true },
  expiresAt: { type: Date, required: true, index: true },
  usedAt: { type: Date, default: null }
}, { timestamps: true })

export default (mongoose.models.EmailVerificationToken as mongoose.Model<IEmailVerificationToken>)
  || mongoose.model<IEmailVerificationToken>('EmailVerificationToken', EmailVerificationTokenSchema)


