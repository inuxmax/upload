import mongoose from 'mongoose';

const FacebookAccountSchema = new mongoose.Schema({
  uid: {
    type: String,
    required: true
  },
  pass: {
    type: String,
    default: ''
  },
  twofa: {
    type: String,
    default: ''
  },
  twoFASecret: {
    type: String,
    default: ''
  },
  has2FA: {
    type: Boolean,
    default: false
  },
  mail: {
    type: String,
    default: ''
  },
  passmail: {
    type: String,
    default: ''
  },
  mailkp: {
    type: String,
    default: ''
  },
  cookie: {
    type: String,
    default: ''
  },
  token: {
    type: String,
    default: ''
  },
  name: {
    type: String,
    default: 'Chưa có'
  },
  friends: {
    type: String,
    default: 'Chưa có'
  },
  gender: {
    type: String,
    default: 'Chưa có'
  },
  creationDate: {
    type: String,
    default: 'Chưa có'
  },
  status: {
    type: String,
    enum: ['active', 'checking', 'error', 'inactive'],
    default: 'active'
  },
  log: {
    type: String,
    default: ''
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  },
  accessToken: {
    type: String,
    default: ''
  },
  cookies: {
    type: String,
    default: ''
  },
  sessionKey: {
    type: String,
    default: ''
  },
  machineId: {
    type: String,
    default: ''
  },
  secret: {
    type: String,
    default: ''
  },
  eaagToken: {
    type: String,
    default: ''
  },
  eaabToken: {
    type: String,
    default: ''
  },
  quality: {
    type: String,
    default: 'Chưa check'
  },
  lastQualityCheck: {
    type: Date,
    default: null
  },
  qualityData: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  dtsg: {
    type: String,
    default: ''
  },
  graphInfo: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  birthday: {
    type: String,
    default: 'Chưa có'
  },
  email: {
    type: String,
    default: ''
  },
  lastGraphUpdate: {
    type: Date,
    default: null
  },
  // TKQC Data
  tkqcData: {
    type: [{
      account_id: String,
      name: String,
      account_status: Number,
      balance: String,
      currency: String,
      adtrust_dsl: Number,
      disable_reason: Number,
      owner: String,
      created_time: String,
      next_bill_date: String,
      is_prepay_account: Boolean,
      threshold_amount: Number,
      user_role: String,
      spend: String,
      source: String,
      bm_id: String,
      bm_name: String,
      owner_business: mongoose.Schema.Types.Mixed,
      // Legacy fields for backward compatibility
      id: String,
      profile_picture: String,
      amount_spent: String
    }],
    default: []
  },
  bmData: {
    type: [{
      id: String,
      name: String,
      is_disabled_for_integrity_reasons: Boolean,
      verification_status: String,
      created_time: String,
      adAccountLimit: String,
      restriction_type: String,
      // Legacy fields for backward compatibility
      profile_picture: String
    }],
    default: []
  },
  accountInfo: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  lastTkqcCheck: {
    type: Date,
    default: null
  },
  tkqcCount: {
    type: Number,
    default: 0
  },
  bmCount: {
    type: Number,
    default: 0
  },
  // Optional reference to owner user
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false,
    index: true,
    default: null
  },
  businessManagers: {
    type: [{
      id: String,
      name: String,
      url: String,
      createdAt: Date,
      data: mongoose.Schema.Types.Mixed
    }],
    default: []
  }
}, {
  timestamps: true
});

// Index to ensure unique UID - removed duplicate
// FacebookAccountSchema.index({ uid: 1 }, { unique: true });

const FacebookAccount = mongoose.models.FacebookAccount || mongoose.model('FacebookAccount', FacebookAccountSchema);

export default FacebookAccount; 