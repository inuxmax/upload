import mongoose from 'mongoose';

const GeneralSettingsSchema = new mongoose.Schema({
  siteName: { type: String, default: 'XMDT - CHECKVIA' },
  siteDescription: { type: String, default: 'Hệ thống quản lý tài khoản Facebook' },
  maintenanceMode: { type: Boolean, default: false },
  maintenanceMessage: { type: String, default: 'Hệ thống đang bảo trì' },
  maxAccountsPerUser: { type: Number, default: 100 },
  maxBulkUploadSize: { type: Number, default: 1000 },
  enableRegistration: { type: Boolean, default: true },
  enableEmailVerification: { type: Boolean, default: false },
  sessionTimeout: { type: Number, default: 24 }, // hours
  maxLoginAttempts: { type: Number, default: 5 },
  lockoutDuration: { type: Number, default: 30 }, // minutes
  systemVersion: { type: String, default: '2.1.8' },
  lastUpdated: { type: Date, default: Date.now }
}, { timestamps: true });

const GeneralSettings = mongoose.models.GeneralSettings || mongoose.model('GeneralSettings', GeneralSettingsSchema);
export default GeneralSettings; 