import mongoose from 'mongoose';

const NavigationSchema = new mongoose.Schema({
  name: { type: String, required: true },
  url: { type: String, required: true },
  icon: { type: String, default: '' },
  order: { type: Number, default: 0 },
  isActive: { type: Boolean, default: true },
  isVisible: { type: Boolean, default: true },
  target: { type: String, enum: ['_self', '_blank'], default: '_self' },
  parentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Navigation', default: null },
  permissions: [{ type: String }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

const Navigation = mongoose.models.Navigation || mongoose.model('Navigation', NavigationSchema);
export default Navigation; 