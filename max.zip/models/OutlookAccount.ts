import mongoose from 'mongoose';

export interface IOutlookAccount {
  _id?: string;
  userId: string;
  email: string;
  password: string;
  accessToken?: string;
  refreshToken?: string;
  clientId?: string;
  tokenExpiresAt?: Date;
  scope?: string;
  tokenType?: string;
  status: 'active' | 'inactive' | 'error' | 'token_expired' | 'needs_reauth';
  lastLogin?: Date;
  lastMailCheck?: Date;
  errorMessage?: string;
  lastError?: string;
  proxy?: string;
  createdAt: Date;
  updatedAt: Date;
}

const OutlookAccountSchema = new mongoose.Schema<IOutlookAccount>({
  userId: {
    type: String,
    required: true,
    index: true
  },
  email: {
    type: String,
    required: true,
    lowercase: true,
    trim: true,
    index: { unique: true },
    validate: {
      validator: function(email: string) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      },
      message: 'Invalid email format'
    }
  },
  password: {
    type: String,
    required: true
  },
  accessToken: {
    type: String,
    default: null
  },
  refreshToken: {
    type: String,
    default: null
  },
  clientId: {
    type: String,
    default: null
  },
  tokenExpiresAt: {
    type: Date,
    default: null
  },
  scope: {
    type: String,
    default: null
  },
  tokenType: {
    type: String,
    default: 'Bearer'
  },
  status: {
    type: String,
    enum: ['active', 'inactive', 'error', 'token_expired', 'needs_reauth'],
    default: 'inactive'
  },
  lastLogin: {
    type: Date,
    default: null
  },
  lastMailCheck: {
    type: Date,
    default: null
  },
  errorMessage: {
    type: String,
    default: null
  },
  lastError: {
    type: String,
    default: null
  },
  proxy: {
    type: String,
    default: null
  }
}, {
  timestamps: true,
  collection: 'outlook_accounts'
});

// Indexes for better performance
OutlookAccountSchema.index({ userId: 1, status: 1 });
OutlookAccountSchema.index({ lastLogin: 1 });
OutlookAccountSchema.index({ tokenExpiresAt: 1 });

// Virtual for checking if token is expired
OutlookAccountSchema.virtual('isTokenExpired').get(function() {
  if (!this.tokenExpiresAt) return true;
  return new Date() > this.tokenExpiresAt;
});

// Method to update token information
OutlookAccountSchema.methods.updateTokens = function(tokenData: any) {
  this.accessToken = tokenData.access_token;
  this.refreshToken = tokenData.refresh_token;
  this.scope = tokenData.scope;
  this.tokenType = tokenData.token_type || 'Bearer';
  
  // Calculate expiration time (expires_in is in seconds)
  if (tokenData.expires_in) {
    this.tokenExpiresAt = new Date(Date.now() + (tokenData.expires_in * 1000));
  }
  
  this.status = 'active';
  this.lastLogin = new Date();
  this.errorMessage = null;
  
  return this.save();
};

// Method to mark account as having an error
OutlookAccountSchema.methods.setError = function(errorMessage: string) {
  this.status = 'error';
  this.errorMessage = errorMessage;
  return this.save();
};

// Method to mark token as expired
OutlookAccountSchema.methods.markTokenExpired = function() {
  this.status = 'token_expired';
  return this.save();
};

// Method to update last mail check time
OutlookAccountSchema.methods.updateLastMailCheck = function() {
  this.lastMailCheck = new Date();
  return this.save();
};

// Static method to find accounts by user
OutlookAccountSchema.statics.findByUser = function(userId: string) {
  return this.find({ userId }).sort({ createdAt: -1 });
};

// Static method to find active accounts
OutlookAccountSchema.statics.findActive = function(userId?: string) {
  const query: any = { status: 'active' };
  if (userId) {
    query.userId = userId;
  }
  return this.find(query).sort({ lastLogin: -1 });
};

// Static method to find accounts with expired tokens
OutlookAccountSchema.statics.findExpiredTokens = function() {
  return this.find({
    $or: [
      { tokenExpiresAt: { $lt: new Date() } },
      { status: 'token_expired' }
    ]
  });
};

// Pre-save middleware to validate email domain (optional - can be customized)
OutlookAccountSchema.pre('save', function(next) {
  // Accept common Microsoft consumer mail domains across regional TLDs, e.g.:
  // outlook.com, outlook.fr, outlook.jp, hotmail.co.uk, hotmail.de, live.it, msn.com, etc.
  const emailDomain = String(this.email).split('@')[1] || '';
  const microsoftDomainPattern = /^(outlook|hotmail|live|msn)\.[a-z]{2,}(?:\.[a-z]{2,})?$/i;

  if (!microsoftDomainPattern.test(emailDomain)) {
    console.warn(`Warning: Email domain ${emailDomain} is not a typical Outlook domain`);
  }

  next();
});

// Ensure model is only compiled once
const OutlookAccount = mongoose.models.OutlookAccount || mongoose.model<IOutlookAccount>('OutlookAccount', OutlookAccountSchema);

export default OutlookAccount;
