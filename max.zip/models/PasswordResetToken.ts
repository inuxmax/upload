import mongoose from 'mongoose'

export interface IPasswordResetToken extends mongoose.Document {
  userId: mongoose.Types.ObjectId
  tokenHash: string
  expiresAt: Date
  usedAt?: Date | null
  createdAt: Date
  updatedAt: Date
}

const PasswordResetTokenSchema = new mongoose.Schema<IPasswordResetToken>({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  tokenHash: { type: String, required: true, unique: true },
  expiresAt: { type: Date, required: true, index: true },
  usedAt: { type: Date, default: null }
}, { timestamps: true })

export default (mongoose.models.PasswordResetToken as mongoose.Model<IPasswordResetToken>)
  || mongoose.model<IPasswordResetToken>('PasswordResetToken', PasswordResetTokenSchema)


