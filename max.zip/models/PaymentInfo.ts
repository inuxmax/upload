import mongoose from 'mongoose';

const paymentInfoSchema = new mongoose.Schema({
  bankName: {
    type: String,
    required: true,
    default: 'ACB Bank'
  },
  accountNumber: {
    type: String,
    required: true,
    default: '123456789'
  },
  accountHolder: {
    type: String,
    required: true,
    default: 'CÔNG TY ABC'
  },
  transferContent: {
    type: String,
    required: true,
    default: 'NAP688f3e936f5f9a834e839cba'
  },
  // ACB API Credentials
  passwordACB: {
    type: String,
    required: false,
    default: ''
  },
  tokenACB: {
    type: String,
    required: false,
    default: ''
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

const PaymentInfo = mongoose.models.PaymentInfo || mongoose.model('PaymentInfo', paymentInfoSchema);

export default PaymentInfo; 