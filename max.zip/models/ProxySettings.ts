import mongoose, { Schema, Document } from 'mongoose';

export interface IProxySettings extends Document {
  name: string;
  apiKey: string;
  isActive: boolean;
  currentProxy?: string;
  refreshAt?: Date;
  nextChange?: number;
  acceptIp?: string;
  isResidential?: boolean;
  maxUsers?: number; // Số lượng user tối đa có thể sử dụng proxy này
  currentUsers?: number; // Số lượng user hiện tại đang sử dụng
  createdAt: Date;
  updatedAt: Date;
}

const ProxySettingsSchema = new Schema<IProxySettings>({
  name: {
    type: String,
    required: true,
    unique: true
  },
  apiKey: {
    type: String,
    required: true,
    index: false // Đảm bảo không có unique index
  },
  isActive: {
    type: Boolean,
    default: true
  },
  currentProxy: {
    type: String
  },
  refreshAt: {
    type: Date
  },
  nextChange: {
    type: Number
  },
  acceptIp: {
    type: String
  },
  isResidential: {
    type: Boolean
  },
  maxUsers: {
    type: Number,
    default: 10 // Mặc định 10 user
  },
  currentUsers: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

export default mongoose.models.ProxySettings || mongoose.model<IProxySettings>('ProxySettings', ProxySettingsSchema); 