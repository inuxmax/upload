import mongoose from 'mongoose';

const SEOSchema = new mongoose.Schema({
  siteTitle: { type: String, default: 'XMDT - CHECKVIA' },
  siteDescription: { type: String, default: 'Hệ thống quản lý tài khoản Facebook chuyên nghiệp' },
  siteKeywords: [{ type: String }],
  siteLogo: { type: String, default: '' },
  siteFavicon: { type: String, default: '' },
  siteBanner: { type: String, default: '' },
  ogImage: { type: String, default: '' },
  ogTitle: { type: String, default: '' },
  ogDescription: { type: String, default: '' },
  twitterCard: { type: String, default: 'summary_large_image' },
  twitterSite: { type: String, default: '' },
  twitterCreator: { type: String, default: '' },
  googleAnalytics: { type: String, default: '' },
  googleTagManager: { type: String, default: '' },
  facebookPixel: { type: String, default: '' },
  customCSS: { type: String, default: '' },
  customJS: { type: String, default: '' },
  metaRobots: { type: String, default: 'index, follow' },
  canonicalUrl: { type: String, default: '' },
  lastUpdated: { type: Date, default: Date.now }
}, { timestamps: true });

const SEO = mongoose.models.SEO || mongoose.model('SEO', SEOSchema);
export default SEO; 