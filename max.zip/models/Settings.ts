import mongoose from 'mongoose';

const SettingsSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  // HTTP Proxy Settings
  httpProxies: {
    type: [String],
    default: []
  },
  // Hotmail Settings
  hotmailAccounts: {
    type: [String],
    default: []
  },
  // General Settings
  enable2FA: {
    type: Boolean,
    default: false
  },
  changeName: {
    type: Boolean,
    default: false
  },
  checkBM: {
    type: Boolean,
    default: false
  },
  checkTKQC: {
    type: Boolean,
    default: false
  },
  checkFullInfo: {
    type: Boolean,
    default: false
  },
  // Additional Settings
  autoLogin: {
    type: Boolean,
    default: false
  },
  notifications: {
    type: Boolean,
    default: true
  },
  maxThreads: {
    type: Number,
    min: 1,
    max: 50,
    default: 10
  },
  theme: {
    type: String,
    enum: ['light', 'dark', 'auto'],
    default: 'auto'
  },
  language: {
    type: String,
    enum: ['vi', 'en'],
    default: 'vi'
  },
  // ProxyFB user keys and location
  proxyFBKeys: {
    type: [String],
    default: []
  },
  proxyFBLocationId: {
    type: Number,
    default: 0
  },
  // Proxy Settings
  selectedProxyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ProxySettings',
    default: null
  },
  // Data encryption preferences
  encryption: {
    type: new mongoose.Schema({
      enabled: { type: Boolean, default: false },
      userKeyEncrypted: { type: String, default: null }
    }, { _id: false }),
    default: { enabled: false, userKeyEncrypted: null }
  },
  // Back-compat flat fields
  encryptionEnabled: { type: Boolean, default: false },
  userEncryptionKey: { type: String, default: null }
}, {
  timestamps: true
});

export default mongoose.models.Settings || mongoose.model('Settings', SettingsSchema); 