import mongoose, { Schema, Document } from 'mongoose';

export interface ISubscriptionPlan extends Document {
  name: string;
  plan: string; // Cho phép nhập giá trị tự do
  duration: number; // Số tháng
  price: number;
  currency: string;
  maxThreads: number; // -1 = không giới hạn
  features: string[];
  isActive: boolean;
  description: string;
  createdAt: Date;
  updatedAt: Date;
}

const SubscriptionPlanSchema = new Schema<ISubscriptionPlan>({
  name: {
    type: String,
    required: true
  },
  plan: {
    type: String,
    required: true,
    unique: true
  },
  duration: {
    type: Number,
    required: true,
    min: 1
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  currency: {
    type: String,
    default: 'VND'
  },
  maxThreads: {
    type: Number,
    required: true,
    default: 2 // Free plan chỉ có 2 luồng
  },
  features: [{
    type: String
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  description: {
    type: String,
    required: true
  }
}, {
  timestamps: true
});

export default mongoose.models.SubscriptionPlan || mongoose.model<ISubscriptionPlan>('SubscriptionPlan', SubscriptionPlanSchema); 