import mongoose from 'mongoose';

const SystemSettingsSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    unique: true,
    enum: ['welcome_popup', 'system', 'payment', 'general']
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index để tìm kiếm nhanh theo type - removed duplicate
// SystemSettingsSchema.index({ type: 1 });

const SystemSettings = mongoose.models.SystemSettings || mongoose.model('SystemSettings', SystemSettingsSchema);

export default SystemSettings;
