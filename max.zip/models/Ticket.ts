import mongoose, { Schema, Document, Types } from 'mongoose'

export interface ITicket extends Document {
  userId: Types.ObjectId | string
  title: string
  subject?: string
  orderId?: string
  status: 'open' | 'closed'
  lastMessageAt?: Date
  createdAt: Date
  updatedAt: Date
}

const TicketSchema = new Schema<ITicket>({
  userId: { type: Schema.Types.ObjectId, required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 200 },
  subject: { type: String, trim: true, maxlength: 100 },
  orderId: { type: String, trim: true, maxlength: 100 },
  status: { type: String, enum: ['open', 'closed'], default: 'open' },
  lastMessageAt: { type: Date, default: Date.now }
}, { timestamps: true })

TicketSchema.index({ createdAt: -1 })

export default mongoose.models.Ticket || mongoose.model<ITicket>('Ticket', TicketSchema)


