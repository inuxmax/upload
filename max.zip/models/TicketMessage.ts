import mongoose, { Schema, Document, Types } from 'mongoose'

export interface ITicketMessage extends Document {
  ticketId: Types.ObjectId | string
  senderType: 'user' | 'admin'
  senderId: Types.ObjectId | string
  content?: string
  imageUrl?: string
  createdAt: Date
  isRead: boolean
}

const TicketMessageSchema: Schema = new Schema({
  ticketId: { type: Schema.Types.ObjectId, required: true, index: true, ref: 'Ticket' },
  senderType: { type: String, enum: ['user', 'admin'], required: true },
  senderId: { type: Schema.Types.ObjectId, required: true },
  content: { type: String, required: false, maxlength: 1000 },
  imageUrl: { type: String, required: false },
  createdAt: { type: Date, default: Date.now },
  isRead: { type: Boolean, default: false }
})

const TicketMessage = mongoose.models.TicketMessage || mongoose.model<ITicketMessage>('TicketMessage', TicketMessageSchema)
export default TicketMessage
