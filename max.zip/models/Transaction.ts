import mongoose from 'mongoose';

const TransactionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  transactionId: {
    type: String,
    unique: true,
    index: true,
    sparse: true // Cho phép null nhưng unique khi có giá trị
  },
  type: {
    type: String,
    enum: ['deposit', 'withdrawal', 'payment'],
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  transferContent: {
    type: String,
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed'],
    default: 'pending'
  },
  bankInfo: {
    bankName: String,
    accountNumber: String,
    accountHolder: String
  },
  description: {
    type: String,
    default: ''
  },
  completedAt: {
    type: Date
  }
}, {
  timestamps: true // Tự động tạo createdAt và updatedAt
});

// Index để tìm kiếm nhanh
TransactionSchema.index({ userId: 1, createdAt: -1 });
TransactionSchema.index({ transferContent: 1 });
// Note: unique+index are defined at field level for transactionId to avoid duplicate index warnings

const Transaction = mongoose.models.Transaction || mongoose.model('Transaction', TransactionSchema);

export default Transaction;