const mongoose = require('mongoose')
const bcrypt = require('bcryptjs')
require('dotenv').config()

// Admin Schema
const AdminSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['super_admin', 'admin'], default: 'super_admin' },
  permissions: [{
    type: String,
    enum: ['manage_users', 'manage_accounts', 'manage_general', 'manage_nav', 'manage_seo', 'manage_threads', 'manage_subscriptions', 'manage_tickets']
  }],
  isActive: { type: Boolean, default: true },
  lastLogin: { type: Date },
  avatar: { type: String, default: '' }
}, { timestamps: true })

const Admin = mongoose.model('Admin', AdminSchema)

async function createDefaultAdmin() {
  try {
    await mongoose.connect(process.env.MONGODB_URI)
    console.log('Connected to MongoDB')

    // Check if admin already exists
    const existingAdmin = await Admin.findOne({ username: 'admin' })
    if (existingAdmin) {
      console.log('Admin already exists')
      process.exit(0)
    }

    // Create default admin
    const hashedPassword = await bcrypt.hash('admin123', 12)
    
    const admin = new Admin({
      username: 'taodeovao',
      email: 'admin@xmdt.com',
      password: hashedPassword,
      role: 'super_admin',
      permissions: [
    "manage_users",
    "manage_accounts",
    "manage_general",
    "manage_threads",
    "manage_subscriptions",
    "manage_nav",
    "manage_seo"
      ],
      isActive: true
    })

    await admin.save()
    console.log('Default admin created successfully')
    console.log('Username: taodeovao')
    console.log('Password: Phamdat@1998@')
    
  } catch (error) {
    console.error('Error creating admin:', error)
  } finally {
    await mongoose.disconnect()
    process.exit(0)
  }
}

createDefaultAdmin() 