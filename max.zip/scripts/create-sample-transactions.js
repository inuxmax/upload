const mongoose = require('mongoose');
require('dotenv').config();

// Import models
const User = require('../models/User');
const Transaction = require('../models/Transaction');

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', async () => {
  console.log('Connected to MongoDB');
  
  try {
    // Get all users
    const users = await User.find({});
    
    if (users.length === 0) {
      console.log('No users found. Please create users first.');
      process.exit(0);
    }
    
    console.log(`Found ${users.length} users`);
    
    // Create sample transactions for each user
    const sampleTransactions = [];
    
    for (const user of users) {
      // Create transactions for the last 30 days
      for (let i = 0; i < 10; i++) {
        const date = new Date();
        date.setDate(date.getDate() - Math.floor(Math.random() * 30));
        
        const transactionTypes = ['deposit', 'withdrawal', 'payment'];
        const statuses = ['completed', 'pending', 'failed'];
        
        const transaction = {
          userId: user._id,
          type: transactionTypes[Math.floor(Math.random() * transactionTypes.length)],
          amount: Math.floor(Math.random() * 1000000) + 10000, // 10k to 1M VND
          status: statuses[Math.floor(Math.random() * statuses.length)],
          description: `Giao dịch mẫu ${i + 1}`,
          transactionId: `TXN${Date.now()}${Math.floor(Math.random() * 1000)}`,
          createdAt: date,
          updatedAt: date
        };
        
        sampleTransactions.push(transaction);
      }
    }
    
    // Insert transactions
    if (sampleTransactions.length > 0) {
      await Transaction.insertMany(sampleTransactions);
      console.log(`Created ${sampleTransactions.length} sample transactions`);
    }
    
    console.log('Sample transactions created successfully!');
    process.exit(0);
    
  } catch (error) {
    console.error('Error creating sample transactions:', error);
    process.exit(1);
  }
}); 