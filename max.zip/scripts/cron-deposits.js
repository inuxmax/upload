/*
  Cron đối soát giao dịch nạp tiền qua ACB
  Cách chạy: NODE_ENV=production node scripts/cron-deposits.js
*/

require('dotenv').config();
const mongoose = require('mongoose');

const PaymentInfo = require('../models/PaymentInfo').default;
const Transaction = require('../models/Transaction').default;
const User = require('../models/User').default;

async function connect() {
  const uri = process.env.MONGODB_URI || process.env.MONGODB_URL;
  if (!uri) {
    throw new Error('MONGODB_URI not set');
  }
  await mongoose.connect(uri, { autoIndex: true });
}

async function fetchACBHistory(paymentInfo) {
  const url = `https://api.web2m.com/historyapiacbv3/${paymentInfo.passwordACB}/${paymentInfo.accountNumber}/${paymentInfo.tokenACB}`;
  const res = await fetch(url, { method: 'GET', headers: { 'Content-Type': 'application/json' } });
  if (!res.ok) {
    throw new Error(`ACB API HTTP ${res.status}`);
  }
  const data = await res.json();
  if (!data || data.status !== true || !Array.isArray(data.transactions)) {
    throw new Error('ACB API payload invalid');
  }
  return data.transactions;
}

function matchesTransaction(acbTxn, pending) {
  if (acbTxn.type !== 'IN') return false;
  if (Number(acbTxn.amount) !== Number(pending.amount)) return false;
  const desc = String(acbTxn.description || '').toUpperCase();
  const needle = String(pending.transferContent || '').toUpperCase();
  if (!needle) return false;
  if (desc.includes(needle)) return true;
  if (needle.length >= 8 && desc.includes(needle.substring(0, 8))) return true;
  return false;
}

async function processPending(paymentInfo) {
  const acbTxns = await fetchACBHistory(paymentInfo);

  const pendings = await Transaction.find({ type: 'deposit', status: 'pending' }).limit(200);
  if (pendings.length === 0) return { checked: 0, matched: 0 };

  let matched = 0;
  for (const pending of pendings) {
    const match = acbTxns.find(t => matchesTransaction(t, pending));
    if (!match) continue;

    const user = await User.findById(pending.userId);
    if (!user) continue;

    // Idempotency check: skip if already completed by another worker
    const fresh = await Transaction.findById(pending._id);
    if (!fresh || fresh.status !== 'pending') continue;

    user.balance = (user.balance || 0) + Number(pending.amount);
    user.pendingTransferContents = user.pendingTransferContents || [];
    if (!user.pendingTransferContents.includes(pending.transferContent)) {
      user.pendingTransferContents.push(pending.transferContent);
    }

    fresh.status = 'completed';
    fresh.completedAt = new Date();
    fresh.description = `Nạp tiền qua ${paymentInfo.bankName || 'ACB'} - ${pending.transferContent}`;
    fresh.bankInfo = {
      bankName: paymentInfo.bankName || 'ACB',
      accountNumber: paymentInfo.accountNumber,
      accountHolder: paymentInfo.accountHolder
    };

    await Promise.all([user.save(), fresh.save()]);
    matched += 1;
  }

  return { checked: pendings.length, matched };
}

(async () => {
  try {
    await connect();
    const paymentInfo = await PaymentInfo.findOne({ isActive: true }).lean();
    if (!paymentInfo) {
      console.log('No active payment info found. Exiting.');
      process.exit(0);
    }
    const result = await processPending(paymentInfo);
    console.log(`[cron-deposits] Checked: ${result.checked}, Matched: ${result.matched}`);
    process.exit(0);
  } catch (err) {
    console.error('[cron-deposits] Error:', err);
    process.exit(1);
  }
})();


