import mongoose from 'mongoose';
import dotenv from 'dotenv';

// Configure dotenv
dotenv.config();

// Define SubscriptionPlan schema directly
const subscriptionPlanSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  plan: {
    type: String,
    enum: ['free', 'basic', 'premium', 'enterprise'],
    unique: true,
    required: true
  },
  duration: {
    type: Number,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  currency: {
    type: String,
    default: 'VND'
  },
  maxThreads: {
    type: Number,
    default: 2
  },
  features: [{
    type: String
  }],
  isActive: {
    type: Boolean,
    default: true
  },
  description: {
    type: String,
    required: true
  }
}, {
  timestamps: true
});

const SubscriptionPlan = mongoose.model('SubscriptionPlan', subscriptionPlanSchema);

const plans = [
  {
    name: 'Gói Miễn Phí',
    plan: 'free',
    duration: 1,
    price: 0,
    currency: 'VND',
    maxThreads: 2,
    features: [
      '2 luồng chạy tối đa',
      'Quản lý tài khoản Facebook cơ bản',
      'Hỗ trợ kỹ thuật cơ bản'
    ],
    description: 'Gói dành cho người dùng mới, trải nghiệm các tính năng cơ bản',
    isActive: true
  },
  {
    name: 'Gói 1 tháng',
    plan: '1 tháng',
    duration: 1,
    price: 500000,
    currency: 'VND',
    maxThreads: 20,
    features: [
      '20 luồng chạy tối đa',
      'Quản lý tài khoản Facebook nâng cao',
      'Hỗ trợ kỹ thuật ưu tiên',
      'Tính năng đa luồng',
      'Xuất báo cáo chi tiết'
    ],
    description: 'Gói phù hợp cho người dùng cá nhân và doanh nghiệp nhỏ',
    isActive: true
  },
  {
    name: 'Gói 3 Tháng',
    plan: '3 tháng',
    duration: 3,
    price: 1500000,
    currency: 'VND',
    maxThreads: 25,
    features: [
      '20 luồng chạy tối đa',
      'Tất cả tính năng Basic',
      'Hỗ trợ kỹ thuật 24/7',
      'Tính năng tự động hóa',
      'Báo cáo nâng cao'
    ],
    description: 'Gói cao cấp cho doanh nghiệp vừa và lớn',
    isActive: true
  },
  {
    name: 'Gói 6 tháng',
    plan: '6 Tháng',
    duration: 6,
    price: 3000000,
    currency: 'VND',
    maxThreads: 20, // Không giới hạn
    features: [
      '20 luồng chạy tối đa',
      'Tất cả tính năng Premium',
      'Hỗ trợ kỹ thuật chuyên dụng',
      'Tính năng tự động hóa',
      'Báo cáo tùy chỉnh'
    ],
    description: 'Gói doanh nghiệp với tính năng tối ưu và hỗ trợ chuyên dụng',
    isActive: true
  }
];

async function initSubscriptionPlans() {
  try {
    // Kết nối MongoDB
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    // Xóa tất cả gói hiện tại
    await SubscriptionPlan.deleteMany({});
    console.log('Cleared existing plans');

    // Tạo các gói mới
    for (const planData of plans) {
      const plan = new SubscriptionPlan(planData);
      await plan.save();
      console.log(`Created plan: ${planData.name}`);
    }

    console.log('All subscription plans initialized successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error initializing subscription plans:', error);
    process.exit(1);
  }
}

initSubscriptionPlans(); 