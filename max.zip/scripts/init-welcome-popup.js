const mongoose = require('mongoose');
require('dotenv').config();

// Kết nối database
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/your-database');

// Import models
const SystemSettings = require('../models/SystemSettings').default;

async function initWelcomePopup() {
  try {
    console.log('Đang khởi tạo welcome popup settings...');
    
    // Kiểm tra xem đã có settings chưa
    const existingSettings = await SystemSettings.findOne({ type: 'welcome_popup' });
    
    if (existingSettings) {
      console.log('Welcome popup settings đã tồn tại:', existingSettings.data);
      return;
    }
    
    // Tạo settings mới
    const defaultSettings = {
      enabled: true,
      title: "Thông báo",
      message: "Chào mừng bạn quay trở lại!",
      showDontShowAgain: true,
      showOnLogin: true,
      showOnDashboard: false
    };
    
    const newSettings = await SystemSettings.create({
      type: 'welcome_popup',
      data: defaultSettings
    });
    
    console.log('Đã tạo welcome popup settings:', newSettings.data);
    
  } catch (error) {
    console.error('Lỗi khi khởi tạo welcome popup settings:', error);
  } finally {
    mongoose.connection.close();
  }
}

initWelcomePopup();
