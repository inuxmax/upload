#!/usr/bin/env node
/*
  Cross-platform self-update script for Node/Next.js apps.
  Steps:
  - Read update-config.json
  - Read local version from public/version.json
  - Fetch manifest.json (latestVersion, zipUrl, sha256)
  - If newer: download zip, verify sha256, backup current, extract, preserve configured paths, mirror to app root
  - Run postUpdate commands, then optional service start
  - On failure, exit non-zero (you can wire your own rollback policy if desired)
*/

import fs from 'fs';
import fsp from 'fs/promises';
import path from 'path';
import os from 'os';
import crypto from 'crypto';
import { spawn } from 'child_process';

const cwd = process.cwd();

function logInfo(message) { console.log(`[INFO] ${message}`); }
function logWarn(message) { console.warn(`[WARN] ${message}`); }
function logError(message) { console.error(`[ERROR] ${message}`); }

async function fileExists(p) {
  try { await fsp.access(p, fs.constants.F_OK); return true; } catch { return false; }
}

async function readJson(filePath, defaultValue = null) {
  try {
    const raw = await fsp.readFile(filePath, 'utf8');
    return JSON.parse(raw);
  } catch {
    return defaultValue;
  }
}

async function fetchJson(url) {
  const res = await fetch(url, { cache: 'no-store' });
  if (!res.ok) throw new Error(`Failed to fetch ${url}: ${res.status}`);
  return await res.json();
}

async function downloadFile(url, destPath) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Download failed: ${url} -> ${res.status}`);
  const fileStream = fs.createWriteStream(destPath);
  await new Promise((resolve, reject) => {
    res.body.pipe(fileStream);
    res.body.on('error', reject);
    fileStream.on('finish', resolve);
  });
}

async function sha256OfFile(filePath) {
  return await new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fs.createReadStream(filePath);
    stream.on('error', reject);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

function runCommand(command, args = [], options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: 'inherit', shell: process.platform === 'win32', ...options });
    child.on('close', (code) => {
      if (code === 0) resolve(); else reject(new Error(`${command} ${args.join(' ')} exited with code ${code}`));
    });
  });
}

async function ensureDir(dir) {
  await fsp.mkdir(dir, { recursive: true });
}

async function copyDir(src, dest) {
  await ensureDir(dest);
  const entries = await fsp.readdir(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      await copyDir(srcPath, destPath);
    } else if (entry.isSymbolicLink()) {
      const link = await fsp.readlink(srcPath);
      try { await fsp.symlink(link, destPath); } catch { /* ignore */ }
    } else {
      await ensureDir(path.dirname(destPath));
      await fsp.copyFile(srcPath, destPath);
    }
  }
}

async function removeDirSafe(target) {
  if (!await fileExists(target)) return;
  await fsp.rm(target, { recursive: true, force: true });
}

async function main() {
  const configPath = path.join(cwd, 'update-config.json');
  if (!await fileExists(configPath)) {
    logError(`Missing ${configPath}`);
    process.exit(1);
  }
  const config = await readJson(configPath, {});
  const manifestUrl = config.manifestUrl;
  if (!manifestUrl) {
    logError('manifestUrl is required in update-config.json');
    process.exit(1);
  }

  const serviceStop = config.service?.stop || '';
  const serviceStart = config.service?.start || '';
  const preserve = Array.isArray(config.preserve) ? config.preserve : [];
  const postUpdate = Array.isArray(config.postUpdate) ? config.postUpdate : [];

  const versionJson = await readJson(path.join(cwd, 'public', 'version.json'), { version: '0.0.0' });
  const localVersion = String(versionJson?.version || '0.0.0');

  logInfo(`Fetching manifest: ${manifestUrl}`);
  const manifest = await fetchJson(manifestUrl);
  const latestVersion = String(manifest.latestVersion || '0.0.0');
  const zipUrl = String(manifest.zipUrl || '');
  const expectedSha = typeof manifest.sha256 === 'string' ? manifest.sha256 : '';

  logInfo(`Local version: ${localVersion}, Remote version: ${latestVersion}`);
  if (!zipUrl) {
    logError('zipUrl missing in manifest');
    process.exit(1);
  }
  if (localVersion === latestVersion) {
    logInfo('Already up-to-date.');
    process.exit(0);
  }

  const timestamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
  const tempDir = path.join(cwd, `__update_tmp_${timestamp}`);
  const backupDir = path.join(cwd, `__backup_${timestamp}`);
  const oldDir = path.join(cwd, `__old_${timestamp}`);
  await ensureDir(tempDir);
  await ensureDir(backupDir);
  await ensureDir(oldDir);

  const zipPath = path.join(tempDir, 'release.zip');
  logInfo(`Downloading: ${zipUrl}`);
  await downloadFile(zipUrl, zipPath);

  if (expectedSha) {
    logInfo('Verifying SHA256...');
    const actualSha = await sha256OfFile(zipPath);
    if (actualSha.toLowerCase() !== expectedSha.toLowerCase()) {
      logError(`Checksum mismatch. Expected ${expectedSha}, got ${actualSha}`);
      process.exit(1);
    }
  } else {
    logWarn('No checksum provided. Skipping verification.');
  }

  // Stop service/app if configured
  if (serviceStop) {
    logInfo(`Stopping service: ${serviceStop}`);
    const [cmd, ...args] = serviceStop.split(' ').filter(Boolean);
    try { await runCommand(cmd, args, { cwd }); } catch (e) { logWarn(`Stop failed: ${e.message}`); }
  }

  // Backup current app (excluding heavy folders for speed)
  logInfo(`Backing up to ${backupDir}`);
  const exclude = new Set(['.git', '.next', 'node_modules', oldDir, backupDir, tempDir].map(p => path.resolve(cwd, p)));
  async function backupWalk(src, dest) {
    await ensureDir(dest);
    const entries = await fsp.readdir(src, { withFileTypes: true });
    for (const entry of entries) {
      const srcPath = path.join(src, entry.name);
      const destPath = path.join(dest, entry.name);
      const resolved = path.resolve(srcPath);
      if ([...exclude].some(ex => resolved.startsWith(ex))) continue;
      if (entry.isDirectory()) await backupWalk(srcPath, destPath);
      else if (entry.isFile()) { await ensureDir(path.dirname(destPath)); await fsp.copyFile(srcPath, destPath); }
    }
  }
  await backupWalk(cwd, backupDir);

  // Extract zip into temp/extracted
  const extractedDir = path.join(tempDir, 'extracted');
  await ensureDir(extractedDir);

  // Native unzip: use PowerShell on Windows, unzip/tar on Unix
  if (process.platform === 'win32') {
    await runCommand('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', `Expand-Archive -Path "${zipPath}" -DestinationPath "${extractedDir}" -Force`]);
  } else {
    // Try unzip, fallback to tar
    try {
      await runCommand('unzip', ['-o', zipPath, '-d', extractedDir]);
    } catch {
      await runCommand('tar', ['-xzf', zipPath, '-C', extractedDir]);
    }
  }

  // Detect root of extracted contents (handle zips with a top-level folder)
  async function findExtractRoot(base) {
    const kids = await fsp.readdir(base, { withFileTypes: true });
    const dirs = kids.filter(k => k.isDirectory());
    if (kids.length === 1 && dirs.length === 1) return path.join(base, dirs[0].name);
    return base;
  }
  const extractedRoot = await findExtractRoot(extractedDir);

  // Preserve configured files/dirs: copy from current app into extractedRoot
  for (const rel of preserve) {
    const srcPath = path.join(cwd, rel);
    if (!(await fileExists(srcPath))) continue;
    const destPath = path.join(extractedRoot, rel);
    logInfo(`Preserving ${rel}`);
    const stat = await fsp.stat(srcPath);
    if (stat.isDirectory()) await copyDir(srcPath, destPath);
    else {
      await ensureDir(path.dirname(destPath));
      await fsp.copyFile(srcPath, destPath);
    }
  }

  // Move current app to __old (mirror), then mirror extractedRoot into cwd
  logInfo(`Staging current app to ${oldDir}`);
  await copyDir(cwd, oldDir);

  // Mirror extracted -> cwd (delete extraneous files first for a clean state)
  logInfo('Applying update...');
  // Remove everything except reserved folders that may be locked
  const keepNames = new Set(['.git', '__backup_*', '__old_*', '__update_tmp_*']);
  const entries = await fsp.readdir(cwd, { withFileTypes: true });
  for (const entry of entries) {
    if (keepNames.has(entry.name)) continue;
    const p = path.join(cwd, entry.name);
    await removeDirSafe(p);
  }
  await copyDir(extractedRoot, cwd);

  // Post-update commands
  for (const line of postUpdate) {
    const trimmed = String(line).trim();
    if (!trimmed) continue;
    logInfo(`Running: ${trimmed}`);
    if (process.platform === 'win32') {
      await runCommand('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', trimmed], { cwd });
    } else {
      await runCommand('/bin/sh', ['-lc', trimmed], { cwd });
    }
  }

  // Start service/app if configured
  if (serviceStart) {
    logInfo(`Starting service: ${serviceStart}`);
    const [cmd, ...args] = serviceStart.split(' ').filter(Boolean);
    try { await runCommand(cmd, args, { cwd }); } catch (e) { logWarn(`Start failed: ${e.message}`); }
  }

  logInfo(`Update complete. Upgraded to ${latestVersion}`);
}

main().catch((err) => {
  logError(err?.stack || err?.message || String(err));
  process.exit(1);
});


